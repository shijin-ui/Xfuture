import { base44 } from './base44Client';


export const Customer = base44.entities.Customer;

export const Case = base44.entities.Case;

export const Quote = base44.entities.Quote;

export const Invoice = base44.entities.Invoice;

export const Communication = base44.entities.Communication;

export const Expense = base44.entities.Expense;

export const Company = base44.entities.Company;

export const MediaEvaluation = base44.entities.MediaEvaluation;

export const CaseFile = base44.entities.CaseFile;

export const JobHistory = base44.entities.JobHistory;

export const Setting = base44.entities.Setting;

export const Inventory = base44.entities.Inventory;

export const Asset = base44.entities.Asset;

export const AccountingLocale = base44.entities.AccountingLocale;

export const CompanyProfile = base44.entities.CompanyProfile;

export const Transaction = base44.entities.Transaction;

export const Bank = base44.entities.Bank;

export const Supplier = base44.entities.Supplier;

export const BankTransfer = base44.entities.BankTransfer;

export const BankDeposit = base44.entities.BankDeposit;

export const StockItem = base44.entities.StockItem;

export const StockTxn = base44.entities.StockTxn;

export const Employee = base44.entities.Employee;

export const EmployeeBankAccount = base44.entities.EmployeeBankAccount;

export const PurchaseOrder = base44.entities.PurchaseOrder;

export const PurchaseOrderLine = base44.entities.PurchaseOrderLine;

export const DownloadAsset = base44.entities.DownloadAsset;

export const VaultItem = base44.entities.VaultItem;

export const LogEvent = base44.entities.LogEvent;

export const Task = base44.entities.Task;

export const Event = base44.entities.Event;

export const InternalNote = base44.entities.InternalNote;



// auth sdk:
export const User = base44.auth;