
import React, { useEffect, useMemo, useState, useRef } from 'react';
import { StockItem } from '@/api/entities';
import { StockTxn } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Table, TableHeader, TableHead, TableRow, TableBody, TableCell } from '@/components/ui/table';
import { Download, Upload, Plus, Search, History, Barcode, Printer } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';

// Helper function to convert data to CSV format
function toCSV(rows, headers) {
  const header = headers.join(',');
  const body = rows.map(r => headers.map(h => {
    let v = r[h]; if (v === null || v === undefined) v = '';
    if (typeof v === 'object') v = JSON.stringify(v);
    const s = String(v);
    // Escape double quotes by doubling them, and enclose in quotes if contains comma or double quote
    return s.includes(',') || s.includes('"') || s.includes('\n') ? `"${s.replace(/"/g, '""')}"` : s;
  }).join(',')).join('\n');
  return [header, body].join('\n');
}

// Helper function to parse CSV text into an array of objects
function parseCSV(text) {
  const [headerLine, ...lines] = text.split(/\r?\n/).filter(Boolean); // Filter out empty lines
  const headers = headerLine.split(",").map(h => h.trim());

  return lines.map(l => {
    const cols = [];
    let inQuote = false;
    let currentCell = '';
    for (let i = 0; i < l.length; i++) {
      const char = l[i];
      if (char === '"') {
        if (inQuote && i + 1 < l.length && l[i + 1] === '"') {
          // Escaped double quote (e.g., "")
          currentCell += '"';
          i++; // Skip the next quote
        } else {
          inQuote = !inQuote;
        }
      } else if (char === ',' && !inQuote) {
        cols.push(currentCell);
        currentCell = '';
      } else {
        currentCell += char;
      }
    }
    cols.push(currentCell); // Add the last cell

    const obj = {};
    headers.forEach((h, i) => {
      // Remove surrounding quotes from parsed value if present
      let value = cols[i] || '';
      obj[h] = value.trim();
    });
    return obj;
  });
}

export default function StockPage() {
  const [items, setItems] = useState([]);
  const [txns, setTxns] = useState([]);
  const [q, setQ] = useState('');
  const [showItemDialog, setShowItemDialog] = useState(false);
  const [editing, setEditing] = useState(null);
  const [scanValue, setScanValue] = useState('');
  const fileInputRef = useRef(null); // Ref for the hidden file input

  const refresh = async () => {
    const [it, t] = await Promise.all([StockItem.list(), StockTxn.list('-timestamp', 1000)]);
    setItems(it); setTxns(t);
  };

  useEffect(() => { refresh(); }, []);

  // Compute available quantity by item ID
  const computed = useMemo(() => {
    const byItem = {};
    txns.forEach(t => {
      const mult = t.type === 'out' ? -1 : 1;
      byItem[t.itemId] = (byItem[t.itemId] || 0) + mult * (t.qty || 0);
    });
    return byItem;
  }, [txns]);

  // Filter items based on search query
  const filtered = useMemo(() => {
    const needle = q.toLowerCase();
    return items.filter(i =>
      [i.sku, i.name, i.barcode, i.location, i.bin].filter(Boolean).some(s => s.toLowerCase().includes(needle))
    );
  }, [items, q]);

  // Identify items with low stock (current quantity <= minimum quantity)
  const lowStockIds = new Set(filtered.filter(i => (computed[i.id] || 0) <= (i.minQty || 0)).map(i => i.id));

  const openNew = () => { setEditing({ sku: '', name: '', unit: 'Each', minQty: 0, reorderQty: 0, status: 'Active' }); setShowItemDialog(true); };

  // Save (create or update) a StockItem
  const saveItem = async () => {
    if (!editing.sku || !editing.name || !editing.unit) {
      alert('SKU, Name, and Unit are required fields.');
      return;
    }
    try {
      if (editing.id) await StockItem.update(editing.id, editing);
      else await StockItem.create(editing);
      setShowItemDialog(false); setEditing(null); refresh();
    } catch (error) {
      console.error('Failed to save item:', error);
      alert('Failed to save item. Check console for details.');
    }
  };

  // Export current filtered stock items to CSV
  const exportCSV = () => {
    const rows = filtered.map(i => ({
      sku: i.sku, name: i.name, unit: i.unit, barcode: i.barcode, qty: computed[i.id] || 0, // 'qty' here is the current available quantity
      minQty: i.minQty || 0, reorderQty: i.reorderQty || 0, location: i.location || '', bin: i.bin || '', status: i.status
    }));
    const csv = toCSV(rows, ['sku', 'name', 'unit', 'barcode', 'qty', 'minQty', 'reorderQty', 'location', 'bin', 'status']);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' }); const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'stock.csv'; a.click(); URL.revokeObjectURL(url);
  };

  // Handle CSV file upload
  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    try {
      const text = await file.text();
      const parsedData = parseCSV(text);
      await importCSV(parsedData);
      event.target.value = ''; // Clear the input so same file can be selected again
    } catch (error) {
      console.error('Error processing CSV file:', error);
      alert('Failed to process CSV file. Make sure it is valid. See console for details.');
    }
  };

  // Logic to import parsed CSV data into StockItems
  const importCSV = async (parsedData) => {
    if (!parsedData || parsedData.length === 0) {
      alert('No data found in CSV to import.');
      return;
    }

    const existingItemsMap = new Map(items.map(item => [item.sku.toLowerCase(), item]));
    const updates = [];
    const creations = [];
    let skipped = 0;

    for (const row of parsedData) {
      const sku = row.sku?.trim();
      if (!sku) {
        console.warn('Skipping row due to missing SKU:', row);
        skipped++;
        continue;
      }

      const itemData = {
        sku: sku,
        name: row.name?.trim() || '',
        unit: row.unit?.trim() || 'Each',
        barcode: row.barcode?.trim() || '',
        minQty: Number(row.minQty) || 0,
        reorderQty: Number(row.reorderQty) || 0,
        location: row.location?.trim() || '',
        bin: row.bin?.trim() || '',
        status: row.status?.trim() || 'Active',
        notes: row.notes?.trim() || '', // Include notes if present in CSV
      };

      const existingItem = existingItemsMap.get(sku.toLowerCase());

      if (existingItem) {
        let changed = false;
        const updatedFields = {};
        for (const key in itemData) {
          // Compare primitive values; convert numbers for comparison
          const existingValue = typeof existingItem[key] === 'number' ? Number(existingItem[key]) : existingItem[key];
          const newValue = typeof itemData[key] === 'number' ? Number(itemData[key]) : itemData[key];

          if (existingValue !== newValue) {
            updatedFields[key] = itemData[key];
            changed = true;
          }
        }
        if (changed) {
          updates.push(StockItem.update(existingItem.id, updatedFields));
        }
      } else {
        creations.push(StockItem.create(itemData));
      }
    }

    try {
      await Promise.all([...updates, ...creations]);
      refresh();
      alert(`CSV Import complete: ${creations.length} new items, ${updates.length} items updated, ${skipped} rows skipped due to missing SKU.`);
    } catch (error) {
      console.error('Failed to import CSV data:', error);
      alert('An error occurred during CSV import. Some items might not have been imported/updated. See console for details.');
    }
  };

  // Print barcode labels for filtered items
  const printLabels = () => {
    const html = filtered.map(i => `<div style="padding:8px;border:1px dashed #999;margin:6px;width:240px">
      <div style="font-weight:700">${i.name}</div>
      <div>SKU: ${i.sku}</div>
      <div>Barcode: ${i.barcode || '-'}</div>
      <div>Loc: ${i.location || ''} ${i.bin || ''}</div>
    </div>`).join('');
    const w = window.open('', '_blank'); if (!w) return;
    w.document.write(`<html><head><title>Print Labels</title></head><body><div style="display:flex;flex-wrap:wrap;gap:8px">${html}</div></body></html>`);
    w.document.close(); // Important for some browsers
    w.focus(); // Focus the new window
    w.print();
    // No URL.revokeObjectURL needed here as it's not a Blob URL
  };

  // Get transaction history for a specific item
  const currentHistory = (itemId) => txns.filter(t => t.itemId === itemId).sort((a, b) => new Date(b.timestamp || b.created_date) - new Date(a.timestamp || a.created_date));

  // Handle barcode/SKU scan input
  const onScanEnter = async (e) => {
    if (e.key === 'Enter' && scanValue) {
      const found = items.find(i => i.barcode === scanValue || i.sku === scanValue);
      if (found) {
        setQ(found.name || found.sku); // Set search query to found item's name/SKU
        setScanValue(''); // Clear scan input
      } else {
        alert(`No item found for "${scanValue}"`);
      }
    }
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Stock Inventory</h1>
        <div className="flex gap-2">
          <Button onClick={openNew}><Plus className="w-4 h-4 mr-2" />New Item</Button>
          <Button variant="outline" onClick={() => fileInputRef.current?.click()}><Upload className="w-4 h-4 mr-2" />Import CSV</Button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept=".csv"
            className="hidden"
          />
          <Button variant="outline" onClick={exportCSV}><Download className="w-4 h-4 mr-2" />Export CSV</Button>
          <Button variant="outline" onClick={printLabels}><Printer className="w-4 h-4 mr-2" />Print Labels</Button>
        </div>
      </div>

      <Card className="mb-4">
        <CardContent className="p-4 flex flex-wrap gap-3 items-center">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <Input className="pl-9 w-64" placeholder="Search name/SKU/barcode" value={q} onChange={e => setQ(e.target.value)} />
          </div>
          <div className="flex items-center gap-2">
            <Barcode className="w-4 h-4 text-gray-500" />
            <Input placeholder="Scan barcode or enter SKU" value={scanValue} onChange={e => setScanValue(e.target.value)} onKeyDown={onScanEnter} className="w-64" />
          </div>
          <Badge variant="secondary">Items: {filtered.length}</Badge>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Inventory List</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>SKU</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Available</TableHead> {/* Changed Qty to Available */}
                <TableHead>On Hold</TableHead> {/* Added On Hold column */}
                <TableHead>Reorder</TableHead>
                <TableHead>Location</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>History</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map(i => (
                <TableRow key={i.id} className={lowStockIds.has(i.id) ? 'bg-red-50' : ''}>
                  <TableCell className="font-mono">{i.sku}</TableCell>
                  <TableCell>{i.name}</TableCell>
                  <TableCell>{computed[i.id] || 0}</TableCell> {/* Available Qty */}
                  <TableCell>0</TableCell> {/* Placeholder for On Hold Qty - logic to derive this would go here */}
                  <TableCell>{i.reorderQty || 0} <span className="text-xs text-gray-500">min {i.minQty || 0}</span></TableCell>
                  <TableCell>{[i.location, i.bin].filter(Boolean).join(' / ')}</TableCell>
                  <TableCell>{i.status}</TableCell>
                  <TableCell><Button variant="outline" size="sm" onClick={() => setEditing({ ...i, _history: true })}><History className="w-4 h-4 mr-1" />View</Button></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Dialog for adding/editing an item */}
      <Dialog open={showItemDialog && !!editing && !editing._history} onOpenChange={(open) => { if (!open) { setShowItemDialog(false); setEditing(null); } }}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing?.id ? 'Edit Item' : 'New Item'}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            <div><Label htmlFor="sku">SKU</Label><Input id="sku" value={editing?.sku || ''} onChange={e => setEditing({ ...editing, sku: e.target.value })} /></div>
            <div><Label htmlFor="name">Name</Label><Input id="name" value={editing?.name || ''} onChange={e => setEditing({ ...editing, name: e.target.value })} /></div>
            <div><Label htmlFor="unit">Unit</Label><Input id="unit" value={editing?.unit || ''} onChange={e => setEditing({ ...editing, unit: e.target.value })} /></div>
            <div><Label htmlFor="barcode">Barcode</Label><Input id="barcode" value={editing?.barcode || ''} onChange={e => setEditing({ ...editing, barcode: e.target.value })} /></div>
            <div><Label htmlFor="minQty">Min Qty</Label><Input id="minQty" type="number" value={editing?.minQty || 0} onChange={e => setEditing({ ...editing, minQty: Number(e.target.value) })} /></div>
            <div><Label htmlFor="reorderQty">Reorder Qty</Label><Input id="reorderQty" type="number" value={editing?.reorderQty || 0} onChange={e => setEditing({ ...editing, reorderQty: Number(e.target.value) })} /></div>
            <div><Label htmlFor="location">Location</Label><Input id="location" value={editing?.location || ''} onChange={e => setEditing({ ...editing, location: e.target.value })} /></div>
            <div><Label htmlFor="bin">Bin</Label><Input id="bin" value={editing?.bin || ''} onChange={e => setEditing({ ...editing, bin: e.target.value })} /></div>
            <div className="col-span-2"><Label htmlFor="notes">Notes</Label><Input id="notes" value={editing?.notes || ''} onChange={e => setEditing({ ...editing, notes: e.target.value })} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setShowItemDialog(false); setEditing(null); }}>Cancel</Button>
            <Button onClick={saveItem}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog for viewing item history */}
      <Dialog open={!!editing && editing._history} onOpenChange={(open) => { if (!open) setEditing(null); }}>
        <DialogContent>
          <DialogHeader><DialogTitle>History — {editing?.name}</DialogTitle></DialogHeader>
          <div className="space-y-2 max-h-[60vh] overflow-y-auto">
            {currentHistory(editing?.id).map(h => (
              <div key={h.id} className="flex items-center justify-between border rounded p-2">
                <div className="flex items-center gap-2">
                  <Badge variant="secondary">{h.type === 'in' ? 'Inbound' : 'Outbound'}</Badge>
                  <span className="font-mono">Qty {h.qty}</span>
                </div>
                <div className="text-xs text-gray-500">{h.timestamp ? new Date(h.timestamp).toLocaleString() : new Date(h.created_date).toLocaleString()}</div>
              </div>
            ))}
            {currentHistory(editing?.id).length === 0 && <p className="text-gray-500 text-center">No transaction history for this item.</p>}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
