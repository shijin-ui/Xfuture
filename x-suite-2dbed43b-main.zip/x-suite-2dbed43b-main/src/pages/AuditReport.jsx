
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { LayoutGrid, Briefcase, Users, FileText, Settings, Key, Link as LinkIcon, AlertTriangle, GitMerge, Workflow, Palette, UserCheck } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

const Section = ({ icon: Icon, title, children }) => (
    <Card className="mb-8 shadow-lg">
        <CardHeader>
            <CardTitle className="flex items-center text-xl font-bold text-gray-800">
                <Icon className="w-6 h-6 mr-3 text-primary" />
                {title}
            </CardTitle>
        </CardHeader>
        <CardContent className="prose prose-sm max-w-none text-gray-700">
            {children}
        </CardContent>
    </Card>
);

const reportContent = `
### Overall App Structure
The application is a single-page application (SPA) built with React. The structure is modular, separating pages, reusable components, and data definitions (entities).

-   **Layout & Navigation**: A central \`Layout.js\` component provides a consistent shell for all pages. It includes a collapsible sidebar for primary navigation and a top header for global search, quick actions, and user settings.
-   **Sidebar Grouping**: Navigation links in the sidebar are dynamically generated based on the current user's role (\`access_role\`). The \`groupedNavLinks\` object in \`Layout.js\` maps roles (Admin, Technician, Sales, Accounts) to a specific set of visible pages, organized into logical groups like "Core Operations," "Business," and "Finance."
-   **Routing**: The app uses \`react-router-dom\` for client-side routing. All main features are accessible as distinct pages (e.g., \`/dashboard\`, \`/cases\`, \`/customers\`).

---

### Entities & Data Models
The data architecture is defined by a set of JSON schema files in the \`entities/\` directory.

-   **Core Entities**:
    -   **Case**: The central entity, tracking a customer job. Contains references to \`Customer\`, and embeds device information in a \`devices\` JSON array.
    -   **Customer**: Represents an individual client. Can be linked to a \`Company\`.
    -   **Company**: Represents a corporate client.
    -   **User**: The system user, with a custom \`access_role\` for permissions.
    -   **Quote & Invoice**: Financial documents linked to a \`Case\`. They contain line items, pricing, and status.
    -   **JobHistory**: An audit trail entity that logs all significant actions performed on a case.
    -   **Setting**: A key-value store for populating dropdowns and system options (e.g., service types, case priorities).

-   **Relationships**:
    -   \`Case\` -> \`Customer\` (one-to-many)
    -   \`Customer\` -> \`Company\` (many-to-one, via \`company_name\` field)
    -   \`Quote\` / \`Invoice\` -> \`Case\` (many-to-one)
    -   \`JobHistory\` / \`MediaEvaluation\` / \`CaseFile\` -> \`Case\` (many-to-one)

-   **Numbering & Prefixes**:
    -   Several entities rely on automated numbering sequences managed in \`Settings\` for fields like \`case_number\`, \`quote_number\`, \`invoice_number\`, and \`customer_code\`. These are typically prefixed (e.g., "DR-25452").

---

### Workflows & Automations
The system contains several automated processes to streamline operations.

-   **Case Number Generation**: Upon creating a new case via \`NewCase.js\`, the system fetches the next available number from the "Number Sequences" setting and assigns it to the new case.
-   **Job History Logging**: Key actions automatically create a \`JobHistory\` record. This includes:
    -   Case creation (\`NewCase.js\`)
    -   Device status changes and checkouts (\`CaseDetails.js\`)
    -   Quote and invoice generation.
-   **Welcome Notifications**: The \`NewCase.js\` page includes toggles for "Welcome Email" and "Welcome SMS," indicating a workflow to notify customers upon case creation.
-   **Status-Based Filtering**: The \`Cases.js\` page automatically filters the displayed cases based on the user's role (e.g., "Accounts" role sees only financially relevant statuses like 'Completed' or 'Payment Pending').

---

### User Roles & Permissions
Role-Based Access Control (RBAC) is implemented primarily on the frontend.

-   **Defined Roles**: The \`User\` entity defines four main \`access_role\` types: \`Admin\`, \`Technician\`, \`Sales\`, and \`Accounts\`.
-   **Navigation Control**: The \`Layout.js\` sidebar is the primary gatekeeper, showing users only the pages they are permitted to see. For example, a \`Technician\` does not see links for Invoices or financial reports.
-   **Feature Access**: Some features, like the "Migration & Export" and "Audit Report" sections in Settings, are hardcoded to be visible only to users with the \`admin\` role.

---

### Logic & Business Flow
The core business logic revolves around the lifecycle of a **Case**.

1.  **Initiation**: A case is created via the \`NewCase\` page, linking it to a new or existing \`Customer\`.
2.  **Device Management**: Devices are added to the case, either upon creation or later in the \`CaseDetails\` page. Each device has its own status (\`In Lab\`, \`Collected\`).
3.  **Evaluation**: A technician creates a \`MediaEvaluation\` report for a specific device, detailing findings and recovery feasibility.
4.  **Quotation**: Based on the evaluation, a \`Quote\` is generated from the \`CaseDetails\` page.
5.  **Financials**: Once a quote is accepted, an \`Invoice\` can be created. Payments against invoices are logged as \`Transaction\` records.
6.  **Closure**: Once work is complete and payment is received, devices are marked as "Collected" via the Checkout dialog, and the case status is moved to "Completed" or "Closed."

---

### Integrations
The application is currently self-contained, but the code indicates placeholders for external integrations.

-   **File Uploads**: The \`UploadFile\` integration is used for attaching files (e.g., in \`CaseFiles\`, \`DownloadAsset\`).
-   **Email/SMS**: The boolean flags (\`welcome_email\`, \`welcome_sms\`) in the \`Case\` entity imply that an email/SMS sending service is intended to be integrated for customer notifications.
-   **AI Services**: No direct AI integrations are currently active.

---

### Settings & Configurations
The \`Settings\` page is a central hub for system-wide configuration, powered by the \`Setting\` entity.

-   **Dynamic Dropdowns**: Most dropdown menus (e.g., Device Types, Service Problems, Case Priorities) are populated from values in the \`Setting\` entity. This allows for easy customization without changing code.
-   **Numbering Sequences**: The "Number Sequences" section allows an admin to view and carefully edit the starting numbers for critical records like cases, quotes, and invoices.
-   **Company & Localization**: The "Company Profile" and "Accounting Locales" sections provide dedicated areas for managing branding, contact information, and financial settings (currency, tax rates).

---

### UI/UX Structure
The user interface is designed for role-based efficiency.

-   **Dashboard**: Serves as the main landing page, showing key statistics (total cases, active cases) and lists of recent items.
-   **Case-Centric Design**: The \`CaseDetails\` page is the core workspace. It uses a tabbed layout (\`Overview\`, \`Client\`, \`Devices\`, \`Evaluation\`, \`Quotes/Invoices\`, etc.) to organize the vast amount of information related to a single job.
-   **Finance Pages**: Pages like \`Invoices\`, \`Quotes\`, and \`Expenses\` provide dedicated list views for financial management, with filtering and search capabilities.
-   **Dialogs for Actions**: Most creation and editing actions (e.g., adding a device, editing a customer, checking out an item) are handled in modal dialogs to keep the user within the main page context.

---

### Issues / Gaps
-   **Redundant Navigation**: Both the \`Migration & Export\` and \`Audit Report\` features were initially designed to be accessed via the \`Migration & Export\` card. This has been corrected to give the Audit Report its own top-level card for better visibility.
-   **Frontend-Only Permissions**: User permissions are currently enforced on the frontend by hiding UI elements. A production-grade system would require these permissions to be validated on the backend API as well.
-   **No Centralized Search**: While some pages have local search, the global search bar in the header is not yet fully implemented to search across all modules.

---

### Summary Map
This illustrates the primary workflow of the application.

\`New Case\` ➜ \`Link/Create Customer\` ➜ \`Add Devices\` ➜ \`Perform Media Evaluation\` ➜ \`Generate Quote\` ➜ \`Quote Accepted\` ➜ \`Generate Invoice\` ➜ \`Receive Payment (Transaction)\` ➜ \`Complete Work\` ➜ \`Checkout Devices\` ➜ \`Case Closed\` ➜ \`View in Reports\`
`;

export default function AuditReportPage() {
    const components = {
        h3: ({node, ...props}) => <h3 className="text-lg font-semibold mt-6 mb-2" {...props} />,
        ul: ({node, ...props}) => <ul className="list-disc pl-6 space-y-1" {...props} />,
        li: ({node, ...props}) => <li className="text-gray-600" {...props} />,
        code: ({node, ...props}) => <Badge variant="secondary" className="font-mono text-sm">{props.children}</Badge>,
        strong: ({node, ...props}) => <strong className="font-bold text-gray-900" {...props} />,
        span: ({node, ...props}) => {
            if (props.className?.includes('text-muted-foreground')) {
                return <span className="text-sm text-gray-500 italic block mb-4" {...props} />;
            }
            return <span {...props} />;
        }
    };

    return (
        <div className="p-4 md:p-8 bg-white min-h-screen">
            <div className="max-w-5xl mx-auto">
                <div className="text-center mb-12 no-print">
                    <h1 className="text-4xl font-extrabold text-gray-900">Application Audit Report</h1>
                    <p className="mt-2 text-lg text-gray-500">A complete analysis of your project's structure, logic, and workflows.</p>
                </div>

                <Section icon={LayoutGrid} title="Overall App Structure">
                    <ReactMarkdown components={components}>{reportContent.split('---')[0]}</ReactMarkdown>
                </Section>
                
                <Section icon={Briefcase} title="Entities & Data Models">
                    <ReactMarkdown components={components}>{reportContent.split('---')[1]}</ReactMarkdown>
                </Section>

                <Section icon={Workflow} title="Workflows & Automations">
                    <ReactMarkdown components={components}>{reportContent.split('---')[2]}</ReactMarkdown>
                </Section>
                
                <Section icon={UserCheck} title="User Roles & Permissions">
                    <ReactMarkdown components={components}>{reportContent.split('---')[3]}</ReactMarkdown>
                </Section>

                <Section icon={GitMerge} title="Logic & Business Flow">
                    <ReactMarkdown components={components}>{reportContent.split('---')[4]}</ReactMarkdown>
                </Section>

                <Section icon={LinkIcon} title="Integrations">
                    <ReactMarkdown components={components}>{reportContent.split('---')[5]}</ReactMarkdown>
                </Section>

                <Section icon={Settings} title="Settings & Configurations">
                    <ReactMarkdown components={components}>{reportContent.split('---')[6]}</ReactMarkdown>
                </Section>
                
                <Section icon={Palette} title="UI/UX Structure">
                    <ReactMarkdown components={components}>{reportContent.split('---')[7]}</ReactMarkdown>
                </Section>

                <Section icon={AlertTriangle} title="Issues / Gaps">
                    <ReactMarkdown components={components}>{reportContent.split('---')[8]}</ReactMarkdown>
                </Section>
                
                <Section icon={FileText} title="Summary Map">
                    <ReactMarkdown components={components}>{reportContent.split('---')[9]}</ReactMarkdown>
                </Section>
            </div>
        </div>
    );
}
