
import React, { useState, useCallback, useEffect } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { Invoice } from '@/api/entities';
import { Case } from '@/api/entities';
import { Customer } from '@/api/entities';
import { Company } from '@/api/entities';
import { Transaction } from '@/api/entities';
import { Setting } from '@/api/entities';
import { User } from '@/api/entities';
import { CompanyProfile } from '@/api/entities';
import { Bank } from '@/api/entities';
import { createPageUrl } from '@/utils';
import { getDefaultLocale, formatCurrency } from '@/components/utils/currencyFormatter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { format, parseISO, addDays } from 'date-fns'; // Added addDays
import { AlertCircle, Plus, Save, Loader2, Trash2, FileText, Download } from 'lucide-react';
import SearchableSelect from '@/components/SearchableSelect';

export default function InvoiceDetailsPage() {
    const location = useLocation();
    const navigate = useNavigate();
    const { id } = useParams(); // Invoice ID from route params
    const searchParams = new URLSearchParams(location.search);

    const invoiceIdFromUrl = searchParams.get('id'); // Invoice ID from URL search param (e.g. ?id=...)
    const caseIdFromUrl = searchParams.get('caseId');
    const proformaFromUrl = searchParams.get('proforma') === 'true';

    const currentInvoiceId = id || invoiceIdFromUrl; // Prioritize route param, then search param

    const [isProforma, setIsProforma] = useState(false);
    const [selectedCaseId, setSelectedCaseId] = useState('');

    const [formData, setFormData] = useState({ // Renamed from 'invoice' to 'formData'
        case_id: '',
        customer_id: '',
        invoice_number: '',
        status: 'Unpaid',
        line_items: [{ description: '', unit: 'Each', quantity: 1, unit_price: 0, amount: 0 }],
        discount_type: 'percentage',
        discount_value: 0,
        discount_amount: 0,
        subtotal: 0,
        include_vat: true,
        vat_rate: 0.05,
        vat_amount: 0,
        total_amount: 0,
        amount_paid: 0,
        balance_due: 0,
        issued_date: format(new Date(), 'yyyy-MM-dd'),
        due_date: format(addDays(new Date(), 30), 'yyyy-MM-dd'), // Using addDays
        is_proforma: false, // New field for proforma
    });

    const [caseDetails, setCaseDetails] = useState(null);
    const [customer, setCustomer] = useState(null);
    const [company, setCompany] = useState(null);
    const [transactions, setTransactions] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const [hasError, setHasError] = useState(false);
    const [errorMessage, setErrorMessage] = useState('');
    const [dataWarning, setDataWarning] = useState(null);
    const [includeVAT, setIncludeVAT] = useState(true);
    const [locale, setLocale] = useState(null);
    const [allCases, setAllCases] = useState([]);
    const [customers, setCustomers] = useState({});
    const [invoiceLineItemOptions, setInvoiceLineItemOptions] = useState([]);
    const [invoiceTermsOptions, setInvoiceTermsOptions] = useState([]);
    const [invoiceNumberSequence, setInvoiceNumberSequence] = useState(null);
    const [companyProfile, setCompanyProfile] = useState(null);

    // Payment dialog state
    const [showPaymentDialog, setShowPaymentDialog] = useState(false);
    const [newTransaction, setNewTransaction] = useState({
        amount: 0,
        payment_method: 'Bank Transfer',
        transaction_date: format(new Date(), 'yyyy-MM-dd'),
        reference_number: '',
        notes: '',
        bank_id: ''
    });
    const [allBanks, setAllBanks] = useState([]);

    const isEditing = !!currentInvoiceId;

    // Helper to get next invoice number sequence
    const getNextInvoiceNumber = useCallback(async () => {
        let currentSequence = invoiceNumberSequence;
        if (!currentSequence) {
            try {
                const settings = await Setting.filter({ key: 'invoice_number_sequence' });
                currentSequence = settings.length > 0 ? settings[0] : null;
                if (currentSequence) setInvoiceNumberSequence(currentSequence);
            } catch (error) {
                console.warn('Failed to load invoice number sequence setting:', error);
            }
        }

        if (currentSequence) {
            const currentNumber = currentSequence.numeric_value || 1;
            const paddedNumber = String(currentNumber).padStart(currentSequence.padding || 4, '0');
            const nextNumber = `${currentSequence.prefix || 'INV-'}${paddedNumber}`;
            return { nextNumber, sequenceId: currentSequence.id, currentNumericValue: currentNumber };
        } else {
            const date = new Date();
            const year = date.getFullYear();
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const day = String(date.getDate()).padStart(2, '0');
            const random = Math.floor(Math.random() * 1000);
            return { nextNumber: `INV-${year}${month}${day}-${random}`, sequenceId: null, currentNumericValue: null };
        }
    }, [invoiceNumberSequence]);

    // Fetch existing invoice data
    const fetchExistingInvoice = useCallback(async (idToFetch, currentLocale) => {
        try {
            const existingInvoice = await Invoice.get(idToFetch);
            setFormData(existingInvoice);
            setIncludeVAT(existingInvoice.include_vat !== false);
            setSelectedCaseId(existingInvoice.case_id || '');
            setIsProforma(existingInvoice.is_proforma || false); // Set proforma status from fetched invoice

            if (existingInvoice.case_id) {
                try {
                    const caseInfo = await Case.get(existingInvoice.case_id);
                    setCaseDetails(caseInfo);
                } catch (error) {
                    console.warn('Could not load case for existing invoice:', error);
                    setDataWarning(prev => ({ ...prev, message: (prev?.message || '') + ' Associated case data could not be loaded.' }));
                }
            }
            if (existingInvoice.customer_id) {
                try {
                    const customerInfo = await Customer.get(existingInvoice.customer_id);
                    setCustomer(customerInfo);
                    if (customerInfo?.company_name) {
                        const companies = await Company.filter({ company_name: customerInfo.company_name });
                        setCompany(companies.length > 0 ? companies[0] : null);
                    } else {
                        setCompany(null);
                    }
                } catch (error) {
                    console.warn('Could not load customer for existing invoice:', error);
                    setDataWarning(prev => ({ ...prev, message: (prev?.message || '') + ' Customer data could not be loaded.' }));
                }
            }
            try {
                const transactionData = await Transaction.filter({ invoice_id: idToFetch }, '-transaction_date');
                setTransactions(transactionData);
            } catch (error) {
                console.warn('Could not load transactions:', error);
            }
        } catch (error) {
            console.error('Failed to load existing invoice:', error);
            setHasError(true);
            setErrorMessage('Failed to load invoice. Please check if it exists and try again.');
            throw error;
        }
    }, []);

    // Initialize new invoice from a case
    const initializeFromCase = useCallback(async (caseId, isProformaInvoice, currentLocale) => {
        try {
            const caseResult = await Case.get(caseId);
            setCaseDetails(caseResult);
            setSelectedCaseId(caseId);

            if (caseResult.customer_id) {
                const customerResult = await Customer.get(caseResult.customer_id);
                setCustomer(customerResult);
                if (customerResult?.company_name) {
                    const companies = await Company.filter({ company_name: customerResult.company_name });
                    setCompany(companies.length > 0 ? companies[0] : null);
                }
            }

            const { nextNumber } = await getNextInvoiceNumber();
            const invoiceNumberPrefix = isProformaInvoice ? 'PI-' : (invoiceNumberSequence?.prefix || 'INV-');
            const invoiceNumber = `${invoiceNumberPrefix}${nextNumber.split('-').pop()}`;

            setFormData({
                case_id: caseId,
                customer_id: caseResult.customer_id,
                invoice_number: invoiceNumber,
                status: isProformaInvoice ? 'Draft' : 'Unpaid',
                line_items: [{ description: '', unit: 'Each', quantity: 1, unit_price: 0, amount: 0 }],
                discount_type: 'percentage',
                discount_value: 0,
                discount_amount: 0,
                subtotal: 0,
                include_vat: true,
                vat_rate: currentLocale?.tax_rate || 0.05,
                vat_amount: 0,
                total_amount: 0,
                amount_paid: 0,
                balance_due: 0,
                issued_date: format(new Date(), 'yyyy-MM-dd'),
                due_date: format(addDays(new Date(), 30), 'yyyy-MM-dd'),
                is_proforma: isProformaInvoice,
            });
            setIsProforma(isProformaInvoice);

        } catch (error) {
            console.error('Failed to initialize invoice from case:', error);
            setHasError(true);
            setErrorMessage('Failed to initialize invoice from selected case. Please try again.');
            throw error;
        }
    }, [getNextInvoiceNumber, invoiceNumberSequence]);

    // Initialize a brand new invoice
    const initializeNewInvoice = useCallback(async (isProformaInvoice, currentLocale) => {
        try {
            const { nextNumber } = await getNextInvoiceNumber();
            const invoiceNumberPrefix = isProformaInvoice ? 'PI-' : (invoiceNumberSequence?.prefix || 'INV-');
            const invoiceNumber = `${invoiceNumberPrefix}${nextNumber.split('-').pop()}`;

            setFormData({
                case_id: '',
                customer_id: '',
                invoice_number: invoiceNumber,
                status: isProformaInvoice ? 'Draft' : 'Unpaid',
                line_items: [{ description: '', unit: 'Each', quantity: 1, unit_price: 0, amount: 0 }],
                discount_type: 'percentage',
                discount_value: 0,
                discount_amount: 0,
                subtotal: 0,
                include_vat: true,
                vat_rate: currentLocale?.tax_rate || 0.05,
                vat_amount: 0,
                total_amount: 0,
                amount_paid: 0,
                balance_due: 0,
                issued_date: format(new Date(), 'yyyy-MM-dd'),
                due_date: format(addDays(new Date(), 30), 'yyyy-MM-dd'),
                is_proforma: isProformaInvoice,
            });
            setIsProforma(isProformaInvoice);
            setCaseDetails(null);
            setCustomer(null);
            setCompany(null);
            setTransactions([]);
            setSelectedCaseId('');
        } catch (error) {
            console.error('Failed to initialize new invoice:', error);
            setHasError(true);
            setErrorMessage('Failed to prepare a new invoice. Please try again.');
            throw error;
        }
    }, [getNextInvoiceNumber, invoiceNumberSequence]);

    // Load all auxiliary data (dropdowns, banks, etc.)
    const loadAuxiliaryData = useCallback(async () => {
        try {
            const [
                banksData,
                profileData,
                casesData,
                lineItemsData,
                sequenceData // Fetch sequence here as well if not already in state
            ] = await Promise.all([
                Bank.list().catch(e => { console.warn('Failed to load banks:', e); return []; }),
                CompanyProfile.list().catch(e => { console.warn('Failed to load company profile:', e); return []; }),
                Case.list().catch(e => { console.warn('Failed to load cases:', e); return []; }),
                Setting.filter({ category: 'Invoice Line Items' }).catch(e => { console.warn('Failed to load line items:', e); return []; }),
                Setting.filter({ key: 'invoice_number_sequence' }).catch(e => { console.warn('Failed to load invoice number sequence:', e); return []; })
            ]);

            setAllBanks(banksData);
            if (banksData.length > 0) {
                setNewTransaction(prev => ({ ...prev, bank_id: banksData[0].id }));
            }
            setCompanyProfile(profileData.length > 0 ? profileData[0] : null);
            setAllCases(casesData);
            setInvoiceLineItemOptions(lineItemsData);
            if (!invoiceNumberSequence) { // Only set if not already set by getNextInvoiceNumber earlier
                setInvoiceNumberSequence(sequenceData.length > 0 ? sequenceData[0] : null);
            }

            const customerIds = [...new Set(casesData.map(c => c.customer_id).filter(Boolean))];
            if (customerIds.length > 0) {
                const customersArray = await Customer.filter({ id: { $in: customerIds } }).catch(e => { console.warn('Failed to load customers for cases:', e); return []; });
                const customersMap = customersArray.reduce((acc, curr) => {
                    if (curr) acc[curr.id] = curr;
                    return acc;
                }, {});
                setCustomers(customersMap);
            }
        } catch (error) {
            console.error('Failed to load auxiliary data:', error);
        }
    }, [invoiceNumberSequence]); // Depend on invoiceNumberSequence to prevent re-fetching if already present

    // Primary data loading effect based on URL parameters
    useEffect(() => {
        const init = async () => {
            setIsLoading(true);
            setHasError(false);
            setErrorMessage('');
            setDataWarning(null);

            try {
                const currentLocale = await getDefaultLocale();
                setLocale(currentLocale);

                setIsProforma(proformaFromUrl); // Set initial proforma state from URL

                if (currentInvoiceId) {
                    await fetchExistingInvoice(currentInvoiceId, currentLocale);
                } else if (caseIdFromUrl) {
                    await initializeFromCase(caseIdFromUrl, proformaFromUrl, currentLocale);
                } else {
                    await initializeNewInvoice(proformaFromUrl, currentLocale);
                }
                await loadAuxiliaryData();

            } catch (error) {
                console.error('Initial data load failed:', error);
                setHasError(true);
                setErrorMessage('Failed to load necessary data. Please try again.');
            } finally {
                setIsLoading(false);
            }
        };
        init();
    }, [
        currentInvoiceId,
        caseIdFromUrl,
        proformaFromUrl,
        location.search, // Re-run if search params change
        fetchExistingInvoice,
        initializeFromCase,
        initializeNewInvoice,
        loadAuxiliaryData
    ]);

    // Calculate totals whenever formData or locale changes
    const calculateTotals = useCallback(() => {
        if (!formData.line_items || !locale) return;

        const lineItemsTotal = formData.line_items.reduce((sum, item) => {
            const itemAmount = (item.quantity || 0) * (item.unit_price || 0);
            return sum + itemAmount;
        }, 0);

        const discountAmount = formData.discount_type === 'percentage'
            ? (lineItemsTotal * (formData.discount_value || 0)) / 100
            : (formData.discount_value || 0);

        const subtotalAfterDiscount = lineItemsTotal - discountAmount;
        const vatAmount = includeVAT ? (subtotalAfterDiscount * (locale?.tax_rate || 0.05)) : 0;
        const total = subtotalAfterDiscount + vatAmount;
        const balanceDue = total - (formData.amount_paid || 0);

        setFormData(prev => ({
            ...prev,
            subtotal: lineItemsTotal,
            discount_amount: discountAmount,
            vat_amount: vatAmount,
            total_amount: total,
            balance_due: balanceDue,
            include_vat: includeVAT // Ensure include_vat in formData reflects the checkbox
        }));
    }, [formData.line_items, formData.discount_type, formData.discount_value, includeVAT, locale, formData.amount_paid]);

    // Recalculate totals when relevant fields change
    useEffect(() => {
        if (locale && formData.line_items) { // Ensure locale and formData are loaded
            calculateTotals();
        }
    }, [calculateTotals, locale, formData.line_items, formData.discount_type, formData.discount_value, formData.amount_paid, includeVAT]);

    const handleLineItemChange = (index, field, value) => {
        const updatedItems = [...formData.line_items];
        updatedItems[index] = { ...updatedItems[index], [field]: value };

        if (field === 'quantity' || field === 'unit_price') {
            const quantity = field === 'quantity' ? parseFloat(value) || 0 : updatedItems[index].quantity || 0;
            const unitPrice = field === 'unit_price' ? parseFloat(value) || 0 : updatedItems[index].unit_price || 0;
            updatedItems[index].amount = quantity * unitPrice;
        }

        setFormData(prev => ({ ...prev, line_items: updatedItems }));
    };

    const addLineItem = () => {
        setFormData(prev => ({
            ...prev,
            line_items: [...prev.line_items, { description: '', unit: 'Each', quantity: 1, unit_price: 0, amount: 0 }]
        }));
    };

    const removeLineItem = (index) => {
        if (formData.line_items.length > 1) {
            const updatedItems = formData.line_items.filter((_, i) => i !== index);
            setFormData(prev => ({ ...prev, line_items: updatedItems }));
        }
    };

    const handleCaseChange = async (caseId) => {
        setSelectedCaseId(caseId);
        if (caseId) {
            try {
                const selectedCase = allCases.find(c => c.id === caseId);
                if (selectedCase) {
                    setCaseDetails(selectedCase);

                    if (selectedCase.customer_id) {
                        const customerData = await Customer.get(selectedCase.customer_id);
                        setCustomer(customerData);

                        if (customerData?.company_name) {
                            const companies = await Company.filter({ company_name: customerData.company_name });
                            setCompany(companies.length > 0 ? companies[0] : null);
                        } else {
                            setCompany(null);
                        }
                        setFormData(prev => ({
                            ...prev,
                            case_id: caseId,
                            customer_id: selectedCase.customer_id
                        }));
                    }
                }
            } catch (error) {
                console.error('Failed to load case details:', error);
            }
        } else {
            setCaseDetails(null);
            setCustomer(null);
            setCompany(null);
            setFormData(prev => ({ ...prev, case_id: '', customer_id: '' }));
        }
    };

    const handleSave = async () => {
        if (!formData.invoice_number.trim()) {
            alert('Invoice number is required');
            return;
        }

        setIsSaving(true);
        try {
            const invoiceData = {
                ...formData,
                include_vat: includeVAT,
                vat_rate: includeVAT ? (locale?.tax_rate || 0.05) : 0
            };

            if (currentInvoiceId) {
                await Invoice.update(currentInvoiceId, invoiceData);
            } else {
                const createdInvoice = await Invoice.create(invoiceData);
                // If it's a new invoice and we used a sequence number, increment it
                if (invoiceNumberSequence && invoiceData.invoice_number.startsWith(invoiceNumberSequence.prefix || 'INV-')) {
                    await Setting.update(invoiceNumberSequence.id, {
                        numeric_value: (invoiceNumberSequence.numeric_value || 0) + 1
                    });
                }
            }

            navigate(createPageUrl('Invoices'));
        } catch (error) {
            console.error('Failed to save invoice:', error);
            alert('Failed to save invoice');
        } finally {
            setIsSaving(false);
        }
    };

    const handleAddPayment = async () => {
        if (isProforma) {
            alert('Cannot add payments to proforma invoices.');
            return;
        }
        if (!newTransaction.amount || parseFloat(newTransaction.amount) <= 0) {
            alert('Please enter a valid payment amount');
            return;
        }
        if (!currentInvoiceId) {
            alert('Invoice must be saved before adding payments.');
            return;
        }

        try {
            const transactionData = {
                invoice_id: currentInvoiceId,
                case_id: formData.case_id,
                customer_id: formData.customer_id,
                amount: parseFloat(newTransaction.amount),
                payment_method: newTransaction.payment_method,
                transaction_date: newTransaction.transaction_date,
                reference_number: newTransaction.reference_number,
                notes: newTransaction.notes,
                status: 'Completed',
                bank_id: newTransaction.bank_id
            };

            await Transaction.create(transactionData);

            const newAmountPaid = (formData.amount_paid || 0) + parseFloat(newTransaction.amount);
            const newBalanceDue = formData.total_amount - newAmountPaid;

            let newStatus = 'Unpaid';
            if (newBalanceDue <= 0) {
                newStatus = 'Paid';
            } else if (newAmountPaid > 0) {
                newStatus = 'Partially Paid';
            }

            await Invoice.update(currentInvoiceId, {
                amount_paid: newAmountPaid,
                balance_due: newBalanceDue,
                status: newStatus
            });

            const updatedInvoice = await Invoice.get(currentInvoiceId);
            const updatedTransactions = await Transaction.filter({ invoice_id: currentInvoiceId }, '-transaction_date');

            setFormData(updatedInvoice);
            setTransactions(updatedTransactions);
            setShowPaymentDialog(false);
            setNewTransaction({
                amount: 0,
                payment_method: 'Bank Transfer',
                transaction_date: format(new Date(), 'yyyy-MM-dd'),
                reference_number: '',
                notes: '',
                bank_id: allBanks.length > 0 ? allBanks[0].id : ''
            });

        } catch (error) {
            console.error('Failed to add payment:', error);
            alert('Failed to add payment');
        }
    };

    if (isLoading) {
        return <div className="p-8 text-center">Loading {isProforma ? 'proforma invoice' : 'invoice'} details...</div>;
    }

    if (hasError) {
        return (
            <div className="p-8 text-center text-red-600">
                <AlertCircle className="w-12 h-12 mx-auto mb-4" />
                <h1 className="text-2xl font-bold mb-2">Error Loading {isProforma ? 'Proforma Invoice' : 'Invoice'}</h1>
                <p className="mb-4">{errorMessage}</p>
                <Button onClick={() => navigate(createPageUrl('Invoices'))}>
                    Back to Invoices
                </Button>
            </div>
        );
    }

    return (
        <div className="p-4 md:p-8 bg-gradient-to-br from-slate-50 to-indigo-100 min-h-screen">
            <div className="max-w-6xl mx-auto">
                <div className="flex justify-between items-center mb-6">
                    <h1 className="text-3xl font-bold text-gray-800">
                        {currentInvoiceId ? (isProforma ? 'Edit Proforma' : 'Edit Invoice') : (isProforma ? 'Create Proforma' : 'Create Invoice')}
                    </h1>
                     <div className="flex items-center space-x-2">
                        {currentInvoiceId && (
                             <Button variant="outline" onClick={() => window.open(createPageUrl(`PrintInvoice?id=${currentInvoiceId}`), '_blank')}>
                                <Download className="w-4 h-4 mr-2"/> Download
                            </Button>
                        )}
                        {currentInvoiceId && (
                            <Button variant="outline" onClick={() => window.open(createPageUrl(`PrintInvoice?id=${currentInvoiceId}`), '_blank')}>
                                <FileText className="w-4 h-4 mr-2"/> Print
                            </Button>
                        )}
                        <Button onClick={handleSave} disabled={isLoading || isSaving}>
                            {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : <Save className="w-4 h-4 mr-2"/>}
                            {currentInvoiceId ? 'Save Changes' : (isProforma ? 'Create Proforma' : 'Create Invoice')}
                        </Button>
                    </div>
                </div>

                {dataWarning && (
                    <div className="mb-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                        <div className="flex items-start">
                            <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5 mr-3" />
                            <div>
                                <h3 className="font-semibold text-yellow-800 mb-1">Data Warning</h3>
                                <p className="text-yellow-700 text-sm mb-2">{dataWarning.message}</p>
                                <p className="text-yellow-600 text-sm">You can still edit the invoice, but some information may not be available.</p>
                            </div>
                        </div>
                    </div>
                )}

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Main Invoice Form */}
                    <div className="lg:col-span-2 space-y-6">
                        {/* Basic Information */}
                        <Card>
                            <CardHeader>
                                <CardTitle>{isProforma ? 'Proforma Invoice' : 'Invoice'} Information</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <Label htmlFor="invoice_number">
                                            {isProforma ? 'Proforma Number' : 'Invoice Number'} *
                                        </Label>
                                        <Input
                                            id="invoice_number"
                                            value={formData.invoice_number}
                                            onChange={(e) => setFormData(prev => ({ ...prev, invoice_number: e.target.value }))}
                                            placeholder={isProforma ? 'PI-0001' : 'INV-0001'}
                                        />
                                    </div>
                                    <div>
                                        <Label htmlFor="status">Status</Label>
                                        <Select
                                            value={formData.status}
                                            onValueChange={(value) => setFormData(prev => ({ ...prev, status: value }))}
                                        >
                                            <SelectTrigger>
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="Draft">Draft</SelectItem>
                                                {!isProforma && ( // Only show payment-related statuses for non-proforma
                                                    <>
                                                        <SelectItem value="Sent">Sent</SelectItem>
                                                        <SelectItem value="Unpaid">Unpaid</SelectItem>
                                                        <SelectItem value="Partially Paid">Partially Paid</SelectItem>
                                                        <SelectItem value="Paid">Paid</SelectItem>
                                                        <SelectItem value="Overdue">Overdue</SelectItem>
                                                    </>
                                                )}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div>
                                        <Label htmlFor="issued_date">Issue Date</Label>
                                        <Input
                                            id="issued_date"
                                            type="date"
                                            value={formData.issued_date}
                                            onChange={(e) => setFormData(prev => ({ ...prev, issued_date: e.target.value }))}
                                        />
                                    </div>
                                    <div>
                                        <Label htmlFor="due_date">Due Date</Label>
                                        <Input
                                            id="due_date"
                                            type="date"
                                            value={formData.due_date}
                                            onChange={(e) => setFormData(prev => ({ ...prev, due_date: e.target.value }))}
                                        />
                                    </div>
                                </div>

                                <div>
                                    <Label htmlFor="case_select">Associated Case</Label>
                                    <SearchableSelect
                                        value={selectedCaseId}
                                        onValueChange={handleCaseChange}
                                        placeholder="Select a case..."
                                        options={allCases.map(caseItem => ({
                                            value: caseItem.id,
                                            label: `${caseItem.case_number} - ${caseItem.service_type}`,
                                            subtitle: customers[caseItem.customer_id]?.full_name || 'Unknown Customer'
                                        }))}
                                        searchPlaceholder="Search cases..."
                                    />
                                </div>
                                <div className="flex items-center space-x-2">
                                    <Checkbox
                                        id="is_proforma"
                                        checked={isProforma}
                                        onCheckedChange={setIsProforma}
                                        disabled={isEditing} // Cannot change type after creation
                                    />
                                    <Label htmlFor="is_proforma">
                                        This is a Proforma Invoice
                                    </Label>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Line Items */}
                        <Card>
                            <CardHeader className="flex flex-row items-center justify-between">
                                <CardTitle>{isProforma ? 'Proforma' : 'Invoice'} Items</CardTitle>
                                <Button onClick={addLineItem} size="sm">
                                    <Plus className="w-4 h-4 mr-2" />
                                    Add Item
                                </Button>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    {formData.line_items.map((item, index) => (
                                        <div key={item.id || index} className="grid grid-cols-12 gap-3 items-end">
                                            <div className="col-span-5">
                                                <Label>Description</Label>
                                                <Input
                                                    value={item.description}
                                                    onChange={(e) => handleLineItemChange(index, 'description', e.target.value)}
                                                    placeholder="Service description..."
                                                />
                                            </div>
                                            <div className="col-span-2">
                                                <Label>Unit</Label>
                                                <Input
                                                    value={item.unit}
                                                    onChange={(e) => handleLineItemChange(index, 'unit', e.target.value)}
                                                    placeholder="Each"
                                                />
                                            </div>
                                            <div className="col-span-1">
                                                <Label>Qty</Label>
                                                <Input
                                                    type="number"
                                                    value={item.quantity}
                                                    onChange={(e) => handleLineItemChange(index, 'quantity', e.target.value)}
                                                    min="1"
                                                />
                                            </div>
                                            <div className="col-span-2">
                                                <Label>Unit Price ({locale?.currency_symbol || 'OMR'})</Label>
                                                <Input
                                                    type="number"
                                                    value={item.unit_price}
                                                    onChange={(e) => handleLineItemChange(index, 'unit_price', e.target.value)}
                                                    step="0.001"
                                                />
                                            </div>
                                            <div className="col-span-1">
                                                <Label>Amount</Label>
                                                <div className="h-10 flex items-center text-sm font-medium">
                                                    {formatCurrency(item.amount, locale)}
                                                </div>
                                            </div>
                                            <div className="col-span-1">
                                                <Button
                                                    variant="outline"
                                                    size="icon"
                                                    onClick={() => removeLineItem(index)}
                                                    disabled={formData.line_items.length === 1}
                                                    className="text-red-600 hover:text-red-700"
                                                >
                                                    <Trash2 className="w-4 h-4" />
                                                </Button>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Discount Section */}
                        <Card>
                            <CardHeader>
                                <CardTitle>Discount & Tax</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <div>
                                        <Label>Discount Type</Label>
                                        <Select
                                            value={formData.discount_type}
                                            onValueChange={(value) => setFormData(prev => ({ ...prev, discount_type: value, discount_value: 0 }))}
                                        >
                                            <SelectTrigger>
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="percentage">Percentage (%)</SelectItem>
                                                <SelectItem value="fixed">Fixed Amount ({locale?.currency_symbol || 'OMR'})</SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>
                                    <div>
                                        <Label>Discount Value</Label>
                                        <Input
                                            type="number"
                                            value={formData.discount_value}
                                            onChange={(e) => setFormData(prev => ({ ...prev, discount_value: parseFloat(e.target.value) || 0 }))}
                                            step={formData.discount_type === 'percentage' ? '1' : '0.001'}
                                            min="0"
                                            max={formData.discount_type === 'percentage' ? '100' : undefined}
                                        />
                                    </div>
                                    <div>
                                        <Label>Discount Amount</Label>
                                        <div className="h-10 flex items-center text-sm font-medium">
                                            {formatCurrency(formData.discount_amount, locale)}
                                        </div>
                                    </div>
                                </div>

                                <div className="flex items-center space-x-2">
                                    <Checkbox
                                        id="include_vat"
                                        checked={includeVAT}
                                        onCheckedChange={setIncludeVAT}
                                    />
                                    <Label htmlFor="include_vat">
                                        Include {locale?.tax_name || 'VAT'} ({((locale?.tax_rate || 0.05) * 100).toFixed(0)}%)
                                    </Label>
                                </div>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Sidebar */}
                    <div className="space-y-6">
                        {/* Invoice Summary */}
                        <Card>
                            <CardHeader>
                                <CardTitle>{isProforma ? 'Proforma' : 'Invoice'} Summary</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                <div className="flex justify-between">
                                    <span>Subtotal:</span>
                                    <span>{formatCurrency(formData.subtotal, locale)}</span>
                                </div>
                                {formData.discount_amount > 0 && (
                                    <div className="flex justify-between text-green-600">
                                        <span>Discount:</span>
                                        <span>-{formatCurrency(formData.discount_amount, locale)}</span>
                                    </div>
                                )}
                                {includeVAT && (
                                    <div className="flex justify-between">
                                        <span>{locale?.tax_name || 'VAT'}:</span>
                                        <span>{formatCurrency(formData.vat_amount, locale)}</span>
                                    </div>
                                )}
                                <div className="border-t pt-3">
                                    <div className="flex justify-between font-bold text-lg">
                                        <span>Total:</span>
                                        <span>{formatCurrency(formData.total_amount, locale)}</span>
                                    </div>
                                </div>
                                {isEditing && !isProforma && ( // Amount paid/balance due only for actual invoices
                                    <>
                                        <div className="flex justify-between text-blue-600">
                                            <span>Amount Paid:</span>
                                            <span>{formatCurrency(formData.amount_paid, locale)}</span>
                                        </div>
                                        <div className="flex justify-between font-semibold text-red-600">
                                            <span>Balance Due:</span>
                                            <span>{formatCurrency(formData.balance_due, locale)}</span>
                                        </div>
                                    </>
                                )}
                            </CardContent>
                        </Card>

                        {/* Customer Information */}
                        {customer && (
                            <Card>
                                <CardHeader>
                                    <CardTitle>Customer Information</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-2 text-sm">
                                    <div>
                                        <strong>Name:</strong> {customer.full_name}
                                    </div>
                                    <div>
                                        <strong>Email:</strong> {customer.email}
                                    </div>
                                    <div>
                                        <strong>Phone:</strong> {customer.phone_number}
                                    </div>
                                    {customer.company_name && (
                                        <div>
                                            <strong>Company:</strong> {customer.company_name}
                                        </div>
                                    )}
                                    {company?.vat_number && (
                                        <div>
                                            <strong>{locale?.tax_number_label || 'VAT Number'}:</strong> {company.vat_number}
                                        </div>
                                    )}
                                </CardContent>
                            </Card>
                        )}

                        {/* Case Information */}
                        {caseDetails && (
                            <Card>
                                <CardHeader>
                                    <CardTitle>Case Information</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-2 text-sm">
                                    <div>
                                        <strong>Case #:</strong> {caseDetails.case_number}
                                    </div>
                                    <div>
                                        <strong>Service:</strong> {caseDetails.service_type}
                                    </div>
                                    <div>
                                        <strong>Status:</strong> {caseDetails.status}
                                    </div>
                                </CardContent>
                            </Card>
                        )}

                        {/* Payment History */}
                        {isEditing && transactions.length > 0 && !isProforma && ( // Payment history only for actual invoices
                            <Card>
                                <CardHeader>
                                    <CardTitle>Payment History</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-3">
                                        {transactions.map(transaction => (
                                            <div key={transaction.id} className="p-3 border rounded-lg">
                                                <div className="flex justify-between items-center mb-1">
                                                    <span className="font-medium">
                                                        {formatCurrency(transaction.amount, locale)}
                                                    </span>
                                                    <Badge className="bg-green-100 text-green-800">
                                                        {transaction.payment_method}
                                                    </Badge>
                                                </div>
                                                <div className="text-xs text-gray-500">
                                                    {format(parseISO(transaction.transaction_date), 'dd MMM yyyy')}
                                                </div>
                                                {transaction.reference_number && (
                                                    <div className="text-xs text-gray-500">
                                                        Ref: {transaction.reference_number}
                                                    </div>
                                                )}
                                            </div>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>
                        )}
                    </div>
                </div>
            </div>

            {/* Add Payment Dialog */}
            <Dialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
                <DialogContent className="max-w-md">
                    <DialogHeader>
                        <DialogTitle>Add Payment</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                        <div>
                            <Label htmlFor="payment_amount">Amount ({locale?.currency_symbol || 'OMR'})</Label>
                            <Input
                                id="payment_amount"
                                type="number"
                                value={newTransaction.amount}
                                onChange={(e) => setNewTransaction(prev => ({ ...prev, amount: parseFloat(e.target.value) || 0 }))}
                                step="0.001"
                                max={formData.balance_due}
                                placeholder="0.000"
                            />
                            <div className="text-xs text-gray-500 mt-1">
                                Outstanding balance: {formatCurrency(formData.balance_due, locale)}
                            </div>
                        </div>

                        <div>
                            <Label htmlFor="payment_method">Payment Method</Label>
                            <Select
                                value={newTransaction.payment_method}
                                onValueChange={(value) => setNewTransaction(prev => ({ ...prev, payment_method: value }))}
                            >
                                <SelectTrigger>
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="Cash">Cash</SelectItem>
                                    <SelectItem value="Bank Transfer">Bank Transfer</SelectItem>
                                    <SelectItem value="Credit Card">Credit Card</SelectItem>
                                    <SelectItem value="Cheque">Cheque</SelectItem>
                                    <SelectItem value="Online Payment">Online Payment</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>

                        <div>
                            <Label htmlFor="bank_id">Deposit to Bank</Label>
                            <Select
                                value={newTransaction.bank_id}
                                onValueChange={(value) => setNewTransaction(prev => ({ ...prev, bank_id: value }))}
                                disabled={allBanks.length === 0}
                            >
                                <SelectTrigger>
                                    <SelectValue placeholder="Select a bank account" />
                                </SelectTrigger>
                                <SelectContent>
                                    {allBanks.map(bank => (
                                        <SelectItem key={bank.id} value={bank.id}>{bank.bank_name} - {bank.account_number}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                            {allBanks.length === 0 && (
                                <p className="text-xs text-red-500 mt-1">No bank accounts configured. Please add one in settings.</p>
                            )}
                        </div>

                        <div>
                            <Label htmlFor="transaction_date">Payment Date</Label>
                            <Input
                                id="transaction_date"
                                type="date"
                                value={newTransaction.transaction_date}
                                onChange={(e) => setNewTransaction(prev => ({ ...prev, transaction_date: e.target.value }))}
                            />
                        </div>

                        <div>
                            <Label htmlFor="reference_number">Reference Number</Label>
                            <Input
                                id="reference_number"
                                value={newTransaction.reference_number}
                                onChange={(e) => setNewTransaction(prev => ({ ...prev, reference_number: e.target.value }))}
                                placeholder="Bank reference, cheque number, etc."
                            />
                        </div>

                        <div>
                            <Label htmlFor="payment_notes">Notes</Label>
                            <Textarea
                                id="payment_notes"
                                value={newTransaction.notes}
                                onChange={(e) => setNewTransaction(prev => ({ ...prev, notes: e.target.value }))}
                                placeholder="Additional payment details..."
                                rows={3}
                            />
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setShowPaymentDialog(false)}>
                            Cancel
                        </Button>
                        <Button onClick={handleAddPayment}>
                            Add Payment
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}
