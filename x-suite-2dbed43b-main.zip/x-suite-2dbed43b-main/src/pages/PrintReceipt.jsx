
import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Case } from '@/api/entities';
import { Customer } from '@/api/entities';
import { CompanyProfile } from '@/api/entities';
import { format } from 'date-fns';
import { Button } from '@/components/ui/button';
import { Download, Printer, UserCircle, ClipboardCheck, Laptop, HardDrive, Server, Smartphone, Database, Usb, MemoryStick, Disc, Monitor, Facebook, Linkedin, Instagram, Youtube } from 'lucide-react';

// Helper function to get device-specific icons
const getDeviceIcon = (mediaType) => {
    if (!mediaType) return HardDrive; // Default icon
    const type = mediaType.toLowerCase();
    
    if (type.includes('laptop') || type.includes('macbook')) return Laptop;
    if (type.includes('hdd') || type.includes('hard drive')) return HardDrive;
    if (type.includes('ssd')) return Database;
    if (type.includes('server') || type.includes('nas')) return Server;
    if (type.includes('mobile') || type.includes('phone') || type.includes('ipad')) return Smartphone;
    if (type.includes('desktop') || type.includes('imac') || type.includes('computer')) return Monitor;
    if (type.includes('usb') || type.includes('flash')) return Usb;
    if (type.includes('memory card') || type.includes('sd')) return MemoryStick;
    if (type.includes('cd') || type.includes('dvd')) return Disc;

    return HardDrive; // Fallback icon
};

export default function PrintReceipt() {
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const caseId = searchParams.get('id');
    
    const [caseDetails, setCaseDetails] = useState(null);
    const [customer, setCustomer] = useState(null);
    const [companyProfile, setCompanyProfile] = useState(null);
    const [createdByUser, setCreatedByUser] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        if (!caseId) {
            setError('Case ID is missing.');
            setIsLoading(false);
            return;
        }

        const fetchData = async () => {
            try {
                const caseData = await Case.get(caseId);
                setCaseDetails(caseData);

                const [customerData, profileData] = await Promise.all([
                    Customer.get(caseData.customer_id).catch(() => null),
                    CompanyProfile.list().then(list => list[0]).catch(() => null)
                ]);

                setCustomer(customerData);
                setCompanyProfile(profileData);

                // Fetch the user who created the case
                if (caseData.created_by) {
                    try {
                        const { User } = await import('@/api/entities');
                        const users = await User.list();
                        const creatorUser = users.find(user => user.email === caseData.created_by);
                        setCreatedByUser(creatorUser);
                    } catch (error) {
                        console.error('Failed to fetch user data:', error);
                    }
                }
            } catch (err) {
                console.error("Failed to fetch data:", err);
                setError('Failed to load document data. Please check the Case ID and try again.');
            } finally {
                setIsLoading(false);
            }
        };

        fetchData();
    }, [caseId]);

    const handleDownloadPDF = () => {
        const element = document.getElementById('checkin-document');
        
        // Check if the html2pdf library and the target element are available
        if (typeof window !== 'undefined' && window.html2pdf && element) {
            const safeCustomerName = customer?.full_name?.replace(/[^a-zA-Z0-9 ]/g, '') || 'N-A';
            const fileName = `Checkin #${caseDetails?.case_number || 'NA'} [ ${safeCustomerName} ].pdf`;

            const options = {
                margin: 0.5,
                filename: fileName,
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2, useCORS: true },
                jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' }
            };

            // Use the direct invocation method for better stability
            window.html2pdf(element, options); // Changed from html2pdf() to window.html2pdf to align with typical global scope access
        } else {
            // Provide console feedback if something is missing and fall back to standard print
            if (!element) console.error('Printable element with ID "checkin-document" not found!');
            if (typeof window === 'undefined' || !window.html2pdf) console.warn('html2pdf.js is not loaded. Falling back to browser print.');
            
            window.print();
        }
    };

    if (isLoading) {
        return <div className="flex items-center justify-center h-screen font-sans">Loading Check-in Form...</div>;
    }

    if (error) {
        return <div className="flex items-center justify-center h-screen font-sans text-red-600">{error}</div>;
    }

    // Get devices for check-in
    const devicesForCheckin = caseDetails?.devices?.length > 0
        ? caseDetails.devices
        : [{
            media_type: caseDetails?.media_type,
            brand: caseDetails?.brand,
            media_model: caseDetails?.media_model,
            media_serial_number: caseDetails?.media_serial_number,
            capacity: caseDetails?.media_capacity,
            role: 'Patient'
        }];

    return (
        <>
            <style jsx global>{`
                @import url('https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&family=Inter:wght@400;500;600;700&display=swap');
                @page {
                    size: A4;
                    margin: 0.5in;
                }
                @media print {
                    body {
                        -webkit-print-color-adjust: exact;
                        print-color-adjust: exact;
                        color-adjust: exact;
                        background-color: #fff !important;
                    }
                    .no-print {
                        display: none !important;
                    }
                    .print-container {
                        max-width: none !important;
                        width: 100% !important;
                    }
                    * {
                        background-color: transparent !important;
                    }
                    .info-box {
                        background-color: #fff !important;
                        border: 1px solid #ccc !important;
                    }
                    .patient-badge {
                        background-color: #fee2e2 !important;
                        color: #991b1b !important;
                    }
                    .backup-badge {
                        background-color: #dcfce7 !important;
                        color: #166534 !important;
                    }
                }
                .font-tajawal { font-family: 'Tajawal', sans-serif; }
                .font-inter { font-family: 'Inter', sans-serif; }
                .info-box {
                    border: 1px solid #d1d5db;
                    border-radius: 8px;
                    padding: 16px;
                }
            `}</style>

            {/* No Print Buttons */}
            <div className="no-print fixed top-4 right-4 flex gap-2 z-50">
                <Button onClick={() => window.print()} className="bg-blue-600 hover:bg-blue-700">
                    <Printer className="w-4 h-4 mr-2" />
                    Print
                </Button>
                <Button onClick={handleDownloadPDF} variant="outline">
                    <Download className="w-4 h-4 mr-2" />
                    Download PDF
                </Button>
            </div>

            <div id="checkin-document" className="max-w-4xl mx-auto bg-white font-inter text-sm leading-tight p-1">
                {/* Professional Header */}
                <div className="flex justify-between items-start mb-4">
                    {/* Company Logo */}
                    <div className="flex items-center">
                        {companyProfile?.full_logo_url ? (
                            <img src={companyProfile.full_logo_url} alt="Company Logo" className="h-12 w-auto" />
                        ) : (
                            <div className="text-lg font-bold text-blue-600">
                                {companyProfile?.company_name || 'SPACE RECOVERY'}
                            </div>
                        )}
                    </div>
                    
                    {/* Company Name and Address */}
                    <div className="text-right text-xs text-gray-600 leading-tight max-w-xs">
                        {companyProfile?.company_name && <div className="font-semibold text-sm text-gray-800 mb-1">{companyProfile.company_name}</div>}
                        {companyProfile?.company_address && <div>{companyProfile.company_address}</div>}
                        {companyProfile?.phone_number && <div>Tel: {companyProfile.phone_number}</div>}
                        {companyProfile?.email && <div>Email: {companyProfile.email}</div>}
                        {companyProfile?.website && <div>{companyProfile.website}</div>}
                    </div>
                </div>

                {/* Line separator */}
                <div className="border-t border-gray-300 mb-4"></div>

                {/* Title Section */}
                <div className="text-center mb-4">
                    <h1 className="text-xl font-bold text-gray-900 mb-1">DEVICE CHECK-IN RECEIPT</h1>
                    <h2 className="text-lg font-bold text-gray-700 font-tajawal">إيصال استقبال الأجهزة</h2>
                </div>
                
                {/* Job Details Bar */}
                <div className="text-center mb-4 p-2 border rounded">
                    <strong className="text-blue-600">Job ID:</strong> <span className="font-mono text-blue-800 font-semibold">{caseDetails?.case_number}</span>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-4">
                    {/* Customer Information */}
                    <div className="info-box">
                        <div className="flex justify-between items-center mb-3 pb-2 border-b border-gray-300">
                            <h3 className="font-bold text-gray-900 text-sm flex items-center gap-2">
                                <UserCircle className="w-4 h-4 text-gray-500" />
                                Customer Information
                            </h3>
                            <h3 className="font-bold text-gray-900 text-sm font-tajawal">معلومات العميل</h3>
                        </div>
                        <div className="space-y-2 text-xs">
                            <div className="flex">
                                <span className="font-medium w-20">Name:</span>
                                <span className="flex-1 pl-2">{customer?.full_name || 'N/A'}</span>
                            </div>
                            {customer?.company_name && (
                                <div className="flex">
                                    <span className="font-medium w-20">Company:</span>
                                    <span className="flex-1 pl-2">{customer.company_name}</span>
                                </div>
                            )}
                            <div className="flex">
                                <span className="font-medium w-20">Phone:</span>
                                <span className="flex-1 pl-2">{customer?.phone_number || 'N/A'}</span>
                            </div>
                            <div className="flex">
                                <span className="font-medium w-20">Email:</span>
                                <span className="flex-1 pl-2">{customer?.email || 'N/A'}</span>
                            </div>
                        </div>
                    </div>

                    {/* Case Information */}
                    <div className="info-box">
                        <div className="flex justify-between items-center mb-3 pb-2 border-b border-gray-300">
                            <h3 className="font-bold text-gray-900 text-sm flex items-center gap-2">
                                <ClipboardCheck className="w-4 h-4 text-gray-500" />
                                Case Details
                            </h3>
                            <h3 className="font-bold text-gray-900 text-sm font-tajawal">تفاصيل الحالة</h3>
                        </div>
                        <div className="space-y-2 text-xs">
                            <div className="flex">
                                <span className="font-medium w-20">Service:</span>
                                <span className="flex-1 pl-2">{caseDetails?.service_type || 'N/A'}</span>
                            </div>
                            <div className="flex">
                                <span className="font-medium w-20">Priority:</span>
                                <span className="flex-1 pl-2">{caseDetails?.priority || 'N/A'}</span>
                            </div>
                            <div className="flex">
                                <span className="font-medium w-20">Problem:</span>
                                <span className="flex-1 pl-2">{caseDetails?.device_problem || 'N/A'}</span>
                            </div>
                            <div className="flex">
                                <span className="font-medium w-20">Date:</span>
                                <span className="flex-1 pl-2">{format(new Date(caseDetails?.created_date), 'dd MMM yyyy, HH:mm') || 'N/A'}</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Devices Section */}
                <div className="mb-6">
                    <div className="flex justify-between items-center mb-3">
                        <h3 className="font-bold text-gray-900 text-sm flex items-center">
                            <ClipboardCheck className="w-4 h-4 mr-2 text-blue-600" />
                            Device(s) Received
                        </h3>
                        <h3 className="font-bold text-gray-900 text-sm font-tajawal">الأجهزة المستلمة</h3>
                    </div>
                    
                    <table className="w-full border border-gray-300 text-xs">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="border border-gray-300 px-2 py-2 text-left font-semibold">Type</th>
                                <th className="border border-gray-300 px-2 py-2 text-left font-semibold">Brand</th>
                                <th className="border border-gray-300 px-2 py-2 text-left font-semibold">Capacity</th>
                                <th className="border border-gray-300 px-2 py-2 text-left font-semibold">Serial Number</th>
                                <th className="border border-gray-300 px-2 py-2 text-left font-semibold">Role</th>
                            </tr>
                        </thead>
                        <tbody>
                            {devicesForCheckin.map((device, index) => {
                                const DeviceIcon = getDeviceIcon(device.media_type);
                                return (
                                    <tr key={index} className="hover:bg-gray-50">
                                        <td className="border border-gray-300 px-2 py-2">
                                            <div className="flex items-center">
                                                <DeviceIcon className="w-4 h-4 mr-2 text-gray-600" />
                                                <span>{device.media_type || 'N/A'}</span>
                                            </div>
                                        </td>
                                        <td className="border border-gray-300 px-2 py-2">{device.brand || 'N/A'}</td>
                                        <td className="border border-gray-300 px-2 py-2">{device.capacity || device.media_capacity || 'N/A'}</td>
                                        <td className="border border-gray-300 px-2 py-2">{device.media_serial_number || 'N/A'}</td>
                                        <td className="border border-gray-300 px-2 py-2">
                                            <span className={`px-2 py-1 rounded text-xs font-medium ${
                                                device.role === 'Patient' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'
                                            }`}>
                                                {device.role || 'Patient'}
                                            </span>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>

                {/* Terms & Conditions */}
                <div className="mb-6">
                    <div className="flex justify-between items-center mb-3">
                        <h3 className="font-bold text-gray-900 text-sm">Terms & Conditions</h3>
                        <h3 className="font-bold text-gray-900 text-sm font-tajawal">الشروط والأحكام</h3>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 leading-relaxed">
                        <div className="text-left text-[11px]">
                            <p>By signing as an authorized signatory, I authorize <strong>{companyProfile?.company_name || 'Future Space LLC'} {companyProfile?.brand_name ? `(${companyProfile.brand_name})` : ''}</strong> to proceed and acknowledge that the T&C {companyProfile?.terms_of_service_url ? `(${companyProfile.terms_of_service_url})` : ''} apply to this engagement. A hard copy of the T&C is available at reception on request.</p>
                        </div>
                        <div className="font-tajawal text-right text-xs" dir="rtl">
                            <p>بتوقيعي كممثل مفوض، أفوض <strong>{companyProfile?.company_name || 'Future Space LLC'} {companyProfile?.brand_name ? `(${companyProfile.brand_name})` : ''}</strong> بالمتابعة وأقر بأن الشروط والأحكام {companyProfile?.terms_of_service_url ? `(${companyProfile.terms_of_service_url})` : ''} تنطبق على هذا التعامل. نسخة ورقية من الشروط والأحكام متاحة في الاستقبال عند الطلب.</p>
                        </div>
                    </div>
                </div>

                {/* Signature Section */}
                <div className="grid grid-cols-2 gap-8 pt-12">
                    <div className="text-center">
                         {/* Placeholder for alignment */}
                        <div className="h-5 mb-1"></div>
                        <div className="border-t-2 border-dotted border-gray-400 pt-2">
                            <div className="font-bold text-sm">Customer Signature</div>
                            <div className="text-xs text-gray-600 font-tajawal">توقيع العميل</div>
                        </div>
                    </div>
                    <div className="text-center">
                        <div className="text-xs text-gray-500 mb-1 h-5 flex items-end justify-center">
                            <span>Registered by: {createdByUser?.full_name || caseDetails?.created_by || 'System'}</span>
                        </div>
                        <div className="border-t-2 border-dotted border-gray-400 pt-2">
                            <div className="font-bold text-sm">Company Representative</div>
                            <div className="text-xs text-gray-600 font-tajawal">ممثل الشركة</div>
                        </div>
                    </div>
                </div>

                {/* Footer */}
                <div className="mt-12 pt-6 border-t border-gray-200 text-center">
                    <p className="text-sm font-semibold text-blue-600 mb-1">Trusted <strong>D</strong>ata <strong>R</strong>ecovery in <strong>O</strong>man for over 10 years.</p>
                    {companyProfile?.website && (
                        <a href={companyProfile.website} target="_blank" rel="noopener noreferrer" className="text-sm text-gray-700 hover:text-blue-700 mb-3 block">
                            {companyProfile.website}
                        </a>
                    )}
                    <div className="flex justify-center items-center space-x-4 text-gray-500">
                        {companyProfile?.facebook_url && (
                            <a href={companyProfile.facebook_url} target="_blank" rel="noopener noreferrer" className="hover:text-blue-800 flex items-center gap-1.5">
                                <Facebook className="w-4 h-4" />
                                <span className="text-xs">Facebook</span>
                            </a>
                        )}
                        {companyProfile?.twitter_url && (
                            <a href={companyProfile.twitter_url} target="_blank" rel="noopener noreferrer" className="hover:text-gray-800 flex items-center gap-1.5">
                                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                                </svg>
                                <span className="text-xs">X</span>
                            </a>
                        )}
                        {companyProfile?.linkedin_url && (
                            <a href={companyProfile.linkedin_url} target="_blank" rel="noopener noreferrer" className="hover:text-blue-700 flex items-center gap-1.5">
                                <Linkedin className="w-4 h-4" />
                                <span className="text-xs">LinkedIn</span>
                            </a>
                        )}
                        {companyProfile?.instagram_url && (
                            <a href={companyProfile.instagram_url} target="_blank" rel="noopener noreferrer" className="hover:text-pink-600 flex items-center gap-1.5">
                                <Instagram className="w-4 h-4" />
                                <span className="text-xs">Instagram</span>
                            </a>
                        )}
                        {companyProfile?.youtube_url && (
                            <a href={companyProfile.youtube_url} target="_blank" rel="noopener noreferrer" className="hover:text-red-600 flex items-center gap-1.5">
                                <Youtube className="w-4 h-4" />
                                <span className="text-xs">YouTube</span>
                            </a>
                        )}
                    </div>
                </div>
            </div>
        </>
    );
}
