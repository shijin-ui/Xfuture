import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Copy, Download, CheckCircle, Palette, Code, Database, Settings } from 'lucide-react';

export default function DesignMigrationPage() {
    const [copiedSection, setCopiedSection] = useState('');

    const copyToClipboard = (text, section) => {
        navigator.clipboard.writeText(text);
        setCopiedSection(section);
        setTimeout(() => setCopiedSection(''), 2000);
    };

    const packageJsonContent = `{
  "name": "space-recovery-frontend",
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.8.1",
    "@radix-ui/react-avatar": "^1.0.4",
    "@radix-ui/react-badge": "^1.0.4",
    "@radix-ui/react-button": "^1.0.4",
    "@radix-ui/react-card": "^1.0.4",
    "@radix-ui/react-dialog": "^1.0.5",
    "@radix-ui/react-dropdown-menu": "^2.0.6",
    "@radix-ui/react-input": "^1.0.4",
    "@radix-ui/react-label": "^2.0.2",
    "@radix-ui/react-popover": "^1.0.7",
    "@radix-ui/react-select": "^2.0.0",
    "@radix-ui/react-separator": "^1.0.3",
    "@radix-ui/react-table": "^1.0.4",
    "@radix-ui/react-tabs": "^1.0.4",
    "@radix-ui/react-textarea": "^1.0.4",
    "@radix-ui/react-tooltip": "^1.0.7",
    "class-variance-authority": "^0.7.0",
    "clsx": "^2.0.0",
    "date-fns": "^2.30.0",
    "framer-motion": "^10.16.16",
    "lucide-react": "^0.294.0",
    "react-markdown": "^9.0.1",
    "tailwind-merge": "^2.0.0",
    "tailwindcss-animate": "^1.0.7"
  },
  "devDependencies": {
    "@types/react": "^18.2.43",
    "@types/react-dom": "^18.2.17",
    "@vitejs/plugin-react": "^4.2.1",
    "autoprefixer": "^10.4.16",
    "postcss": "^8.4.32",
    "tailwindcss": "^3.3.6",
    "vite": "^5.0.8"
  }
}`;

    const tailwindConfig = `/** @type {import('tailwindcss').Config} */
export default {
  darkMode: ["class"],
  content: [
    './pages/**/*.{js,jsx}',
    './components/**/*.{js,jsx}',
    './app/**/*.{js,jsx}',
    './src/**/*.{js,jsx}',
  ],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
}`;

    const viteConfig = `import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  server: {
    port: 5173,
    host: true
  },
  build: {
    outDir: 'dist',
    sourcemap: true
  }
})`;

    const envLocal = `# Backend API URL
REACT_APP_API_URL=http://localhost:8000/api

# Development settings
NODE_ENV=development
VITE_APP_NAME=Space Recovery Suite`;

    return (
        <div className="p-6 bg-gradient-to-br from-slate-50 to-indigo-100 min-h-screen">
            <div className="max-w-6xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent mb-2">
                        Design Migration Guide
                    </h1>
                    <p className="text-gray-600">Preserve 100% of your UI/UX design in standalone deployment</p>
                </div>

                <div className="grid gap-6 mb-8">
                    <Card className="bg-green-50 border-green-200">
                        <CardContent className="p-6">
                            <div className="flex items-center gap-3 mb-4">
                                <CheckCircle className="w-6 h-6 text-green-600" />
                                <h3 className="text-lg font-semibold text-green-800">Good News!</h3>
                            </div>
                            <p className="text-green-700 mb-4">
                                <strong>100% of your design is already yours!</strong> All the beautiful UI, gradients, layouts, 
                                animations, and styling you see is in your frontend code - not dependent on base44's backend.
                            </p>
                            <div className="grid md:grid-cols-2 gap-4">
                                <div>
                                    <h4 className="font-medium text-green-800 mb-2">Design Assets You Own:</h4>
                                    <ul className="text-sm text-green-700 space-y-1">
                                        <li>• Layout.js - Sidebar, navigation, themes</li>
                                        <li>• All page designs and layouts</li>
                                        <li>• Custom components and styling</li>
                                        <li>• Tailwind CSS classes</li>
                                        <li>• shadcn/ui components</li>
                                        <li>• All animations and transitions</li>
                                    </ul>
                                </div>
                                <div>
                                    <h4 className="font-medium text-green-800 mb-2">What Needs Migration:</h4>
                                    <ul className="text-sm text-green-700 space-y-1">
                                        <li>• API calls (backend endpoints)</li>
                                        <li>• Authentication flow</li>
                                        <li>• File upload endpoints</li>
                                        <li>• Database connections</li>
                                        <li>• Environment variables</li>
                                    </ul>
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </div>

                <Tabs defaultValue="setup" className="w-full">
                    <TabsList className="grid w-full grid-cols-4">
                        <TabsTrigger value="setup" className="flex items-center gap-2">
                            <Settings className="w-4 h-4" />
                            Setup
                        </TabsTrigger>
                        <TabsTrigger value="design" className="flex items-center gap-2">
                            <Palette className="w-4 h-4" />
                            Design
                        </TabsTrigger>
                        <TabsTrigger value="code" className="flex items-center gap-2">
                            <Code className="w-4 h-4" />
                            Code
                        </TabsTrigger>
                        <TabsTrigger value="api" className="flex items-center gap-2">
                            <Database className="w-4 h-4" />
                            API
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="setup" className="mt-6">
                        <div className="grid gap-6">
                            <Card>
                                <CardHeader>
                                    <CardTitle>1. Project Setup Files</CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    <div>
                                        <div className="flex justify-between items-center mb-2">
                                            <h4 className="font-medium">package.json</h4>
                                            <Button 
                                                variant="outline" 
                                                size="sm"
                                                onClick={() => copyToClipboard(packageJsonContent, 'package')}
                                            >
                                                {copiedSection === 'package' ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                                                Copy
                                            </Button>
                                        </div>
                                        <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto text-sm">
                                            <code>{packageJsonContent}</code>
                                        </pre>
                                    </div>

                                    <div>
                                        <div className="flex justify-between items-center mb-2">
                                            <h4 className="font-medium">tailwind.config.js</h4>
                                            <Button 
                                                variant="outline" 
                                                size="sm"
                                                onClick={() => copyToClipboard(tailwindConfig, 'tailwind')}
                                            >
                                                {copiedSection === 'tailwind' ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                                                Copy
                                            </Button>
                                        </div>
                                        <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto text-sm">
                                            <code>{tailwindConfig}</code>
                                        </pre>
                                    </div>

                                    <div>
                                        <div className="flex justify-between items-center mb-2">
                                            <h4 className="font-medium">vite.config.js</h4>
                                            <Button 
                                                variant="outline" 
                                                size="sm"
                                                onClick={() => copyToClipboard(viteConfig, 'vite')}
                                            >
                                                {copiedSection === 'vite' ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                                                Copy
                                            </Button>
                                        </div>
                                        <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto text-sm">
                                            <code>{viteConfig}</code>
                                        </pre>
                                    </div>

                                    <div>
                                        <div className="flex justify-between items-center mb-2">
                                            <h4 className="font-medium">.env.local</h4>
                                            <Button 
                                                variant="outline" 
                                                size="sm"
                                                onClick={() => copyToClipboard(envLocal, 'env')}
                                            >
                                                {copiedSection === 'env' ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                                                Copy
                                            </Button>
                                        </div>
                                        <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto text-sm">
                                            <code>{envLocal}</code>
                                        </pre>
                                    </div>
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>

                    <TabsContent value="design" className="mt-6">
                        <div className="grid gap-6">
                            <Card>
                                <CardHeader>
                                    <CardTitle>Design Preservation Checklist</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-4">
                                        <div className="flex items-center gap-3">
                                            <CheckCircle className="w-5 h-5 text-green-500" />
                                            <span><strong>Layout.js</strong> - Contains your sidebar, theme system, navigation</span>
                                        </div>
                                        <div className="flex items-center gap-3">
                                            <CheckCircle className="w-5 h-5 text-green-500" />
                                            <span><strong>All pages/</strong> - Dashboard, Cases, CaseDetails, etc. with full styling</span>
                                        </div>
                                        <div className="flex items-center gap-3">
                                            <CheckCircle className="w-5 h-5 text-green-500" />
                                            <span><strong>components/</strong> - All your custom components (SearchableSelect, DeviceDialog, etc.)</span>
                                        </div>
                                        <div className="flex items-center gap-3">
                                            <CheckCircle className="w-5 h-5 text-green-500" />
                                            <span><strong>Tailwind CSS</strong> - All your gradients, shadows, animations</span>
                                        </div>
                                        <div className="flex items-center gap-3">
                                            <CheckCircle className="w-5 h-5 text-green-500" />
                                            <span><strong>shadcn/ui</strong> - Card, Button, Table, Dialog components</span>
                                        </div>
                                        <div className="flex items-center gap-3">
                                            <CheckCircle className="w-5 h-5 text-green-500" />
                                            <span><strong>Lucide React</strong> - All your icons</span>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>

                            <Card>
                                <CardHeader>
                                    <CardTitle>Key Design Features Preserved</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="grid md:grid-cols-3 gap-4">
                                        <div className="p-4 bg-blue-50 rounded-lg">
                                            <h4 className="font-medium text-blue-800 mb-2">Color Schemes</h4>
                                            <ul className="text-sm text-blue-700 space-y-1">
                                                <li>• Gradient backgrounds</li>
                                                <li>• Status color coding</li>
                                                <li>• Priority badges</li>
                                                <li>• Dark/light theme</li>
                                            </ul>
                                        </div>
                                        <div className="p-4 bg-green-50 rounded-lg">
                                            <h4 className="font-medium text-green-800 mb-2">Layouts</h4>
                                            <ul className="text-sm text-green-700 space-y-1">
                                                <li>• Responsive sidebar</li>
                                                <li>• Card-based design</li>
                                                <li>• Table layouts</li>
                                                <li>• Modal dialogs</li>
                                            </ul>
                                        </div>
                                        <div className="p-4 bg-purple-50 rounded-lg">
                                            <h4 className="font-medium text-purple-800 mb-2">Interactions</h4>
                                            <ul className="text-sm text-purple-700 space-y-1">
                                                <li>• Hover effects</li>
                                                <li>• Loading states</li>
                                                <li>• Form validation</li>
                                                <li>• Smooth transitions</li>
                                            </ul>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>

                    <TabsContent value="code" className="mt-6">
                        <div className="grid gap-6">
                            <Card>
                                <CardHeader>
                                    <CardTitle>Frontend Code Migration Steps</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-6">
                                        <div className="border-l-4 border-blue-500 pl-4">
                                            <h4 className="font-medium text-blue-800 mb-2">Step 1: Copy All Frontend Files</h4>
                                            <p className="text-sm text-gray-600 mb-2">Copy these folders/files from your base44 project to your new standalone project:</p>
                                            <pre className="bg-gray-100 p-3 rounded text-sm">
{`src/
├── pages/           # All your page components
├── components/      # All your custom components  
├── utils/           # Utility functions
├── Layout.js        # Your main layout
└── globals.css      # Global styles`}
                                            </pre>
                                        </div>

                                        <div className="border-l-4 border-green-500 pl-4">
                                            <h4 className="font-medium text-green-800 mb-2">Step 2: Update Import Paths</h4>
                                            <p className="text-sm text-gray-600 mb-2">Update these import statements:</p>
                                            <div className="bg-gray-100 p-3 rounded text-sm">
                                                <div className="text-red-600">// Change from:</div>
                                                <div>import {`{ Case }`} from '@/api/entities';</div>
                                                <div className="text-green-600 mt-2">// Change to:</div>
                                                <div>import {`{ Case }`} from './api/entities';</div>
                                            </div>
                                        </div>

                                        <div className="border-l-4 border-purple-500 pl-4">
                                            <h4 className="font-medium text-purple-800 mb-2">Step 3: Replace API Calls</h4>
                                            <p className="text-sm text-gray-600 mb-2">Use the downloaded entities.js file to replace base44 API calls:</p>
                                            <div className="bg-gray-100 p-3 rounded text-sm">
                                                <div className="text-red-600">// Old base44 call:</div>
                                                <div>const cases = await Case.list();</div>
                                                <div className="text-green-600 mt-2">// New standalone call:</div>
                                                <div>const cases = await Case.list(); // Same syntax!</div>
                                            </div>
                                        </div>

                                        <div className="border-l-4 border-orange-500 pl-4">
                                            <h4 className="font-medium text-orange-800 mb-2">Step 4: Environment Variables</h4>
                                            <p className="text-sm text-gray-600 mb-2">Set your API URL:</p>
                                            <div className="bg-gray-100 p-3 rounded text-sm">
                                                <div>REACT_APP_API_URL=http://localhost:8000/api</div>
                                            </div>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>

                    <TabsContent value="api" className="mt-6">
                        <div className="grid gap-6">
                            <Card>
                                <CardHeader>
                                    <CardTitle>API Integration</CardTitle>
                                </CardHeader>
                                <CardContent>
                                    <div className="space-y-4">
                                        <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                                            <h4 className="font-medium text-yellow-800 mb-2">Key Point</h4>
                                            <p className="text-yellow-700 text-sm">
                                                The downloaded <code>entities.js</code> file maintains the exact same API interface 
                                                as base44. Your frontend code won't need to change - just point it to your new backend!
                                            </p>
                                        </div>

                                        <div>
                                            <h4 className="font-medium mb-2">API Interface Compatibility</h4>
                                            <div className="bg-gray-100 p-4 rounded-lg text-sm">
                                                <div className="text-green-600 font-medium">✅ These calls work exactly the same:</div>
                                                <div className="mt-2 space-y-1">
                                                    <div>• await Case.list()</div>
                                                    <div>• await Case.get(id)</div>
                                                    <div>• await Case.create(data)</div>
                                                    <div>• await Case.update(id, data)</div>
                                                    <div>• await User.me()</div>
                                                    <div>• await Customer.filter(filters)</div>
                                                </div>
                                            </div>
                                        </div>

                                        <div>
                                            <h4 className="font-medium mb-2">Backend Requirements</h4>
                                            <p className="text-sm text-gray-600 mb-2">Your backend needs these endpoints:</p>
                                            <div className="bg-gray-900 text-gray-100 p-4 rounded-lg text-sm">
                                                <div>GET    /api/cases        # List cases</div>
                                                <div>GET    /api/cases/:id    # Get case</div>
                                                <div>POST   /api/cases        # Create case</div>
                                                <div>PUT    /api/cases/:id    # Update case</div>
                                                <div>DELETE /api/cases/:id    # Delete case</div>
                                                <div className="mt-2 text-gray-400"># Repeat for all entities...</div>
                                            </div>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>
                </Tabs>

                <Card className="mt-6 bg-blue-50 border-blue-200">
                    <CardContent className="p-6">
                        <h3 className="text-lg font-semibold text-blue-800 mb-3">🎯 Migration Summary</h3>
                        <div className="text-blue-700 space-y-2">
                            <p><strong>Design Preservation:</strong> 100% - All your UI is in your frontend code</p>
                            <p><strong>Functionality:</strong> 100% - Same API interface with new backend</p>
                            <p><strong>Migration Effort:</strong> Low - Mainly configuration and API endpoint changes</p>
                            <p><strong>Risk:</strong> Very Low - You're keeping all your proven frontend code</p>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}