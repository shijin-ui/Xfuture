import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Case } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Printer } from 'lucide-react';
import { format } from 'date-fns';

export default function PrintLabel() {
  const [caseData, setCaseData] = useState(null);
  const location = useLocation();

  useEffect(() => {
    const fetch_data = async () => {
      const caseId = new URLSearchParams(location.search).get('id');
      if (caseId) {
        try {
            const caseResult = await Case.get(caseId);
            setCaseData(caseResult);
        } catch (error) {
            console.error("Failed to fetch case data:", error);
        }
      }
    };
    fetch_data();
  }, [location]);

  // Automatically trigger print dialog when data is loaded
  useEffect(() => {
    if (caseData) {
      // Small delay to ensure rendering is complete before printing
      setTimeout(() => window.print(), 500);
    }
  }, [caseData]);

  if (!caseData) {
    return <div>Loading label data...</div>;
  }

  return (
    <>
      <style>{`
        @page {
          size: 25mm 15mm;
          margin: 1mm;
        }
        @media screen {
            body {
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                background-color: #f0f0f0;
            }
        }
        @media print {
          .no-print {
            display: none;
          }
          body {
            background-color: white;
          }
        }
        .label-container {
          width: 23mm;
          height: 13mm;
          border: 1px dashed #999;
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          text-align: center;
          font-family: 'Arial', sans-serif;
          background-color: white;
          padding: 1mm;
          box-sizing: border-box;
          overflow: hidden;
        }
        .case-number {
          font-weight: bold;
          font-size: 8pt;
          line-height: 1;
          margin: 0;
          word-break: break-all;
        }
        .date {
          font-size: 5pt;
          margin: 0;
          margin-top: 3px;
        }
      `}</style>
      <div className="flex flex-col items-center no-print">
        <div className="label-container">
          <p className="case-number">{caseData.case_number}</p>
          <p className="date">{format(new Date(caseData.created_date), 'dd/MM/yyyy')}</p>
        </div>
        <div className="mt-4">
          <Button onClick={() => window.print()}><Printer className="mr-2 h-4 w-4" /> Print Label</Button>
          <p className="text-xs text-gray-500 mt-2 text-center">Preview for 25x15mm label.</p>
        </div>
      </div>
      {/* This is the actual printable content, hidden on screen */}
      <div className="hidden print:flex print:flex-col print:justify-center print:items-center">
        <p className="case-number">{caseData.case_number}</p>
        <p className="date">{format(new Date(caseData.created_date), 'dd/MM/yyyy')}</p>
      </div>
    </>
  );
}