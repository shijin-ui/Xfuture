import React, { useState, useEffect } from 'react';
import { Case } from '@/api/entities';
import { Customer } from '@/api/entities';
import { User } from '@/api/entities';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { HardDrive, PlusCircle, Trash2, Search, Filter, AlertTriangle, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { format } from 'date-fns';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { getSettingsByCategory } from '@/components/utils/settingsLoader';

const statusColors = {
  Received: 'bg-gradient-to-r from-blue-100 to-blue-200 text-blue-800 border-blue-300 shadow-sm',
  'In Lab': 'bg-gradient-to-r from-indigo-100 to-indigo-200 text-indigo-800 border-indigo-300 shadow-sm',
  Diagnosis: 'bg-gradient-to-r from-purple-100 to-purple-200 text-purple-800 border-purple-300 shadow-sm',
  Quoted: 'bg-gradient-to-r from-yellow-100 to-yellow-200 text-yellow-800 border-yellow-300 shadow-sm',
  'Waiting for Approval': 'bg-gradient-to-r from-amber-100 to-amber-200 text-amber-800 border-amber-300 shadow-sm',
  Approved: 'bg-gradient-to-r from-emerald-100 to-emerald-200 text-emerald-800 border-emerald-300 shadow-sm',
  'Cleanroom Operations': 'bg-gradient-to-r from-cyan-100 to-cyan-200 text-cyan-800 border-cyan-300 shadow-sm',
  'In Progress': 'bg-gradient-to-r from-indigo-100 to-indigo-200 text-indigo-800 border-indigo-300 shadow-sm',
  Completed: 'bg-gradient-to-r from-green-100 to-green-200 text-green-800 border-green-300 shadow-sm',
  'Waiting for Backup Device': 'bg-gradient-to-r from-teal-100 to-teal-200 text-teal-800 border-teal-300 shadow-sm',
  Delivered: 'bg-gradient-to-r from-green-100 to-green-200 text-green-800 border-green-300 shadow-sm',
  Cancelled: 'bg-gradient-to-r from-gray-100 to-gray-200 text-gray-800 border-gray-300 shadow-sm',
  Unrecoverable: 'bg-gradient-to-r from-red-100 to-red-200 text-red-800 border-red-300 shadow-sm',
  Scheduled: 'bg-gradient-to-r from-purple-100 to-purple-200 text-purple-800 border-purple-300 shadow-sm',
  default: 'bg-gradient-to-r from-gray-100 to-gray-200 text-gray-800 border-gray-300 shadow-sm'
};

const priorityColors = {
    "Low": "text-gray-600 bg-gray-50 px-2 py-1 rounded-full text-xs font-medium",
    "Normal": "text-blue-600 bg-blue-50 px-2 py-1 rounded-full text-xs font-medium",
    "High Priority": "text-orange-600 bg-orange-50 px-2 py-1 rounded-full text-xs font-semibold",
    "Urgent": "text-red-600 bg-red-50 px-2 py-1 rounded-full text-xs font-bold animate-pulse"
};

export default function CasesPage() {
  const [cases, setCases] = useState([]);
  const [customers, setCustomers] = useState({});
  const [users, setUsers] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [caseToDelete, setCaseToDelete] = useState(null);
  const [deleteConfirmationInput, setDeleteConfirmationInput] = useState('');
  const [filters, setFilters] = useState({
    status: '',
    priority: '',
    serviceType: ''
  });
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [caseStatuses, setCaseStatuses] = useState([]);
  const [priorityOptions, setPriorityOptions] = useState([]);
  const [serviceTypeOptions, setServiceTypeOptions] = useState([]);
  const casesPerPage = 7;

  const fetchData = async () => {
    setCurrentPage(1);
    setHasMore(true);
    try {
      const user = await User.me();
      setCurrentUser(user);
      
      console.log('Current user:', user); // Debug log
      const userRole = user?.access_role || (user?.role === 'admin' ? 'Admin' : 'Technician');
      console.log('Determined user role:', userRole); // Debug log
      
      // Fetch ALL cases first - no filtering on the API call
      const allFetchedCases = await Case.list('-created_date');
      console.log('All fetched cases:', allFetchedCases.length); // Debug log

      let caseData = allFetchedCases;
      
      // Apply role-based filtering AFTER fetching
      if (userRole === 'Technician') {
        caseData = allFetchedCases.filter(caseItem => 
          caseItem.assigned_engineer === user.email || 
          caseItem.created_by === user.email
        );
        console.log('Technician filtered cases:', caseData.length); // Debug log
      } else if (userRole === 'Accounts') {
        caseData = allFetchedCases.filter(caseItem =>
          ['Completed', 'Delivered', 'Payment Pending', 'Closed'].includes(caseItem.status)
        );
        console.log('Accounts filtered cases:', caseData.length); // Debug log
      }
      // Admin and Sales see all cases - no additional filtering needed
      console.log('Final case data:', caseData.length); // Debug log
      
      if (caseData.length < casesPerPage * 2) {
        setHasMore(false);
      }
      
      const [customerData, userData] = await Promise.all([
        Customer.list(),
        User.list()
      ]);
      
      const customerMap = customerData.reduce((acc, customer) => {
        acc[customer.id] = customer;
        if (customer.customer_code) {
          acc[customer.customer_code] = customer;
        }
        return acc;
      }, {});

      const casesWithMissingCustomers = [];
      caseData.forEach(caseItem => {
        const customerIdentifier = caseItem.customer_id || caseItem.customer_code;
        if (customerIdentifier && !customerMap[customerIdentifier]) {
          casesWithMissingCustomers.push(caseItem);
          customerMap[customerIdentifier] = {
            id: customerIdentifier,
            full_name: 'Customer Data Missing',
            email: 'N/A',
            phone_number: 'N/A',
            company_name: null
          };
        }
      });

      if (casesWithMissingCustomers.length > 0) {
        console.warn(
          'Data Integrity Issue: The following cases have invalid or deleted customer IDs/Codes:', 
          casesWithMissingCustomers.map(c => `Case #${c.case_number} (CustomerID/Code: ${c.customer_id || c.customer_code})`).join(', ')
        );
      }

      const userMap = userData.reduce((acc, user) => {
        acc[user.email] = user;
        return acc;
      }, {});

      if (user && !userMap[user.email]) {
          userMap[user.email] = user;
      }

      setCases(caseData);
      setCustomers(customerMap);
      setUsers(userMap);
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } 
  };

  const loadMoreCases = async () => {
    setIsLoadingMore(true);
    try {
      const fetchedMoreCases = await Case.list('-created_date', casesPerPage * 2, Math.floor(cases.length / (casesPerPage * 2)) + 1);
      let roleFilteredMoreCases = fetchedMoreCases;

      if (currentUser) {
          const userRole = currentUser?.access_role || (currentUser?.role === 'admin' ? 'Admin' : '');
          if (userRole === 'Technician') {
              roleFilteredMoreCases = fetchedMoreCases.filter(caseItem =>
                  caseItem.assigned_engineer === currentUser.email ||
                  caseItem.created_by === currentUser.email
              );
          } else if (userRole === 'Accounts') {
              roleFilteredMoreCases = fetchedMoreCases.filter(caseItem =>
                  ['Completed', 'Delivered', 'Payment Pending', 'Closed'].includes(caseItem.status)
              );
          }
      }

      if (roleFilteredMoreCases.length < casesPerPage * 2) {
        setHasMore(false);
      }
      setCases(prevCases => [...prevCases, ...roleFilteredMoreCases]);
    } catch (error) {
      console.error('Failed to load more cases:', error);
    } finally {
      setIsLoadingMore(false);
    }
  };

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      await fetchData();
      
      // Load dynamic settings
      const [statuses, priorities, services] = await Promise.all([
        getSettingsByCategory('Case Statuses'),
        getSettingsByCategory('Case Priorities'),
        getSettingsByCategory('Service Types')
      ]);
      
      setCaseStatuses(statuses || []);
      setPriorityOptions(priorities || []);
      setServiceTypeOptions(services || []);
      setIsLoading(false);
    };
    loadData();
  }, []);
  
  const promptDelete = (caseItem) => {
    setCaseToDelete(caseItem);
    setDeleteConfirmationInput('');
    setIsDeleteDialogOpen(true);
  };

  const handleConfirmDelete = async () => {
    const userRole = currentUser?.access_role || (currentUser?.role === 'admin' ? 'Admin' : '');
    if (!currentUser || !['Admin', 'Sales'].includes(userRole)) {
      alert('You do not have permission to delete cases.');
      return;
    }

    if (!caseToDelete || deleteConfirmationInput !== caseToDelete.case_number) {
      alert('The entered Job ID does not match. Deletion cancelled.');
      return;
    }
    try {
      await Case.delete(caseToDelete.id);
      fetchData();
      setIsDeleteDialogOpen(false);
      setCaseToDelete(null);
    } catch (error) {
      console.error('Failed to delete case:', error);
      alert('Could not delete the case.');
    }
  };

  const handleStatusChange = async (caseId, newStatus) => {
    if (!currentUser) return;
    const userRole = currentUser?.access_role || (currentUser?.role === 'admin' ? 'Admin' : 'Technician');
    
    const allowedStatusChanges = {
      'Technician': ["In Lab", "Diagnosis", "In Progress", "Cleanroom Operations", "Completed"],
      'Sales': ["Received", "Quoted", "Waiting for Approval", "Approved", "Delivered", "Cancelled"],
      'Accounts': ["Payment Pending", "Completed", "Delivered", "Closed"],
      'Admin': 'all'
    };
    
    const userAllowedStatuses = allowedStatusChanges[userRole];
    if (userAllowedStatuses !== 'all' && !userAllowedStatuses.includes(newStatus)) {
      alert(`You don't have permission to change status to "${newStatus}"`);
      return;
    }

    try {
      await Case.update(caseId, { status: newStatus });
      fetchData();
    } catch (error) {
      console.error('Failed to update case status:', error);
      alert('Failed to update case status.');
    }
  };

  const handlePriorityChange = async (caseId, newPriority) => {
    try {
      await Case.update(caseId, { priority: newPriority });
      fetchData();
    } catch (error) {
      console.error('Failed to update case priority:', error);
      alert('Failed to update case priority.');
    }
  };

  const filteredCases = cases.filter(caseItem => {
    const customerIdentifier = caseItem.customer_id || caseItem.customer_code;
    const customer = customers[customerIdentifier];
    const searchLower = searchTerm.toLowerCase();

    const matchesSearch = (
      (caseItem.case_number || '').toLowerCase().includes(searchLower) ||
      (customer?.full_name || '').toLowerCase().includes(searchLower) ||
      (caseItem.status || '').toLowerCase().includes(searchLower) ||
      (caseItem.priority || '').toLowerCase().includes(searchLower)
    );

    const matchesStatus = !filters.status || caseItem.status === filters.status;
    const matchesPriority = !filters.priority || caseItem.priority === filters.priority;
    const matchesServiceType = !filters.serviceType || caseItem.service_type === filters.serviceType;

    return matchesSearch && matchesStatus && matchesPriority && matchesServiceType;
  });

  const totalPages = Math.ceil(filteredCases.length / casesPerPage);
  const startIndex = (currentPage - 1) * casesPerPage;
  const endIndex = startIndex + casesPerPage;
  const currentCases = filteredCases.slice(startIndex, endIndex);

  const clearFilters = () => {
    setFilters({
      status: '',
      priority: '',
      serviceType: ''
    });
    setCurrentPage(1);
  };

  const hasActiveFilters = filters.status || filters.priority || filters.serviceType;

  const getStatusOptionsForUser = () => {
    if (!currentUser || !caseStatuses.length) return [];
    const userRole = currentUser?.access_role || (currentUser?.role === 'admin' ? 'Admin' : 'Technician');
    
    const allowedStatusChanges = {
      'Technician': ["In Lab", "Diagnosis", "In Progress", "Cleanroom Operations", "Completed"],
      'Sales': ["Received", "Quoted", "Waiting for Approval", "Approved", "Delivered", "Cancelled"],
      'Accounts': ["Payment Pending", "Completed", "Delivered", "Closed"],
      'Admin': 'all'
    };
    
    const userAllowedStatuses = allowedStatusChanges[userRole];
    if (userAllowedStatuses === 'all') {
      return caseStatuses;
    } else {
      return caseStatuses.filter(status => userAllowedStatuses.includes(status));
    }
  };
  
  const userRole = currentUser?.access_role || (currentUser?.role === 'admin' ? 'Admin' : null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 p-6">
      <div className="flex justify-between items-center mb-8">
        <div className="flex items-center space-x-4">
          <div className="p-3 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-xl shadow-lg">
            <HardDrive className="w-8 h-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              {userRole === 'Technician' ? 'My Cases' : 
               userRole === 'Accounts' ? 'Billable Cases' : 'Cases Management'}
            </h1>
            <p className="text-sm text-gray-500 mt-1">
              {isLoading ? 'Loading cases...' : `You have access to ${cases.length} cases.`}
            </p>
          </div>
        </div>
        {userRole && ['Admin', 'Sales'].includes(userRole) && (
          <Link to={createPageUrl('NewCase')}>
            <Button className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white shadow-lg transform hover:scale-105 transition-all duration-200">
              <PlusCircle className="w-5 h-5 mr-2"/>
              New Case
            </Button>
          </Link>
        )}
      </div>

      <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0 overflow-hidden">
        <div className="bg-gradient-to-r from-gray-50 to-blue-50 p-4 border-b">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold text-gray-800">
              Recent Cases ({currentCases.length} of {filteredCases.length})
            </h2>
            <div className="flex items-center space-x-2">
               <div className="relative w-64">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Search cases..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9 h-9 bg-white/70 border-gray-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-100 text-sm"
                  />
                </div>
              {hasActiveFilters && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={clearFilters}
                  className="bg-red-50 hover:bg-red-100 text-red-600 border-red-200 h-9"
                >
                  <X className="w-4 h-4 mr-1" />
                  Clear
                </Button>
              )}
              <Popover open={isFilterOpen} onOpenChange={setIsFilterOpen}>
                <PopoverTrigger asChild>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className={`h-9 bg-white/50 hover:bg-white border-gray-200 ${hasActiveFilters ? 'bg-blue-50 border-blue-300 text-blue-700' : ''}`}
                  >
                    <Filter className="w-4 h-4 mr-2" />
                    Filter
                    {hasActiveFilters && <span className="ml-1 text-xs bg-blue-600 text-white rounded-full w-4 h-4 flex items-center justify-center">!</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent align="end" className="w-80 p-4">
                  <div className="space-y-4">
                    <h4 className="font-semibold text-sm">Filter Cases</h4>
                    
                    <div>
                      <Label className="text-xs text-gray-600">Status</Label>
                      <Select value={filters.status} onValueChange={(value) => setFilters({...filters, status: value})}>
                        <SelectTrigger className="h-8 text-sm">
                          <SelectValue placeholder="All statuses" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value={null}>All statuses</SelectItem>
                          {caseStatuses.map(status => (
                            <SelectItem key={status} value={status}>{status}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label className="text-xs text-gray-600">Priority</Label>
                      <Select value={filters.priority} onValueChange={(value) => setFilters({...filters, priority: value})}>
                        <SelectTrigger className="h-8 text-sm">
                          <SelectValue placeholder="All priorities" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value={null}>All priorities</SelectItem>
                          {priorityOptions.map(priority => (
                            <SelectItem key={priority} value={priority}>{priority}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label className="text-xs text-gray-600">Service Type</Label>
                      <Select value={filters.serviceType} onValueChange={(value) => setFilters({...filters, serviceType: value})}>
                        <SelectTrigger className="h-8 text-sm">
                          <SelectValue placeholder="All service types" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value={null}>All service types</SelectItem>
                          {serviceTypeOptions.map(type => (
                            <SelectItem key={type} value={type}>{type}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="flex justify-between pt-2">
                      <Button variant="outline" size="sm" onClick={clearFilters}>
                        Clear All
                      </Button>
                      <Button size="sm" onClick={() => setIsFilterOpen(false)}>
                        Apply Filters
                      </Button>
                    </div>
                  </div>
                </PopoverContent>
              </Popover>
            </div>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-gradient-to-r from-gray-100 to-gray-50 hover:from-gray-100 hover:to-gray-50">
                <TableHead className="font-semibold text-gray-700">Job ID</TableHead>
                <TableHead className="font-semibold text-gray-700">Priority</TableHead>
                <TableHead className="font-semibold text-gray-700">Client</TableHead>
                {userRole !== 'Technician' && (
                  <TableHead className="font-semibold text-gray-700">Client Ref</TableHead>
                )}
                <TableHead className="font-semibold text-gray-700">Status</TableHead>
                {userRole !== 'Accounts' && (
                  <>
                    <TableHead className="font-semibold text-gray-700">Phone</TableHead>
                    <TableHead className="font-semibold text-gray-700">SN</TableHead>
                    <TableHead className="font-semibold text-gray-700">Type</TableHead>
                  </>
                )}
                <TableHead className="font-semibold text-gray-700">Created</TableHead>
                {userRole === 'Admin' && (
                  <TableHead className="font-semibold text-gray-700">Created by</TableHead>
                )}
                <TableHead className="font-semibold text-gray-700">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={11} className="text-center py-12">
                    <div className="flex items-center justify-center space-x-2">
                      <div className="w-6 h-6 bg-blue-500 rounded-full animate-pulse"></div>
                      <div className="w-6 h-6 bg-indigo-500 rounded-full animate-pulse delay-100"></div>
                      <div className="w-6 h-6 bg-purple-500 rounded-full animate-pulse delay-200"></div>
                    </div>
                    <p className="mt-4 text-gray-600">Loading cases...</p>
                  </TableCell>
                </TableRow>
              ) : currentCases.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={11} className="text-center py-12">
                    <div className="text-gray-400">
                      <HardDrive className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p className="text-lg font-medium">No cases found</p>
                      <p className="text-sm">
                        {userRole === 'Technician' ? 'No cases assigned to you' :
                         userRole === 'Accounts' ? 'No billable cases available' :
                         'Try adjusting your search criteria'}
                      </p>
                    </div>
                  </TableCell>
                </TableRow>
              ) : (
                currentCases.map((caseItem, index) => {
                  const customerIdentifier = caseItem.customer_id || caseItem.customer_code;
                  const customer = customers[customerIdentifier];
                  const creator = users[caseItem.created_by];
                  const isEvenRow = index % 2 === 0;
                  
                  const isDataMissing = !customer || customer.full_name === 'Customer Data Missing';
                  const customerName = isDataMissing ? 'Customer Missing' : customer.full_name;
                  const customerPhone = isDataMissing ? '--' : customer.phone_number || '--';
                  
                  return (
                    <TableRow 
                      key={caseItem.id} 
                      className={`text-sm hover:bg-gradient-to-r hover:from-blue-50 hover:to-indigo-50 transition-all duration-200 ${
                        isEvenRow ? 'bg-white' : 'bg-gray-50/50'
                      } ${isDataMissing ? 'bg-red-50/50' : ''}`}
                    >
                      <TableCell className="font-medium">
                        <Link 
                          to={createPageUrl(`CaseDetails?id=${caseItem.id}`)}
                          className="text-blue-600 hover:text-blue-800 font-semibold hover:underline transition-colors duration-200"
                        >
                          {caseItem.case_number}
                        </Link>
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-auto p-0 border-none focus-visible:ring-0 focus-visible:ring-offset-0">
                              <span className={priorityColors[caseItem.priority] || 'text-gray-600 bg-gray-50 px-2 py-1 rounded-full text-xs font-medium cursor-pointer hover:opacity-80 transition-opacity'}>
                                {caseItem.priority}
                              </span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="start" className="w-40">
                            {priorityOptions.map((priority) => (
                              <DropdownMenuItem 
                                key={priority}
                                onClick={() => handlePriorityChange(caseItem.id, priority)}
                                className={`text-sm ${caseItem.priority === priority ? 'bg-blue-50 text-blue-700 font-medium' : ''}`}
                              >
                                <div className="flex items-center justify-between w-full">
                                  <span>{priority}</span>
                                  {caseItem.priority === priority && (
                                    <Badge variant="secondary" className="text-xs">Current</Badge>
                                  )}
                                </div>
                              </DropdownMenuItem>
                            ))}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                      <TableCell className={`font-medium ${isDataMissing ? 'text-red-700' : 'text-gray-800'}`}>
                        <div className="flex items-center space-x-1.5">
                          <span>{customerName}</span>
                          {isDataMissing && (
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger>
                                  <AlertTriangle className="w-4 h-4 text-red-500" />
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>Customer record not found (ID/Code: {customerIdentifier})</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          )}
                        </div>
                      </TableCell>
                      {userRole !== 'Technician' && (
                        <TableCell className="text-gray-600">
                          {caseItem.client_reference || '--'}
                        </TableCell>
                      )}
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-auto p-0 border-none focus-visible:ring-0 focus-visible:ring-offset-0">
                              <Badge className={`${statusColors[caseItem.status] || statusColors.default} font-medium px-3 py-1 cursor-pointer hover:opacity-80 transition-opacity`}>
                                {caseItem.status}
                              </Badge>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="start" className="w-48">
                            {getStatusOptionsForUser().map((status) => (
                              <DropdownMenuItem 
                                key={status}
                                onClick={() => handleStatusChange(caseItem.id, status)}
                                className={`text-sm ${caseItem.status === status ? 'bg-blue-50 text-blue-700 font-medium' : ''}`}
                              >
                                <div className="flex items-center justify-between w-full">
                                  <span>{status}</span>
                                  {caseItem.status === status && (
                                    <Badge variant="secondary" className="text-xs">Current</Badge>
                                  )}
                                </div>
                              </DropdownMenuItem>
                            ))}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                      {userRole !== 'Accounts' && (
                        <>
                          <TableCell className="text-gray-700">
                            {customerPhone}
                          </TableCell>
                          <TableCell className="text-gray-700 font-mono text-xs">
                            {caseItem.media_serial_number || '--'}
                          </TableCell>
                          <TableCell className="text-gray-700">
                            {caseItem.media_type || caseItem.service_type}
                          </TableCell>
                        </>
                      )}
                      <TableCell className="text-gray-600 text-xs">
                        {format(new Date(caseItem.created_date), 'dd-MM-yyyy')}
                      </TableCell>
                      {userRole === 'Admin' && (
                        <TableCell className="text-gray-600 text-xs">
                          {creator?.full_name || caseItem.created_by}
                        </TableCell>
                      )}
                      <TableCell>
                        <div className="flex items-center space-x-1">
                          {userRole && ['Admin', 'Sales'].includes(userRole) && (
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-8 w-8 text-red-600 hover:bg-red-100 hover:text-red-700 transition-colors duration-200"
                              title="Delete Case"
                              onClick={() => promptDelete(caseItem)}
                            >
                              <Trash2 className="w-4 h-4"/>
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })
              )}
            </TableBody>
          </Table>
        </div>

        {filteredCases.length > casesPerPage && (
          <div className="bg-gradient-to-r from-gray-50 to-blue-50 p-4 border-t">
            <div className="flex justify-between items-center">
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                  disabled={currentPage === 1}
                >
                  Previous
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                  disabled={currentPage === totalPages}
                >
                  Next
                </Button>
              </div>
              
              {hasMore && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={loadMoreCases}
                  disabled={isLoadingMore}
                  className="bg-blue-50 hover:bg-blue-100 text-blue-600 border-blue-200"
                >
                  {isLoadingMore ? 'Loading...' : 'Load More Cases'}
                </Button>
              )}
            </div>
          </div>
        )}
      </Card>

      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <AlertTriangle className="w-6 h-6 mr-2 text-red-500" />
              Confirm Deletion
            </DialogTitle>
            <DialogDescription className="pt-2">
              This action is irreversible and will permanently delete the case. Please type the Job ID{' '}
              <strong className="text-red-600">{caseToDelete?.case_number}</strong> to confirm.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Label htmlFor="delete-confirm-input" className="text-gray-700">Job ID</Label>
            <Input
              id="delete-confirm-input"
              value={deleteConfirmationInput}
              onChange={(e) => setDeleteConfirmationInput(e.target.value)}
              placeholder={caseToDelete?.case_number}
              className="mt-1"
              autoComplete="off"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleConfirmDelete}
              disabled={deleteConfirmationInput !== caseToDelete?.case_number}
            >
              Delete Case
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}