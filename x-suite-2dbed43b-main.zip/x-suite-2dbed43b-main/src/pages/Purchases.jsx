
import React, { useEffect, useMemo, useState } from 'react';
import { PurchaseOrder } from '@/api/entities';
import { PurchaseOrderLine } from '@/api/entities';
import { Supplier } from '@/api/entities';
import { StockItem } from '@/api/entities';
import { StockTxn } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Table, TableHeader, TableHead, TableRow, TableBody, TableCell } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Plus, PackageCheck, Send } from 'lucide-react';
import { Label } from '@/components/ui/label';

export default function PurchasesPage() {
  const [pos, setPos] = useState([]);
  const [lines, setLines] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [items, setItems] = useState([]);
  const [editing, setEditing] = useState(null);
  const [poLines, setPoLines] = useState([]);

  const refresh = async () => {
    const [p, l, s, i] = await Promise.all([PurchaseOrder.list('-created_date'), PurchaseOrderLine.list(), Supplier.list(), StockItem.list()]);
    setPos(p); setLines(l); setSuppliers(s); setItems(i);
  };
  useEffect(() => { refresh(); }, []);

  const supplierName = (id) => suppliers.find(s => s.id === id)?.supplier_name || '—';

  const openNew = () => setEditing({ poNumber: '', supplierId: '', status: 'Draft', issueDate: new Date().toISOString().slice(0,10), expectedDate: '' });

  const savePO = async () => {
    let poId = editing.id;
    if (!poId) {
      const c = await PurchaseOrder.create(editing);
      poId = c.id;
    } else {
      await PurchaseOrder.update(poId, editing);
    }
    // save lines
    for (const l of poLines) {
      if (l.id) await PurchaseOrderLine.update(l.id, l);
      else await PurchaseOrderLine.create({ ...l, poId });
    }
    setEditing(null); setPoLines([]); refresh();
  };

  const receiveLine = async (po, line) => {
    await StockTxn.create({
      itemId: line.itemId, type: 'in', qty: line.qty, unitCost: line.unitCost,
      reference: { docType: 'PO', docId: po.id }, timestamp: new Date().toISOString()
    });
    const receivedCount = (await StockTxn.filter({ 'reference.docId': po.id })).length;
    const totalLines = lines.filter(l => l.poId === po.id).length;
    const status = receivedCount >= totalLines ? 'Closed' : 'Partially Received';
    await PurchaseOrder.update(po.id, { status });
    refresh();
  };

  const poLinesFor = (poId) => lines.filter(l => l.poId === poId);

  const exportPOs = () => {
    const rows = pos.map(po => ({
      poNumber: po.poNumber, supplierId: po.supplierId, status: po.status, issueDate: po.issueDate, expectedDate: po.expectedDate
    }));
    const headers = ["poNumber","supplierId","status","issueDate","expectedDate"];
    const csv = [headers.join(","), ...rows.map(r => headers.map(h => `"${String(r[h] ?? "").replace(/"/g,'""')}"`).join(","))].join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    const a = document.createElement("a"); a.href = url; a.download = "purchase_orders.csv"; a.click(); URL.revokeObjectURL(url);
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold">Purchases</h1>
        <div className="flex space-x-2"> {/* Added a div to group buttons */}
          <Button variant="outline" onClick={exportPOs}>Export CSV</Button>
          <Button onClick={openNew}><Plus className="w-4 h-4 mr-2" />New PO</Button>
        </div>
      </div>

      <Card className="mb-6">
        <CardHeader><CardTitle>Purchase Orders</CardTitle></CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>PO #</TableHead>
                <TableHead>Supplier</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Issue</TableHead>
                <TableHead>Expected</TableHead>
                <TableHead>Lines</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pos.map(po => (
                <TableRow key={po.id}>
                  <TableCell className="font-mono">{po.poNumber}</TableCell>
                  <TableCell>{supplierName(po.supplierId)}</TableCell>
                  <TableCell>{po.status}</TableCell>
                  <TableCell>{po.issueDate}</TableCell>
                  <TableCell>{po.expectedDate || '—'}</TableCell>
                  <TableCell>{poLinesFor(po.id).length}</TableCell>
                  <TableCell className="space-x-2">
                    <Button variant="outline" size="sm" onClick={() => { setEditing(po); setPoLines(poLinesFor(po.id)); }}>Edit</Button>
                    <Button variant="outline" size="sm" onClick={() => poLinesFor(po.id).forEach(l => receiveLine(po, l))}><PackageCheck className="w-4 h-4 mr-1" />Receive All</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {editing && (
        <Card>
          <CardHeader><CardTitle>{editing.id ? 'Edit PO' : 'New PO'}</CardTitle></CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3 mb-3">
              <div>
                <Label>PO Number</Label>
                <Input value={editing.poNumber || ''} onChange={e => setEditing({ ...editing, poNumber: e.target.value })} />
              </div>
              <div>
                <Label>Supplier</Label>
                <Input value={editing.supplierId || ''} onChange={e => setEditing({ ...editing, supplierId: e.target.value })} placeholder="Supplier ID" />
              </div>
              <div>
                <Label>Issue Date</Label>
                <Input type="date" value={editing.issueDate || ''} onChange={e => setEditing({ ...editing, issueDate: e.target.value })} />
              </div>
              <div>
                <Label>Expected Date</Label>
                <Input type="date" value={editing.expectedDate || ''} onChange={e => setEditing({ ...editing, expectedDate: e.target.value })} />
              </div>
            </div>

            <div className="mb-3">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">Lines</h3>
                <Button variant="outline" size="sm" onClick={() => setPoLines([...poLines, { poId: editing.id, itemId: '', description: '', qty: 1, unitCost: 0 }])}><Plus className="w-4 h-4 mr-1" />Add Line</Button>
              </div>
              <div className="space-y-2 mt-2">
                {poLines.map((l, idx) => (
                  <div key={idx} className="grid grid-cols-5 gap-2 items-center">
                    <Input placeholder="Item ID" value={l.itemId} onChange={e => { const v = [...poLines]; v[idx] = { ...v[idx], itemId: e.target.value }; setPoLines(v); }} />
                    <Input placeholder="Description" value={l.description || ''} onChange={e => { const v = [...poLines]; v[idx] = { ...v[idx], description: e.target.value }; setPoLines(v); }} />
                    <Input type="number" placeholder="Qty" value={l.qty || 0} onChange={e => { const v = [...poLines]; v[idx] = { ...v[idx], qty: Number(e.target.value) }; setPoLines(v); }} />
                    <Input type="number" placeholder="Unit Cost" value={l.unitCost || 0} onChange={e => { const v = [...poLines]; v[idx] = { ...v[idx], unitCost: Number(e.target.value) }; setPoLines(v); }} />
                    <Button variant="outline" size="sm" onClick={() => setPoLines(poLines.filter((_, i) => i !== idx))}>Remove</Button>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => { setEditing(null); setPoLines([]); }}>Cancel</Button>
              <Button onClick={savePO}><Send className="w-4 h-4 mr-1" />Save PO</Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
