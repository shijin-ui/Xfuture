import React, { useEffect, useMemo, useState } from "react";
import { Case } from "@/api/entities";
import { Quote } from "@/api/entities";
import { Invoice } from "@/api/entities";
import { Expense } from "@/api/entities";
import { Transaction } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import QuickDateRange from "@/components/common/QuickDateRange";
import DataExportButtons from "@/components/common/DataExportButtons";

function sum(arr, getter) {
  return arr.reduce((acc, x) => acc + (getter(x) || 0), 0);
}

export default function ReportsPage() {
  const [range, setRange] = useState(null);
  const [type, setType] = useState("Cases");
  const [rows, setRows] = useState([]);

  useEffect(() => {
    const load = async () => {
      if (type === "Cases") {
        const cs = await Case.list("-created_date", 5000);
        setRows(cs);
      } else if (type === "Sales") {
        const inv = await Invoice.list("-issued_date", 5000);
        setRows(inv);
      } else if (type === "Expenses") {
        const ex = await Expense.list("-expense_date", 5000);
        setRows(ex);
      } else if (type === "Payments") {
        const tx = await Transaction.list("-transaction_date", 5000);
        setRows(tx);
      }
    };
    load();
  }, [type]);

  const filtered = useMemo(() => {
    if (!range) return rows;
    const k = (r) => r.created_date || r.issued_date || r.expense_date || r.transaction_date;
    return rows.filter(r => {
      const d = k(r) ? new Date(k(r)) : null;
      return d ? (d >= range.start && d <= range.end) : true;
    });
  }, [rows, range]);

  const totals = useMemo(() => {
    if (type === "Sales") return { total: sum(filtered, r => r.total_amount) };
    if (type === "Expenses") return { total: sum(filtered, r => r.total_amount) };
    if (type === "Payments") return { income: sum(filtered.filter(f => f.transaction_type === "Income"), r => r.amount), expense: sum(filtered.filter(f => f.transaction_type === "Expense"), r => r.amount) };
    return {};
  }, [filtered, type]);

  const toCsv = (rs) => {
    if (!rs.length) return "";
    const headers = Object.keys(rs[0]);
    const esc = (v) => {
      if (v === null || v === undefined) return "";
      const s = typeof v === "object" ? JSON.stringify(v) : String(v);
      return s.includes(",") || s.includes('"') || s.includes("\n") ? `"${s.replace(/"/g, '""')}"` : s;
    };
    return [headers.join(","), ...rs.map(r => headers.map(h => esc(r[h])).join(","))].join("\n");
  };

  return (
    <div className="p-6">
      <Card>
        <CardHeader className="flex items-center justify-between">
          <CardTitle>Reports</CardTitle>
          <div className="flex items-center gap-2">
            <Select value={type} onValueChange={setType}>
              <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="Cases">Case Report</SelectItem>
                <SelectItem value="Sales">Sales Report</SelectItem>
                <SelectItem value="Payments">Payments</SelectItem>
                <SelectItem value="Expenses">Expenses</SelectItem>
              </SelectContent>
            </Select>
            <QuickDateRange value={range} onChange={setRange} />
            <DataExportButtons rows={filtered} filename={type.toLowerCase()} toCsv={toCsv} />
          </div>
        </CardHeader>
        <CardContent>
          {/* Totals */}
          <div className="flex gap-6 mb-4 text-sm">
            {type === "Sales" && <div><span className="text-muted-foreground">Total Sales:</span> <span className="font-semibold">{totals.total?.toLocaleString()}</span></div>}
            {type === "Expenses" && <div><span className="text-muted-foreground">Total Expenses:</span> <span className="font-semibold">{totals.total?.toLocaleString()}</span></div>}
            {type === "Payments" && (
              <>
                <div><span className="text-muted-foreground">Income:</span> <span className="font-semibold">{totals.income?.toLocaleString()}</span></div>
                <div><span className="text-muted-foreground">Expense:</span> <span className="font-semibold">{totals.expense?.toLocaleString()}</span></div>
              </>
            )}
          </div>
          {/* Table */}
          <div className="overflow-auto">
            <table className="w-full text-sm">
              <thead className="sticky top-0 bg-muted">
                <tr>
                  {filtered.length > 0 ? Object.keys(filtered[0]).map(h => <th key={h} className="text-left p-2">{h}</th>) : <th className="text-left p-2">No data</th>}
                </tr>
              </thead>
              <tbody>
                {filtered.map((r) => (
                  <tr key={r.id} className="hover:bg-muted/50">
                    {Object.keys(filtered[0]).map(h => <td key={h} className="p-2">{String(r[h])}</td>)}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}