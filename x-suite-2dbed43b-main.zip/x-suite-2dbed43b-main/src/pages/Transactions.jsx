
import React, { useState, useEffect, useMemo } from 'react';
import { Transaction } from '@/api/entities';
import { Bank } from '@/api/entities'; // Added Bank entity
import { User } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'; // Added Select components
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'; // Added Table components
import { Search, Building, Calculator, User as UserIcon } from 'lucide-react'; // Updated icons: removed DollarSign, Trash2, Edit, Plus, Lock; added Building, Calculator, User as UserIcon
import { format, parseISO } from 'date-fns';

// Helper functions for locale and currency formatting
// These functions would typically be in a separate utility file or context.
// For this example, they are defined here to ensure the component is self-contained and functional.
const getDefaultLocale = async () => {
  // In a real application, this would fetch the user's preferred locale
  // or a system-wide default from configuration.
  return 'en-US'; // Defaulting to US English locale for demonstration
};

const formatCurrency = (amount, locale) => {
  // Assuming a default currency, e.g., Omani Rial (OMR) as suggested by the fallback.
  // In a full application, the currency code would be dynamic based on settings or bank account.
  return new Intl.NumberFormat(locale, { style: 'currency', currency: 'OMR' }).format(amount);
};


export default function TransactionsPage() {
  const [transactions, setTransactions] = useState([]);
  const [banks, setBanks] = useState([]); // New state for bank accounts
  const [users, setUsers] = useState([]); // New state for users
  const [isLoading, setIsLoading] = useState(true);
  const [locale, setLocale] = useState(null); // New state to store the user's locale
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all'); // New state for transaction type filter
  const [filterBank, setFilterBank] = useState('all'); // New state for bank filter

  // Old states related to authentication (currentUser, authPassword, showAuthDialog, pendingAction) removed

  useEffect(() => {
    fetchData(); // Calls the combined data fetching function on component mount
  }, []);

  const fetchData = async () => {
    setIsLoading(true);
    try {
      // Use Promise.all to fetch all necessary data concurrently for efficiency
      const [transactionsData, banksData, usersData, localeData] = await Promise.all([
        Transaction.list('-transaction_date'), // Fetch transactions, sorted by date descending
        Bank.list(), // Fetch all bank accounts
        User.list(), // Fetch all users (for 'processed by' information)
        getDefaultLocale() // Fetch the default locale for currency formatting
      ]);

      setTransactions(transactionsData);
      setBanks(banksData);
      setUsers(usersData);
      setLocale(localeData);
    } catch (error) {
      console.error('Failed to fetch data:', error);
      // Handle error gracefully, e.g., display an error message to the user
    } finally {
      setIsLoading(false);
    }
  };

  // The `useMemo` hook optimizes filtering by re-calculating only when dependencies change.
  const filteredTransactions = useMemo(() => {
    return transactions.filter(transaction => {
      const searchLower = searchTerm.toLowerCase();

      // Check if transaction matches the search term in notes, reference number, or payment method
      const matchesSearch = (
        transaction.notes?.toLowerCase().includes(searchLower) ||
        transaction.reference_number?.toLowerCase().includes(searchLower) ||
        transaction.payment_method?.toLowerCase().includes(searchLower)
      );

      // Check if transaction type matches the selected filter
      const matchesType = filterType === 'all' || transaction.transaction_type === filterType;

      // Check if bank ID matches the selected filter
      const matchesBank = filterBank === 'all' || transaction.bank_id === filterBank;

      return matchesSearch && matchesType && matchesBank;
    });
  }, [transactions, searchTerm, filterType, filterBank]); // Dependencies for useMemo

  // Helper function to get bank name and account name from bank ID
  const getBankName = (bankId) => {
    const bank = banks.find(b => b.id === bankId);
    return bank ? `${bank.bank_name} - ${bank.account_name}` : 'N/A';
  };

  // Helper function to get user's full name from their email
  const getUserName = (email) => {
    const user = users.find(u => u.email === email);
    // Fallback to the local part of the email or 'System' if user not found
    return user ? user.full_name : email ? email.split('@')[0] : 'System';
  };

  // Helper function to determine badge color based on transaction type
  const getTransactionTypeColor = (type) => {
    switch (type) {
      case 'Income':
        return 'bg-green-100 text-green-800';
      case 'Expense':
        return 'bg-red-100 text-red-800';
      case 'Transfer':
        return 'bg-blue-100 text-blue-800';
      case 'Deposit':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="p-8 bg-gradient-to-br from-slate-50 to-indigo-100 min-h-screen">
      {/* Header Section */}
      <div className="flex justify-between items-center mb-8">
        <div className="flex items-center space-x-4">
          <div className="p-3 bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl shadow-lg">
            <Calculator className="w-8 h-8 text-white" /> {/* New icon for the header */}
          </div>
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
              Transactions
            </h1>
            <p className="text-gray-500 mt-1">All financial transactions and movements</p>
          </div>
        </div>
      </div>

      {/* Filters Section */}
      <Card className="shadow-lg bg-white/90 backdrop-blur-sm border-0 mb-6">
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Search Input */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search transactions..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 bg-white/70"
              />
            </div>

            {/* Transaction Type Filter */}
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger>
                <SelectValue placeholder="All Types" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="Income">Income</SelectItem>
                <SelectItem value="Expense">Expense</SelectItem>
                <SelectItem value="Transfer">Transfer</SelectItem>
                <SelectItem value="Deposit">Deposit</SelectItem>
              </SelectContent>
            </Select>

            {/* Bank Filter */}
            <Select value={filterBank} onValueChange={setFilterBank}>
              <SelectTrigger>
                <SelectValue placeholder="All Banks" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Banks</SelectItem>
                {banks.map(bank => (
                  <SelectItem key={bank.id} value={bank.id}>
                    {bank.bank_name} - {bank.account_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Transactions Table */}
      <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0">
        <CardHeader>
          <CardTitle>All Transactions ({filteredTransactions.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Bank Account</TableHead>
                  <TableHead>Method</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                  <TableHead>Reference</TableHead>
                  <TableHead>Processed By</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={9} className="text-center py-10">
                      Loading transactions...
                    </TableCell>
                  </TableRow>
                ) : filteredTransactions.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={9} className="text-center py-10">
                      No transactions found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredTransactions.map(transaction => (
                    <TableRow key={transaction.id} className="hover:bg-blue-50/50">
                      <TableCell>
                        {format(parseISO(transaction.transaction_date), 'dd MMM yyyy')}
                      </TableCell>
                      <TableCell>
                        <Badge className={getTransactionTypeColor(transaction.transaction_type)}>
                          {transaction.transaction_type || 'Unknown'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="max-w-xs truncate">
                          {transaction.notes || 'No description'}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center text-sm">
                          <Building className="w-4 h-4 mr-2 text-gray-400 flex-shrink-0" />
                          <span className="truncate">{getBankName(transaction.bank_id)}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {transaction.payment_method}
                        </Badge>
                      </TableCell>
                      <TableCell className={`text-right font-mono font-semibold ${
                        transaction.amount >= 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {transaction.amount >= 0 ? '+' : ''}
                        {locale ? formatCurrency(Math.abs(transaction.amount || 0), locale) :
                         `${Math.abs(transaction.amount || 0).toFixed(3)} OMR`} {/* Fallback currency display */}
                      </TableCell>
                      <TableCell className="font-mono text-sm">
                        {transaction.reference_number || '-'}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center text-sm">
                          <UserIcon className="w-3 h-3 mr-1 text-gray-400" />
                          <span className="truncate">{getUserName(transaction.processed_by)}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={
                            transaction.status === 'Completed' ? 'default' :
                            transaction.status === 'Pending' ? 'secondary' : 'destructive'
                        }>
                          {transaction.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
