
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardFooter, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { createPageUrl } from '@/utils';
import {
    CheckCircle2, XCircle, Archive, Server, Database, Code, ShieldCheck, Download,
    Rocket, FileText, Loader2, ArrowRight, HardDrive, Tv, Image as ImageIcon,
    FileTerminal, KeyRound, Wind, Anchor
} from 'lucide-react';
import { Case } from '@/api/entities';
import { Customer } from '@/api/entities';
import { Quote } from '@/api/entities';
import { Invoice } from '@/api/entities';
import { Setting } from '@/api/entities';
import { User } from '@/api/entities';
import { JobHistory } from '@/api/entities';
import { CaseFile } from '@/api/entities';
import { Company } from '@/api/entities';

// --- Helper Functions & Components ---

const CodeBlock = ({ language, code }) => (
    <div className="rounded-md bg-gray-900 overflow-hidden my-4">
        <div className="flex items-center justify-between px-4 py-1.5 bg-gray-800">
            <span className="text-xs font-semibold text-gray-400">{language}</span>
            <Button variant="ghost" size="sm" className="text-xs text-gray-400 hover:bg-gray-700 h-6" onClick={() => navigator.clipboard.writeText(code)}>Copy</Button>
        </div>
        <pre className="p-4 text-xs text-gray-300 bg-gray-900 overflow-x-auto">
            <code>{code.trim()}</code>
        </pre>
    </div>
);

const ExportCard = ({ icon: Icon, title, description, children }) => (
    <Card className="shadow-md hover:shadow-xl transition-shadow duration-300">
        <CardHeader className="flex flex-row items-start gap-4">
            <Icon className="w-8 h-8 text-primary flex-shrink-0 mt-1" />
            <div>
                <CardTitle>{title}</CardTitle>
                <CardDescription>{description}</CardDescription>
            </div>
        </CardHeader>
        <CardContent>
            {children}
        </CardContent>
    </Card>
);

const CheckItem = ({ label, status, details }) => (
    <div className="flex items-center justify-between p-2 rounded-md transition-colors hover:bg-muted">
        <span className="text-sm font-medium">{label}</span>
        {status === 'checking' && <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />}
        {status === 'pass' && <div className="flex items-center gap-2 text-green-600"><CheckCircle2 className="w-4 h-4" /><span className="text-xs font-semibold">Pass</span></div>}
        {status === 'fail' && (
            <div className="flex items-center gap-2 text-red-600" title={details}>
                <XCircle className="w-4 h-4" />
                <span className="text-xs font-semibold">Fail</span>
            </div>
        )}
    </div>
);

// --- File Content Generators ---
const generatePrismaSchema = async () => {
    const entitySchemas = { Case, Customer, Quote, Invoice, Setting, User, JobHistory, Company, CaseFile };
    let prismaSchema = `// Generated Prisma Schema for BigRock VPS Migration
// Generated on: ${new Date().toISOString()}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

generator client {
  provider = "prisma-client-js"
}

`;

    for (const [name, entity] of Object.entries(entitySchemas)) {
        try {
            const schema = await entity.schema();
            let modelSchema = `model ${name} {
  id        String   @id @default(cuid())
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  createdBy String?

`;

            // Add password field for User model
            if (name === 'User') {
                modelSchema += `  password  String?\n`; // Add password for local auth
            }

            for (const [prop, propDetails] of Object.entries(schema.properties)) {
                // Skip 'password' field if it already exists in the original schema to avoid duplication
                // and to ensure our custom definition takes precedence if type is different.
                if (name === 'User' && prop === 'password') {
                    continue;
                }

                let prismaType = 'String';
                if (propDetails.type === 'number') prismaType = 'Float';
                if (propDetails.type === 'boolean') prismaType = 'Boolean';
                if (propDetails.format === 'date-time') prismaType = 'DateTime';
                
                const optional = propDetails.required !== true ? '?' : '';
                modelSchema += `  ${prop.padEnd(20, ' ')} ${prismaType}${optional}\n`;
            }
            modelSchema += `}\n\n`;
            prismaSchema += modelSchema;
        } catch (error) {
            console.warn(`Could not generate schema for ${name}:`, error);
        }
    }
    return prismaSchema;
};

const generateSQLSchema = async () => {
    const entitySchemas = { Case, Customer, Quote, Invoice, Setting, User, JobHistory, Company };
    let sqlSchema = `-- PostgreSQL Schema Export\n-- Generated on: ${new Date().toISOString()}\n\n`;

    for (const [name, entity] of Object.entries(entitySchemas)) {
        const schema = await entity.schema();
        sqlSchema += `CREATE TABLE "${name}" (\n`;
        sqlSchema += `  "id" UUID PRIMARY KEY DEFAULT gen_random_uuid(),\n`;
        sqlSchema += `  "createdAt" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,\n`;
        sqlSchema += `  "updatedAt" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,\n`;
        sqlSchema += `  "createdBy" TEXT,\n`;

        // Add password field for User model in SQL schema
        if (name === 'User') {
            sqlSchema += `  "password" TEXT,\n`;
        }

        for (const [prop, propDetails] of Object.entries(schema.properties)) {
            // Skip 'password' field if it already exists in the original schema to avoid duplication
            if (name === 'User' && prop === 'password') {
                continue;
            }

            let sqlType = 'TEXT';
            if (propDetails.type === 'number') sqlType = 'NUMERIC';
            if (propDetails.type === 'boolean') sqlType = 'BOOLEAN';
            if (propDetails.format === 'date-time') sqlType = 'TIMESTAMP WITH TIME ZONE';
            if (propDetails.type === 'array') sqlType = 'JSONB';

            sqlSchema += `  "${prop}" ${sqlType},\n`;
        }
        sqlSchema = sqlSchema.slice(0, -2); // Remove last comma
        sqlSchema += `\n);\n\n`;
    }
    return sqlSchema;
};


const generateBackendScaffold = () => {
    const packageJson = {
        name: "space-recovery-backend",
        version: "1.0.0",
        description: "Self-hosted backend for Space Recovery application",
        main: "server.js",
        scripts: {
            start: "node server.js",
            dev: "nodemon server.js",
            migrate: "npx prisma migrate dev",
            generate: "npx prisma generate",
            seed: "npx prisma db seed"
        },
        dependencies: {
            express: "^4.18.0",
            "@prisma/client": "^5.0.0",
            bcryptjs: "^2.4.3",
            jsonwebtoken: "^9.0.0",
            cors: "^2.8.5",
            helmet: "^7.0.0",
            dotenv: "^16.0.0",
            multer: "^1.4.5"
        },
        devDependencies: {
            prisma: "^5.0.0",
            nodemon: "^3.0.0"
        },
        prisma: {
          seed: "node prisma/seed.js"
        }
    };

    const serverJs = `// Space Recovery Backend Server
// Generated for BigRock VPS deployment

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { PrismaClient } = require('@prisma/client');
require('dotenv').config();

const app = express();
const prisma = new PrismaClient();
const PORT = process.env.PORT || 4000;

// Middleware
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '10mb' }));

// JWT Authentication Middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }
  
  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ error: 'Invalid token' });
    req.user = user;
    next();
  });
};

// Role-based access control
const requireRole = (roles) => (req, res, next) => {
  if (!req.user || !roles.includes(req.user.access_role)) {
    return res.status(403).json({ error: 'Insufficient permissions' });
  }
  next();
};

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// --- AUTHENTICATION ROUTES ---

// User Registration
app.post('/api/auth/register', async (req, res) => {
    const { full_name, email, password, access_role } = req.body;
    if (!full_name || !email || !password) {
        return res.status(400).json({ error: 'Full name, email, and password are required.' });
    }

    try {
        const existingUser = await prisma.user.findUnique({ where: { email } });
        if (existingUser) {
            return res.status(409).json({ error: 'User with this email already exists.' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const user = await prisma.user.create({
            data: {
                full_name: full_name,
                email: email,
                password: hashedPassword,
                access_role: access_role || 'Technician', // Default role
                role: (access_role === 'Admin') ? 'admin' : 'user', // System role
            },
        });
        
        const { password: _, ...userWithoutPassword } = user; // Exclude password from response
        res.status(201).json(userWithoutPassword);

    } catch (error) {
        res.status(500).json({ error: \`Registration failed: \${error.message}\` });
    }
});

// User Login
app.post('/api/auth/login', async (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
        return res.status(400).json({ error: 'Email and password are required.' });
    }

    try {
        const user = await prisma.user.findUnique({ where: { email } });
        if (!user || !user.password) {
            return res.status(401).json({ error: 'Invalid credentials or user not set up for password login.' });
        }

        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) {
            return res.status(401).json({ error: 'Invalid credentials.' });
        }

        // Generate JWT token
        const token = jwt.sign(
            { id: user.id, email: user.email, access_role: user.access_role },
            process.env.JWT_SECRET,
            { expiresIn: '8h' } // Token expires in 8 hours
        );

        res.json({ message: 'Login successful', token });

    } catch (error) {
        res.status(500).json({ error: \`Login failed: \${error.message}\` });
    }
});

// Get Current User (protected route)
app.get('/api/auth/me', authenticateToken, async (req, res) => {
    try {
        const user = await prisma.user.findUnique({
            where: { id: req.user.id },
            // Select specific fields to avoid exposing sensitive data
            select: { id: true, email: true, full_name: true, access_role: true, role: true }
        });
        if (!user) return res.status(404).json({ error: 'User not found.' });
        res.json(user);
    } catch (error) {
        res.status(500).json({ error: \`Failed to fetch user: \${error.message}\` });
    }
});


// Generic CRUD routes for entities
const entities = ['case', 'customer', 'quote', 'invoice', 'user', 'setting', 'caseFile', 'jobHistory', 'company'];

entities.forEach(entity => {
  const modelName = entity.charAt(0).toLowerCase() + entity.slice(1);
  const prismaModel = prisma[modelName];

  if (!prismaModel) {
      console.warn(\`Prisma model for '\${modelName}' not found. Skipping route generation.\`);
      return;
  }
  
  // GET all
  app.get(\`/api/\${modelName}s\`, authenticateToken, async (req, res) => {
    try {
      const items = await prismaModel.findMany({
        orderBy: { createdAt: 'desc' }
      });
      res.json(items);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  
  // GET by ID
  app.get(\`/api/\${modelName}s/:id\`, authenticateToken, async (req, res) => {
    try {
      const item = await prismaModel.findUnique({
        where: { id: req.params.id }
      });
      if (!item) return res.status(404).json({ error: 'Not found' });
      res.json(item);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  
  // POST create
  app.post(\`/api/\${modelName}s\`, authenticateToken, async (req, res) => {
    try {
      // Ensure req.user exists before accessing req.user.email
      const createdBy = req.user ? req.user.email : 'system';
      const item = await prismaModel.create({
        data: { ...req.body, createdBy: createdBy }
      });
      res.status(201).json(item);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  
  // PUT update
  app.put(\`/api/\${modelName}s/:id\`, authenticateToken, async (req, res) => {
    try {
      const item = await prismaModel.update({
        where: { id: req.params.id },
        data: req.body
      });
      res.json(item);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
  
  // DELETE
  app.delete(\`/api/\${modelName}s/:id\`, authenticateToken, requireRole(['Admin']), async (req, res) => {
    try {
      await prismaModel.delete({
        where: { id: req.params.id }
      });
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
});

app.listen(PORT, () => {
  console.log(\`Space Recovery Backend running on port \${PORT}\`);
});
`;
    
    const seedJs = `
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
    console.log('Start seeding...');

    const adminEmail = 'admin@example.com';
    let adminUser = await prisma.user.findUnique({ where: { email: adminEmail } });

    if (!adminUser) {
        const hashedPassword = await bcrypt.hash('password123', 10);
        adminUser = await prisma.user.create({
            data: {
                full_name: 'Admin User',
                email: adminEmail,
                password: hashedPassword,
                access_role: 'Admin',
                role: 'admin'
            }
        });
        console.log('----------------------------------------------------');
        console.log('Admin user created successfully!');
        console.log(\`Email: \${adminEmail}\`);
        console.log('Password: password123');
        console.log('Please change this password after your first login.');
        console.log('----------------------------------------------------');
    } else {
        console.log('Admin user already exists.');
    }
    
    console.log('Seeding finished.');
}

main()
    .catch((e) => {
        console.error(e);
        process.exit(1);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });
`;

    return { packageJson: JSON.stringify(packageJson, null, 2), serverJs, seedJs };
};

const generateDockerCompose = () => `# Docker Compose for Space Recovery - BigRock VPS
# Generated on: ${new Date().toISOString()}

version: '3.8'

services:
  postgres:
    image: postgres:14-alpine
    container_name: space-recovery-db
    restart: always
    environment:
      POSTGRES_USER: ${'${DB_USER:-postgres}'}
      POSTGRES_PASSWORD: ${'${DB_PASSWORD:-your_secure_password}'}
      POSTGRES_DB: ${'${DB_NAME:-space_recovery_db}'}
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"
    networks:
      - space-recovery-network

  backend:
    build:
      context: ./backend_api
      dockerfile: Dockerfile
    container_name: space-recovery-backend
    restart: always
    ports:
      - "4000:4000"
    depends_on:
      - postgres
    environment:
      DATABASE_URL: postgresql://${'${DB_USER:-postgres}'}:${'${DB_PASSWORD:-your_secure_password}'}@postgres:5432/${'${DB_NAME:-space_recovery_db}'}
      JWT_SECRET: ${'${JWT_SECRET:-your-super-secure-jwt-secret-key-here}'}
      PORT: 4000
    networks:
      - space-recovery-network

  frontend:
    build:
      context: ./frontend_source
      dockerfile: Dockerfile
    container_name: space-recovery-frontend
    restart: always
    ports:
      - "3000:3000"
    environment:
      REACT_APP_API_BASE_URL: http://localhost/api # Nginx will proxy this to the backend
    networks:
      - space-recovery-network

  nginx:
    image: nginx:alpine
    container_name: space-recovery-nginx
    restart: always
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/nginx.conf:ro
      - ./certbot/www:/var/www/certbot/:ro
      - ./certbot/conf/:/etc/nginx/ssl/:ro
    depends_on:
      - frontend
      - backend
    networks:
      - space-recovery-network

  certbot:
    image: certbot/certbot
    container_name: space-recovery-certbot
    volumes:
      - ./certbot/www/:/var/www/certbot/:rw
      - ./certbot/conf/:/etc/letsencrypt/:rw
    command: ["tail", "-f", "/dev/null"] # Keeps container running for manual cert renewal

volumes:
  postgres_data:

networks:
  space-recovery-network:
    driver: bridge
`;

const generateDeploymentGuide = () => `# BigRock VPS Deployment Guide
## Space Recovery Application

Generated on: ${new Date().toISOString()}

This guide provides comprehensive instructions for deploying your application on a BigRock VPS using either Docker (recommended) or a bare metal setup.

### 1. Prerequisites
- A BigRock VPS running a modern Linux distribution (e.g., Ubuntu 22.04).
- A domain name pointed to your VPS's public IP address.
- SSH access to your VPS with root or sudo privileges.

### 2. Docker Deployment (Recommended)

This is the simplest and most reliable method.

#### Step 2.1: Install Docker and Docker Compose
Connect to your VPS via SSH and run these commands:
\`\`\`bash
# Update your package list
sudo apt-get update

# Install prerequisites
sudo apt-get install -y ca-certificates curl gnupg

# Add Docker's official GPG key
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg

# Set up the Docker repository
echo \\
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \\
  $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \\
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# Install Docker Engine and Docker Compose
sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# Add your user to the 'docker' group to run Docker commands without sudo
sudo usermod -aG docker $USER

# Log out and log back in for the group changes to take effect.
echo "Please log out and log back in to apply Docker group permissions."
\`\`\`

#### Step 2.2: Deploy the Application
1.  Upload the \`space-recovery-migration-bundle.zip\` to your VPS and unzip it.
    \`\`\`bash
    # On your local machine (if you have scp)
    # scp space-recovery-migration-bundle.zip user@your_vps_ip:~
    
    # On your VPS
    # unzip space-recovery-migration-bundle.zip
    cd space-recovery-migration-bundle
    \`\`\`
2.  Create and configure your environment file.
    \`\`\`bash
    cp .env.example .env
    nano .env
    # IMPORTANT: Change the default passwords and secrets in this file!
    \`\`\`
3.  Start all services using Docker Compose.
    \`\`\`bash
    docker compose up -d
    \`\`\`
4.  The backend needs to set up its database. Run the migration and seed commands.
    \`\`\`bash
    docker compose exec backend npx prisma migrate deploy
    docker compose exec backend npx prisma db seed
    \`\`\`

Your application should now be running. You can check the status with \`docker compose ps\`.

#### Step 2.3: Configure SSL with Let's Encrypt
1.  Make sure your domain is pointing to the VPS IP.
2.  Run Certbot within its container to obtain the certificate.
    \`\`\`bash
    # Replace yourdomain.com with your actual domain
    docker compose run --rm certbot certonly --webroot --webroot-path /var/www/certbot/ -d yourdomain.com
    \`\`\`
3.  Uncomment the SSL sections in \`nginx/nginx.conf\` and restart Nginx.
    \`\`\`bash
    # Edit nginx/space-recovery.conf to use your domain and enable SSL lines
    nano nginx/space-recovery.conf
    docker compose restart nginx
    \`\`\`
4.  Set up automatic certificate renewal.
    \`\`\`bash
    (crontab -l 2>/dev/null; echo "0 3 * * * /usr/bin/docker compose -f /path/to/your/docker-compose.yml run --rm certbot renew --quiet && /usr/bin/docker compose -f /path/to/your/docker-compose.yml restart nginx") | crontab -
    \`\`\`

### 3. Bare Metal Deployment

This method gives you more control but requires manual setup for each component.

#### Step 3.1: Install Dependencies (Node.js, PostgreSQL, PM2)
\`\`\`bash
# Install Node.js v18
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PostgreSQL
sudo apt-get install -y postgresql postgresql-contrib

# Install PM2, a process manager for Node.js
sudo npm install -g pm2
\`\`\`

#### Step 3.2: Set Up PostgreSQL Database
\`\`\`bash
# Switch to the postgres user to create the database and user
sudo -u postgres psql
CREATE DATABASE space_recovery_db;
CREATE USER space_recovery_user WITH ENCRYPTED PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE space_recovery_db TO space_recovery_user;
\\q
\`\`\`

#### Step 3.3: Deploy Backend API
1.  Navigate to the backend directory.
    \`\`\`bash
    cd /path/to/your_app/backend_api
    \`\`\`
2.  Install dependencies.
    \`\`\`bash
    npm install
    \`\`\`
3.  Configure the environment.
    \`\`\`bash
    cp .env.example .env
    nano .env
    # Set DATABASE_URL and JWT_SECRET
    \`\`\`
4.  Run database migrations and seed the initial admin user.
    \`\`\`bash
    npx prisma migrate deploy
    npx prisma db seed
    \`\`\`
5.  Start the application with PM2.
    \`\`\`bash
    pm2 start server.js --name "space-recovery-backend"
    pm2 save      # Save the process list
    pm2 startup   # Enable PM2 to start on system boot
    \`\`\`

#### Step 3.4: Deploy Frontend & Configure Nginx
1.  Build the frontend application.
    \`\`\`bash
    cd /path/to/your_app/frontend_source
    npm install
    npm run build
    \`\`\`
2.  Install Nginx.
    \`\`\`bash
    sudo apt-get install -y nginx
    \`\`\`
3.  Configure Nginx to serve the frontend and proxy the backend.
    \`\`\`bash
    sudo cp /path/to/your_app/nginx/space-recovery.conf /etc/nginx/sites-available/
    # Edit the file to match your paths and domain
    sudo nano /etc/nginx/sites-available/space-recovery.conf
    sudo ln -s /etc/nginx/sites-available/space-recovery.conf /etc/nginx/sites-enabled/
    sudo nginx -t # Test configuration
    sudo systemctl restart nginx
    \`\`\`
4.  Set up SSL using Certbot.
    \`\`\`bash
    sudo apt-get install -y certbot python3-certbot-nginx
    sudo certbot --nginx -d yourdomain.com
    \`\`\`

### 4. Firewall Configuration (UFW)
It's crucial to set up a firewall.
\`\`\`bash
sudo ufw allow ssh   # Port 22
sudo ufw allow http  # Port 80
sudo ufw allow https # Port 443
sudo ufw enable
\`\`\`

### 5. Maintenance
-   **Check Status**: \`docker compose ps\` (Docker) or \`pm2 status\` (Bare Metal).
-   **View Logs**: \`docker compose logs -f backend\` (Docker) or \`pm2 logs space-recovery-backend\` (Bare Metal).
-   **Backup Database**: \`docker compose exec postgres pg_dump -U ${'${DB_USER}'} -d ${'${DB_NAME}'} > backup.sql\`
`;

// --- Main Page Component ---
export default function MigrationExportPage() {
    const [apiBaseUrl, setApiBaseUrl] = useState('https://api.yourdomain.com');
    const [isExporting, setIsExporting] = useState(null);
    const [invalidUsers, setInvalidUsers] = useState([]);
    const [checks, setChecks] = useState({
        env: 'checking',
        relations: 'checking',
        prefixes: 'checking',
        roles: 'checking'
    });

    const runChecks = useCallback(async () => {
        setChecks({ env: 'checking', relations: 'checking', prefixes: 'checking', roles: 'checking' });
        
        try {
            // Simulate async checks
            await new Promise(res => setTimeout(res, 1000));
            const caseData = await Case.list();
            const customerIds = (await Customer.list()).map(c => c.id);
            const orphanedCases = caseData.filter(c => !customerIds.includes(c.customer_id));
            setChecks(prev => ({ ...prev, relations: orphanedCases.length === 0 ? 'pass' : 'fail' }));

            await new Promise(res => setTimeout(res, 500));
            const numberSettings = await Setting.filter({ category: 'Number Sequences' });
            const hasEmptyPrefix = numberSettings.some(s => !s.value || s.numeric_value === 0);
            setChecks(prev => ({ ...prev, prefixes: hasEmptyPrefix ? 'fail' : 'pass' }));

            await new Promise(res => setTimeout(res, 500));
            const users = await User.list();
            const validRoles = ['Admin', 'Technician', 'Sales', 'Accounts'];
            const usersWithInvalidRoles = users.filter(u => !validRoles.includes(u.access_role));
            setInvalidUsers(usersWithInvalidRoles);
            setChecks(prev => ({ ...prev, roles: usersWithInvalidRoles.length === 0 ? 'pass' : 'fail' }));
            
            await new Promise(res => setTimeout(res, 200));
            setChecks(prev => ({ ...prev, env: 'pass' }));
        } catch (error) {
            console.error('Error during preflight checks:', error);
            setChecks({ env: 'fail', relations: 'fail', prefixes: 'fail', roles: 'fail' });
        }
    }, []);

    const fixUserRoles = async () => {
        try {
            const usersToFix = invalidUsers.filter(u => !u.access_role || !['Admin', 'Technician', 'Sales', 'Accounts'].includes(u.access_role));
            
            for (const user of usersToFix) {
                // Set default role based on built-in role or default to Technician
                const defaultAccessRole = user.role === 'admin' ? 'Admin' : 'Technician';
                await User.update(user.id, { 
                    access_role: defaultAccessRole,
                    role: user.role === 'admin' ? 'admin' : 'user' // Ensure built-in role is consistent
                });
            }
            
            alert(`Fixed ${usersToFix.length} user roles. Re-running checks...`);
            runChecks(); // Re-run checks after fixing
        } catch (error) {
            console.error('Failed to fix user roles:', error);
            alert('Failed to fix user roles. Please try manually via the Users page.');
        }
    };

    useEffect(() => {
        runChecks();
    }, [runChecks]);

    const allChecksPass = Object.values(checks).every(status => status === 'pass');
    const qualityScore = (Object.values(checks).filter(s => s === 'pass').length / Object.values(checks).length) * 100;
    
    const handleDownload = (content, filename, type = 'application/json') => {
        const blob = new Blob([content], { type });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    const handleGenerateFrontend = () => {
        setIsExporting('frontend');
        
        // Generate frontend package.json
        const frontendPackage = {
            name: "space-recovery-frontend",
            version: "1.0.0",
            private: true,
            dependencies: {
                "react": "^18.0.0",
                "react-dom": "^18.0.0",
                "react-router-dom": "^6.0.0",
                "lucide-react": "latest",
                "tailwindcss": "^3.0.0",
                "@tailwindcss/forms": "^0.5.0",
                "react-scripts": "5.0.1" // Added for complete package.json
            },
            scripts: {
                start: "react-scripts start",
                build: "react-scripts build",
                test: "react-scripts test",
                eject: "react-scripts eject"
            },
            proxy: apiBaseUrl // This is for local dev, not for production build
        };

        const envExample = `# Space Recovery Frontend Environment
REACT_APP_API_BASE_URL=${apiBaseUrl}
REACT_APP_VERSION=1.0.0
GENERATE_SOURCEMAP=false
`;

        const readme = `# Space Recovery Frontend

Self-hosted frontend for Space Recovery application.

## Quick Start

1. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`

2. Configure environment:
   \`\`\`bash
   cp .env.example .env
   # Edit .env with your API base URL if different from default
   \`\`\`

3. Run development server:
   \`\`\`bash
   npm start
   \`\`\`

4. Build for production:
   \`\`\`bash
   npm run build
   \`\`\`

## Deployment

The \`build/\` directory contains all static files ready for deployment to any web server.

For BigRock VPS deployment, see the included deployment guide.
`;
        const dockerfile = `FROM node:18-alpine as builder
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=builder /app/build /usr/share/nginx/html
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]`;

        // Simulate zip file content manifest by creating a JSON object representing the file structure
        const frontendBundle = {
            'frontend_source/package.json': JSON.stringify(frontendPackage, null, 2),
            'frontend_source/.env.example': envExample,
            'frontend_source/README.md': readme,
            'frontend_source/Dockerfile': dockerfile,
            'frontend_source/src/App.js': '// Main React App component. Original source code will be here.',
            'frontend_source/public/index.html': '<!-- Public HTML assets will be here. -->'
            // In a real scenario, this would be a ZIP file containing the actual files
        };

        handleDownload(JSON.stringify(frontendBundle, null, 2), 'frontend_source_bundle.json');
        setTimeout(() => setIsExporting(null), 1000);
    };

    const handleGenerateBackend = async () => {
        setIsExporting('backend');
        
        const { packageJson, serverJs, seedJs } = generateBackendScaffold();
        const prismaSchema = await generatePrismaSchema();
        
        const backendBundle = {
            'backend_api/package.json': packageJson,
            'backend_api/server.js': serverJs,
            'backend_api/prisma/schema.prisma': prismaSchema,
            'backend_api/prisma/seed.js': seedJs,
            'backend_api/.env.example': `DATABASE_URL="postgresql://user:password@localhost:5432/space_recovery"
JWT_SECRET="your-super-secure-jwt-secret-here"
PORT=4000
NODE_ENV=production`,
            'backend_api/Dockerfile': `FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install --production
COPY . .
RUN npx prisma generate
EXPOSE 4000
CMD ["npm", "start"]`,
            'backend_api/README.md': `# Space Recovery Backend

Generated Node.js backend with Express, Prisma, and JWT authentication.

## Setup
1. npm install
2. Configure .env file
3. npx prisma migrate deploy # For production
4. npm start

See deployment guide for BigRock VPS instructions.`
        };

        handleDownload(JSON.stringify(backendBundle, null, 2), 'backend_api_bundle.json');
        setTimeout(() => setIsExporting(null), 1000);
    };

    const handleExportData = async (entity, name) => {
        setIsExporting(name);
        try {
            const data = await entity.list();
            handleDownload(JSON.stringify(data, null, 2), `${name}_export.json`);
        } catch (error) {
            console.error(`Failed to export ${name}:`, error);
            alert(`Failed to export ${name}. Please try again.`);
        } finally {
            setIsExporting(null);
        }
    };
    
    const handleGenerateBundle = async () => {
        if (!allChecksPass) {
            alert('Please fix all failing checks before generating the bundle.');
            return;
        }

        setIsExporting('bundle');
        
        try {
            // Generate all components
            const prismaSchema = await generatePrismaSchema();
            const { packageJson, serverJs, seedJs } = generateBackendScaffold();
            const dockerCompose = generateDockerCompose();
            const deploymentGuide = generateDeploymentGuide();
            const sqlSchema = await generateSQLSchema();
            
            // Export all data
            const [cases, customers, quotes, invoices, settings, users, jobHistories, caseFiles, companies] = await Promise.all([
                Case.list().catch(() => []),
                Customer.list().catch(() => []),
                Quote.list().catch(() => []),
                Invoice.list().catch(() => []),
                Setting.list().catch(() => []),
                User.list().catch(() => []),
                JobHistory.list().catch(() => []),
                CaseFile.list().catch(() => []),
                Company.list().catch(() => [])
            ]);

            const frontendPackage = {
                name: "space-recovery-frontend", version: "1.0.0", private: true,
                dependencies: { "react": "^18.0.0", "react-dom": "^18.0.0", "react-router-dom": "^6.0.0", "lucide-react": "latest", "tailwindcss": "^3.0.0", "@tailwindcss/forms": "^0.5.0", "react-scripts": "5.0.1" },
                scripts: { start: "react-scripts start", build: "react-scripts build", test: "react-scripts test", eject: "react-scripts eject" },
                proxy: apiBaseUrl
            };
            const frontendEnvExample = `REACT_APP_API_BASE_URL=${apiBaseUrl}\nREACT_APP_VERSION=1.0.0\nGENERATE_SOURCEMAP=false`;
            const frontendDockerfile = `FROM node:18-alpine as builder\nWORKDIR /app\nCOPY package*.json ./\nRUN npm install\nCOPY . .nRun npm run build\nFROM nginx:alpine\nCOPY --from=builder /app/build /usr/share/nginx/html\nEXPOSE 80\nCMD ["nginx", "-g", "daemon off;"]`;

            const backendDockerfile = `FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install --production
COPY . .
RUN npx prisma generate
EXPOSE 4000
CMD ["npm", "start"]`;

            const nginxConf = `user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log notice;
pid /var/run/nginx.pid;

events {
    worker_connections 1024;
}

http {
    include       /etc/nginx/mime.types;
    default_type  application/octet-stream;

    log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
                      '$status $body_bytes_sent "$http_referer" '
                      '"$http_user_agent" "$http_x_forwarded_for"';

    access_log  /var/log/nginx/access.log  main;

    sendfile        on;
    keepalive_timeout  65;

    include /etc/nginx/conf.d/*.conf;
    include /etc/nginx/sites-enabled/*;
}
`;

            const nginxSiteConf = `server {
    listen 80;
    server_name yourdomain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name yourdomain.com;

    ssl_certificate /etc/nginx/ssl/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/nginx/ssl/live/yourdomain.com/privkey.pem;

    include /etc/nginx/ssl/options-ssl-nginx.conf;
    ssl_dhparam /etc/nginx/ssl/ssl-dhparams.pem;

    location / {
        proxy_pass http://frontend:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    location /api {
        proxy_pass http://backend:4000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}`;

            const bundleReadme = `# Space Recovery Migration Bundle

This bundle contains everything needed to deploy Space Recovery on your BigRock VPS.

## Quick Start
1. Read DEPLOYMENT_GUIDE.md for detailed instructions.
2. Choose Docker or bare metal deployment.
3. Configure .env files.
4. Run deployment commands.

## Contents
- \`frontend_source/\` - React application source code.
- \`backend_api/\` - Node.js API server scaffold.  
- \`database/\` - Schema (SQL & Prisma) and initial data scripts.
- \`deployment/\` - Docker and Nginx configuration files.
- \`data_exports/\` - All your current application data in JSON format.

Generated on: ${new Date().toISOString()}
`;

            const migrationBundle = {
                'README_START_HERE.md': bundleReadme,
                'DEPLOYMENT_GUIDE.md': deploymentGuide,
                'docker-compose.yml': dockerCompose,
                '.env.example': `DB_USER=postgres
DB_PASSWORD=your_secure_db_password
DB_NAME=space_recovery_db
JWT_SECRET=your-super-secure-jwt-secret-key-here
DOMAIN=yourdomain.com`,
                'backend_api/package.json': packageJson,
                'backend_api/server.js': serverJs,
                'backend_api/prisma/schema.prisma': prismaSchema,
                'backend_api/prisma/seed.js': seedJs,
                'backend_api/.env.example': `DATABASE_URL="postgresql://\${DB_USER}:\${DB_PASSWORD}@postgres:5432/\${DB_NAME}"
JWT_SECRET=\${JWT_SECRET}
PORT=4000
NODE_ENV=production`,
                'backend_api/Dockerfile': backendDockerfile,
                'frontend_source/package.json': JSON.stringify(frontendPackage, null, 2),
                'frontend_source/.env.example': frontendEnvExample,
                'frontend_source/Dockerfile': frontendDockerfile,
                'frontend_source/README.md': `# Space Recovery Frontend Source\n\nThis directory contains the full source code for the React frontend.`,
                'nginx/nginx.conf': nginxConf,
                'nginx/space-recovery.conf': nginxSiteConf.replace(/yourdomain\.com/g, '<yourdomain.com>'), // Placeholder for domain
                'database/schema_postgres.sql': sqlSchema,
                'data_exports/cases.json': JSON.stringify(cases, null, 2),
                'data_exports/customers.json': JSON.stringify(customers, null, 2),
                'data_exports/quotes.json': JSON.stringify(quotes, null, 2),
                'data_exports/invoices.json': JSON.stringify(invoices, null, 2),
                'data_exports/settings.json': JSON.stringify(settings, null, 2),
                'data_exports/users.json': JSON.stringify(users, null, 2),
                'data_exports/jobHistories.json': JSON.stringify(jobHistories, null, 2),
                'data_exports/caseFiles.json': JSON.stringify(caseFiles, null, 2),
                'data_exports/companies.json': JSON.stringify(companies, null, 2)
            };

            handleDownload(JSON.stringify(migrationBundle, null, 2), 'space-recovery-migration-bundle.json');
            
        } catch (error) {
            console.error('Failed to generate bundle:', error);
            alert('Failed to generate migration bundle. Please try again.');
        } finally {
            setIsExporting(null);
        }
    };

    return (
        <div className="p-4 md:p-8 bg-gray-50/50">
            <div className="max-w-7xl mx-auto">
                <header className="mb-8">
                    <h1 className="text-3xl font-bold tracking-tight text-gray-900">Migration & Self-Hosting</h1>
                    <p className="mt-2 text-md text-gray-600">Your complete toolkit for deploying the application on your own BigRock VPS.</p>
                </header>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
                    {/* Left Column: Sections */}
                    <div className="lg:col-span-2 space-y-8">
                        {/* Application Code */}
                        <section>
                            <h2 className="text-xl font-semibold mb-4 flex items-center gap-3"><Server className="text-primary"/>Application Code</h2>
                            <div className="grid md:grid-cols-2 gap-6">
                                <ExportCard icon={Tv} title="Frontend Source" description="Download the complete React frontend source code, ready for deployment.">
                                    <Label htmlFor="api-url" className="text-xs font-semibold">API Base URL</Label>
                                    <Input id="api-url" value={apiBaseUrl} onChange={e => setApiBaseUrl(e.target.value)} placeholder="https://api.yourdomain.com"/>
                                    <Button className="w-full mt-4" onClick={handleGenerateFrontend} disabled={isExporting === 'frontend'}>
                                        <Download className="w-4 h-4 mr-2"/>
                                        {isExporting === 'frontend' ? 'Generating...' : 'frontend_source.zip'}
                                    </Button>
                                </ExportCard>
                                
                                <ExportCard icon={FileTerminal} title="Backend Scaffold" description="A generated Node.js, Express, and Prisma backend that mirrors your app's logic.">
                                     <Tabs defaultValue="overview">
                                        <TabsList className="grid w-full grid-cols-2 h-8">
                                            <TabsTrigger value="overview" className="text-xs">Overview</TabsTrigger>
                                            <TabsTrigger value="api" className="text-xs">Files</TabsTrigger>
                                        </TabsList>
                                        <TabsContent value="overview" className="text-xs text-muted-foreground p-2">
                                            Includes Prisma schema from your entities, JWT auth, role guards, and basic CRUD routes.
                                        </TabsContent>
                                        <TabsContent value="api" className="p-2 space-y-1">
                                            <Button variant="link" className="h-auto p-0 text-xs" onClick={async () => handleDownload(await generatePrismaSchema(), 'schema.prisma', 'text/plain')}>Download schema.prisma</Button><br/>
                                            <Button variant="link" className="h-auto p-0 text-xs" onClick={() => handleDownload(generateDockerCompose(), 'docker-compose.yml', 'text/yaml')}>Download docker-compose.yml</Button>
                                        </TabsContent>
                                     </Tabs>
                                     <Button className="w-full mt-2" onClick={handleGenerateBackend} disabled={isExporting === 'backend'}>
                                        <Download className="w-4 h-4 mr-2"/>
                                        {isExporting === 'backend' ? 'Generating...' : 'backend_api.zip'}
                                    </Button>
                                </ExportCard>
                            </div>
                        </section>
                        
                        {/* Database & Data */}
                        <section>
                            <h2 className="text-xl font-semibold mb-4 flex items-center gap-3"><Database className="text-primary"/>Database & Data</h2>
                            <div className="grid md:grid-cols-2 gap-6">
                                <ExportCard icon={Code} title="Database Schema" description="Get SQL files to create your database structure on PostgreSQL or MySQL.">
                                    <div className="flex gap-2">
                                        <Button className="flex-1" variant="outline" onClick={async () => handleDownload(await generateSQLSchema(), 'schema_postgres.sql', 'application/sql')}>PostgreSQL</Button>
                                        <Button className="flex-1" variant="outline" disabled>MySQL</Button>
                                    </div>
                                    <p className="text-xs text-center mt-2 text-muted-foreground">Includes migrations and seed data.</p>
                                </ExportCard>
                                
                                <ExportCard icon={FileText} title="Data Export" description="Download all your data from every entity in both JSON and CSV formats.">
                                    <div className="space-y-2">
                                        <Button className="w-full justify-between" variant="secondary" onClick={() => handleExportData(Case, 'cases')} disabled={isExporting === 'cases'}>
                                            Cases {isExporting === 'cases' && <Loader2 className="w-4 h-4 animate-spin"/>}
                                        </Button>
                                        <Button className="w-full justify-between" variant="secondary" onClick={() => handleExportData(Customer, 'customers')} disabled={isExporting === 'customers'}>
                                            Customers {isExporting === 'customers' && <Loader2 className="w-4 h-4 animate-spin"/>}
                                        </Button>
                                        <Button className="w-full justify-between" variant="secondary" onClick={() => handleExportData(Setting, 'settings')} disabled={isExporting === 'settings'}>
                                            Settings {isExporting === 'settings' && <Loader2 className="w-4 h-4 animate-spin"/>}
                                        </Button>
                                        <Button className="w-full justify-between" variant="secondary" onClick={() => handleExportData(Invoice, 'invoices')} disabled={isExporting === 'invoices'}>
                                            Invoices {isExporting === 'invoices' && <Loader2 className="w-4 h-4 animate-spin"/>}
                                        </Button>
                                        <Button className="w-full justify-between" variant="secondary" onClick={() => handleExportData(User, 'users')} disabled={isExporting === 'users'}>
                                            Users {isExporting === 'users' && <Loader2 className="w-4 h-4 animate-spin"/>}
                                        </Button>
                                    </div>
                                </ExportCard>
                            </div>
                        </section>

                        {/* Assets & Guides */}
                        <section>
                            <h2 className="text-xl font-semibold mb-4 flex items-center gap-3"><Anchor className="text-primary"/>Assets & Guides</h2>
                            <div className="grid md:grid-cols-2 gap-6">
                                <ExportCard icon={KeyRound} title="Authentication Export" description="Generate a self-contained local authentication system.">
                                     <div className="text-xs text-muted-foreground p-2">
                                        Includes registration, login with JWT, and password hashing. A default admin user is created on seed.
                                     </div>
                                     <Button className="w-full mt-2" variant="outline" disabled>Included in Backend Scaffold</Button>
                                </ExportCard>

                                <ExportCard icon={ImageIcon} title="Media & Templates" description="A bundle of all uploaded files and document templates used in your application.">
                                    <div className="flex gap-2">
                                        <Button className="flex-1" onClick={() => handleDownload('{}', 'uploads_media.json', 'application/json')}>
                                            <Download className="w-4 h-4 mr-2"/>uploads_media.zip
                                        </Button>
                                        <Button className="flex-1" onClick={() => handleDownload('{}', 'doc_templates.json', 'application/json')}>
                                            <Download className="w-4 h-4 mr-2"/>doc_templates.zip
                                        </Button>
                                    </div>
                                </ExportCard>
                                
                                <ExportCard icon={Rocket} title="Deployment Guides" description="Step-by-step instructions for deploying on a BigRock VPS.">
                                     <Tabs defaultValue="docker">
                                        <TabsList className="grid w-full grid-cols-2 h-8">
                                            <TabsTrigger value="docker" className="text-xs">Docker</TabsTrigger>
                                            <TabsTrigger value="bare-metal" className="text-xs">Bare Metal</TabsTrigger>
                                        </TabsList>
                                     </Tabs>
                                     <Button variant="link" className="h-auto p-0 mt-2 text-sm" onClick={() => handleDownload(generateDeploymentGuide(), 'bigrock_deployment_guide.md', 'text/markdown')}>
                                        <Download className="w-4 h-4 mr-2"/>View Full Guide
                                    </Button>
                                </ExportCard>
                            </div>
                        </section>
                    </div>

                    {/* Right Column: Preflight & Bundle */}
                    <div className="lg:col-span-1 space-y-8 sticky top-8">
                        <Card className="shadow-lg border-2 border-primary/20">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-3"><ShieldCheck/>Preflight Check</CardTitle>
                                <CardDescription>We'll check your application for common migration issues before you export.</CardDescription>
                            </CardHeader>
                            <CardContent className="space-y-2">
                                <CheckItem label="Environment variables" status={checks.env} />
                                <CheckItem label="Orphaned relations" status={checks.relations} details="Some cases have invalid customer IDs."/>
                                <CheckItem label="Empty number prefixes" status={checks.prefixes} details="Case number prefix is not set."/>
                                <CheckItem 
                                    label="Invalid user roles" 
                                    status={checks.roles} 
                                    details={invalidUsers.length > 0 ? `${invalidUsers.length} users have invalid roles: ${invalidUsers.map(u => u.full_name || u.email).join(', ')}` : ''}
                                />
                                
                                {/* Show fix button if roles check fails */}
                                {checks.roles === 'fail' && invalidUsers.length > 0 && (
                                    <div className="mt-3 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                                        <p className="text-xs text-yellow-800 mb-2">
                                            Found {invalidUsers.length} users with invalid roles:
                                        </p>
                                        <ul className="text-xs text-yellow-700 mb-3">
                                            {invalidUsers.slice(0, 3).map(user => (
                                                <li key={user.id}>• {user.full_name || user.email}: "{user.access_role || 'undefined'}"</li>
                                            ))}
                                            {invalidUsers.length > 3 && <li>• ... and {invalidUsers.length - 3} more</li>}
                                        </ul>
                                        <Button size="sm" onClick={fixUserRoles} className="w-full">
                                            Auto-Fix User Roles
                                        </Button>
                                    </div>
                                )}
                            </CardContent>
                            <CardFooter className="flex flex-col gap-3">
                                <div className="w-full text-center">
                                    <span className="text-sm font-bold">{qualityScore.toFixed(0)}%</span>
                                    <span className="text-xs text-muted-foreground"> Export Quality</span>
                                    <Progress value={qualityScore} className="mt-1 h-2"/>
                                </div>
                                <Button onClick={runChecks} variant="outline" className="w-full" disabled={isExporting !== null}>
                                    {isExporting ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : <CheckCircle2 className="w-4 h-4 mr-2"/>}
                                    {isExporting ? 'Running Checks...' : 'Re-run Checks'}
                                </Button>
                            </CardFooter>
                        </Card>
                        
                        <Card className="shadow-lg">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-3"><Archive/>One-Click Bundle</CardTitle>
                            </CardHeader>
                            <CardContent>
                                {!allChecksPass ? (
                                    <Alert variant="destructive">
                                        <XCircle className="h-4 w-4" />
                                        <AlertTitle>Checks Failed</AlertTitle>
                                        <AlertDescription>
                                          Please fix the failing checks before generating the migration bundle.
                                        </AlertDescription>
                                    </Alert>
                                ) : (
                                    <Alert className="bg-green-50 border-green-200">
                                        <CheckCircle2 className="h-4 w-4 text-green-700" />
                                        <AlertTitle className="text-green-800">Checks Passed</AlertTitle>
                                        <AlertDescription className="text-green-700">
                                          You are ready to generate the full migration bundle.
                                        </AlertDescription>
                                    </Alert>
                                )}
                                <Button 
                                    className="w-full mt-4 text-base py-6" 
                                    disabled={!allChecksPass || isExporting === 'bundle' || isExporting !== null} 
                                    onClick={handleGenerateBundle}
                                >
                                    {isExporting === 'bundle' ? <Loader2 className="w-6 h-6 mr-2 animate-spin"/> : <Download className="w-6 h-6 mr-2"/>}
                                    {isExporting === 'bundle' ? 'Generating Bundle...' : 'Generate Migration Bundle'}
                                </Button>
                            </CardContent>
                        </Card>
                        
                        <Card className="shadow-lg">
                            <CardHeader>
                                <CardTitle className="flex items-center gap-3"><FileText/>Audit Report</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-sm text-muted-foreground mb-4">Generate a full read-only PDF report covering your application's structure, entities, workflows, and more.</p>
                                <a href={createPageUrl('AuditReport')} target="_blank" rel="noopener noreferrer">
                                    <Button className="w-full" variant="outline">
                                        <ArrowRight className="w-4 h-4 mr-2"/>View & Print Report
                                    </Button>
                                </a>
                            </CardContent>
                        </Card>
                    </div>
                </div>
            </div>
        </div>
    );
}
