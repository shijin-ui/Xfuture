import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Case } from '@/api/entities';
import { Customer } from '@/api/entities';
import { Company } from '@/api/entities';
import { User } from '@/api/entities';
import { JobHistory } from '@/api/entities';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Plus, ArrowLeft, Save, X, Printer, FileText, Tag, UserPlus, HardDrive, Eye, EyeOff, Briefcase, Info, Trash2 } from 'lucide-react';
import SearchableSelect from '../components/SearchableSelect';
import { getSettingsByCategory } from '../components/utils/settingsLoader';
import { previewNextEntityNumber, generateEntityNumber, prepareEntityForCreation } from '../components/utils/entityNumbering';
import ServerDrivesDialog from '../components/ServerDrivesDialog';
import { Badge } from '@/components/ui/badge';
import MultiSelect from '../components/common/MultiSelect';

const NewCustomerDialog = ({ onCustomerCreated, open, setOpen }) => {
  const [customerData, setCustomerData] = useState({
    full_name: '',
    customer_code: '',
    email: '',
    secondary_email: '',
    phone_number: '',
    phone_country_code: '+968',
    secondary_phone: '',
    secondary_phone_country_code: '+968',
    city: '',
    country: 'Oman',
    address: '',
    company_name: '',
    customer_group: 'Individual',
    notes: ''
  });

  const [companies, setCompanies] = useState([]);
  const [cities, setCities] = useState([]);
  const [customerGroups, setCustomerGroups] = useState([]);
  const [countries, setCountries] = useState([]);
  const [showNewCompanyDialog, setShowNewCompanyDialog] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [newCompanyData, setNewCompanyData] = useState({
    company_name: '',
    company_code: '',
    vat_number: '',
    url: '',
    industry: '',
    country: 'Oman',
    city: '',
    address: ''
  });

  const [industries, setIndustries] = useState([]);

  useEffect(() => {
    if (open) {
      const loadInitialData = async () => {
        try {
          const nextCustomerCode = await previewNextEntityNumber('Customer');
          setCustomerData(prev => ({ ...prev, customer_code: nextCustomerCode }));

          const nextCompanyCode = await previewNextEntityNumber('Company');
          setNewCompanyData(prev => ({ ...prev, company_code: nextCompanyCode }));
        } catch (error) {
          console.error('Failed to preview entity numbers:', error);
        }
        
        try {
          const [companiesData, citiesData, groupsData, countriesData, industriesData] = await Promise.all([
            Company.list(),
            getSettingsByCategory('Cities'),
            getSettingsByCategory('Customer Groups'),
            getSettingsByCategory('Countries'),
            getSettingsByCategory('Industries')
          ]);
          setCompanies(companiesData || []);
          
          const uniqueCities = [...new Set(citiesData || [])];
          setCities(uniqueCities.map(cityName => ({ city_name: cityName, country: 'Oman' })));

          setCustomerGroups([...new Set(groupsData || ['Individual', 'Corporate', 'VIP', 'Government', 'Education'])]);
          setCountries([...new Set(countriesData || ['Oman'])]);
          setIndustries([...new Set(industriesData || ['Data Recovery', 'IT Services', 'Technology', 'Healthcare', 'Finance', 'Education', 'Government'])]);
        } catch (error) {
          console.error('Failed to fetch data:', error);
          setCompanies([]);
          setCities([]);
          setCustomerGroups(['Individual', 'Corporate', 'VIP', 'Government', 'Education']);
          setCountries(['Oman']);
          setIndustries(['Data Recovery', 'IT Services', 'Technology']);
        }
      };
      loadInitialData();
    }
  }, [open]);

  const handleAddNewCompany = async () => {
    if (!newCompanyData.company_name.trim()) {
      alert('Company name cannot be empty.');
      return;
    }

    try {
      const finalCompanyData = await prepareEntityForCreation('Company', newCompanyData);
      const newCompany = await Company.create(finalCompanyData);
      setCompanies(prev => [...prev, newCompany]);
      setCustomerData(prev => ({ ...prev, company_name: newCompany.company_name }));
      
      const nextCompanyCode = await previewNextEntityNumber('Company');
      setNewCompanyData({ 
        company_name: '', 
        company_code: nextCompanyCode, 
        vat_number: '', 
        url: '', 
        industry: '', 
        country: 'Oman', 
        city: '', 
        address: '' 
      });
      setShowNewCompanyDialog(false);
    } catch (error) {
      console.error('Failed to create company:', error);
      alert('Failed to create company.');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!customerData.full_name || !customerData.email) {
      alert('Please fill in required fields (Full Name, Email).');
      return;
    }

    setIsSubmitting(true);
    try {
      const finalCustomerData = await prepareEntityForCreation('Customer', customerData);
      const newCustomer = await Customer.create(finalCustomerData);
      onCustomerCreated(newCustomer);
      setOpen(false);
      
      const nextCustomerCode = await previewNextEntityNumber('Customer');
      setCustomerData({
        full_name: '',
        customer_code: nextCustomerCode,
        email: '',
        secondary_email: '',
        phone_number: '',
        phone_country_code: '+968',
        secondary_phone: '',
        secondary_phone_country_code: '+968',
        city: '',
        country: 'Oman',
        address: '',
        company_name: '',
        customer_group: 'Individual',
        notes: ''
      });
    } catch (error) {
      console.error('Failed to create customer:', error);
      alert('Failed to create customer');
    } finally {
      setIsSubmitting(false);
    }
  };

  const countryCodes = [
    { code: '+968', flag: '🇴🇲', country: 'Oman' },
    { code: '+971', flag: '🇦🇪', country: 'UAE' },
    { code: '+966', flag: '🇸🇦', country: 'Saudi Arabia' },
    { code: '+965', flag: '🇰🇼', country: 'Kuwait' },
    { code: '+974', flag: '🇶🇦', country: 'Qatar' },
    { code: '+973', flag: '🇧🇭', country: 'Bahrain' },
    { code: '+1', flag: '🇺🇸', country: 'USA' },
    { code: '+44', flag: '🇬🇧', country: 'UK' },
    { code: '+91', flag: '🇮🇳', country: 'India' }
  ];

  return (
    <>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-3xl">
           <DialogHeader>
            <div className="flex items-center justify-between">
                <DialogTitle className="text-xl font-semibold text-gray-800">Add New Customer</DialogTitle>
                <Badge variant="outline" className="text-sm">#{customerData.customer_code}</Badge>
            </div>
            <DialogDescription>
                Create a new customer profile. Fields marked with * are required.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="grid grid-cols-2 gap-x-6 gap-y-4 py-4">
            <div className="col-span-2">
              <Label className="font-semibold text-gray-700">Full Name <span className="text-red-500">*</span></Label>
              <Input
                value={customerData.full_name}
                onChange={(e) => setCustomerData({...customerData, full_name: e.target.value})}
                placeholder="Customer's full name"
                required
                className="mt-1"
              />
            </div>
            
            <div>
              <Label className="font-semibold text-gray-700">Primary Phone</Label>
              <div className="flex mt-1">
                <Select
                  value={customerData.phone_country_code}
                  onValueChange={(value) => setCustomerData({...customerData, phone_country_code: value})}
                >
                  <SelectTrigger className="w-28">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {countryCodes.map(cc => (
                      <SelectItem key={cc.code} value={cc.code}>
                        <span className="flex items-center text-sm">
                          <span className="mr-2">{cc.flag}</span>
                          {cc.code}
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Input
                  value={customerData.phone_number}
                  onChange={(e) => setCustomerData({...customerData, phone_number: e.target.value})}
                  placeholder="Phone Number"
                  className="flex-1 ml-2"
                />
              </div>
            </div>

            <div>
              <Label className="font-semibold text-gray-700">Secondary Phone</Label>
              <div className="flex mt-1">
                <Select
                  value={customerData.secondary_phone_country_code}
                  onValueChange={(value) => setCustomerData({...customerData, secondary_phone_country_code: value})}
                >
                  <SelectTrigger className="w-28">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {countryCodes.map(cc => (
                      <SelectItem key={cc.code} value={cc.code}>
                        <span className="flex items-center text-sm">
                          <span className="mr-2">{cc.flag}</span>
                          {cc.code}
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Input
                  value={customerData.secondary_phone}
                  onChange={(e) => setCustomerData({...customerData, secondary_phone: e.target.value})}
                  placeholder="Secondary Phone"
                  className="flex-1 ml-2"
                />
              </div>
            </div>

            <div>
              <Label className="font-semibold text-gray-700">Email <span className="text-red-500">*</span></Label>
              <Input
                type="email"
                value={customerData.email}
                onChange={(e) => setCustomerData({...customerData, email: e.target.value})}
                placeholder="email address"
                required
                className="mt-1"
              />
            </div>

            <div>
              <Label className="font-semibold text-gray-700">Secondary Email</Label>
              <Input
                type="email"
                value={customerData.secondary_email}
                onChange={(e) => setCustomerData({...customerData, secondary_email: e.target.value})}
                placeholder="secondary email"
                className="mt-1"
              />
            </div>
            
            <div className="col-span-2">
              <Label className="font-semibold text-gray-700">Company</Label>
              <SearchableSelect
                value={customerData.company_name}
                onValueChange={(value) => setCustomerData({...customerData, company_name: value})}
                placeholder="Search and select company..."
                options={companies.map(company => ({
                  value: company.company_name,
                  label: company.company_name,
                  subtitle: company.city ? `${company.city}${company.country ? `, ${company.country}` : ''}` : company.country || ''
                }))}
                searchPlaceholder="Type to search companies..."
                className="mt-1"
              />
              <button
                type="button"
                onClick={() => setShowNewCompanyDialog(true)}
                className="text-xs text-blue-600 hover:text-blue-800 mt-1"
              >
                Or Add New Company
              </button>
            </div>
            
            <div>
              <Label className="font-semibold text-gray-700">Group</Label>
              <SearchableSelect
                value={customerData.customer_group}
                onValueChange={(value) => setCustomerData({...customerData, customer_group: value})}
                options={customerGroups.map(opt => ({ label: opt, value: opt }))}
                placeholder="Select customer group"
                searchPlaceholder="Search groups..."
                className="mt-1"
              />
            </div>

            <div>
              <Label className="font-semibold text-gray-700">Country</Label>
              <SearchableSelect
                value={customerData.country}
                onValueChange={(value) => { 
                  setCustomerData({...customerData, country: value, city: ''});
                }}
                options={countries.map(opt => ({ label: opt, value: opt }))}
                placeholder="Select Country"
                searchPlaceholder="Search countries..."
                className="mt-1"
              />
            </div>

            <div>
              <Label className="font-semibold text-gray-700">City</Label>
              <SearchableSelect
                value={customerData.city}
                onValueChange={(value) => setCustomerData({...customerData, city: value})}
                options={cities.filter(city => city.country === customerData.country).map(city => ({ label: city.city_name, value: city.city_name }))}
                placeholder="Select City"
                searchPlaceholder="Search cities..."
                creatable={true}
                className="mt-1"
              />
            </div>

            <div>
                <Label className="font-semibold text-gray-700">Address</Label>
                <Input
                    value={customerData.address}
                    onChange={(e) => setCustomerData({...customerData, address: e.target.value})}
                    placeholder="Full address"
                    className="mt-1"
                />
            </div>

            <div className="col-span-2">
              <Label className="font-semibold text-gray-700">Notes</Label>
              <Textarea
                value={customerData.notes}
                onChange={(e) => setCustomerData({...customerData, notes: e.target.value})}
                placeholder="Any notes about the customer"
                rows={2}
                className="mt-1"
              />
            </div>

            <DialogFooter className="col-span-2 mt-4 pt-4 border-t">
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={isSubmitting || !customerData.full_name || !customerData.email} className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                {isSubmitting ? 'Adding...' : 'Add Customer'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={showNewCompanyDialog} onOpenChange={setShowNewCompanyDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Company</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 py-4">
            <div className="col-span-2">
              <Label>Company Name <span className="text-red-500">*</span></Label>
              <Input
                value={newCompanyData.company_name}
                onChange={(e) => setNewCompanyData({...newCompanyData, company_name: e.target.value})}
                placeholder="Enter company name"
              />
            </div>
            <div>
              <Label>Company Code</Label>
              <Input 
                value={newCompanyData.company_code}
                readOnly
                className="bg-gray-50 text-gray-600"
                title="Auto-generated from Settings"
              />
            </div>
            <div>
              <Label>VAT Number</Label>
              <Input
                value={newCompanyData.vat_number}
                onChange={(e) => setNewCompanyData({...newCompanyData, vat_number: e.target.value})}
                placeholder="Enter VAT registration number"
              />
            </div>
            <div>
              <Label>Website URL</Label>
              <Input 
                placeholder="https://company.com"
                value={newCompanyData.url}
                onChange={(e) => setNewCompanyData({...newCompanyData, url: e.target.value})}
              />
            </div>
            <div>
              <Label>Industry</Label>
              <SearchableSelect
                value={newCompanyData.industry}
                onValueChange={(value) => setNewCompanyData({...newCompanyData, industry: value})}
                options={industries.map(opt => ({ label: opt, value: opt }))}
                placeholder="Select industry"
                creatable={false}
              />
            </div>
            <div>
              <Label>Country</Label>
              <SearchableSelect
                value={newCompanyData.country}
                onValueChange={(value) => setNewCompanyData({...newCompanyData, country: value, city: ''})}
                options={countries.map(opt => ({ label: opt, value: opt }))}
                placeholder="Select country"
              />
            </div>
            <div>
              <Label>City</Label>
              <SearchableSelect
                value={newCompanyData.city}
                onValueChange={(value) => setNewCompanyData({...newCompanyData, city: value})}
                options={cities.filter(city => city.country === newCompanyData.country).map(city => ({ label: city.city_name, value: city.city_name }))}
                placeholder="Select city"
                searchPlaceholder="Search cities..."
                creatable={true}
              />
            </div>
            <div className="col-span-2">
              <Label>Address</Label>
              <Input 
                placeholder="Full address"
                value={newCompanyData.address}
                onChange={(e) => setNewCompanyData({...newCompanyData, address: e.target.value})}
              />
            </div>
          </div>
          <DialogFooter className="pt-4">
            <Button variant="outline" onClick={() => setShowNewCompanyDialog(false)}>Cancel</Button>
            <Button onClick={handleAddNewCompany}>Add Company</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

const BulkMemoryCardsDialog = ({ open, onOpenChange, onSave, brands, capacities }) => {
    const [batches, setBatches] = useState([{ quantity: 1, capacity: '', brand: '', prefix: 'MC' }]);

    useEffect(() => {
        if (open) {
            setBatches([{ quantity: 1, capacity: '', brand: '', prefix: 'MC' }]);
        }
    }, [open]);

    const handleBatchChange = (index, field, value) => {
        const newBatches = [...batches];
        newBatches[index][field] = value;
        setBatches(newBatches);
    };

    const addBatch = () => {
        setBatches([...batches, { quantity: 1, capacity: '', brand: '', prefix: 'MC' }]);
    };

    const removeBatch = (index) => {
        setBatches(batches.filter((_, i) => i !== index));
    };

    const handleSave = () => {
        const memoryCards = [];
        let startNumber = 1;

        for (const batch of batches) {
            if (batch.quantity > 0 && batch.capacity) {
                for (let i = 0; i < batch.quantity; i++) {
                    const serial = `${batch.prefix || 'MC'}-${String(startNumber).padStart(3, '0')}`;
                    memoryCards.push({
                        media_type: 'Memory Card',
                        brand: batch.brand || 'N/A',
                        media_model: serial,
                        media_serial_number: serial,
                        capacity: batch.capacity,
                        condition: 'Good',
                        role: 'Patient',
                        accessories: []
                    });
                    startNumber++;
                }
            }
        }
        
        if (memoryCards.length === 0) {
            alert('Please configure at least one batch with quantity and capacity.');
            return;
        }

        onSave(memoryCards);
    };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>Bulk Add Memory Card Batches</DialogTitle>
          <DialogDescription>
            Add multiple groups of memory cards with different quantities and capacities.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4 max-h-[60vh] overflow-y-auto">
            {batches.map((batch, index) => (
                <div key={index} className="grid grid-cols-5 gap-4 items-end p-4 border rounded-lg bg-gray-50">
                    <div>
                        <Label className="text-sm font-medium text-gray-700">Quantity</Label>
                        <Input 
                            type="number" 
                            value={batch.quantity} 
                            onChange={e => handleBatchChange(index, 'quantity', parseInt(e.target.value) || 1)} 
                            min="1" 
                            className="mt-1"
                        />
                    </div>
                    
                    <div>
                        <Label className="text-sm font-medium text-gray-700">Capacity</Label>
                        <SearchableSelect 
                            value={batch.capacity} 
                            onValueChange={val => handleBatchChange(index, 'capacity', val)} 
                            options={capacities.map(c => ({ label: c, value: c }))} 
                            placeholder="Select..." 
                            creatable={true} 
                            className="mt-1"
                        />
                    </div>
                    
                    <div>
                        <Label className="text-sm font-medium text-gray-700">Brand</Label>
                        <SearchableSelect 
                            value={batch.brand} 
                            onValueChange={val => handleBatchChange(index, 'brand', val)} 
                            options={brands.map(b => ({ label: b, value: b }))} 
                            placeholder="Select..." 
                            creatable={true} 
                            className="mt-1"
                        />
                    </div>
                    
                    <div>
                        <Label className="text-sm font-medium text-gray-700">Prefix</Label>
                        <Input 
                            value={batch.prefix} 
                            onChange={e => handleBatchChange(index, 'prefix', e.target.value)} 
                            placeholder="e.g., MC, SD" 
                            className="mt-1"
                        />
                    </div>
                    
                    <div>
                        <Button 
                            variant="destructive" 
                            size="icon" 
                            onClick={() => removeBatch(index)}
                            className="mt-6"
                        >
                            <Trash2 className="w-4 h-4" />
                        </Button>
                    </div>
                </div>
            ))}
            
            <Button variant="outline" onClick={addBatch} className="w-full mt-2">
                <Plus className="w-4 h-4 mr-2" />
                Add Another Batch
            </Button>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSave}>
            Add {batches.reduce((sum, b) => sum + (b.quantity || 0), 0)} Cards
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};


export default function NewCasePage() {
  const navigate = useNavigate();
  const [customers, setCustomers] = useState([]);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [showNewCustomerDialog, setShowNewCustomerDialog] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [postSaveActions, setPostSaveActions] = useState({ show: false, caseId: null, caseNumber: null });
  const [showPassword, setShowPassword] = useState(false);
  const [caseNumber, setCaseNumber] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [isServerDrivesDialogOpen, setIsServerDrivesDialogOpen] = useState(false);

  const [deviceTypes, setDeviceTypes] = useState([]);
  const [brands, setBrands] = useState([]);
  const [capacities, setCapacities] = useState([]);
  const [accessoriesOptions, setAccessoriesOptions] = useState([]);

  const initialFormData = {
    client_reference: '',
    service_type: 'Data Recovery',
    priority: 'Low',
    welcome_email: true,
    welcome_sms: false,
    service_location: 'In Lab',
    device_password: '',
  };

  const [formData, setFormData] = useState(initialFormData);

  const initialDeviceInfo = {
    media_type: '',
    brand: '',
    media_model: '',
    media_serial_number: '',
    capacity: '',
    condition: 'Good',
    accessories: [],
    device_problem: '',
    important_data: '',
    pcb_no: '',
    part_no: '',
    dom: '',
    dcm_mlc: '',
    interface: '',
    made_in: '',
    firmware: '',
    encryption: '',
    platter_no: '',
    head_no: '',
    ph: '',
    preamp: ''
  };
  const [deviceInfo, setDeviceInfo] = useState(initialDeviceInfo);
  const [additionalDevices, setAdditionalDevices] = useState([]);
  const [showBulkMemoryDialog, setShowBulkMemoryDialog] = useState(false);

  const [serverDrives, setServerDrives] = useState([]);

  const serviceTypes = [
    "Data Recovery", "Data Destruction", "Forensic Analysis", "Hardware Repair", "IT Services",
    "CCTV Installation", "Networking", "System Setup", "Consultation"
  ];

  const serviceProblems = {
    "Data Recovery": [
      "Not working", "Won't turn on", "Won't boot", "Clicking Sound", "Grinding noise", "Beeping sounds", "Head crash",
      "Motor failure", "PCB failure", "Firmware corruption", "Bad sectors", "Platter damage", "Fell Down",
      "Dropped device", "Physical impact", "Crushed/bent", "Broken connector", "Screen cracked", "Water Damage",
      "Liquid spill", "Fire Damage", "Heat damage", "Smoke damage", "Flood damage", "Corrosion", "Deleted",
      "Accidentally deleted files", "Formatted", "Partition lost", "Partition Missing", "File corrupted", "Corrupted",
      "Data overwritten", "Lost photos/videos", "Missing documents", "Not Booting", "Boot failure", "OS won't start",
      "Logo Stuck", "Stuck on boot screen", "Blue screen", "Kernel panic", "System crash", "Frozen system",
      "Slow Responding", "Very slow performance", "Password Forget", "Locked device", "Encrypted Drive",
      "BitLocker locked", "FileVault locked", "Ransomware", "Virus attack", "Malware infection",
      "Encrypted by malware", "Asking Format", "Drive not recognized", "Can't Access", "Access denied",
      "Disk not detected", "Not showing up", "Unallocated space", "RAW file system", "Unknown file system",
      "Power Failure", "Power surge damage", "Electrical damage", "Lightning strike", "UPS failure", "RAID Rebuild",
      "RAID failure", "RAID degraded", "Multiple drive failure", "RAID controller failure", "RAID configuration lost",
      "iPhone Unavailable", "iPhone disabled", "iPad locked", "Android won't start", "Bootloop", "Factory reset",
      "iTunes error", "Recovery mode stuck", "DFU mode", "Server crash", "Database corruption", "Exchange corruption",
      "VM failure", "Hypervisor failure", "SAN failure", "NAS failure", "CCTV Recovery", "DVR failure",
      "NVR corruption", "Surveillance data lost", "Security footage missing", "Tape drive failure", "Optical disc error",
      "CD/DVD scratched", "Blu-ray unreadable", "Memory card error", "SD card corrupted", "USB not working",
      "External drive failure", "Reset", "Factory reset done", "System restore failed", "Update failed",
      "Upgrade error", "Installation error", "Driver corruption", "Cloud sync error", "OneDrive corruption",
      "Google Drive error", "Dropbox sync issue", "Network drive failure", "Forensic imaging needed",
      "Evidence recovery", "Legal hold required", "Chain of custody", "Deleted browser history",
      "Email recovery needed", "Disabled", "Write protected", "Read-only mode", "Disk full recovery",
      "Recycle bin recovery", "Temporary files lost", "System backup failed", "Clone operation failed",
      "Migration error", "Others"
    ],
    "IT Services": ["Network Setup Required", "WiFi Configuration", "System Installation", "Software Setup", "Hardware Installation", "Troubleshooting", "Maintenance Required", "Upgrade Needed", "Configuration Issue", "Others"],
    "CCTV Installation": ["New Installation", "Camera Replacement", "System Upgrade", "Configuration Required", "Maintenance", "Repair Needed", "Others"],
    "Networking": ["Network Setup", "Router Configuration", "Switch Installation", "Cable Installation", "Network Troubleshooting", "WiFi Setup", "Others"],
    "System Setup": ["New System Setup", "Operating System Installation", "Software Installation", "Data Migration", "System Configuration", "Others"],
    "Consultation": ["Technical Consultation", "System Assessment", "Security Audit", "Performance Analysis", "Recommendation Required", "Others"],
    "Hardware Repair": ["Component Replacement", "Diagnostic Required", "Power Issue", "Display Issue", "Overheating", "Software Glitch", "Physical Damage", "Others"],
    "Data Destruction": ["Secure Erase Needed", "Physical Shredding", "Degaussing Required", "Data Overwrite", "Compliance Audit", "Others"],
    "Forensic Analysis": ["Digital Evidence Collection", "Malware Analysis", "Incident Response", "Data Carving", "E-Discovery", "Others"]
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const customerData = await Customer.list();
        setCustomers(customerData);

        const [
          deviceTypesData, brandsData, capacitiesData, accessoriesData, currentUserData
        ] = await Promise.all([
          getSettingsByCategory('Device Types'), getSettingsByCategory('Brands'),
          getSettingsByCategory('Capacities'), getSettingsByCategory('Accessories'), User.me()
        ]);
        setDeviceTypes([...new Set(deviceTypesData)]);
        setBrands([...new Set(brandsData)]);
        setCapacities([...new Set(capacitiesData)]);
        setAccessoriesOptions([...new Set(accessoriesData)]);
        setCurrentUser(currentUserData);
      } catch (error) {
        console.error('Failed to fetch initial data:', error);
      }
    };
    fetchData();
  }, []);
  

  useEffect(() => {
    const loadCaseNumber = async () => {
      try {
        const nextNum = await previewNextEntityNumber('Case');
        setCaseNumber(nextNum);
      } catch (error) {
        console.error('Failed to preview Case Number:', error);
        setCaseNumber(`C-${Date.now().toString().slice(-5)}`);
      }
    };
    if (!postSaveActions.show) {
      loadCaseNumber();
    }
  }, [postSaveActions.show]);

  const validateForm = () => {
    const errors = [];
    if (!selectedCustomer) errors.push('Please select a client.');
    if (!formData.service_type) errors.push('Please select a service type.');
    
    const isDeviceRelatedService = ['Data Recovery', 'Data Destruction', 'Forensic Analysis', 'Hardware Repair'].includes(formData.service_type);
    
    if (isDeviceRelatedService) {
      const isServerCase = deviceInfo.media_type?.toLowerCase().includes('server');

      if (isServerCase) {
        if (serverDrives.length === 0) errors.push('For server cases, at least one drive must be added.');
      } else {
        if (!deviceInfo.media_type) errors.push('Media Type is required for this service type.');
        if (!deviceInfo.media_serial_number) {
          errors.push('Serial Number is required for the primary device.');
        }
      }
      if (!deviceInfo.device_problem) errors.push('Device Problem description is required.');
    }

    additionalDevices.forEach((device, index) => {
      if (isDeviceRelatedService) {
        if (!device.media_type) {
          errors.push(`Media Type is required for Additional Device ${index + 1}.`);
        }
        if (!device.media_serial_number) {
          errors.push(`Serial Number is required for Additional Device ${index + 1}.`);
        }
      }
    });

    if (errors.length > 0) {
      alert('Please fix the following errors:\n\n' + errors.join('\n'));
      return false;
    }
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    setIsSubmitting(true);
    try {
      const currentCaseNumber = await generateEntityNumber('Case');
      
      const devicesToSave = [];
      
      const isServerCase = deviceInfo.media_type?.toLowerCase().includes('server');
      
      if (isServerCase) {
        devicesToSave.push(...serverDrives.map(drive => ({
            ...drive, 
            role: 'Patient',
            device_status: 'In Lab', 
            registered_date: new Date().toISOString(),
            registered_by: currentUser?.email || 'System',
            accessories: Array.isArray(drive.accessories) ? drive.accessories.join(', ') : ''
        })));
      } else if (deviceInfo.media_type) {
        devicesToSave.push({
          ...deviceInfo, 
          accessories: deviceInfo.accessories.join(', '),
          role: 'Patient',
          device_status: 'In Lab', 
          registered_date: new Date().toISOString(),
          registered_by: currentUser?.email || 'System'
        });
      }
      
      devicesToSave.push(...additionalDevices.map(device => ({
        ...device,
        accessories: Array.isArray(device.accessories) ? device.accessories.join(', ') : '',
        device_status: 'In Lab',
        registered_date: new Date().toISOString(),
        registered_by: currentUser?.email || 'System'
      })));

      const caseData = {
        ...formData, 
        case_number: currentCaseNumber, 
        customer_id: selectedCustomer.id,
        status: formData.service_location === 'On-Site' ? 'Scheduled' : 'Received',
        priority: formData.priority || 'Normal', 
        assigned_engineer: '', 
        devices: devicesToSave,
        device_problem: deviceInfo.device_problem || '',
        important_data: deviceInfo.important_data || ''
      };
      
      const createdCase = await Case.create(caseData);
      await JobHistory.create({
        case_id: createdCase.id, action_type: "Case Created",
        description: `Case #${currentCaseNumber} created for ${selectedCustomer.full_name}. Service: ${formData.service_type}. Devices: ${devicesToSave.length} device(s) registered.`,
        performed_by: currentUser?.email || 'System', timestamp: new Date().toISOString()
      });
      setPostSaveActions({ show: true, caseId: createdCase.id, caseNumber: currentCaseNumber });
    } catch (error) {
      console.error('Error creating case:', error);
      alert('Failed to create case. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCustomerCreated = (newCustomer) => {
    setCustomers(prev => [...prev, newCustomer]);
    setSelectedCustomer(newCustomer);
    setShowNewCustomerDialog(false);
  };

  const handleServerDrivesUpdate = (drives) => {
    setServerDrives(drives);
    setDeviceInfo(prev => ({ ...prev, media_serial_number: `${drives.length} drives in array` }));
  };

  const handleCreateAnother = () => {
    setFormData(initialFormData);
    setDeviceInfo(initialDeviceInfo);
    setSelectedCustomer(null);
    setServerDrives([]);
    setAdditionalDevices([]);
    setPostSaveActions({ show: false, caseId: null, caseNumber: null });
  };

  const handleGoToProfile = () => {
    window.open(createPageUrl(`CaseDetails?id=${postSaveActions.caseId}`), '_blank');
  };

  const handlePrintReceipt = () => {
    window.open(createPageUrl(`PrintReceipt?id=${postSaveActions.caseId}`), '_blank');
  };

  const handlePrintLabel = () => {
    window.open(createPageUrl(`PrintLabel?id=${postSaveActions.caseId}`), '_blank');
  };

  const handleCloseSuccessDialog = () => {
    setFormData(initialFormData);
    setDeviceInfo(initialDeviceInfo);
    setSelectedCustomer(null);
    setServerDrives([]);
    setAdditionalDevices([]);
    setPostSaveActions({ show: false, caseId: null, caseNumber: null });
  };

  const handleAddAnotherDevice = () => {
    const newDevice = {
      ...initialDeviceInfo,
      role: additionalDevices.length === 0 ? 'Backup' : 'Patient',
      accessories: []
    };
    setAdditionalDevices([...additionalDevices, newDevice]);
  };

  const handleRemoveDevice = (index) => {
    setAdditionalDevices(additionalDevices.filter((_, i) => i !== index));
  };

  const handleUpdateAdditionalDevice = (index, field, value) => {
    const updated = [...additionalDevices];
    updated[index][field] = value;
    setAdditionalDevices(updated);
  };

  const handleBulkAddMemoryCards = (memoryCards) => {
    setAdditionalDevices([...additionalDevices, ...memoryCards]);
    setShowBulkMemoryDialog(false);
  };

  const currentProblems = serviceProblems[formData.service_type] || serviceProblems["Data Recovery"];
  const isDeviceTypeMandatory = ['Data Recovery', 'Data Destruction', 'Forensic Analysis', 'Hardware Repair'].includes(formData.service_type);
  const isProblemDescriptionMandatory = isDeviceTypeMandatory;
  const isMemoryCardSelected = deviceInfo.media_type === 'Memory Card';

  const totalDeviceCount = (
    ((deviceInfo.media_type?.toLowerCase().includes('server') && serverDrives.length > 0) ? serverDrives.length : (deviceInfo.media_type ? 1 : 0))
    + additionalDevices.length
  );


  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-indigo-50 to-purple-100">
      <div className="sticky top-0 z-10 bg-transparent pt-4">
        <div className="max-w-full mx-auto flex items-center justify-between px-6 pb-4">
          <div className="flex items-center space-x-3">
            <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl('Cases'))} className="h-9 w-9 bg-white/50 hover:bg-white/80">
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <h1 className="text-2xl font-bold text-gray-800">Create New Job</h1>
            <div className="px-3 py-1.5 bg-blue-50 text-blue-700 rounded-lg text-sm font-semibold">
              #{caseNumber}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-full mx-auto px-4 pb-4">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          
          <Card className="shadow-xl bg-gradient-to-br from-blue-50 to-indigo-100 border-0 overflow-hidden">
            <div className="bg-gradient-to-r from-blue-500 to-indigo-600 p-4">
              <CardTitle className="flex items-center text-white text-lg font-semibold">
                <UserPlus className="w-5 h-5 mr-2" />
                Client & Service
              </CardTitle>
            </div>
            <CardContent className="p-6 space-y-5">
              <div>
                <Label className="font-semibold text-gray-700">Client <span className="text-red-500">*</span></Label>
                <SearchableSelect
                  value={selectedCustomer?.id || ''}
                  onValueChange={(value) => {
                    const customer = customers.find(c => c.id === value);
                    setSelectedCustomer(customer);
                  }}
                  options={customers.map(c => ({ label: c.full_name, value: c.id, subtitle: c.email }))}
                  placeholder="Select a Client"
                  searchPlaceholder="Search clients..."
                  className="mt-2"
                />
                <button
                  type="button"
                  onClick={() => setShowNewCustomerDialog(true)}
                  className="text-sm text-blue-600 hover:text-blue-800 mt-2 flex items-center"
                >
                  <UserPlus className="w-3 h-3 mr-1" />
                  Add New Customer
                </button>
              </div>

              <div>
                <Label className="font-semibold text-gray-700">Client Reference</Label>
                <Input
                  value={formData.client_reference}
                  onChange={(e) => setFormData({...formData, client_reference: e.target.value})}
                  placeholder="PO number, ticket ID"
                  className="mt-2"
                />
              </div>

              <div>
                <Label className="font-semibold text-gray-700">Service Type <span className="text-red-500">*</span></Label>
                <Select
                  value={formData.service_type}
                  onValueChange={(value) => {
                    setFormData({...formData, service_type: value});
                    setDeviceInfo(prev => ({...prev, device_problem: serviceProblems[value]?.[0] || ''}));
                  }}
                >
                  <SelectTrigger className="mt-2"><SelectValue /></SelectTrigger>
                  <SelectContent>{serviceTypes.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="font-semibold text-gray-700">Priority</Label>
                  <Select value={formData.priority} onValueChange={(v) => setFormData({...formData, priority: v})}>
                    <SelectTrigger className="mt-2"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Low">Low</SelectItem><SelectItem value="Normal">Normal</SelectItem>
                      <SelectItem value="High Priority">High Priority</SelectItem><SelectItem value="Urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="font-semibold text-gray-700">Location</Label>
                  <Select value={formData.service_location} onValueChange={(v) => setFormData({...formData, service_location: v})}>
                    <SelectTrigger className="mt-2"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="In Lab">In Lab</SelectItem><SelectItem value="On-Site">On-Site</SelectItem>
                      <SelectItem value="Remote">Remote</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex items-center space-x-4 pt-2 border-t border-blue-200">
                <div className="flex items-center space-x-2">
                  <Checkbox id="welcome-email" checked={formData.welcome_email} onCheckedChange={(c) => setFormData({...formData, welcome_email: c})} />
                  <Label htmlFor="welcome-email" className="text-sm font-medium">Welcome Email</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="welcome-sms" checked={formData.welcome_sms} onCheckedChange={(c) => setFormData({...formData, welcome_sms: c})} />
                  <Label htmlFor="welcome-sms" className="text-sm font-medium">Welcome SMS</Label>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-xl bg-gradient-to-br from-emerald-50 to-green-100 border-0 overflow-hidden">
            <div className="bg-gradient-to-r from-emerald-500 to-green-600 p-4">
              <CardTitle className="flex items-center text-white text-lg font-semibold">
                <HardDrive className="w-5 h-5 mr-2" />
                Device Information ({totalDeviceCount} device{totalDeviceCount !== 1 ? 's' : ''})
              </CardTitle>
            </div>
            <CardContent className="p-6 space-y-5 max-h-[600px] overflow-y-auto">
              <div className="border border-green-200 rounded-lg p-4 bg-white/70">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-semibold text-green-800">Primary Device (Patient)</h4>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <Label className="font-semibold text-gray-700">Media Type {isDeviceTypeMandatory && <span className="text-red-500">*</span>}</Label>
                    <SearchableSelect
                      value={deviceInfo.media_type}
                      onValueChange={(v) => {
                        setDeviceInfo({...deviceInfo, media_type: v});
                        if (v.toLowerCase().includes('server')) {
                          setDeviceInfo(prev => ({ ...prev, media_serial_number: `${serverDrives.length} drives in array` }));
                        } else if (deviceInfo.media_type?.toLowerCase().includes('server') && !v.toLowerCase().includes('server')) {
                          setDeviceInfo(prev => ({ ...prev, media_serial_number: '' }));
                        }
                      }}
                      options={deviceTypes.map(opt => ({ label: opt, value: opt }))}
                      placeholder="Select device type..."
                      className="mt-2"
                    />
                    {deviceInfo.media_type?.toLowerCase().includes('server') && (
                      <Button type="button" variant="outline" size="sm" className="mt-2 w-full h-9 text-sm bg-white" onClick={() => setIsServerDrivesDialogOpen(true)}>
                        Manage Drives ({serverDrives.length})
                      </Button>
                    )}
                  </div>
                  <div>
                    <Label className="font-semibold text-gray-700">Brand</Label>
                    <SearchableSelect
                      value={deviceInfo.brand}
                      onValueChange={(v) => setDeviceInfo({...deviceInfo, brand: v})}
                      options={brands.map(opt => ({ label: opt, value: opt }))}
                      placeholder="Select brand..."
                      className="mt-2"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <Label className="font-semibold text-gray-700">Model</Label>
                    <Input 
                      value={deviceInfo.media_model} 
                      onChange={(e) => setDeviceInfo({...deviceInfo, media_model: e.target.value})} 
                      placeholder="Device model" 
                      className="mt-2" 
                    />
                  </div>
                  <div>
                    <Label className="font-semibold text-gray-700">Serial Number {isDeviceTypeMandatory && !deviceInfo.media_type?.toLowerCase().includes('server') && <span className="text-red-500">*</span>}</Label>
                    <Input 
                        value={deviceInfo.media_serial_number} 
                        onChange={(e) => setDeviceInfo({...deviceInfo, media_serial_number: e.target.value})} 
                        placeholder="Serial number" 
                        className="mt-2" 
                        disabled={deviceInfo.media_type?.toLowerCase().includes('server')}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="font-semibold text-gray-700">Capacity</Label>
                    <SearchableSelect
                      value={deviceInfo.capacity} onValueChange={(v) => setDeviceInfo({...deviceInfo, capacity: v})}
                      options={capacities.map(opt => ({ label: opt, value: opt }))}
                      placeholder="Select capacity..." creatable={true} className="mt-2"
                    />
                  </div>
                  <div>
                    <Label className="font-semibold text-gray-700">Condition</Label>
                    <Select value={deviceInfo.condition} onValueChange={(v) => setDeviceInfo({...deviceInfo, condition: v})}>
                      <SelectTrigger className="mt-2"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Excellent">Excellent</SelectItem><SelectItem value="Good">Good</SelectItem>
                        <SelectItem value="Fair">Fair</SelectItem><SelectItem value="Poor">Poor</SelectItem><SelectItem value="Damaged">Damaged</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <div className="mt-4">
                  <Label className="font-semibold text-gray-700">Accessories (for Primary Device)</Label>
                  <MultiSelect
                    options={accessoriesOptions}
                    selected={deviceInfo.accessories}
                    onChange={(value) => setDeviceInfo(prev => ({ ...prev, accessories: value }))}
                    placeholder="Select accessories..."
                    className="mt-2"
                  />
              </div>

              {additionalDevices.map((device, index) => (
                <div key={index} className="border border-green-200 rounded-lg p-4 bg-white/50">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-semibold text-green-800">Device {index + 2} ({device.role})</h4>
                    <Button variant="ghost" size="sm" onClick={() => handleRemoveDevice(index)} className="text-red-600 hover:bg-red-50">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 mb-2">
                    <div>
                      <Label className="text-sm font-semibold text-gray-700">Media Type</Label>
                      <SearchableSelect
                        value={device.media_type}
                        onValueChange={(v) => handleUpdateAdditionalDevice(index, 'media_type', v)}
                        options={deviceTypes.map(opt => ({ label: opt, value: opt }))}
                        placeholder="Device type..."
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label className="text-sm font-semibold text-gray-700">Brand</Label>
                      <SearchableSelect
                        value={device.brand}
                        onValueChange={(v) => handleUpdateAdditionalDevice(index, 'brand', v)}
                        options={brands.map(opt => ({ label: opt, value: opt }))}
                        placeholder="Brand..."
                        className="mt-1"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <Label className="text-sm font-semibold text-gray-700">Model</Label>
                      <Input 
                        value={device.media_model} 
                        onChange={(e) => handleUpdateAdditionalDevice(index, 'media_model', e.target.value)}
                        placeholder="Model" 
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label className="text-sm font-semibold text-gray-700">Serial Number</Label>
                      <Input 
                        value={device.media_serial_number} 
                        onChange={(e) => handleUpdateAdditionalDevice(index, 'media_serial_number', e.target.value)}
                        placeholder="Serial #" 
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label className="text-sm font-semibold text-gray-700">Role</Label>
                      <Select value={device.role} onValueChange={(v) => handleUpdateAdditionalDevice(index, 'role', v)}>
                        <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Patient">Patient</SelectItem>
                          <SelectItem value="Backup">Backup</SelectItem>
                          <SelectItem value="Clone">Clone</SelectItem>
                          <SelectItem value="Donor">Donor</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="mt-4">
                    <Label className="text-sm font-semibold text-gray-700">Device Problem</Label>
                    <SearchableSelect
                        value={device.device_problem} onValueChange={(v) => handleUpdateAdditionalDevice(index, 'device_problem', v)}
                        placeholder="Describe the problem..." options={currentProblems.map(opt => ({ label: opt, value: opt }))}
                        creatable={true} className="mt-1"
                    />
                  </div>
                  <div className="mt-4">
                    <Label className="text-sm font-semibold text-gray-700">Important Data</Label>
                    <Textarea 
                      value={device.important_data} 
                      onChange={(e) => handleUpdateAdditionalDevice(index, 'important_data', e.target.value)} 
                      placeholder="Specific data on this device..." 
                      className="mt-1 resize-none text-sm bg-white" 
                      rows={2}
                    />
                  </div>
                </div>
              ))}

              <div className="space-y-2">
                <Button 
                  type="button" 
                  variant="outline" 
                  className="w-full bg-white hover:bg-green-50 text-green-700 border-green-300"
                  onClick={handleAddAnotherDevice}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Another Device
                </Button>
                
                {isMemoryCardSelected && (
                  <Button 
                    type="button" 
                    variant="outline" 
                    className="w-full bg-white hover:bg-green-50 text-green-700 border-green-300"
                    onClick={() => setShowBulkMemoryDialog(true)}
                  >
                    <HardDrive className="w-4 h-4 mr-2" />
                    Bulk Add Memory Cards
                  </Button>
                )}
              </div>

            </CardContent>
          </Card>

          <Card className="shadow-xl bg-gradient-to-br from-orange-50 to-amber-100 border-0 overflow-hidden">
            <div className="bg-gradient-to-r from-orange-500 to-amber-600 p-4">
              <CardTitle className="flex items-center text-white text-lg font-semibold">
                <Info className="w-5 h-5 mr-2" />
                Problem & Requirements
              </CardTitle>
            </div>
            <CardContent className="p-6 space-y-5">
              <div>
                <Label className="font-semibold text-gray-700">Device Problem {isProblemDescriptionMandatory && <span className="text-red-500">*</span>}</Label>
                <SearchableSelect
                  value={deviceInfo.device_problem} onValueChange={(v) => setDeviceInfo({...deviceInfo, device_problem: v})}
                  placeholder="Describe the problem..." options={currentProblems.map(opt => ({ label: opt, value: opt }))}
                  creatable={true} className="mt-2"
                />
              </div>

              <div>
                <Label className="font-semibold text-gray-700">Recovery Requirements</Label>
                <Textarea 
                  value={deviceInfo.important_data} 
                  onChange={(e) => setDeviceInfo({...deviceInfo, important_data: e.target.value})} 
                  placeholder="What specific data needs to be recovered? e.g., 'Family Photos from 2020', 'Company financial reports', 'Entire User folder'..." 
                  className="mt-2 h-20 resize-none text-sm bg-white" 
                  rows={3}
                />
              </div>

              <div>
                <Label className="font-semibold text-gray-700">Device Password</Label>
                <div className="relative mt-2">
                  <Input 
                    type={showPassword ? 'text' : 'password'} 
                    placeholder="BitLocker, device password..." 
                    value={formData.device_password} 
                    onChange={(e) => setFormData({ ...formData, device_password: e.target.value })} 
                    className="bg-white pr-12"
                  />
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="icon" 
                    className="absolute right-0 top-0 h-full w-10" 
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>

              <div className="bg-orange-100/50 p-4 rounded-lg border border-orange-200 space-y-3 mt-6">
                <h4 className="font-semibold text-orange-800 text-sm mb-2">🚀 Ready to Create Job?</h4>
                <div className="space-y-2">
                  <Button 
                    type="button" 
                    onClick={handleSubmit} 
                    disabled={isSubmitting} 
                    className="w-full bg-green-600 hover:bg-green-700 text-white"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    {isSubmitting ? 'Creating Job...' : 'Create Job'}
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    onClick={() => navigate(createPageUrl('Cases'))}
                    className="w-full border-orange-300 text-orange-700 hover:bg-orange-50"
                  >
                    <X className="w-4 h-4 mr-2" />
                    Cancel
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

        </div>
      </div>

      <NewCustomerDialog open={showNewCustomerDialog} setOpen={setShowNewCustomerDialog} onCustomerCreated={handleCustomerCreated} />
      <ServerDrivesDialog open={isServerDrivesDialogOpen} onOpenChange={setIsServerDrivesDialogOpen} initialDrives={serverDrives} onSave={handleServerDrivesUpdate} capacities={capacities} />

      <Dialog open={postSaveActions.show} onOpenChange={(open) => !open && handleCloseSuccessDialog()}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Success! Case {postSaveActions.caseNumber} Created</DialogTitle>
            <DialogDescription>What would you like to do next?</DialogDescription>
          </DialogHeader>
          <div className="flex flex-col space-y-3 py-4">
            <Button onClick={handleGoToProfile}><FileText className="w-4 h-4 mr-2"/> Go to Case Profile</Button>
            <Button variant="outline" onClick={handlePrintReceipt}><Printer className="w-4 h-4 mr-2"/> Print Check-in Receipt</Button>
            <Button variant="outline" onClick={handlePrintLabel}><Tag className="w-4 h-4 mr-2"/> Print Case Label</Button>
          </div>
          <DialogFooter>
            <Button variant="secondary" onClick={handleCreateAnother}>Create Another Case</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <BulkMemoryCardsDialog 
        open={showBulkMemoryDialog}
        onOpenChange={setShowBulkMemoryDialog}
        onSave={handleBulkAddMemoryCards}
        brands={brands}
        capacities={capacities}
      />
    </div>
  );
}