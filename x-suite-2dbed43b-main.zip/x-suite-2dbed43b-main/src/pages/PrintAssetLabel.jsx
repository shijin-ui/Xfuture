import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Asset } from '@/api/entities';
import { QrCode } from 'lucide-react'; // Using an icon as a placeholder

export default function PrintAssetLabel() {
    const [asset, setAsset] = useState(null);
    const location = useLocation();

    useEffect(() => {
        const assetId = new URLSearchParams(location.search).get('id');
        if (assetId) {
            Asset.get(assetId).then(setAsset).catch(console.error);
        }
    }, [location.search]);

    useEffect(() => {
        if (asset) {
            setTimeout(() => window.print(), 500);
        }
    }, [asset]);

    if (!asset) {
        return <div className="p-4">Loading asset details...</div>;
    }

    return (
        <div className="p-2" style={{ fontFamily: 'sans-serif' }}>
            <style>{`
                @media print {
                    body {
                        -webkit-print-color-adjust: exact;
                        print-color-adjust: exact;
                    }
                    @page {
                        size: 3in 1.5in;
                        margin: 0.1in;
                    }
                }
            `}</style>
            <div className="w-full h-full border border-black p-2 flex flex-col items-center justify-center text-center">
                <div className="text-xs font-bold">{asset.asset_name}</div>
                <div className="text-sm font-mono font-semibold my-1">{asset.asset_code}</div>
                <div className="text-center">
                     {/* In a real scenario, this would be a QR code generation library */}
                     <QrCode className="w-12 h-12" />
                </div>
                <div className="text-[10px] mt-1">Property of Space Recovery</div>
            </div>
        </div>
    );
}