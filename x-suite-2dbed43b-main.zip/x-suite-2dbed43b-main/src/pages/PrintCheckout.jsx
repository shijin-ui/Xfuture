
import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Case } from '@/api/entities';
import { Customer } from '@/api/entities';
import { CompanyProfile } from '@/api/entities'; // Added CompanyProfile import
import { Button } from '@/components/ui/button';
import { Printer } from 'lucide-react';
import { format } from 'date-fns';

export default function PrintCheckout() {
  const [caseData, setCaseData] = useState(null);
  const [customer, setCustomer] = useState(null);
  const [companyProfile, setCompanyProfile] = useState(null); // Added state for companyProfile
  const location = useLocation();

  useEffect(() => {
    const fetchData = async () => { // Renamed from fetch_data to fetchData as per outline
      const caseId = new URLSearchParams(location.search).get('id');
      if (caseId) {
        try {
            // Fetch case and company profile concurrently
            const [caseResult, profiles] = await Promise.all([
                Case.get(caseId),
                CompanyProfile.list() // Fetch company profiles
            ]);
            
            setCaseData(caseResult);
            if (profiles.length > 0) {
                // Assuming there's typically one company profile for the system
                setCompanyProfile(profiles[0]);
            }

            if (caseResult && caseResult.customer_id) {
                const customerResult = await Customer.get(caseResult.customer_id);
                setCustomer(customerResult);
            }
        } catch (error) {
            console.error("Failed to fetch checkout data:", error);
        }
      }
    };
    fetchData();
  }, [location]);

  // Updated loading check to include companyProfile
  if (!caseData || !customer || !companyProfile) {
    return <div>Loading checkout form...</div>;
  }
  
  const collectorName = caseData.collected_by_name || customer.full_name;

  return (
    <>
      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          /* Updated to print-container and explicitly set A4 dimensions */
          .print-container, .print-container * { 
            visibility: visible;
          }
          .print-container { 
            position: absolute;
            left: 0;
            top: 0;
            width: 210mm; /* A4 width */
            min-height: 297mm; /* A4 height */
            background-color: white; /* from original Tailwind bg-white */
            font-family: sans-serif; /* from original Tailwind font-sans */
            margin: auto; /* from original Tailwind mx-auto */
          }
          .no-print {
            display: none;
          }
        }
        @page {
          size: A4;
          margin: 1cm;
        }
        .arabic-text {
          font-family: 'Arial', 'Tahoma', sans-serif;
          direction: rtl;
          text-align: right;
        }
      `}</style>
      
      {/* New outer container as per outline */}
      <div className="max-w-4xl mx-auto p-4 bg-white">
        {/* The print button is outside the A4 page container so it's not part of the printout */}
        {/* Adjusted button container class as per outline */}
        <div className="no-print flex justify-end mb-4">
          <Button onClick={() => window.print()}><Printer className="mr-2 h-4 w-4" /> Print</Button>
        </div>
        
        {/* Updated a4-page-container class names based on outline, preserving A4 dimensions */}
        <div className="print-container border p-8 rounded-lg">
          {/* Professional Header - Updated to use companyProfile data */}
          <header className="flex justify-between items-start pb-4 border-b-2 border-gray-100 mb-6">
            <div className="flex-shrink-0">
                {companyProfile?.full_logo_url ? (
                    <img src={companyProfile.full_logo_url} alt={`${companyProfile.company_name || ''} Logo`} className="h-16 max-w-xs object-contain" />
                ) : (
                    <h1 className="text-2xl font-bold text-gray-800">{companyProfile?.logo_text || companyProfile?.company_name || 'Space Recovery'}</h1>
                )}
            </div>
            <div className="text-right text-xs text-gray-600 space-y-1">
                <p className="font-bold text-base text-gray-800">{companyProfile?.company_name}</p>
                {companyProfile?.company_address && <p>{companyProfile.company_address}</p>}
                <div className="flex justify-end space-x-4">
                    {companyProfile?.email && <p>{companyProfile.email}</p>}
                    {companyProfile?.mobile_number_1 && <p> | {companyProfile.mobile_number_1}</p>}
                </div>
                {companyProfile?.website && <p className="text-blue-600">{companyProfile.website}</p>}
                <div className="flex justify-end text-xs mt-1 space-x-2">
                    {companyProfile?.company_registration_number && <span>Reg: {companyProfile.company_registration_number}</span>}
                    {companyProfile?.tax_id && <span>VAT: {companyProfile.tax_id}</span>}
                </div>
            </div>
          </header>

          {/* Main Content */}
          <div className="mt-8">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h2 className="text-xl font-semibold">Customer Check-out Receipt</h2>
                <h3 className="text-lg font-semibold arabic-text text-gray-700">إيصال تسليم الأجهزة</h3>
              </div>
              <div className="text-right">
                <p className="text-sm">Date: {format(new Date(), 'dd MMM yyyy')}</p>
                <div className="mt-1 bg-gray-100 p-2 rounded-lg inline-block">
                  <span className="text-sm font-semibold text-gray-600">Job ID:</span>
                  <span className="ml-2 font-mono font-bold text-lg text-gray-800">
                    {caseData.case_number}
                  </span>
                </div>
              </div>
            </div>

            <section className="grid grid-cols-2 gap-8 my-6">
              <div>
                <h3 className="font-semibold text-lg mb-2 border-b pb-1">Customer Information</h3>
                <p><strong>Name:</strong> {customer.full_name}</p>
                <p><strong>Company:</strong> {customer.company_name || 'N/A'}</p>
                <p><strong>Phone:</strong> {customer.phone_number}</p>
                <p><strong>Email:</strong> {customer.email}</p>
              </div>
              <div>
                <h3 className="font-semibold text-lg mb-2 border-b pb-1">Service Summary</h3>
                <p><strong>Service Type:</strong> {caseData.service_type}</p>
                <p><strong>Final Status:</strong> {caseData.status}</p>
                {caseData.client_reference && (
                  <p><strong>Client Reference:</strong> {caseData.client_reference}</p>
                )}
              </div>
            </section>

            {caseData.collected_by_name && (
              <section className="my-6">
                <h3 className="font-semibold text-lg mb-2 border-b pb-1">Device(s) Collected By</h3>
                <div className="grid grid-cols-3 gap-8 text-sm">
                  <p><strong>Name:</strong> {caseData.collected_by_name}</p>
                  <p><strong>Mobile:</strong> {caseData.collected_by_mobile}</p>
                  <p><strong>National ID:</strong> {caseData.collected_by_id || 'N/A'}</p>
                </div>
              </section>
            )}

            <section>
              <div className="flex justify-between items-baseline border-b pb-1 mb-2">
                  <h3 className="font-semibold text-lg">Devices Returned</h3>
                  <h3 className="font-semibold text-lg arabic-text">الأجهزة المسلمة</h3>
              </div>
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-gray-50">
                    <th className="text-left p-2">Type</th>
                    <th className="text-left p-2">Brand</th>
                    <th className="text-left p-2">Model</th>
                    <th className="text-left p-2">Serial Number</th>
                    <th className="text-left p-2">Role</th>
                  </tr>
                </thead>
                <tbody>
                  {caseData.devices.map((device, index) => (
                    <tr key={index} className="border-b">
                      <td className="p-2">{device.media_type}</td>
                      <td className="p-2">{device.brand}</td>
                      <td className="p-2">{device.media_model}</td>
                      <td className="p-2">{device.media_serial_number}</td>
                      <td className="p-2">{device.role}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </section>

            <section className="mt-6 text-xs text-gray-600">
              <div className="flex justify-between items-baseline border-b pb-1 mb-2">
                  <h3 className="font-semibold text-sm text-gray-800">DEVICE COLLECTION & ACCEPTANCE</h3>
                  <h3 className="font-semibold text-sm text-gray-800 arabic-text">استلام وقبول الأجهزة</h3>
              </div>
              
              <div className="grid grid-cols-2 gap-8 mt-2">
                <div>
                  <p className="mb-2">By signing below, I, the undersigned, confirm that I have received the device(s) listed above. I acknowledge that Space Recovery has completed the requested service. I understand that from this point forward, Space Recovery holds no further responsibility for the device(s) or the data contained within.</p>
                </div>
                <div className="arabic-text">
                  <p className="mb-2">بتوقيعي أدناه، أقر أنا، الموقع أدناه، بأنني قد استلمت الجهاز/الأجهزة المذكورة أعلاه. أقر بأن شركة سبيس ريكفري قد أكملت الخدمة المطلوبة. وأفهم أنه من هذه النقطة فصاعدًا، لا تتحمل شركة سبيس ريكفري أي مسؤولية أخرى عن الجهاز/الأجهزة أو البيانات الموجودة بداخلها.</p>
                </div>
              </div>
            </section>

            <footer className="mt-16 pt-8 border-t flex justify-between text-sm">
              <div>
                <p>{collectorName}'s Signature:</p>
                <p className="arabic-text">توقيع المستلم:</p>
                <div className="w-64 h-12 border-b mt-2"></div>
              </div>
              <div>
                <p>Technician:</p>
                <p className="arabic-text">الفني:</p>
                <div className="w-64 h-12 border-b mt-2"></div>
              </div>
            </footer>
          </div>
        </div>
      </div>
    </>
  );
}
