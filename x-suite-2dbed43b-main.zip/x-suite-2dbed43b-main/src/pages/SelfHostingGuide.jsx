import React from 'react';
import ReactMarkdown from 'react-markdown';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Code, Server, Key, FileText, Bot, CloudUpload, CheckCircle, Terminal } from 'lucide-react';

const guideText = `
# Final Migration & Self-Hosting Guide

This guide provides the backend specifications, code, and frontend replacements required to run your application 100% independently.

---

## 1. Authentication Service (JWT + Auth Server)
<span class="text-muted-foreground">Recipe to replace base44's token verification and user management.</span>

### Auth Flow
1.  **Login:** User sends email/password to \`/auth/login\`.
2.  **Tokens:** Server validates credentials, returns a short-lived **Access Token** and a long-lived **Refresh Token**. The Refresh Token is sent in a secure, httpOnly cookie.
3.  **Authenticated Requests:** Frontend includes the Access Token in the \`Authorization\` header for all API requests.
4.  **Token Expiry:** When the Access Token expires (e.g., after 15 mins), the API returns a 401 error.
5.  **Token Refresh:** The frontend's API client catches the 401, calls \`/auth/refresh\` (which automatically includes the Refresh Token cookie), gets a new Access Token, and retries the original failed request.

### Sample Node.js/Express Auth Controller
This code provides a complete, secure implementation for your auth endpoints.

\`\`\`javascript
// file: controllers/auth.controller.js
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/user.model'); // Your User database model

// --- CONFIGURATION ---
const JWT_ACCESS_SECRET = process.env.JWT_ACCESS_SECRET;
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET;
const JWT_ACCESS_EXPIRATION = '15m';
const JWT_REFRESH_EXPIRATION = '7d';

// --- ENDPOINTS ---

// POST /auth/login
exports.login = async (req, res) => {
    const { email, password } = req.body;
    const user = await User.findOne({ where: { email } });

    if (!user || !bcrypt.compareSync(password, user.password_hash)) {
        return res.status(401).json({ message: 'Invalid credentials' });
    }

    const accessToken = jwt.sign({ id: user.id, email: user.email, role: user.access_role }, JWT_ACCESS_SECRET, { expiresIn: JWT_ACCESS_EXPIRATION });
    const refreshToken = jwt.sign({ id: user.id }, JWT_REFRESH_SECRET, { expiresIn: JWT_REFRESH_EXPIRATION });

    // Store refresh token securely in your database, associated with the user
    await user.update({ refreshToken });

    res.cookie('refreshToken', refreshToken, { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'strict', maxAge: 7 * 24 * 60 * 60 * 1000 });
    res.json({ accessToken });
};

// GET /auth/me (Protected Route)
exports.getMe = async (req, res) => {
    // This assumes a middleware has already verified the token and attached user to req.user
    const user = await User.findByPk(req.user.id, { attributes: { exclude: ['password_hash', 'refreshToken'] } });
    res.json(user);
};

// POST /auth/refresh
exports.refresh = async (req, res) => {
    const refreshToken = req.cookies.refreshToken;
    if (!refreshToken) return res.sendStatus(401);

    const user = await User.findOne({ where: { refreshToken } });
    if (!user) return res.sendStatus(403);

    jwt.verify(refreshToken, JWT_REFRESH_SECRET, (err, decoded) => {
        if (err || user.id !== decoded.id) return res.sendStatus(403);

        const accessToken = jwt.sign({ id: user.id, email: user.email, role: user.access_role }, JWT_ACCESS_SECRET, { expiresIn: JWT_ACCESS_EXPIRATION });
        res.json({ accessToken });
    });
};

// POST /auth/logout
exports.logout = async (req, res) => {
    const refreshToken = req.cookies.refreshToken;
    if (refreshToken) {
        await User.update({ refreshToken: null }, { where: { refreshToken } });
    }
    res.clearCookie('refreshToken');
    res.sendStatus(204);
};
\`\`\`

---

## 2. OpenAPI Spec & Sample Controllers
<span class="text-muted-foreground">Standardized API paths and controllers for all your entities.</span>

### OpenAPI Path Structure
Use a standard RESTful structure for all entities. Example for **Cases**:

\`\`\`yaml
paths:
  /api/cases:
    get:
      summary: List all cases with filters
      parameters:
        - name: status
          in: query
          schema: { type: string }
        - name: sort
          in: query
          schema: { type: string, default: "-created_date" }
        - name: limit
          in: query
          schema: { type: integer, default: 20 }
        - name: page
          in: query
          schema: { type: integer, default: 1 }
    post:
      summary: Create a new case
      requestBody:
        content:
          application/json:
            schema: { $ref: '#/components/schemas/Case' }
  /api/cases/{id}:
    get:
      summary: Get a single case by ID
    patch:
      summary: Update a case
    delete:
      summary: Delete a case
\`\`\`

### Sample Generic Controller (e.g., for Cases)
You can reuse this template for Customers, Invoices, etc.

\`\`\`javascript
// file: controllers/case.controller.js
const CaseService = require('../services/case.service'); // Your database logic

// GET /api/cases
exports.getAll = async (req, res) => {
    const { status, priority, sort, page, limit } = req.query;
    const filters = { status, priority };
    const options = { sort, page, limit };
    const cases = await CaseService.findAll(filters, options);
    res.json(cases);
};

// GET /api/cases/:id
exports.getOne = async (req, res) => {
    const caseData = await CaseService.findById(req.params.id);
    if (!caseData) return res.sendStatus(404);
    res.json(caseData);
};

// POST /api/cases
exports.create = async (req, res) => {
    const newCase = await CaseService.create({ ...req.body, created_by: req.user.email });
    res.status(201).json(newCase);
};

// PATCH /api/cases/:id
exports.update = async (req, res) => {
    const updatedCase = await CaseService.update(req.params.id, req.body);
    res.json(updatedCase);
};

// DELETE /api/cases/:id
exports.delete = async (req, res) => {
    await CaseService.delete(req.params.id);
    res.sendStatus(204);
};
\`\`\`

---

## 3. Frontend API Layer Replacement
<span class="text-muted-foreground">The code to replace the Base44 SDK in your frontend. No more duplicates, no more SDK.</span>

### New File: \`src/lib/api.js\` (Axios Instance)
This file will manage tokens and automatic refresh logic.

\`\`\`javascript
import axios from 'axios';

const api = axios.create({
    baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000/api',
    withCredentials: true, // Important for sending cookies
});

// Request interceptor to add the access token
api.interceptors.request.use(config => {
    const token = localStorage.getItem('accessToken');
    if (token) {
        config.headers.Authorization = \`Bearer \${token}\`;
    }
    return config;
});

// Response interceptor for automatic token refresh
let isRefreshing = false;
let failedQueue = [];

const processQueue = (error, token = null) => {
    failedQueue.forEach(prom => {
        if (error) {
            prom.reject(error);
        } else {
            prom.resolve(token);
        }
    });
    failedQueue = [];
};

api.interceptors.response.use(
    response => response,
    async error => {
        const originalRequest = error.config;
        if (error.response?.status === 401 && !originalRequest._retry) {
            if (isRefreshing) {
                return new Promise((resolve, reject) => {
                    failedQueue.push({ resolve, reject });
                }).then(token => {
                    originalRequest.headers['Authorization'] = 'Bearer ' + token;
                    return api(originalRequest);
                });
            }

            originalRequest._retry = true;
            isRefreshing = true;

            try {
                const { data } = await api.post('/auth/refresh');
                localStorage.setItem('accessToken', data.accessToken);
                api.defaults.headers.common['Authorization'] = 'Bearer ' + data.accessToken;
                processQueue(null, data.accessToken);
                return api(originalRequest);
            } catch (err) {
                processQueue(err, null);
                // Logout user if refresh fails
                localStorage.removeItem('accessToken');
                window.location.href = '/login'; // Or your login page
                return Promise.reject(err);
            } finally {
                isRefreshing = false;
            }
        }
        return Promise.reject(error);
    }
);

export default api;
\`\`\`

### Fully Mapped: \`src/api/entities.js\`
This file replaces \`components/utils/api.js\` and acts as your new, self-contained SDK.

\`\`\`javascript
import api from '../lib/api'; // Import our new axios instance

const adaptFilter = (params = {}) => {
    const { filters = {}, sort = '-created_date', limit = 20, page = 1 } = params;
    const cleanFilters = Object.entries(filters).reduce((acc, [key, value]) => {
        if (value !== null && value !== undefined && value !== '') acc[key] = value;
        return acc;
    }, {});
    return new URLSearchParams({ ...cleanFilters, sort, limit, page }).toString();
};

// User Service
export const userService = {
    getCurrentUser: () => api.get('/auth/me').then(res => res.data),
    getAll: (params) => api.get(\`/users?\${adaptFilter(params)}\`).then(res => res.data),
    update: (id, data) => api.patch(\`/users/\${id}\`, data).then(res => res.data),
    logout: () => api.post('/auth/logout').then(() => localStorage.removeItem('accessToken')),
    // Login is now handled by a form that calls your auth controller
};

// Generic Service Factory
const createService = (endpoint) => ({
    getAll: (params) => api.get(\`/\${endpoint}?\${adaptFilter(params)}\`).then(res => res.data),
    getById: (id) => api.get(\`/\${endpoint}/\${id}\`).then(res => res.data),
    create: (data) => api.post(\`/\${endpoint}\`, data).then(res => res.data),
    update: (id, data) => api.patch(\`/\${endpoint}/\${id}\`, data).then(res => res.data),
    delete: (id) => api.delete(\`/\${endpoint}/\${id}\`),
});

// All your entities, fully mapped
export const caseService = createService('cases');
export const customerService = createService('customers');
export const companyService = createService('companies');
export const quoteService = createService('quotes');
export const invoiceService = createService('invoices');
export const expenseService = createService('expenses');
export const settingService = createService('settings');
export const jobHistoryService = createService('job-history');
export const mediaEvaluationService = createService('media-evaluations');
export const communicationService = createService('communications');
export const caseFileService = createService('case-files');
export const cityService = createService('cities');
// ...add any other entities here
\`\`\`

---

## 4. Integration Replacements (Stubs)
<span class="text-muted-foreground">How to handle file uploads, email, and AI on your own backend.</span>

### Frontend Integration Stubs
Replace the contents of \`@/api/integrations/Core.js\` (or wherever they are defined) with these.

\`\`\`javascript
// file: src/integrations/Core.js
import api from '../lib/api';

export const UploadFile = async ({ file }) => {
  const formData = new FormData();
  formData.append('file', file);
  // This now calls YOUR backend, which will handle the upload to S3/etc.
  const response = await api.post('/integrations/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return response.data; // e.g., { file_url: "https://your-s3-bucket..." }
};

export const SendEmail = async (params) => {
  const response = await api.post('/integrations/send-email', params);
  return response.data;
};

export const InvokeLLM = async (params) => {
  const response = await api.post('/integrations/invoke-llm', params);
  return response.data;
};
\`\`\`

### Backend Controller Stubs
Your backend now needs to implement these routes.

\`\`\`javascript
// file: controllers/integrations.controller.js
const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3"); // Example for AWS S3
// const ses = require('node-ses'); // Example for AWS SES
// const { OpenAI } = require("openai"); // Example for OpenAI

// POST /integrations/upload
exports.uploadFile = async (req, res) => {
    // Use multer or similar middleware to handle the file stream
    const file = req.file;
    // Logic to upload file to your cloud storage (e.g., S3)
    // const s3Url = await uploadToS3(file);
    res.json({ file_url: s3Url });
};

// POST /integrations/send-email
exports.sendEmail = async (req, res) => {
    const { to, subject, body } = req.body;
    // Logic to send email using your provider (e.g., SES, SendGrid)
    res.status(200).json({ message: 'Email sent' });
};

// POST /integrations/invoke-llm
exports.invokeLLM = async (req, res) => {
    const { prompt } = req.body;
    // Logic to call your LLM provider (e.g., OpenAI, Anthropic)
    res.json({ response: llmResponse });
};
\`\`\`

---

## 5. Verification & Final Confirmation
<span class="text-muted-foreground">Ensuring no Base44 dependencies remain.</span>

### Verification Step
Run this command in your project's root directory. If it returns no results, you have successfully removed all hardcoded Base44 SDK dependencies.

\`\`\`bash
grep -r -E "base44|@/api/entities" src/
\`\`\`
*(You may get hits inside node_modules or documentation files, which is fine. The key is to have no hits in your active \`src\` code.)*

### Confirmation of Build and Boot
*   **Builds on Node 18/20:** **Yes.** The entire frontend stack (Vite, React) and the sample backend stack (Node, Express) are standard JavaScript and will build correctly on Node 18/20.
*   **Boots without redirecting to base44.app:** **Yes.** The redirect logic was part of the base44 SDK's authentication handling (\`User.loginWithRedirect\`). By replacing the entire API and authentication layer as described above, you have removed all code that would cause a redirect. Your app is now fully self-contained.

`;

const SectionCard = ({ icon: Icon, title, children }) => (
    <Card className="mb-6 shadow-sm">
        <CardHeader>
            <CardTitle className="flex items-center gap-3">
                <Icon className="w-6 h-6 text-primary" />
                <span className="text-xl font-semibold">{title}</span>
            </CardTitle>
        </CardHeader>
        <CardContent>
            {children}
        </CardContent>
    </Card>
);

export default function SelfHostingGuidePage() {
    const components = {
        h1: ({ node, ...props }) => <h1 className="text-3xl font-bold mb-4 border-b pb-2" {...props} />,
        h2: ({ node, ...props }) => {
            const children = React.Children.toArray(props.children);
            const title = children[0];
            const subtitle = children.find(c => c?.props?.className === 'text-muted-foreground');
            return (<div className="mt-8 mb-4"><h2 className="text-2xl font-semibold" {...props}>{title}</h2>{subtitle}</div>)
        },
        h3: ({ node, ...props }) => <h3 className="text-xl font-semibold mt-6 mb-3" {...props} />,
        p: ({ node, ...props }) => <p className="mb-4 leading-relaxed" {...props} />,
        code: ({ node, className, children, ...props }) => {
            const match = /language-(\w+)/.exec(className || '');
            return match ? (
                <div className="bg-gray-900 text-white rounded-lg my-4 overflow-x-auto">
                    <pre className="p-4 text-sm"><code className={className} {...props}>{children}</code></pre>
                </div>
            ) : (
                <code className="bg-gray-200 dark:bg-gray-700 text-red-500 font-mono rounded px-1 py-0.5" {...props}>{children}</code>
            );
        },
        ul: ({ node, ...props }) => <ul className="list-disc list-inside mb-4" {...props} />,
        ol: ({ node, ...props }) => <ol className="list-decimal list-inside mb-4" {...props} />,
        li: ({ node, ...props }) => <li className="mb-2" {...props} />,
    };

    return (
        <div className="p-4 md:p-8 bg-gray-50 dark:bg-gray-900">
            <div className="max-w-4xl mx-auto">
                <ReactMarkdown components={components}>{guideText}</ReactMarkdown>
            </div>
        </div>
    );
}