
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { toast } from 'sonner';
import {
  MoreHorizontal,
  PlusCircle,
  FileText,
  Download,
  Trash2,
  Edit,
  RefreshCcw,
  Search,
  Loader2,
  Info,
} from 'lucide-react';

import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

import { createPageUrl } from '@/lib/utils';
import api from '@/lib/api';

const statusColors = {
  Paid: 'bg-green-100 text-green-800',
  Pending: 'bg-yellow-100 text-yellow-800',
  Overdue: 'bg-red-100 text-red-800',
  Draft: 'bg-gray-100 text-gray-800',
};

export default function InvoicesPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const [invoices, setInvoices] = useState([]);
  const [customers, setCustomers] = useState({});
  const [cases, setCases] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  const getCompanyName = (customerId) => customers[customerId]?.company_name || ''; // Can be empty if no company
  const getStatusColor = (status) => statusColors[status] || 'bg-gray-200 text-gray-800';

  const fetchInvoiceData = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);
      const [invoicesRes, customersRes, casesRes] = await Promise.all([
        api.get('/invoices'),
        api.get('/customers'),
        api.get('/cases'),
      ]);

      setInvoices(invoicesRes.data.data); // Assuming data structure { data: [...] }
      setCustomers(customersRes.data.data.reduce((acc, customer) => {
        acc[customer.id] = customer;
        return acc;
      }, {}));
      setCases(casesRes.data.data.reduce((acc, caze) => { // 'case' is a reserved keyword
        acc[caze.id] = caze;
        return acc;
      }, {}));
    } catch (err) {
      console.error('Failed to fetch invoice data:', err);
      setError('Failed to load invoices. Please try again.');
      toast.error('Failed to load invoices. Please try again.');
    } finally {
      setIsLoading(false);
    }
  }, []); // Dependencies for useCallback are empty as state setters are stable

  useEffect(() => {
    fetchInvoiceData();
  }, [fetchInvoiceData]); // Dependency on useCallback

  const filteredInvoices = useMemo(() => {
    return invoices.filter(invoice => {
      const caseInfo = cases[invoice.case_id] || {};
      const customerInfo = customers[invoice.customer_id] || {};
      const searchTermLower = searchTerm.toLowerCase();

      return (
        invoice.invoice_number?.toLowerCase().includes(searchTermLower) ||
        caseInfo.case_number?.toLowerCase().includes(searchTermLower) ||
        customerInfo.full_name?.toLowerCase().includes(searchTermLower) ||
        customerInfo.company_name?.toLowerCase().includes(searchTermLower)
      );
    });
  }, [searchTerm, invoices, cases, customers]);

  const handlePrintOrDownload = (invoiceId) => {
    // This will open the print page in a new tab. The PrintInvoice page
    // will automatically set the document title for the PDF filename
    // and trigger the print dialog, which can be used for printing or saving as PDF.
    window.open(createPageUrl(`PrintInvoice?id=${invoiceId}`), '_blank');
  };

  const handleDelete = async (invoiceId) => {
    if (!window.confirm('Are you sure you want to delete this invoice? This action cannot be undone.')) {
      return;
    }
    try {
      await api.delete(`/invoices/${invoiceId}`);
      setInvoices(prev => prev.filter(invoice => invoice.id !== invoiceId));
      toast.success('Invoice deleted successfully!');
    } catch (err) {
      console.error('Failed to delete invoice:', err);
      toast.error('Failed to delete invoice. Please try again.');
    }
  };

  const handleRetry = () => {
    fetchInvoiceData();
  };

  if (error) {
    return (
      <div className="p-8 bg-gradient-to-br from-slate-50 to-indigo-100 min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md text-center shadow-lg">
          <CardHeader>
            <CardTitle className="text-red-600">Error</CardTitle>
            <CardDescription>{error}</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center space-y-4">
            <Info className="w-12 h-12 text-red-500" />
            <p>There was a problem loading the invoices.</p>
            <Button onClick={handleRetry} className="mt-4">
              <RefreshCcw className="mr-2 h-4 w-4" /> Retry
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-8 bg-gradient-to-br from-slate-50 to-indigo-100 min-h-screen">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-extrabold text-gray-900 drop-shadow-sm">Invoices</h1>
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
            <Input
              type="text"
              placeholder="Search invoices..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 pr-4 py-2 border rounded-md shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 ease-in-out"
            />
          </div>
          <Button onClick={() => navigate(createPageUrl('NewInvoice'))} className="bg-blue-600 hover:bg-blue-700 text-white shadow-md transition-all duration-200 ease-in-out">
            <PlusCircle className="mr-2 h-4 w-4" /> New Invoice
          </Button>
        </div>
      </div>

      <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0 overflow-hidden">
        <CardHeader className="bg-gray-50/50">
          <CardTitle className="text-lg font-semibold text-gray-800">All Invoices</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[150px]">Invoice #</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Case</TableHead>
                  <TableHead>Due Date</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={7} className="h-24 text-center">
                      <Loader2 className="h-6 w-6 animate-spin text-gray-500 mx-auto" />
                      <p className="mt-2 text-gray-600">Loading invoices...</p>
                    </TableCell>
                  </TableRow>
                ) : filteredInvoices.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="h-24 text-center text-gray-500">
                      No invoices found.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredInvoices.map(invoice => {
                    const customerName = getCompanyName(invoice.customer_id);
                    const caseNumber = cases[invoice.case_id]?.case_number || 'N/A';
                    const formattedAmount = new Intl.NumberFormat('en-US', {
                      style: 'currency',
                      currency: 'USD',
                    }).format(invoice.total_amount);
                    const statusColorClass = getStatusColor(invoice.status);
                    const formattedDueDate = new Date(invoice.due_date).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                    });
                    return (
                      <TableRow key={invoice.id} className="hover:bg-blue-50/50">
                        <TableCell className="font-medium text-gray-900">{invoice.invoice_number}</TableCell>
                        <TableCell>{customerName || 'N/A'}</TableCell>
                        <TableCell>{caseNumber}</TableCell>
                        <TableCell>{formattedDueDate}</TableCell>
                        <TableCell className="font-semibold">{formattedAmount}</TableCell>
                        <TableCell>
                          <Badge className={statusColorClass}>{invoice.status}</Badge>
                        </TableCell>
                        <TableCell className="text-right">
                           <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" className="h-8 w-8">
                                  <MoreHorizontal className="w-4 h-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => navigate(createPageUrl(`InvoiceDetails?id=${invoice.id}`))}>
                                  <Edit className="w-4 h-4 mr-2" /> Edit / View
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handlePrintOrDownload(invoice.id)}>
                                  <FileText className="w-4 h-4 mr-2" /> Print Invoice
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handlePrintOrDownload(invoice.id)}>
                                  <Download className="w-4 h-4 mr-2" /> Download PDF
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleDelete(invoice.id)} className="text-red-600">
                                  <Trash2 className="w-4 h-4 mr-2" /> Delete
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
