import React, { useEffect, useMemo, useState } from "react";
import { Task } from "@/api/entities";
import { Event } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Plus } from "lucide-react";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay } from "date-fns";

const statusCols = [
  { key: "todo", title: "To Do" },
  { key: "in_progress", title: "In Progress" },
  { key: "done", title: "Done" },
];

export default function TasksPage() {
  const [tasks, setTasks] = useState([]);
  const [events, setEvents] = useState([]);
  const [showTaskDialog, setShowTaskDialog] = useState(false);
  const [showEventDialog, setShowEventDialog] = useState(false);
  const [editingTask, setEditingTask] = useState(null);
  const [editingEvent, setEditingEvent] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [calendarMonth, setCalendarMonth] = useState(new Date());

  const refresh = async () => {
    const [ts, es, u] = await Promise.all([Task.list("-updated_date", 500), Event.list("-start", 500), User.me()]);
    setTasks(ts);
    setEvents(es);
    setCurrentUser(u);
  };
  useEffect(() => { refresh(); }, []);

  const onDragEnd = async (result) => {
    const { destination, source, draggableId } = result;
    if (!destination) return;
    if (destination.droppableId === source.droppableId) return;
    const t = tasks.find(x => x.id === draggableId);
    if (!t) return;
    await Task.update(t.id, { status: destination.droppableId });
    refresh();
  };

  const saveTask = async () => {
    if (!editingTask?.title?.trim()) return alert("Title is required");
    if (editingTask.id) await Task.update(editingTask.id, editingTask);
    else await Task.create({ ...editingTask, status: editingTask.status || "todo" });
    setShowTaskDialog(false); setEditingTask(null); refresh();
  };

  const saveEvent = async () => {
    if (!editingEvent?.title?.trim() || !editingEvent?.start || !editingEvent?.end) return alert("Title, start and end are required");
    if (new Date(editingEvent.end) < new Date(editingEvent.start)) return alert("End must be after start");
    if (editingEvent.id) await Event.update(editingEvent.id, editingEvent);
    else await Event.create(editingEvent);
    setShowEventDialog(false); setEditingEvent(null); refresh();
  };

  const daysInMonth = useMemo(() => {
    return eachDayOfInterval({ start: startOfMonth(calendarMonth), end: endOfMonth(calendarMonth) });
  }, [calendarMonth]);

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold">Tasks & Calendar</h1>
        <div className="flex gap-2">
          <Button onClick={() => { setEditingTask({ title: "", priority: "medium", status: "todo", assignees: [currentUser?.email].filter(Boolean) }); setShowTaskDialog(true); }}>
            <Plus className="w-4 h-4 mr-2" />New Task
          </Button>
          <Button variant="outline" onClick={() => { setEditingEvent({ title: "", start: new Date().toISOString().slice(0,16), end: new Date().toISOString().slice(0,16) }); setShowEventDialog(true); }}>
            <Plus className="w-4 h-4 mr-2" />New Event
          </Button>
        </div>
      </div>

      <Tabs defaultValue="kanban">
        <TabsList>
          <TabsTrigger value="kanban">Kanban</TabsTrigger>
          <TabsTrigger value="calendar">Calendar</TabsTrigger>
        </TabsList>

        <TabsContent value="kanban" className="mt-4">
          <DragDropContext onDragEnd={onDragEnd}>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {statusCols.map(col => (
                <Droppable key={col.key} droppableId={col.key}>
                  {(provided) => (
                    <Card ref={provided.innerRef} {...provided.droppableProps}>
                      <CardHeader><CardTitle>{col.title}</CardTitle></CardHeader>
                      <CardContent className="space-y-2 min-h-[200px]">
                        {tasks.filter(t => t.status === col.key).map((t, idx) => (
                          <Draggable key={t.id} draggableId={t.id} index={idx}>
                            {(prov) => (
                              <div ref={prov.innerRef} {...prov.draggableProps} {...prov.dragHandleProps}
                                   className="border rounded p-3 bg-white hover:shadow-sm">
                                <div className="font-semibold">{t.title}</div>
                                {t.due && <div className="text-xs text-gray-500">Due: {new Date(t.due).toLocaleString()}</div>}
                                <div className="text-xs text-gray-500">Priority: {t.priority}</div>
                                <div className="mt-2">
                                  <Button variant="outline" size="sm" onClick={() => { setEditingTask(t); setShowTaskDialog(true); }}>Edit</Button>
                                </div>
                              </div>
                            )}
                          </Draggable>
                        ))}
                        {provided.placeholder}
                      </CardContent>
                    </Card>
                  )}
                </Droppable>
              ))}
            </div>
          </DragDropContext>
        </TabsContent>

        <TabsContent value="calendar" className="mt-4">
          <Card>
            <CardHeader className="flex items-center justify-between">
              <CardTitle>{format(calendarMonth, "MMMM yyyy")}</CardTitle>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setCalendarMonth(new Date(calendarMonth.getFullYear(), calendarMonth.getMonth() - 1, 1))}>Prev</Button>
                <Button variant="outline" onClick={() => setCalendarMonth(new Date())}>Today</Button>
                <Button variant="outline" onClick={() => setCalendarMonth(new Date(calendarMonth.getFullYear(), calendarMonth.getMonth() + 1, 1))}>Next</Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-2 text-xs text-gray-500 mb-2">
                {["Sun","Mon","Tue","Wed","Thu","Fri","Sat"].map(d => <div key={d} className="text-center">{d}</div>)}
              </div>
              <div className="grid grid-cols-7 gap-2">
                {daysInMonth.map(d => (
                  <div key={d.toISOString()} className="border rounded p-2 min-h-[90px]">
                    <div className="text-xs text-gray-500">{format(d, "d")}</div>
                    <div className="space-y-1 mt-1">
                      {events.filter(e => isSameDay(new Date(e.start), d)).slice(0,3).map(e => (
                        <div key={e.id} className="text-[11px] px-2 py-1 bg-blue-50 text-blue-700 rounded">
                          {e.title}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={showTaskDialog} onOpenChange={setShowTaskDialog}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editingTask?.id ? "Edit Task" : "New Task"}</DialogTitle></DialogHeader>
          {editingTask && (
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <Label>Title</Label>
                <Input value={editingTask.title || ""} onChange={e => setEditingTask({ ...editingTask, title: e.target.value })} />
              </div>
              <div>
                <Label>Priority</Label>
                <Input value={editingTask.priority || "medium"} onChange={e => setEditingTask({ ...editingTask, priority: e.target.value })} />
              </div>
              <div>
                <Label>Due</Label>
                <Input type="datetime-local" value={editingTask.due ? new Date(editingTask.due).toISOString().slice(0,16) : ""} onChange={e => setEditingTask({ ...editingTask, due: e.target.value })} />
              </div>
              <div className="col-span-2">
                <Label>Notes</Label>
                <Input value={editingTask.notes || ""} onChange={e => setEditingTask({ ...editingTask, notes: e.target.value })} />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowTaskDialog(false)}>Cancel</Button>
            <Button onClick={saveTask}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showEventDialog} onOpenChange={setShowEventDialog}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editingEvent?.id ? "Edit Event" : "New Event"}</DialogTitle></DialogHeader>
          {editingEvent && (
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <Label>Title</Label>
                <Input value={editingEvent.title || ""} onChange={e => setEditingEvent({ ...editingEvent, title: e.target.value })} />
              </div>
              <div>
                <Label>Start</Label>
                <Input type="datetime-local" value={editingEvent.start || ""} onChange={e => setEditingEvent({ ...editingEvent, start: e.target.value })} />
              </div>
              <div>
                <Label>End</Label>
                <Input type="datetime-local" value={editingEvent.end || ""} onChange={e => setEditingEvent({ ...editingEvent, end: e.target.value })} />
              </div>
              <div className="col-span-2">
                <Label>Location</Label>
                <Input value={editingEvent.location || ""} onChange={e => setEditingEvent({ ...editingEvent, location: e.target.value })} />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEventDialog(false)}>Cancel</Button>
            <Button onClick={saveEvent}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}