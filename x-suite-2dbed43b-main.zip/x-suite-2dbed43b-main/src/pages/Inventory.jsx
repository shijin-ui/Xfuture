import React, { useState, useEffect, useMemo } from 'react';
import { Inventory } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Archive, PlusCircle, Search, Filter, Edit, Trash2, Link as LinkIcon, AlertTriangle, Package } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import InventoryFormDialog from '../components/inventory/InventoryFormDialog';

const itemTypes = ["All", "HDD", "SSD", "PCB", "Other"];
const conditions = ["All", "New", "Used - Working", "Used - Tested", "For Parts Only", "Defective"];

export default function InventoryPage() {
    const [inventory, setInventory] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [filters, setFilters] = useState({ item_type: 'All', condition: 'All' });
    const [editingItem, setEditingItem] = useState(null);
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [itemToDelete, setItemToDelete] = useState(null);

    const fetchData = async () => {
        setIsLoading(true);
        try {
            const data = await Inventory.list('-created_date');
            setInventory(data);
        } catch (error) {
            console.error("Failed to fetch inventory:", error);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    const filteredInventory = useMemo(() => {
        return inventory.filter(item => {
            const searchLower = searchTerm.toLowerCase();
            const matchesSearch = (
                item.name?.toLowerCase().includes(searchLower) ||
                item.brand?.toLowerCase().includes(searchLower) ||
                item.model_number?.toLowerCase().includes(searchLower) ||
                item.serial_number?.toLowerCase().includes(searchLower) ||
                item.pcb_number?.toLowerCase().includes(searchLower) ||
                item.location?.toLowerCase().includes(searchLower) ||
                item.compatibility_tags?.toLowerCase().includes(searchLower)
            );
            const matchesType = filters.item_type === 'All' || item.item_type === filters.item_type;
            const matchesCondition = filters.condition === 'All' || item.condition === filters.condition;
            return matchesSearch && matchesType && matchesCondition;
        });
    }, [inventory, searchTerm, filters]);

    const handleAddItem = () => {
        setEditingItem(null);
        setIsFormOpen(true);
    };

    const handleEditItem = (item) => {
        setEditingItem(item);
        setIsFormOpen(true);
    };
    
    const handleDeleteConfirmation = async () => {
        if (!itemToDelete) return;
        try {
            await Inventory.delete(itemToDelete.id);
            setItemToDelete(null);
            fetchData();
        } catch(error) {
            console.error("Failed to delete item:", error);
            alert("Could not delete the item.");
        }
    }

    const getItemTypeColor = (type) => {
        switch (type) {
            case 'HDD': return 'bg-blue-100 text-blue-800 border border-blue-200';
            case 'SSD': return 'bg-green-100 text-green-800 border border-green-200';
            case 'PCB': return 'bg-purple-100 text-purple-800 border border-purple-200';
            case 'Other': return 'bg-orange-100 text-orange-800 border border-orange-200';
            default: return 'bg-gray-100 text-gray-800 border border-gray-200';
        }
    };

    const getConditionColor = (condition) => {
        switch (condition) {
            case 'New': return 'bg-green-100 text-green-800';
            case 'Used - Working': return 'bg-blue-100 text-blue-800';
            case 'Used - Tested': return 'bg-yellow-100 text-yellow-800';
            case 'For Parts Only': return 'bg-orange-100 text-orange-800';
            case 'Defective': return 'bg-red-100 text-red-800';
            default: return 'bg-gray-100 text-gray-800';
        }
    };

    const inventoryStats = useMemo(() => {
        const total = inventory.length;
        const byType = inventory.reduce((acc, item) => {
            acc[item.item_type] = (acc[item.item_type] || 0) + 1;
            return acc;
        }, {});
        const totalValue = inventory.reduce((sum, item) => sum + ((item.purchase_cost || 0) * (item.quantity || 1)), 0);
        return { total, byType, totalValue };
    }, [inventory]);
    
    return (
        <div className="p-8">
            <div className="flex justify-between items-center mb-8">
                <div className="flex items-center space-x-4">
                    <div className="p-3 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl shadow-lg">
                        <Archive className="w-8 h-8 text-white" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                            Professional Data Recovery Inventory
                        </h1>
                        <p className="text-sm text-gray-500 mt-1">
                            Manage donor drives, PCBs, and recovery parts with technical specifications.
                        </p>
                    </div>
                </div>
                <Button onClick={handleAddItem} className="bg-gradient-to-r from-green-500 to-emerald-600 text-white shadow-lg">
                    <PlusCircle className="w-5 h-5 mr-2" />
                    Add Inventory Item
                </Button>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
                <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
                    <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-blue-100 text-sm">Total Items</p>
                                <p className="text-2xl font-bold">{inventoryStats.total}</p>
                            </div>
                            <Package className="w-8 h-8 text-blue-200" />
                        </div>
                    </CardContent>
                </Card>
                <Card className="bg-gradient-to-r from-indigo-500 to-indigo-600 text-white">
                    <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-indigo-100 text-sm">HDDs</p>
                                <p className="text-2xl font-bold">{inventoryStats.byType.HDD || 0}</p>
                            </div>
                            <Archive className="w-8 h-8 text-indigo-200" />
                        </div>
                    </CardContent>
                </Card>
                <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
                    <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-green-100 text-sm">SSDs</p>
                                <p className="text-2xl font-bold">{inventoryStats.byType.SSD || 0}</p>
                            </div>
                            <Package className="w-8 h-8 text-green-200" />
                        </div>
                    </CardContent>
                </Card>
                <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
                    <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-purple-100 text-sm">PCBs</p>
                                <p className="text-2xl font-bold">{inventoryStats.byType.PCB || 0}</p>
                            </div>
                            <Package className="w-8 h-8 text-purple-200" />
                        </div>
                    </CardContent>
                </Card>
                <Card className="bg-gradient-to-r from-emerald-500 to-emerald-600 text-white">
                    <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-emerald-100 text-sm">Total Value</p>
                                <p className="text-xl font-bold">${inventoryStats.totalValue.toLocaleString()}</p>
                            </div>
                            <Package className="w-8 h-8 text-emerald-200" />
                        </div>
                    </CardContent>
                </Card>
            </div>

            <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0">
                <CardHeader className="p-4 border-b bg-gradient-to-r from-gray-50 to-blue-50">
                    <div className="flex flex-wrap items-center gap-4">
                        <div className="relative flex-grow sm:flex-grow-0 sm:w-80">
                            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                            <Input
                                placeholder="Search by brand, model, S/N, PCB number..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="pl-9 bg-white/70"
                            />
                        </div>
                        <div className="flex items-center space-x-2">
                             <Filter className="w-4 h-4 text-gray-500"/>
                             <Select value={filters.item_type} onValueChange={(value) => setFilters(f => ({...f, item_type: value}))}>
                                <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    {itemTypes.map(type => <SelectItem key={type} value={type}>{type}</SelectItem>)}
                                </SelectContent>
                            </Select>
                        </div>
                         <div className="flex items-center space-x-2">
                             <Filter className="w-4 h-4 text-gray-500"/>
                            <Select value={filters.condition} onValueChange={(value) => setFilters(f => ({...f, condition: value}))}>
                                <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    {conditions.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="text-sm text-gray-600">
                            Showing {filteredInventory.length} of {inventory.length} items
                        </div>
                    </div>
                </CardHeader>
                <CardContent className="p-0">
                    <div className="overflow-x-auto">
                        <Table>
                            <TableHeader>
                                <TableRow className="bg-gray-50">
                                    <TableHead className="font-semibold">Item Details</TableHead>
                                    <TableHead className="font-semibold">Type</TableHead>
                                    <TableHead className="font-semibold">Technical Info</TableHead>
                                    <TableHead className="font-semibold">Stock</TableHead>
                                    <TableHead className="font-semibold">Location</TableHead>
                                    <TableHead className="font-semibold">Condition</TableHead>
                                    <TableHead className="font-semibold">Status</TableHead>
                                    <TableHead className="font-semibold text-right">Actions</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {isLoading ? (
                                    <TableRow><TableCell colSpan={8} className="text-center py-12">Loading inventory...</TableCell></TableRow>
                                ) : filteredInventory.length === 0 ? (
                                    <TableRow><TableCell colSpan={8} className="text-center py-12">No items found matching your criteria.</TableCell></TableRow>
                                ) : (
                                    filteredInventory.map(item => (
                                        <TableRow key={item.id} className="hover:bg-gray-50">
                                            <TableCell className="font-medium">
                                                <div className="space-y-1">
                                                    <div className="font-semibold">{item.name || `${item.brand} ${item.model_number || 'Unknown'}`}</div>
                                                    <div className="text-xs text-gray-600">
                                                        <span className="font-mono">{item.brand}</span>
                                                        {item.model_number && <span className="ml-2 font-mono">{item.model_number}</span>}
                                                    </div>
                                                    {item.serial_number && (
                                                        <div className="text-xs text-gray-500 font-mono">S/N: {item.serial_number}</div>
                                                    )}
                                                </div>
                                            </TableCell>
                                            <TableCell>
                                                <Badge className={getItemTypeColor(item.item_type)}>{item.item_type}</Badge>
                                            </TableCell>
                                            <TableCell>
                                                <div className="text-xs space-y-1">
                                                    {item.capacity && <div><span className="font-medium">Capacity:</span> {item.capacity}</div>}
                                                    {item.interface && <div><span className="font-medium">Interface:</span> {item.interface}</div>}
                                                    {item.pcb_number && <div><span className="font-medium">PCB:</span> {item.pcb_number}</div>}
                                                    {item.dcm && <div><span className="font-medium">DCM:</span> {item.dcm}</div>}
                                                    {item.controller_details && <div><span className="font-medium">Controller:</span> {item.controller_details}</div>}
                                                </div>
                                            </TableCell>
                                            <TableCell>
                                                <span className={`font-bold text-lg ${item.quantity > 5 ? 'text-green-600' : item.quantity > 0 ? 'text-orange-600' : 'text-red-600'}`}>
                                                    {item.quantity || 0}
                                                </span>
                                            </TableCell>
                                            <TableCell className="text-sm">{item.location || 'Not specified'}</TableCell>
                                            <TableCell>
                                                <Badge className={getConditionColor(item.condition)} variant="outline">
                                                    {item.condition}
                                                </Badge>
                                            </TableCell>
                                            <TableCell>
                                                {item.case_id ? (
                                                    <Badge variant="secondary" className="bg-indigo-100 text-indigo-800">
                                                        <LinkIcon className="w-3 h-3 mr-1"/>
                                                        Assigned
                                                    </Badge>
                                                ) : (
                                                    <Badge className="bg-green-100 text-green-800">
                                                        Available
                                                    </Badge>
                                                )}
                                            </TableCell>
                                            <TableCell className="text-right">
                                                <div className="flex items-center justify-end space-x-1">
                                                    <Button variant="ghost" size="icon" onClick={() => handleEditItem(item)} className="h-8 w-8 hover:bg-blue-100">
                                                        <Edit className="w-4 h-4 text-blue-600" />
                                                    </Button>
                                                    <Button variant="ghost" size="icon" onClick={() => setItemToDelete(item)} className="h-8 w-8 hover:bg-red-100">
                                                        <Trash2 className="w-4 h-4 text-red-600" />
                                                    </Button>
                                                </div>
                                            </TableCell>
                                        </TableRow>
                                    ))
                                )}
                            </TableBody>
                        </Table>
                    </div>
                </CardContent>
            </Card>
            
            <InventoryFormDialog
                open={isFormOpen}
                onOpenChange={setIsFormOpen}
                item={editingItem}
                onSave={fetchData}
            />
            
            <Dialog open={!!itemToDelete} onOpenChange={() => setItemToDelete(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle className="flex items-center">
                            <AlertTriangle className="w-6 h-6 mr-2 text-red-500"/>
                            Confirm Deletion
                        </DialogTitle>
                        <DialogDescription className="pt-2">
                            Are you sure you want to delete "{itemToDelete?.name}"? This action cannot be undone and will remove all technical specifications.
                        </DialogDescription>
                    </DialogHeader>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setItemToDelete(null)}>Cancel</Button>
                        <Button variant="destructive" onClick={handleDeleteConfirmation}>Delete Item</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}