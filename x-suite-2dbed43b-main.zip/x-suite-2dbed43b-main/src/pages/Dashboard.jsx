import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Case } from '@/api/entities';
import { Quote } from '@/api/entities';
import { Invoice } from '@/api/entities';
import { Expense } from '@/api/entities';
import { User } from '@/api/entities';
import { JobHistory } from '@/api/entities';
import { createPageUrl } from '@/utils';
import {
    HardDrive, DollarSign, Activity, CheckCircle, BarChart, TrendingUp, TrendingDown, AlertTriangle, Clock, Zap,
    FilePlus, Briefcase, MessageSquare, Users, Settings, LogOut, ChevronRight,
    Package, Banknote, ShoppingCart, Download, Key
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { startOfMonth, endOfMonth, startOfDay, endOfDay, isWithinInterval, parseISO, formatDistanceToNow } from 'date-fns';
import { Button } from '@/components/ui/button';

// Re-designed Stat Card Component
const StatCard = ({ title, value, icon: Icon, color, change, period }) => (
    <Card className="shadow-lg hover:shadow-xl transition-all duration-300 bg-white/80 backdrop-blur-sm border-0">
        <CardContent className="p-4 flex items-center justify-between">
            <div>
                <p className="text-sm font-medium text-gray-500">{title}</p>
                <p className="text-2xl font-bold text-gray-800">{value}</p>
                {change && (
                    <div className={`flex items-center text-xs mt-1 ${change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {change >= 0 ? <TrendingUp className="w-4 h-4 mr-1" /> : <TrendingDown className="w-4 h-4 mr-1" />}
                        <span>{change}% {period}</span>
                    </div>
                )}
            </div>
            <div className={`p-3 rounded-full bg-gradient-to-br ${color}`}>
                <Icon className="w-6 h-6 text-white" />
            </div>
        </CardContent>
    </Card>
);

// Quick Action Button Component
const QuickActionButton = ({ icon: Icon, label, color, onClick }) => (
    <Button
        variant="outline"
        className={`w-full justify-start h-12 text-base font-semibold border-2 hover:bg-opacity-80 transition-all duration-200 bg-white hover:text-white ${color}`}
        onClick={onClick}
    >
        <Icon className="w-5 h-5 mr-3" />
        {label}
    </Button>
);

// Recent Activity Item Component
const ActivityItem = ({ icon: Icon, description, time }) => (
    <div className="flex items-start space-x-3">
        <div className="p-2 bg-gray-100 rounded-full">
            <Icon className="w-4 h-4 text-gray-500" />
        </div>
        <div className="flex-1">
            <p className="text-sm text-gray-800">{description}</p>
            <p className="text-xs text-gray-400">{time}</p>
        </div>
    </div>
);

export default function Dashboard() {
  const [stats, setStats] = useState({
    cases: 0,
    incomeToday: 0,
    incomeThisMonth: 0,
    quotes: 0,
    completed: 0,
    activeCases: 0,
  });
  const [urgentCases, setUrgentCases] = useState([]);
  const [recentActivity, setRecentActivity] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);
  const [todaysCases, setTodaysCases] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        const user = await User.me();
        setCurrentUser(user);

        const userRole = user?.role ? user.role.charAt(0).toUpperCase() + user.role.slice(1) : 'Technician';

        let cases = [];
        let invoices = [];
        let quotes = [];
        let expenses = [];

        if (userRole === 'Technician') {
          const allCases = await Case.list();
          cases = allCases.filter(c => c.assigned_engineer === user.email || c.created_by === user.email);
        } else {
            [cases, invoices, quotes, expenses] = await Promise.all([
                Case.list(), Invoice.list(), Quote.list(), Expense.list()
            ]);
        }

        const now = new Date();
        const todayStart = startOfDay(now);
        const todayEnd = endOfDay(now);
        const monthStart = startOfMonth(now);
        const monthEnd = endOfMonth(now);

        const incomeToday = invoices.filter(inv => inv.status === 'Paid' && inv.issued_date && isWithinInterval(parseISO(inv.issued_date), { start: todayStart, end: todayEnd })).reduce((acc, inv) => acc + (inv.total_amount || 0), 0);
        const incomeThisMonth = invoices.filter(inv => inv.status === 'Paid' && inv.issued_date && isWithinInterval(parseISO(inv.issued_date), { start: monthStart, end: monthEnd })).reduce((acc, inv) => acc + (inv.total_amount || 0), 0);
        const totalAcceptedQuotes = quotes.filter(q => q.status === 'Accepted').reduce((acc, q) => acc + (q.total_amount || 0), 0);

        // Updated to use dynamic workflow statuses
        const activeCases = cases.filter(c => !['Completed', 'Delivered', 'Closed', 'Cancelled', 'Unrecoverable'].includes(c.status));
        const completedCases = cases.filter(c => ['Completed', 'Delivered'].includes(c.status)).length;

        const top10UrgentCases = cases
            .filter(c => c.priority === 'Urgent' && !['Completed', 'Delivered', 'Closed', 'Cancelled', 'Unrecoverable'].includes(c.status))
            .sort((a, b) => new Date(a.created_at) - new Date(b.created_at))
            .slice(0, 10);
        setUrgentCases(top10UrgentCases);

        const todayCases = cases.filter(c => c.created_date && isWithinInterval(new Date(c.created_date), { start: todayStart, end: todayEnd }));
        setTodaysCases(todayCases.slice(0, 10));

        if (userRole === 'Admin' || userRole === 'Accounts') {
          const activity = await JobHistory.list('-timestamp', 5);
          setRecentActivity(activity);
        }
        
        setStats({
          cases: cases.length,
          incomeToday: userRole === 'Technician' ? 0 : incomeToday,
          incomeThisMonth: userRole === 'Technician' ? 0 : incomeThisMonth,
          quotes: userRole === 'Technician' ? 0 : totalAcceptedQuotes,
          completed: completedCases,
          activeCases: activeCases.length,
        });

      } catch (error) {
        console.error("Failed to fetch dashboard data:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);
  
  const userRole = currentUser?.role ? currentUser.role.charAt(0).toUpperCase() + currentUser.role.slice(1) : null;

  const getActivityIcon = (actionType) => {
      const iconMap = {
          "Case Created": FilePlus,
          "Status Changed": Activity,
          "Device Added": HardDrive,
          "Quote Generated": Briefcase,
          "Invoice Created": DollarSign,
          "Communication Added": MessageSquare,
          "Device Collected": CheckCircle,
      };
      return iconMap[actionType] || Activity;
  };

  if (isLoading) {
    return (
        <div className="flex h-screen w-full items-center justify-center">
            <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-blue-500 rounded-full animate-pulse"></div>
                <div className="w-8 h-8 bg-indigo-500 rounded-full animate-pulse delay-150"></div>
                <div className="w-8 h-8 bg-purple-500 rounded-full animate-pulse delay-300"></div>
            </div>
        </div>
    );
  }

  return (
    <div className="p-4 md:p-6 bg-gradient-to-br from-slate-50 to-indigo-100 min-h-screen">
        <div className="flex justify-between items-center mb-6">
            <div>
                <h1 className="text-2xl md:text-3xl font-bold text-gray-800">Welcome back, {currentUser?.full_name || 'User'}!</h1>
                <p className="text-gray-500 mt-1">Here's a snapshot of your business today.</p>
            </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
            
            <div className="lg:col-span-3 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <StatCard title="Total Cases" value={stats.cases} icon={HardDrive} color="from-blue-500 to-cyan-500" />
                    <StatCard title="Active Cases" value={stats.activeCases} icon={Activity} color="from-orange-500 to-amber-500" />
                    <StatCard title="Completed Cases" value={stats.completed} icon={CheckCircle} color="from-green-500 to-emerald-500" />
                </div>

                {userRole !== 'Technician' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <StatCard title="Income Today" value={`$${stats.incomeToday.toLocaleString()}`} icon={DollarSign} color="from-emerald-500 to-lime-600" />
                        <StatCard title="Income This Month" value={`$${stats.incomeThisMonth.toLocaleString()}`} icon={BarChart} color="from-purple-500 to-indigo-600" />
                    </div>
                )}
                
                <Card className="shadow-lg bg-white/80 backdrop-blur-sm border-0">
                    <CardHeader className="pb-3">
                        <CardTitle className="flex items-center text-gray-700 text-lg">
                            <Clock className="w-5 h-5 mr-2 text-blue-500" />
                            Today's Cases
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="pt-0">
                        {todaysCases.length === 0 ? (
                            <p className="text-sm text-gray-500 py-4">No cases created today.</p>
                        ) : (
                            <ul className="space-y-2">
                                {todaysCases.map(c => (
                                    <li key={c.id} className="flex justify-between items-center p-3 rounded-md hover:bg-gray-50 transition-colors">
                                        <span className="text-sm font-medium text-gray-800 truncate">#{c.case_number} — {c.case_title || c.service_type}</span>
                                        <Button variant="ghost" size="sm" onClick={() => window.open(createPageUrl(`CaseDetails?id=${c.id}`), "_blank")}>
                                            View
                                        </Button>
                                    </li>
                                ))}
                            </ul>
                        )}
                    </CardContent>
                </Card>

                {urgentCases.length > 0 && (
                    <Card className="shadow-lg bg-white/80 backdrop-blur-sm border-0">
                        <CardHeader className="pb-3">
                            <CardTitle className="flex items-center text-gray-700 text-lg">
                                <AlertTriangle className="w-5 h-5 mr-2 text-red-500" />
                                Urgent Cases
                                <Badge variant="destructive" className="ml-2 bg-red-500/10 text-red-700">Top {urgentCases.length}</Badge>
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="pt-0">
                            <ul className="space-y-2">
                                {urgentCases.map(c => (
                                    <li key={c.id} className="flex justify-between items-center p-3 rounded-md hover:bg-gray-50 transition-colors cursor-pointer" onClick={() => navigate(createPageUrl('CaseDetails', { id: c.id }))}>
                                        <div className="flex-1">
                                            <p className="text-sm font-medium text-gray-800 line-clamp-1">{c.case_title || `Case ID: ${c.id}`}</p>
                                            <p className="text-xs text-gray-500">{c.assigned_engineer ? `Assigned: ${c.assigned_engineer}` : 'Unassigned'}</p>
                                        </div>
                                        <ChevronRight className="w-4 h-4 text-gray-400" />
                                    </li>
                                ))}
                            </ul>
                        </CardContent>
                    </Card>
                )}
            </div>

            <div className="lg:col-span-1 space-y-4">
                <Card className="shadow-lg bg-white/80 backdrop-blur-sm border-0">
                    <CardHeader className="pb-3">
                        <CardTitle className="flex items-center text-gray-700 text-lg">
                            <Zap className="w-5 h-5 mr-2" />
                            Quick Actions
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2 pt-0">
                        <QuickActionButton icon={FilePlus} label="New Case" color="hover:bg-blue-500 border-blue-500 text-blue-600" onClick={() => navigate(createPageUrl('NewCase'))} />
                        <QuickActionButton icon={DollarSign} label="New Invoice" color="hover:bg-green-500 border-green-500 text-green-600" onClick={() => navigate(createPageUrl('NewInvoice'))} />
                        <QuickActionButton icon={Download} label="Download Center" color="hover:bg-purple-500 border-purple-500 text-purple-600" onClick={() => navigate(createPageUrl('DownloadCenter'))} />
                        <QuickActionButton icon={CheckCircle} label="New Task" color="hover:bg-orange-500 border-orange-500 text-orange-600" onClick={() => navigate(createPageUrl('Tasks'))} />
                        
                        <Button variant="ghost" className="w-full justify-end text-sm" onClick={() => User.logout()}>
                           Log Out <LogOut className="w-4 h-4 ml-2" />
                        </Button>
                    </CardContent>
                </Card>

                {userRole && ['Admin', 'Accounts'].includes(userRole) && recentActivity.length > 0 && (
                  <Card className="shadow-lg bg-white/80 backdrop-blur-sm border-0">
                      <CardHeader className="pb-3">
                          <CardTitle className="flex items-center justify-between text-gray-700 text-lg">
                              <div className="flex items-center">
                                  <Clock className="w-5 h-5 mr-2" />
                                  Recent Activity
                              </div>
                              <Button variant="ghost" size="sm" onClick={() => navigate(createPageUrl('JobHistory'))}>View All <ChevronRight className="w-4 h-4 ml-1" /></Button>
                          </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3 pt-0">
                          {recentActivity.map(activity => (
                              <ActivityItem 
                                  key={activity.id}
                                  icon={getActivityIcon(activity.action_type)}
                                  description={activity.description}
                                  time={formatDistanceToNow(new Date(activity.timestamp), { addSuffix: true })}
                              />
                          ))}
                      </CardContent>
                  </Card>
                )}
            </div>
        </div>
    </div>
  );
}