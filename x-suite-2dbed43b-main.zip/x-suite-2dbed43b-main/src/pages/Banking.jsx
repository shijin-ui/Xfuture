import React, { useEffect, useMemo, useState } from "react";
import { Bank } from "@/api/entities";
import { BankDeposit } from "@/api/entities";
import { BankTransfer } from "@/api/entities";
import { Transaction } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import QuickDateRange from "@/components/common/QuickDateRange";
import DataExportButtons from "@/components/common/DataExportButtons";
import { Plus, Search } from "lucide-react";
import { format, isWithinInterval } from "date-fns";

function BankAccountsTab() {
  const [banks, setBanks] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ bank_name: "", account_name: "", account_number: "", iban: "", currency: "OMR" });

  const refresh = async () => setBanks(await Bank.list());
  useEffect(() => { refresh(); }, []);

  const save = async () => {
    if (!form.bank_name || !form.account_name || !form.account_number) return alert("Please fill required fields");
    await Bank.create(form);
    setShowForm(false);
    setForm({ bank_name: "", account_name: "", account_number: "", iban: "", currency: "OMR" });
    refresh();
  };

  return (
    <Card>
      <CardHeader className="flex items-center justify-between">
        <CardTitle>Company Bank Accounts</CardTitle>
        <Button onClick={() => setShowForm(s => !s)} size="sm"><Plus className="w-4 h-4 mr-2" />Add Bank</Button>
      </CardHeader>
      <CardContent>
        {showForm && (
          <div className="grid grid-cols-1 md:grid-cols-5 gap-3 mb-4">
            <Input placeholder="Bank Name" value={form.bank_name} onChange={e => setForm({ ...form, bank_name: e.target.value })} />
            <Input placeholder="Account Name" value={form.account_name} onChange={e => setForm({ ...form, account_name: e.target.value })} />
            <Input placeholder="Account Number" value={form.account_number} onChange={e => setForm({ ...form, account_number: e.target.value })} />
            <Input placeholder="IBAN" value={form.iban} onChange={e => setForm({ ...form, iban: e.target.value })} />
            <Button onClick={save}>Save</Button>
          </div>
        )}
        <div className="overflow-auto">
          <table className="w-full text-sm">
            <thead className="sticky top-0 bg-muted">
              <tr>
                <th className="text-left p-2">Bank</th>
                <th className="text-left p-2">Account</th>
                <th className="text-left p-2">Number</th>
                <th className="text-left p-2">IBAN</th>
                <th className="text-left p-2">Currency</th>
              </tr>
            </thead>
            <tbody>
              {banks.map(b => (
                <tr key={b.id} className="hover:bg-muted/50">
                  <td className="p-2">{b.bank_name}</td>
                  <td className="p-2">{b.account_name}</td>
                  <td className="p-2">{b.account_number}</td>
                  <td className="p-2">{b.iban}</td>
                  <td className="p-2">{b.currency}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}

function TxnList({ title, filterType }) {
  const [txns, setTxns] = useState([]);
  const [search, setSearch] = useState("");
  const [range, setRange] = useState({ start: new Date(new Date().setHours(0,0,0,0)), end: new Date() });

  const refresh = async () => setTxns(await Transaction.list("-transaction_date", 2000));
  useEffect(() => { refresh(); }, []);

  const filtered = useMemo(() => {
    return txns.filter(t => {
      const matchType = filterType === "credit" ? t.transaction_type === "Income" : filterType === "debit" ? t.transaction_type === "Expense" : true;
      const matchText = [t.reference_number, t.notes, t.payment_method, t.amount].join(" ").toLowerCase().includes(search.toLowerCase());
      const d = t.transaction_date ? new Date(t.transaction_date) : null;
      const matchDate = d ? isWithinInterval(d, { start: range.start, end: range.end }) : true;
      return matchType && matchText && matchDate;
    });
  }, [txns, search, range, filterType]);

  const toCsv = (rows) => {
    return ["Date,Type,Method,Amount,Reference,Notes",
      ...rows.map(r => [
        r.transaction_date || "",
        r.transaction_type || "",
        r.payment_method || "",
        r.amount ?? "",
        r.reference_number || "",
        (r.notes || "").replace(/,/g, ";")
      ].join(",")),
    ].join("\n");
  };

  return (
    <Card>
      <CardHeader className="flex items-center justify-between">
        <CardTitle>{title}</CardTitle>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Search..." value={search} onChange={e => setSearch(e.target.value)} className="pl-8 w-48" />
          </div>
          <QuickDateRange value={range} onChange={setRange} />
          <DataExportButtons rows={filtered} filename={title.replace(/\s+/g, "_")} toCsv={toCsv} />
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-auto">
          <table className="w-full text-sm">
            <thead className="sticky top-0 bg-muted">
              <tr>
                <th className="text-left p-2">Date</th>
                <th className="text-left p-2">Type</th>
                <th className="text-left p-2">Method</th>
                <th className="text-left p-2">Amount</th>
                <th className="text-left p-2">Reference</th>
                <th className="text-left p-2">Notes</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(t => (
                <tr key={t.id} className="hover:bg-muted/50">
                  <td className="p-2">{t.transaction_date}</td>
                  <td className="p-2">{t.transaction_type}</td>
                  <td className="p-2">{t.payment_method}</td>
                  <td className="p-2">{t.amount}</td>
                  <td className="p-2">{t.reference_number}</td>
                  <td className="p-2">{t.notes}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}

export default function BankingPage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Banking</h1>
      <Tabs defaultValue="accounts">
        <TabsList className="mb-4">
          <TabsTrigger value="accounts">Bank Accounts</TabsTrigger>
          <TabsTrigger value="deposits">Deposits</TabsTrigger>
          <TabsTrigger value="transfers">Transfers</TabsTrigger>
          <TabsTrigger value="credit">Credit / Income</TabsTrigger>
          <TabsTrigger value="debit">Debit / Expense</TabsTrigger>
        </TabsList>

        <TabsContent value="accounts"><BankAccountsTab /></TabsContent>
        <TabsContent value="deposits">
          <TxnList title="Deposits" filterType="credit" />
        </TabsContent>
        <TabsContent value="transfers">
          <TxnList title="Transfers" />
        </TabsContent>
        <TabsContent value="credit"><TxnList title="Credit / Income" filterType="credit" /></TabsContent>
        <TabsContent value="debit"><TxnList title="Debit / Expense" filterType="debit" /></TabsContent>
      </Tabs>
    </div>
  );
}