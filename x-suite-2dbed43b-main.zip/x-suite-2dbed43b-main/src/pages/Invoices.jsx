
import React, { useState, useEffect, useMemo } from 'react';
import { Invoice } from '@/api/entities';
import { Case } from '@/api/entities';
import { Customer } from '@/api/entities';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { DollarSign, PlusCircle, Search, MoreHorizontal, Edit, FileText, Download, Receipt, Plus, Eye, Trash2, Loader2, AlertTriangle } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { format, parseISO } from 'date-fns';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const statusColors = {
  Draft: 'bg-gray-200 text-gray-800',
  Sent: 'bg-blue-100 text-blue-800',
  Paid: 'bg-green-100 text-green-800',
  Overdue: 'bg-red-100 text-red-800',
};

export default function InvoicesPage() {
  const [invoices, setInvoices] = useState([]);
  const [cases, setCases] = useState({});
  const [customers, setCustomers] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [error, setError] = useState(null); // New state for error handling
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      setError(null); // Clear any previous errors
      
      try {
        // Add delay between API calls to avoid potential rate limiting issues
        const invoiceData = await Invoice.list('-created_date');
        // console.log('Fetched invoices:', invoiceData.length); // For debugging
        
        // Small delay before next call
        await new Promise(resolve => setTimeout(resolve, 500)); 
        
        const caseData = await Case.list();
        // console.log('Fetched cases:', caseData.length); // For debugging
        
        // Small delay before next call
        await new Promise(resolve => setTimeout(resolve, 500)); 
        
        const customerData = await Customer.list();
        // console.log('Fetched customers:', customerData.length); // For debugging
        
        setInvoices(invoiceData);
        setCases(caseData.reduce((acc, c) => ({ ...acc, [c.id]: c }), {}));
        setCustomers(customerData.reduce((acc, c) => ({ ...acc, [c.id]: c }), {}));

      } catch (err) {
        console.error('Failed to fetch data:', err);
        setError('Failed to load invoices. The system may be experiencing high traffic or a temporary issue. Please wait a moment and refresh the page.');
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, []);

  const getCaseNumber = (caseId) => cases[caseId]?.case_number || 'N/A';
  const getCustomerName = (customerId) => customers[customerId]?.full_name || 'N/A';
  const getCompanyName = (customerId) => customers[customerId]?.company_name || ''; // Can be empty if no company
  const getStatusColor = (status) => statusColors[status] || 'bg-gray-200 text-gray-800';

  const filteredInvoices = useMemo(() => {
    if (!searchTerm) return invoices;
    const lowercasedFilter = searchTerm.toLowerCase();
    return invoices.filter(invoice => {
      const caseInfo = cases[invoice.case_id];
      const customerInfo = customers[invoice.customer_id];
      return (
        invoice.invoice_number?.toLowerCase().includes(lowercasedFilter) ||
        invoice.status?.toLowerCase().includes(lowercasedFilter) ||
        (invoice.is_proforma ? 'proforma' : 'invoice').includes(lowercasedFilter) || // Allow searching by type
        caseInfo?.case_number?.toLowerCase().includes(lowercasedFilter) ||
        customerInfo?.full_name?.toLowerCase().includes(lowercasedFilter) ||
        customerInfo?.company_name?.toLowerCase().includes(lowercasedFilter)
      );
    });
  }, [searchTerm, invoices, cases, customers]);

  const handleDownload = (invoice) => {
    const invoiceType = invoice.include_vat ? 'Tax Invoice' : (invoice.is_proforma ? 'Proforma Invoice' : 'Invoice');
    const caseInfo = cases[invoice.case_id];
    const fileName = `${invoiceType} #${invoice.invoice_number} [${caseInfo?.case_number || 'N/A'}].pdf`;
    
    // Create temporary link to trigger download
    const link = document.createElement('a');
    link.href = createPageUrl(`PrintInvoice?id=${invoice.id}&download=true`);
    link.download = fileName;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDelete = async (invoiceId) => {
    if (window.confirm('Are you sure you want to delete this invoice? This action cannot be undone.')) {
      try {
        await Invoice.delete(invoiceId);
        setInvoices(prev => prev.filter(inv => inv.id !== invoiceId));
        console.log(`Invoice ${invoiceId} deleted successfully.`);
      } catch (err) {
        console.error('Failed to delete invoice:', err);
        alert('Failed to delete invoice. Please try again.');
      }
    }
  };

  const handleRetry = () => {
    window.location.reload(); // Simple retry by reloading the page
  };

  if (error) {
    return (
      <div className="p-8 bg-gradient-to-br from-slate-50 to-indigo-100 min-h-screen flex items-center justify-center">
        <div className="max-w-2xl w-full mx-auto">
          <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0">
            <CardContent className="p-8 text-center">
              <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
              <h2 className="text-xl font-bold text-gray-800 mb-2">Unable to Load Invoices</h2>
              <p className="text-gray-600 mb-6">{error}</p>
              <Button onClick={handleRetry} className="bg-blue-600 hover:bg-blue-700">
                <Loader2 className="w-4 h-4 mr-2 hidden animate-spin" /> {/* Hidden for now, can be shown on click */}
                Retry
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 bg-gradient-to-br from-slate-50 to-indigo-100 min-h-screen">
      <div className="flex justify-between items-center mb-8">
        <div className="flex items-center space-x-4">
          <div className="p-3 bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl shadow-lg">
            <DollarSign className="w-8 h-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
              Invoices & Proforma
            </h1>
            <p className="text-gray-500 mt-1">Manage all invoices and proforma invoices</p>
          </div>
        </div>
        
        <div className="flex space-x-3">
          <Button 
            onClick={() => navigate(createPageUrl('InvoiceDetails?proforma=true'))} 
            variant="outline"
            className="bg-purple-50 text-purple-600 border-purple-200 hover:bg-purple-100"
          >
            <Receipt className="w-5 h-5 mr-2" />
            New Proforma
          </Button>
          <Button 
            className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white shadow-lg"
            onClick={() => navigate(createPageUrl('InvoiceDetails'))}
          >
            <Plus className="w-5 h-5 mr-2" />
            New Invoice
          </Button>
        </div>
      </div>

      <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0 overflow-hidden">
        <CardHeader className="bg-gray-50/50">
          <div className="flex justify-between items-center">
            <CardTitle className="text-xl font-semibold text-gray-800">All Invoices & Proforma ({filteredInvoices.length})</CardTitle>
            <div className="relative w-72">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search by invoice #, case #, client, type..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 h-9 bg-white/70"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-100/80">
                  <TableHead>Type</TableHead>
                  <TableHead>Invoice #</TableHead>
                  <TableHead>Case #</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Issue Date</TableHead>
                  <TableHead>Due Date</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={9} className="text-center py-12">
                      <div className="flex items-center justify-center space-x-2">
                        <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
                        <span className="text-gray-600">Loading invoices...</span>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : filteredInvoices.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={9} className="text-center py-12">
                      <p className="text-gray-500">No invoices found.</p>
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredInvoices.map(invoice => {
                    const caseInfo = cases[invoice.case_id];
                    const customerInfo = customers[invoice.customer_id];
                    return (
                      <TableRow key={invoice.id} className="hover:bg-blue-50/50">
                        <TableCell>
                          <Badge className={invoice.is_proforma ? 'bg-purple-100 text-purple-800' : 'bg-green-100 text-green-800'}>
                            {invoice.is_proforma ? 'Proforma' : 'Invoice'}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-mono font-semibold">
                          <Link to={createPageUrl(`InvoiceDetails?id=${invoice.id}`)} className="hover:underline">
                            {invoice.invoice_number}
                          </Link>
                        </TableCell>
                        <TableCell>
                          <Link 
                            to={createPageUrl(`CaseDetails?id=${invoice.case_id}`)}
                            className="text-blue-600 hover:underline font-mono"
                          >
                            {getCaseNumber(invoice.case_id)}
                          </Link>
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{getCustomerName(invoice.customer_id)}</div>
                            {getCompanyName(invoice.customer_id) && (
                              <div className="text-sm text-gray-500">{getCompanyName(invoice.customer_id)}</div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          {format(parseISO(invoice.issued_date || invoice.created_date), 'dd MMM yyyy')}
                        </TableCell>
                        <TableCell>
                          {invoice.due_date && !invoice.is_proforma ? 
                            format(parseISO(invoice.due_date), 'dd MMM yyyy') : 
                            '-'
                          }
                        </TableCell>
                        <TableCell className="text-right font-mono font-semibold">
                          {(invoice.total_amount || 0).toFixed(3)} OMR
                        </TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(invoice.status)}>
                            {invoice.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end space-x-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => navigate(createPageUrl(`InvoiceDetails?id=${invoice.id}`))}
                              title="Edit / View"
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => window.open(createPageUrl(`PrintInvoice?id=${invoice.id}`), '_blank')}
                              title="Print / View PDF"
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDownload(invoice)}
                              title="Download PDF"
                            >
                              <Download className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDelete(invoice.id)}
                              className="text-red-600 hover:bg-red-50"
                              title="Delete Invoice"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
