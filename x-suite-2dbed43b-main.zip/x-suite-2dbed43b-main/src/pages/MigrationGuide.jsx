import React from 'react';
import ReactMarkdown from 'react-markdown';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const migrationGuideText = `
# Self-Hosting & Backend Migration Guide

This guide provides the necessary assets and architecture patterns to migrate your application off the base44 platform and run it with your own custom backend.

---

## 1. SQL Database Schema

Here is a complete PostgreSQL schema generated from all the entities in your application. You can use this to set up your local database.

\`\`\`sql
-- Enable UUID generation
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- User Table (with built-in fields)
CREATE TABLE "User" (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_date TIMESTAMPTZ DEFAULT NOW(),
    updated_date TIMESTAMPTZ DEFAULT NOW(),
    full_name TEXT,
    email TEXT UNIQUE NOT NULL,
    role TEXT, -- base44 standard role
    access_role TEXT, -- your custom role
    avatar_url TEXT,
    user_code TEXT,
    secondary_email TEXT,
    phone_country_code TEXT DEFAULT '+968',
    secondary_phone_country_code TEXT DEFAULT '+968',
    secondary_phone TEXT
);

-- Cases Table
CREATE TABLE "Case" (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_date TIMESTAMPTZ DEFAULT NOW(),
    updated_date TIMESTAMPTZ DEFAULT NOW(),
    created_by TEXT,
    customer_id UUID REFERENCES "Customer"(id) ON DELETE SET NULL,
    case_number TEXT,
    client_reference TEXT,
    service_type TEXT,
    status TEXT,
    priority TEXT,
    assigned_engineer TEXT,
    welcome_email BOOLEAN DEFAULT true,
    welcome_sms BOOLEAN DEFAULT false,
    device_problem TEXT,
    important_data TEXT,
    service_location TEXT,
    service_description TEXT,
    devices JSONB,
    media_type TEXT,
    media_model TEXT,
    media_serial_number TEXT,
    media_capacity TEXT,
    device_password TEXT,
    collected_by_name TEXT,
    collected_by_mobile TEXT,
    collected_by_id TEXT,
    collection_date TIMESTAMPTZ
);

-- Customer Table
CREATE TABLE "Customer" (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_date TIMESTAMPTZ DEFAULT NOW(),
    updated_date TIMESTAMPTZ DEFAULT NOW(),
    created_by TEXT,
    full_name TEXT NOT NULL,
    customer_code TEXT,
    email TEXT NOT NULL,
    secondary_email TEXT,
    phone_number TEXT,
    phone_country_code TEXT DEFAULT '+968',
    secondary_phone TEXT,
    secondary_phone_country_code TEXT DEFAULT '+968',
    city TEXT,
    country TEXT DEFAULT 'Oman',
    company_name TEXT,
    customer_group TEXT,
    dealer_discount_percentage NUMERIC DEFAULT 0,
    dealer_since DATE,
    monthly_case_target NUMERIC,
    notes TEXT,
    address TEXT
);

-- Company Table
CREATE TABLE "Company" (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_date TIMESTAMPTZ DEFAULT NOW(),
    updated_date TIMESTAMPTZ DEFAULT NOW(),
    created_by TEXT,
    company_name TEXT NOT NULL,
    company_code TEXT,
    vat_number TEXT,
    url TEXT,
    country TEXT,
    city TEXT,
    industry TEXT,
    contact_person TEXT,
    email TEXT,
    secondary_email TEXT,
    phone TEXT,
    phone_country_code TEXT DEFAULT '+968',
    secondary_phone TEXT,
    secondary_phone_country_code TEXT DEFAULT '+968',
    address TEXT,
    customer_group TEXT
);

-- Other Entities...

CREATE TABLE "Quote" (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_date TIMESTAMPTZ DEFAULT NOW(),
    updated_date TIMESTAMPTZ DEFAULT NOW(),
    created_by TEXT,
    case_id UUID REFERENCES "Case"(id) ON DELETE CASCADE,
    customer_id UUID REFERENCES "Customer"(id) ON DELETE SET NULL,
    quote_number TEXT NOT NULL,
    status TEXT,
    rejection_reason TEXT,
    status_notes TEXT,
    line_items JSONB,
    quote_terms JSONB,
    discount_type TEXT,
    discount_value NUMERIC,
    discount_amount NUMERIC,
    subtotal NUMERIC,
    dealer_discount_percentage NUMERIC,
    dealer_discount_amount NUMERIC,
    include_vat BOOLEAN,
    vat_rate NUMERIC,
    vat_amount NUMERIC,
    total_amount NUMERIC,
    sent_date DATE,
    expiry_date DATE
);

CREATE TABLE "Invoice" (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_date TIMESTAMPTZ DEFAULT NOW(),
    updated_date TIMESTAMPTZ DEFAULT NOW(),
    created_by TEXT,
    case_id UUID REFERENCES "Case"(id) ON DELETE CASCADE,
    customer_id UUID REFERENCES "Customer"(id) ON DELETE SET NULL,
    invoice_number TEXT NOT NULL,
    is_proforma BOOLEAN,
    status TEXT,
    line_items JSONB,
    discount_type TEXT,
    discount_value NUMERIC,
    discount_amount NUMERIC,
    subtotal NUMERIC,
    include_vat BOOLEAN,
    vat_rate NUMERIC,
    vat_amount NUMERIC,
    total_amount NUMERIC,
    amount_paid NUMERIC,
    balance_due NUMERIC,
    issued_date DATE,
    due_date DATE
);

CREATE TABLE "JobHistory" (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_date TIMESTAMPTZ DEFAULT NOW(),
    updated_date TIMESTAMPTZ DEFAULT NOW(),
    created_by TEXT,
    case_id UUID REFERENCES "Case"(id) ON DELETE CASCADE,
    action_type TEXT,
    description TEXT,
    old_value TEXT,
    new_value TEXT,
    performed_by TEXT,
    "timestamp" TIMESTAMPTZ
);

-- You can continue this pattern for all other entities:
-- Expense, Communication, City, MediaEvaluation, CaseFile, Setting, etc.
\`\`\`

---

## 2. Backend API (OpenAPI/Server Stubs)

I cannot provide a pre-built OpenAPI spec, but you can easily create one. Your application's API is defined by the **methods available on your entities**.

**Your Task:** Create a standard REST or GraphQL API. For each entity (e.g., \`Case\`), create the following endpoints:
- \`GET /api/cases\`: List all cases (with filtering and pagination).
- \`GET /api/cases/:id\`: Get a single case by its ID.
- \`POST /api/cases\`: Create a new case.
- \`PATCH /api/cases/:id\`: Update an existing case.
- \`DELETE /api/cases/:id\`: Delete a case.

The JSON structure for the request/response bodies of these endpoints should match the \`properties\` defined in each \`entities/*.json\` file.

---

## 3. Authentication (Auth Server Recipe)

The base44 auth flow is proprietary, but you can replicate it with standard tools. The core is JWT (JSON Web Tokens).

**Your Task: Build an Auth Server**
1.  **Choose a library:** Use libraries like \`jsonwebtoken\` in Node.js, \`Passport.js\`, or a service like Auth0 or Clerk.
2.  **Create Login Endpoint (\`POST /api/auth/login\`):**
    *   Accepts email/password or social login credentials.
    *   Verifies credentials against your \`User\` table.
    *   If valid, **mint a JWT**. The token's payload should include \`userId\`, \`email\`, and \`access_role\`.
    *   Return the JWT to the frontend.
3.  **Create "Me" Endpoint (\`GET /api/users/me\`):**
    *   This endpoint must require a valid JWT in the \`Authorization\` header.
    *   It should verify the token, then look up the user in the database by the \`userId\` from the token payload.
    *   It returns the full user object. This replaces the \`User.me()\` functionality.
4.  **Frontend Changes:**
    *   Store the JWT securely (e.g., in an HttpOnly cookie or local storage).
    *   Modify your API client to include \`Authorization: Bearer <your_jwt>\` on every request to protected endpoints.
    *   Update the \`userCache.js\` or \`api.js\` to call your new \`/api/users/me\` endpoint instead of \`User.me()\`.

---

## 4. Replacing Platform Services

### File Storage
The \`UploadFile\` integration needs to be replaced with your own file storage endpoint.

**Your Task:**
1.  **Set up a storage service:** Use AWS S3, Google Cloud Storage, or a local file server.
2.  **Create a backend endpoint (\`POST /api/upload\`):**
    *   This endpoint should accept a multipart/form-data request containing the file.
    *   It uploads the file to your storage service.
    *   It returns a JSON object with the public URL of the uploaded file: \`{ "file_url": "..." }\`.
3.  **Frontend Changes:** Update any component using \`UploadFile\` (like \`FilesTab.jsx\`) to call your new \`/api/upload\` endpoint.

### Role-Based Access Control (RBAC)
This is critical for security. Frontend checks must be moved to the backend.

**Your Task:**
1.  **Create Backend Middleware:** Implement a middleware function for your API server.
2.  **Check Permissions:** The middleware should run before your protected route handlers. It must:
    *   Verify the user's JWT.
    *   Extract the \`access_role\` from the token.
    *   Check if that role is allowed to access the specific endpoint (e.g., only \`'Admin'\` can access \`DELETE /api/cases/:id\`).
    *   If not allowed, return a \`403 Forbidden\` error.
3.  **Frontend Simplification:** Your frontend code can still use the user's role to show/hide UI elements (like buttons), but the backend middleware is now the source of truth for security.

By following this guide, you will have a solid foundation for a fully self-hosted version of your application.
`;

const MarkdownStyles = () => (
    <style>{`
        .prose {
            color: #374151;
            line-height: 1.75;
            width: 100%;
        }
        .prose h1 {
            font-size: 2.25rem;
            line-height: 2.5rem;
            font-weight: 800;
            margin-top: 0;
            margin-bottom: 2rem;
        }
        .prose h2 {
            font-size: 1.5rem;
            line-height: 2rem;
            font-weight: 700;
            margin-top: 3rem;
            margin-bottom: 1.5rem;
            border-bottom: 1px solid #e5e7eb;
            padding-bottom: 0.5rem;
        }
        .prose h3 {
            font-size: 1.25rem;
            line-height: 1.75rem;
            font-weight: 600;
            margin-top: 2rem;
            margin-bottom: 1rem;
        }
        .prose p, .prose ul, .prose ol {
            margin-top: 1.25em;
            margin-bottom: 1.25em;
        }
        .prose a {
            color: #2563eb;
            text-decoration: none;
            font-weight: 500;
        }
        .prose a:hover {
            text-decoration: underline;
        }
        .prose code {
            color: #4b5563;
            background-color: #f3f4f6;
            padding: 0.2em 0.4em;
            margin: 0;
            font-size: 85%;
            border-radius: 6px;
            font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
        }
        .prose pre {
            background-color: #1f2937;
            color: #d1d5db;
            padding: 1em;
            border-radius: 8px;
            overflow-x: auto;
        }
        .prose pre code {
            background-color: transparent;
            padding: 0;
            color: inherit;
        }
        .prose ul {
            list-style-type: disc;
            padding-left: 1.5rem;
        }
        .prose li {
            margin-top: 0.5em;
            margin-bottom: 0.5em;
        }
    `}</style>
);

export default function MigrationGuidePage() {
    return (
        <div className="p-4 md:p-8 bg-gray-50 min-h-screen">
            <MarkdownStyles />
            <Card>
                <CardHeader>
                    <CardTitle className="text-2xl font-bold">Migration Guide</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="prose max-w-none">
                       <ReactMarkdown>{migrationGuideText}</ReactMarkdown>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}