
import React, { useState, useEffect } from 'react';
import { Customer } from '@/api/entities';
import { Company } from '@/api/entities';
import { User } from '@/api/entities'; // Added for admin check
import { JobHistory } from '@/api/entities'; // Added for logging deletions
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Card, CardHeader, CardContent } from '@/components/ui/card'; // Added CardHeader, CardContent
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog'; // Added DialogDescription
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Users, PlusCircle, Mail, Phone, Building, Edit, Search, Trash2, Loader2, ArrowUpDown } from 'lucide-react'; // Added Trash2, Loader2, ArrowUpDown
import { format } from 'date-fns';
import { getSettingsByCategory } from '../components/utils/settingsLoader';
import SearchableSelect from '../components/SearchableSelect';

// Company Edit Dialog Component
const EditCompanyDialog = ({ open, onOpenChange, company, onCompanyUpdate }) => {
  const [companyData, setCompanyData] = useState({
    company_name: '',
    vat_number: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    country: 'Oman',
    customer_group: 'Corporate'
  });
  const [isLoading, setIsLoading] = useState(false);
  const [customerGroups, setCustomerGroups] = useState([]);

  useEffect(() => {
    if (company && open) {
      setCompanyData({
        company_name: company.company_name || '',
        vat_number: company.vat_number || '',
        email: company.email || '',
        phone: company.phone || '',
        address: company.address || '',
        city: company.city || '',
        country: company.country || 'Oman',
        customer_group: company.customer_group || 'Corporate'
      });
    }

    const fetchCustomerGroups = async () => {
      try {
        const groups = await getSettingsByCategory('Customer Groups');
        setCustomerGroups(groups.length > 0 ? groups : ['Individual', 'Corporate', 'VIP', 'Government', 'Education']);
      } catch (error) {
        console.error('Failed to fetch customer groups:', error);
        setCustomerGroups(['Individual', 'Corporate', 'VIP', 'Government', 'Education']);
      }
    };

    if (open) {
      fetchCustomerGroups();
    }
  }, [company, open]);

  const handleSave = async () => {
    if (!companyData.company_name.trim()) {
      alert('Company name is required');
      return;
    }

    setIsLoading(true);
    try {
      if (company?.id) {
        await Company.update(company.id, companyData);
      } else {
        await Company.create(companyData);
      }
      onCompanyUpdate();
      onOpenChange(false);
    } catch (error) {
      console.error('Failed to save company:', error);
      alert('Failed to save company details');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <Building className="w-5 h-5 mr-2 text-blue-600" />
            Edit Company Details
          </DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-4 py-4">
          <div className="space-y-4">
            <div>
              <Label>Company Name <span className="text-red-500">*</span></Label>
              <Input
                value={companyData.company_name}
                onChange={(e) => setCompanyData({...companyData, company_name: e.target.value})}
                placeholder="Enter company name"
              />
            </div>
            <div>
              <Label>VAT Number</Label>
              <Input
                value={companyData.vat_number}
                onChange={(e) => setCompanyData({...companyData, vat_number: e.target.value})}
                placeholder="Enter VAT number"
              />
            </div>
            <div>
              <Label>Email</Label>
              <Input
                type="email"
                value={companyData.email}
                onChange={(e) => setCompanyData({...companyData, email: e.target.value})}
                placeholder="company@example.com"
              />
            </div>
            <div>
              <Label>Customer Group</Label>
              <Select value={companyData.customer_group} onValueChange={(value) => setCompanyData({...companyData, customer_group: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select Group" />
                </SelectTrigger>
                <SelectContent>
                  {customerGroups.length > 0 ? (
                    customerGroups.map(group => (
                      <SelectItem key={group} value={group}>{group}</SelectItem>
                    ))
                  ) : (
                    <SelectItem value="Corporate" disabled>Loading...</SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-4">
            <div>
              <Label>Phone</Label>
              <Input
                value={companyData.phone}
                onChange={(e) => setCompanyData({...companyData, phone: e.target.value})}
                placeholder="Enter phone number"
              />
            </div>
            <div>
              <Label>City</Label>
              <Input
                value={companyData.city}
                onChange={(e) => setCompanyData({...companyData, city: e.target.value})}
                placeholder="Enter city"
              />
            </div>
            <div>
              <Label>Address</Label>
              <Textarea
                value={companyData.address}
                onChange={(e) => setCompanyData({...companyData, address: e.target.value})}
                placeholder="Enter full address"
                rows={3}
              />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSave} disabled={isLoading}>
            {isLoading ? 'Saving...' : 'Save Changes'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

// Customer Edit Dialog Component
const EditCustomerDialog = ({ open, onOpenChange, customer, onCustomerUpdate }) => {
  const [customerData, setCustomerData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [allCompanies, setAllCompanies] = useState([]);
  const [customerGroups, setCustomerGroups] = useState([]);
  const [countries, setCountries] = useState([]);
  const [cities, setCities] = useState([]);

  useEffect(() => {
    if (customer && open) {
      setCustomerData({
        full_name: customer.full_name || '',
        email: customer.email || '',
        phone_number: customer.phone_number || '',
        customer_group: customer.customer_group || 'Individual',
        company_name: customer.company_name || '',
        address: customer.address || '',
        city: customer.city || '',
        country: customer.country || 'Oman',
        notes: customer.notes || '',
        secondary_email: customer.secondary_email || '', // NEW
        secondary_phone: customer.secondary_phone || '', // NEW
        customer_code: customer.customer_code || '',     // NEW
      });

      // Fetch all companies, customer groups, countries, and cities when dialog opens
      const fetchData = async () => {
        try {
          const [companies, groups, countriesData, citiesData] = await Promise.all([
            Company.list(),
            getSettingsByCategory('Customer Groups'),
            getSettingsByCategory('Countries'),
            getSettingsByCategory('Cities')
          ]);
          setAllCompanies(companies);
          setCustomerGroups(groups.length > 0 ? groups : ['Individual', 'Corporate', 'VIP', 'Government', 'Education']);
          setCountries(countriesData.length > 0 ? countriesData.map(c => ({ value: c, label: c })) : ['Oman', 'United Arab Emirates', 'Qatar', 'Kuwait', 'Bahrain', 'Saudi Arabia'].map(c => ({ value: c, label: c })));
          setCities(citiesData.length > 0 ? citiesData.map(c => ({ value: c, label: c })) : ['Muscat', 'Salalah', 'Sohar', 'Nizwa', 'Dubai', 'Abu Dhabi', 'Doha'].map(c => ({ value: c, label: c })));
        } catch (error) {
          console.error('Failed to fetch data:', error);
          setCustomerGroups(['Individual', 'Corporate', 'VIP', 'Government', 'Education']);
          setCountries(['Oman', 'United Arab Emirates', 'Qatar', 'Kuwait', 'Bahrain', 'Saudi Arabia'].map(c => ({ value: c, label: c })));
          setCities(['Muscat', 'Salalah', 'Sohar', 'Nizwa', 'Dubai', 'Abu Dhabi', 'Doha'].map(c => ({ value: c, label: c })));
        }
      };
      fetchData();
    } else {
      setCustomerData(null);
      setCustomerGroups([]);
      setCountries([]);
      setCities([]);
    }
  }, [customer, open]);

  const handleSave = async () => {
    if (!customerData.full_name || !customerData.email) {
      alert('Full Name and Email are required.');
      return;
    }
    setIsLoading(true);
    try {
      await Customer.update(customer.id, customerData);
      onCustomerUpdate();
      onOpenChange(false);
    } catch (error) {
      console.error('Failed to update customer:', error);
      alert('Failed to update customer details.');
    } finally {
      setIsLoading(false);
    }
  };

  if (!customerData) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <Users className="w-5 h-5 mr-2 text-purple-600" />
            Edit Customer Details
          </DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-4 py-4">
          <div>
            <Label>Full Name <span className="text-red-500">*</span></Label>
            <Input
              value={customerData.full_name}
              onChange={(e) => setCustomerData({ ...customerData, full_name: e.target.value })}
            />
          </div>
          <div>
            <Label>Customer Code</Label> {/* NEW FIELD */}
            <Input
              value={customerData.customer_code}
              onChange={(e) => setCustomerData({ ...customerData, customer_code: e.target.value })}
              placeholder="e.g. CUST001"
            />
          </div>
          <div>
            <Label>Email <span className="text-red-500">*</span></Label>
            <Input
              type="email"
              value={customerData.email}
              onChange={(e) => setCustomerData({ ...customerData, email: e.target.value })}
            />
          </div>
          <div>
            <Label>Secondary Email</Label> {/* NEW FIELD */}
            <Input
              type="email"
              value={customerData.secondary_email}
              onChange={(e) => setCustomerData({ ...customerData, secondary_email: e.target.value })}
              placeholder="secondary@example.com"
            />
          </div>
          <div>
            <Label>Phone</Label>
            <Input
              value={customerData.phone_number}
              onChange={(e) => setCustomerData({ ...customerData, phone_number: e.target.value })}
            />
          </div>
          <div>
            <Label>Secondary Phone</Label> {/* NEW FIELD */}
            <Input
              value={customerData.secondary_phone}
              onChange={(e) => setCustomerData({ ...customerData, secondary_phone: e.target.value })}
              placeholder="Secondary phone number"
            />
          </div>
          <div>
            <Label>Group</Label>
            <Select value={customerData.customer_group} onValueChange={(value) => setCustomerData({ ...customerData, customer_group: value })}>
              <SelectTrigger>
                <SelectValue placeholder="Select Group" />
              </SelectTrigger>
              <SelectContent>
                {customerGroups.length > 0 ? (
                  customerGroups.map(group => (
                    <SelectItem key={group} value={group}>{group}</SelectItem>
                  ))
                ) : (
                  <SelectItem value="Individual" disabled>Loading...</SelectItem>
                )}
              </SelectContent>
            </Select>
          </div>
          <div className="col-span-2">
            <Label>Company</Label>
            <SearchableSelect
              value={customerData.company_name}
              onValueChange={(value) => setCustomerData({ ...customerData, company_name: value })}
              placeholder="Search and select company..."
              options={allCompanies.map(company => ({
                value: company.company_name,
                label: company.company_name,
                subtitle: company.vat_number ? `VAT: ${company.vat_number}` : (company.city ? `${company.city}` : '')
              }))}
              searchPlaceholder="Type to search companies..."
            />
            <p className="text-xs text-gray-500 mt-1">
              Start typing to search existing companies, or enter a new company name
            </p>
          </div>
          <div>
            <Label>Country</Label>
            <SearchableSelect
              value={customerData.country}
              onValueChange={(value) => setCustomerData({ ...customerData, country: value })}
              placeholder="Search and select country..."
              options={countries}
              searchPlaceholder="Type to search countries..."
            />
          </div>
          <div>
            <Label>City</Label>
            <SearchableSelect
              value={customerData.city}
              onValueChange={(value) => setCustomerData({ ...customerData, city: value })}
              placeholder="Search and select city..."
              options={cities}
              searchPlaceholder="Type to search cities..."
            />
          </div>
          <div className="col-span-2">
            <Label>Address</Label>
            <Textarea
              value={customerData.address}
              onChange={(e) => setCustomerData({ ...customerData, address: e.target.value })}
              placeholder="Enter full address"
              rows={2}
            />
          </div>
           <div className="col-span-2">
            <Label>Notes</Label>
            <Textarea
              value={customerData.notes || ''}
              onChange={(e) => setCustomerData({ ...customerData, notes: e.target.value })}
              placeholder="Any notes about the customer"
              rows={2}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSave} disabled={isLoading}>
            {isLoading ? 'Saving...' : 'Save Changes'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

// Add Customer Dialog Component
const AddCustomerDialog = ({ open, onOpenChange, onCustomerCreated }) => {
  const [customerData, setCustomerData] = useState({
    full_name: '',
    email: '',
    phone_number: '',
    customer_group: 'Individual',
    company_name: '',
    address: '',
    city: '',
    country: 'Oman',
    notes: '',
    secondary_email: '', // NEW
    secondary_phone: '', // NEW
    customer_code: '',   // NEW
  });
  const [isLoading, setIsLoading] = useState(false);
  const [allCompanies, setAllCompanies] = useState([]);
  const [customerGroups, setCustomerGroups] = useState([]);
  const [countries, setCountries] = useState([]);
  const [cities, setCities] = useState([]);

  useEffect(() => {
    if (open) {
      // Reset form data when opening
      setCustomerData({
        full_name: '',
        email: '',
        phone_number: '',
        customer_group: 'Individual',
        company_name: '',
        address: '',
        city: '',
        country: 'Oman',
        notes: '',
        secondary_email: '', // NEW
        secondary_phone: '', // NEW
        customer_code: '',   // NEW
      });

      // Fetch companies, customer groups, countries, and cities
      const fetchData = async () => {
        try {
          const [companies, groups, countriesData, citiesData] = await Promise.all([
            Company.list(),
            getSettingsByCategory('Customer Groups'),
            getSettingsByCategory('Countries'),
            getSettingsByCategory('Cities')
          ]);
          setAllCompanies(companies);
          setCustomerGroups(groups.length > 0 ? groups : ['Individual', 'Corporate', 'VIP', 'Government', 'Education']);
          setCountries(countriesData.length > 0 ? countriesData.map(c => ({ value: c, label: c })) : ['Oman', 'United Arab Emirates', 'Qatar', 'Kuwait', 'Bahrain', 'Saudi Arabia'].map(c => ({ value: c, label: c })));
          setCities(citiesData.length > 0 ? citiesData.map(c => ({ value: c, label: c })) : ['Muscat', 'Salalah', 'Sohar', 'Nizwa', 'Dubai', 'Abu Dhabi', 'Doha'].map(c => ({ value: c, label: c })));
        } catch (error) {
          console.error('Failed to fetch data:', error);
          setCustomerGroups(['Individual', 'Corporate', 'VIP', 'Government', 'Education']);
          setCountries(['Oman', 'United Arab Emirates', 'Qatar', 'Kuwait', 'Bahrain', 'Saudi Arabia'].map(c => ({ value: c, label: c })));
          setCities(['Muscat', 'Salalah', 'Sohar', 'Nizwa', 'Dubai', 'Abu Dhabi', 'Doha'].map(c => ({ value: c, label: c })));
        }
      };
      fetchData();
    }
  }, [open]);

  const handleSave = async () => {
    if (!customerData.full_name || !customerData.email) {
      alert('Full Name and Email are required.');
      return;
    }

    setIsLoading(true);
    try {
      await Customer.create(customerData);
      onCustomerCreated();
      onOpenChange(false);
    } catch (error) {
      console.error('Failed to create customer:', error);
      alert('Failed to create customer.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <PlusCircle className="w-5 h-5 mr-2 text-green-600" />
            Add New Customer
          </DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-4 py-4">
          <div>
            <Label>Full Name <span className="text-red-500">*</span></Label>
            <Input
              value={customerData.full_name}
              onChange={(e) => setCustomerData({ ...customerData, full_name: e.target.value })}
              placeholder="Enter customer's full name"
            />
          </div>
          <div>
            <Label>Customer Code</Label> {/* NEW FIELD */}
            <Input
              value={customerData.customer_code}
              onChange={(e) => setCustomerData({ ...customerData, customer_code: e.target.value })}
              placeholder="e.g. CUST001"
            />
          </div>
          <div>
            <Label>Email <span className="text-red-500">*</span></Label>
            <Input
              type="email"
              value={customerData.email}
              onChange={(e) => setCustomerData({ ...customerData, email: e.target.value })}
              placeholder="customer@example.com"
            />
          </div>
          <div>
            <Label>Secondary Email</Label> {/* NEW FIELD */}
            <Input
              type="email"
              value={customerData.secondary_email}
              onChange={(e) => setCustomerData({ ...customerData, secondary_email: e.target.value })}
              placeholder="secondary@example.com"
            />
          </div>
          <div>
            <Label>Phone</Label>
            <Input
              value={customerData.phone_number}
              onChange={(e) => setCustomerData({ ...customerData, phone_number: e.target.value })}
              placeholder="Phone number"
            />
          </div>
          <div>
            <Label>Secondary Phone</Label> {/* NEW FIELD */}
            <Input
              value={customerData.secondary_phone}
              onChange={(e) => setCustomerData({ ...customerData, secondary_phone: e.target.value })}
              placeholder="Secondary phone number"
            />
          </div>
          <div>
            <Label>Group</Label>
            <Select value={customerData.customer_group} onValueChange={(value) => setCustomerData({ ...customerData, customer_group: value })}>
              <SelectTrigger>
                <SelectValue placeholder="Select Group" />
              </SelectTrigger>
              <SelectContent>
                {customerGroups.map(group => (
                  <SelectItem key={group} value={group}>{group}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="col-span-2">
            <Label>Company</Label>
            <SearchableSelect
              value={customerData.company_name}
              onValueChange={(value) => setCustomerData({ ...customerData, company_name: value })}
              placeholder="Search and select company..."
              options={allCompanies.map(company => ({
                value: company.company_name,
                label: company.company_name,
                subtitle: company.vat_number ? `VAT: ${company.vat_number}` : (company.city ? `${company.city}` : '')
              }))}
              searchPlaceholder="Type to search companies..."
            />
          </div>
          <div>
            <Label>Country</Label>
            <SearchableSelect
              value={customerData.country}
              onValueChange={(value) => setCustomerData({ ...customerData, country: value })}
              placeholder="Search and select country..."
              options={countries}
              searchPlaceholder="Type to search countries..."
            />
          </div>
          <div>
            <Label>City</Label>
            <SearchableSelect
              value={customerData.city}
              onValueChange={(value) => setCustomerData({ ...customerData, city: value })}
              placeholder="Search and select city..."
              options={cities}
              searchPlaceholder="Type to search cities..."
            />
          </div>
          <div className="col-span-2">
            <Label>Address</Label>
            <Textarea
              value={customerData.address}
              onChange={(e) => setCustomerData({ ...customerData, address: e.target.value })}
              placeholder="Enter full address"
              rows={2}
            />
          </div>
           <div className="col-span-2">
            <Label>Notes</Label>
            <Textarea
              value={customerData.notes}
              onChange={(e) => setCustomerData({ ...customerData, notes: e.target.value })}
              placeholder="Any notes about the customer"
              rows={2}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSave} disabled={isLoading || !customerData.full_name || !customerData.email}>
            {isLoading ? 'Creating...' : 'Create Customer'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default function CustomersPage() {
  const [customers, setCustomers] = useState([]);
  const [companies, setCompanies] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [editingCompany, setEditingCompany] = useState(null);
  const [isEditCompanyOpen, setIsEditCompanyOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState(null);
  const [isEditCustomerOpen, setIsEditCustomerOpen] = useState(false);
  const [isAddCustomerOpen, setIsAddCustomerOpen] = useState(false);
  const [sortBy, setSortBy] = useState('-created_date'); // Added sortBy state for sorting
  const [showDeleteDialog, setShowDeleteDialog] = useState(false); // Added for delete dialog
  const [customerToDelete, setCustomerToDelete] = useState(null); // Added for customer to delete
  const [adminPassword, setAdminPassword] = useState(''); // Added for delete confirmation
  const [isDeleting, setIsDeleting] = useState(false); // Added for delete loading state

  const fetchCustomers = async () => {
    setIsLoading(true);
    try {
      // Filter out soft-deleted customers and apply sorting
      const customerData = await Customer.filter({ is_deleted: false }, sortBy, 50); // Assuming Customer.filter exists
      const companyData = await Company.list();

      // Create company lookup by name
      const companyMap = companyData.reduce((acc, company) => {
        acc[company.company_name] = company;
        return acc;
      }, {});

      setCustomers(customerData);
      setCompanies(companyMap);
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchCustomers();
  }, [sortBy]); // Refetch when sortBy changes

  const handleEditCompany = (customerCompanyName) => {
    const company = companies[customerCompanyName];
    if (company) {
      setEditingCompany(company);
    } else {
      // Create new company entry if not found
      setEditingCompany({
        company_name: customerCompanyName,
        vat_number: '',
        email: '',
        phone: '',
        address: '',
        city: '',
        country: 'Oman',
        customer_group: 'Corporate' // Default for new company
      });
    }
    setIsEditCompanyOpen(true);
  };

  const handleEditCustomer = (customer) => {
    setEditingCustomer(customer);
    setIsEditCustomerOpen(true);
  };

  const handleDeleteCustomer = async () => {
    if (!customerToDelete || !adminPassword) {
        alert('Please enter admin password to confirm deletion.');
        return;
    }

    setIsDeleting(true);
    try {
        // In a real app, you'd verify the admin password here
        // For now, we'll just check if the current user is admin
        const currentUser = await User.me(); // Assuming User.me() exists
        if (currentUser.access_role !== 'Admin') {
            alert('Only administrators can delete customers.');
            return;
        }

        // Soft delete the customer
        await Customer.update(customerToDelete.id, {
            is_deleted: true,
            deleted_at: new Date().toISOString(),
            deleted_by: currentUser.email
        });

        // Log the deletion
        await JobHistory.create({
            case_id: null, // Assuming case_id can be null for customer deletion
            action_type: "Customer Deleted",
            description: `Customer ${customerToDelete.full_name} (${customerToDelete.email}) was soft deleted`,
            performed_by: currentUser.email,
            timestamp: new Date().toISOString()
        });

        alert('Customer deleted successfully.');
        fetchCustomers(); // Re-fetch customers after deletion
        setShowDeleteDialog(false);
        setCustomerToDelete(null);
        setAdminPassword('');
    } catch (error) {
        console.error('Failed to delete customer:', error);
        alert('Failed to delete customer.');
    } finally {
        setIsDeleting(false);
    }
  };

  const filteredCustomers = customers.filter(customer => {
    const searchLower = searchTerm.toLowerCase();
    return (
      customer.full_name?.toLowerCase().includes(searchLower) ||
      customer.email?.toLowerCase().includes(searchLower) ||
      customer.company_name?.toLowerCase().includes(searchLower) ||
      customer.phone_number?.includes(searchTerm) ||
      customer.secondary_phone?.includes(searchTerm) || // New search field
      customer.secondary_email?.toLowerCase().includes(searchLower) || // New search field
      customer.customer_code?.toLowerCase().includes(searchLower) // New search field
    );
  });

  const getCustomerGroupColor = (group) => {
    const colors = {
      'VIP': 'bg-gradient-to-r from-purple-100 to-pink-100 text-purple-800 border-purple-200',
      'Corporate': 'bg-gradient-to-r from-blue-100 to-indigo-100 text-blue-800 border-blue-200',
      'Individual': 'bg-gradient-to-r from-green-100 to-emerald-100 text-green-800 border-green-200',
      'Government': 'bg-gradient-to-r from-red-100 to-rose-100 text-red-800 border-red-200',
      'Education': 'bg-gradient-to-r from-yellow-100 to-orange-100 text-yellow-800 border-yellow-200'
    };
    return colors[group] || 'bg-gray-100 text-gray-800 border-gray-200';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      <div className="p-8">
        {/* Beautiful Header */}
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center space-x-4">
            <div className="p-3 bg-gradient-to-r from-purple-500 to-pink-600 rounded-xl shadow-lg">
              <Users className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                Customers
              </h1>
              <p className="text-sm text-gray-500 mt-1">
                {isLoading ? 'Loading customers...' : `Manage ${customers.length} customers and their companies`}
              </p>
            </div>
          </div>
          <Button
            onClick={() => setIsAddCustomerOpen(true)}
            className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white shadow-lg transform hover:scale-105 transition-all duration-200"
          >
            <PlusCircle className="w-5 h-5 mr-2"/>
            Add Customer
          </Button>
        </div>

        {/* Beautiful Customers Table */}
        <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0 overflow-hidden">
          <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50 p-4 border-b flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <h2 className="text-xl font-semibold text-gray-800">
              Customer Directory ({filteredCustomers.length})
            </h2>
            {/* Search Bar moved inside CardHeader */}
            <div className="relative max-w-md w-full sm:w-auto">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search customers..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 bg-white/70 border-gray-200 focus:border-purple-400 focus:ring-2 focus:ring-purple-100"
              />
            </div>
          </CardHeader>

          <CardContent className="p-0"> {/* Removed padding from CardContent to allow table to fill */}
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-gradient-to-r from-gray-100 to-gray-50">
                    <TableHead
                      className="font-semibold text-gray-700 cursor-pointer"
                      onClick={() => setSortBy(sortBy === 'full_name' ? '-full_name' : 'full_name')}
                    >
                      Name {sortBy.includes('full_name') && <ArrowUpDown className="w-4 h-4 inline-block ml-1" />}
                    </TableHead>
                    <TableHead className="font-semibold text-gray-700">Contact</TableHead>
                    <TableHead className="font-semibold text-gray-700">Secondary Contact</TableHead>
                    <TableHead className="font-semibold text-gray-700">Company</TableHead>
                    <TableHead className="font-semibold text-gray-700">Group</TableHead>
                    <TableHead className="font-semibold text-gray-700">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-12">
                        <div className="flex items-center justify-center space-x-2">
                          <div className="w-6 h-6 bg-purple-500 rounded-full animate-pulse"></div>
                          <div className="w-6 h-6 bg-pink-500 rounded-full animate-pulse delay-100"></div>
                          <div className="w-6 h-6 bg-indigo-500 rounded-full animate-pulse delay-200"></div>
                        </div>
                        <p className="mt-4 text-gray-600">Loading customers...</p>
                      </TableCell>
                    </TableRow>
                  ) : filteredCustomers.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-12">
                        <Users className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                        <p className="text-lg font-medium text-gray-500">No customers found</p>
                        <p className="text-sm text-gray-400">Try adjusting your search criteria</p>
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredCustomers.map((customer, index) => {
                      const isEvenRow = index % 2 === 0;
                      return (
                        <TableRow
                          key={customer.id}
                          className={`hover:bg-gradient-to-r hover:from-purple-50 hover:to-pink-50 transition-all duration-200 ${
                            isEvenRow ? 'bg-white' : 'bg-gray-50/50'
                          }`}
                        >
                          <TableCell className="font-medium text-gray-800">
                            <div>
                              <Link
                                to={createPageUrl(`CustomerProfile?id=${customer.id}`)}
                                className="font-semibold text-blue-600 hover:text-blue-800 hover:underline cursor-pointer"
                              >
                                {customer.full_name}
                              </Link>
                              {customer.customer_code && (
                                <div className="text-xs text-gray-500 mt-1">#{customer.customer_code}</div>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="text-sm">
                              <div className="flex items-center">
                                <Mail className="w-3 h-3 mr-1 text-gray-400" />
                                <a href={`mailto:${customer.email}`} className="text-blue-600 hover:underline">
                                  {customer.email}
                                </a>
                              </div>
                              <div className="flex items-center mt-1">
                                <Phone className="w-3 h-3 mr-1 text-gray-400" />
                                <a href={`tel:${customer.phone_number}`} className="text-green-600 hover:underline">
                                  {customer.phone_number || 'N/A'}
                                </a>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="text-sm">
                              {customer.secondary_email && (
                                <div className="flex items-center">
                                  <Mail className="w-3 h-3 mr-1 text-gray-400" />
                                  <a href={`mailto:${customer.secondary_email}`} className="text-blue-600 hover:underline">
                                    {customer.secondary_email}
                                  </a>
                                </div>
                              )}
                              {customer.secondary_phone && (
                                <div className="flex items-center mt-1">
                                  <Phone className="w-3 h-3 mr-1 text-gray-400" />
                                  <a href={`tel:${customer.secondary_phone}`} className="text-green-600 hover:underline">
                                    {customer.secondary_phone}
                                  </a>
                                </div>
                              )}
                              {!customer.secondary_email && !customer.secondary_phone && <span className="text-gray-400">-</span>}
                            </div>
                          </TableCell>
                          <TableCell>
                            {customer.company_name ? (
                              <div className="flex items-center space-x-2">
                                <span className="font-medium text-blue-700">{customer.company_name}</span>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleEditCompany(customer.company_name)}
                                  className="h-6 w-6 p-0 text-blue-600 hover:bg-blue-100"
                                  title="Edit company details"
                                >
                                  <Edit className="w-3 h-3" />
                                </Button>
                              </div>
                            ) : (
                              <span className="text-gray-400">N/A</span>
                            )}
                          </TableCell>
                          <TableCell>
                            <Badge className={`${getCustomerGroupColor(customer.customer_group)} font-medium px-3 py-1`}>
                              {customer.customer_group || 'Individual'}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center space-x-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleEditCustomer(customer)}
                                className="text-gray-600 hover:text-blue-600"
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="text-red-600 hover:text-red-800"
                                onClick={() => { setCustomerToDelete(customer); setShowDeleteDialog(true); }}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>

      <EditCompanyDialog
        open={isEditCompanyOpen}
        onOpenChange={setIsEditCompanyOpen}
        company={editingCompany}
        onCompanyUpdate={fetchCustomers}
      />

      <EditCustomerDialog
        open={isEditCustomerOpen}
        onOpenChange={setIsEditCustomerOpen}
        customer={editingCustomer}
        onCustomerUpdate={fetchCustomers}
      />

      <AddCustomerDialog
        open={isAddCustomerOpen}
        onOpenChange={setIsAddCustomerOpen}
        onCustomerCreated={fetchCustomers}
      />

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
          <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                  <DialogTitle className="flex items-center text-red-600">
                      <Trash2 className="w-5 h-5 mr-2" />
                      Delete Customer
                  </DialogTitle>
                  <DialogDescription>
                      This action will permanently hide the customer from the system. This cannot be undone.
                  </DialogDescription>
              </DialogHeader>

              {customerToDelete && (
                  <div className="py-4">
                      <div className="mb-4 p-3 bg-red-50 rounded-lg border border-red-200">
                          <p className="font-semibold text-red-800">{customerToDelete.full_name}</p>
                          <p className="text-sm text-red-600">{customerToDelete.email}</p>
                      </div>

                      <div>
                          <Label htmlFor="adminPassword">Admin Password <span className="text-red-500">*</span></Label>
                          <Input
                              id="adminPassword"
                              type="password"
                              value={adminPassword}
                              onChange={(e) => setAdminPassword(e.target.value)}
                              placeholder="Enter your admin password to confirm"
                              className="mt-1"
                          />
                      </div>
                  </div>
              )}

              <DialogFooter>
                  <Button variant="outline" onClick={() => { setShowDeleteDialog(false); setCustomerToDelete(null); setAdminPassword(''); }}>
                      Cancel
                  </Button>
                  <Button
                      variant="destructive"
                      onClick={handleDeleteCustomer}
                      disabled={!adminPassword || isDeleting}
                  >
                      {isDeleting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Trash2 className="w-4 h-4 mr-2" />}
                      {isDeleting ? 'Deleting...' : 'Delete Customer'}
                  </Button>
              </DialogFooter>
          </DialogContent>
      </Dialog>
    </div>
  );
}
