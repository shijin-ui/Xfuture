
import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { MediaEvaluation } from '@/api/entities';
import { Case } from '@/api/entities';
import { Customer } from '@/api/entities';
import { CompanyProfile } from '@/api/entities'; // New import for CompanyProfile
import { Button } from '@/components/ui/button';
import { Printer, CheckSquare, Wrench, Database, Microscope, ClipboardList, Target, AlertTriangle, FileText } from 'lucide-react'; // Updated icon imports based on usage
import { format } from 'date-fns';

const ReportSection = ({ title, icon: Icon, children }) => (
    <div className="mb-6">
        <h3 className="flex items-center text-lg font-semibold text-gray-800 border-b-2 border-gray-200 pb-2 mb-3">
            <Icon className="w-5 h-5 mr-3 text-blue-600" />
            {title}
        </h3>
        <div className="text-sm text-gray-700 space-y-2">{children}</div>
    </div>
);

const FindingItem = ({ item }) => (
    <li className="flex items-start">
        <CheckSquare className="w-4 h-4 mr-2 mt-0.5 text-green-600 flex-shrink-0" />
        <span>{item}</span>
    </li>
);

export default function PrintEvaluationReport() {
    const [evaluation, setEvaluation] = useState(null);
    const [caseData, setCaseData] = useState(null);
    const [customer, setCustomer] = useState(null);
    const [companyProfile, setCompanyProfile] = useState(null); // New state for company profile
    const [isLoading, setIsLoading] = useState(true);
    const location = useLocation();

    useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            const evaluationId = new URLSearchParams(location.search).get('id');
            if (!evaluationId) {
                setIsLoading(false);
                return;
            }

            try {
                // Fetch evaluation and company profile in parallel
                const [evalData, profiles] = await Promise.all([
                    MediaEvaluation.get(evaluationId),
                    CompanyProfile.list() // Fetch company profile
                ]);

                setEvaluation(evalData);
                if (profiles.length > 0) {
                    setCompanyProfile(profiles[0]); // Assuming one company profile for the system
                }

                if (evalData && evalData.case_id) {
                    const caseResult = await Case.get(evalData.case_id);
                    setCaseData(caseResult);

                    if (caseResult && caseResult.customer_id) {
                        const customerResult = await Customer.get(caseResult.customer_id);
                        setCustomer(customerResult);
                    }
                }
            } catch (error) {
                console.error("Error fetching report data:", error);
                setEvaluation(null); // Indicate failure to load evaluation
                setCaseData(null);
                setCustomer(null);
                setCompanyProfile(null);
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, [location]);

    useEffect(() => {
        // Only print when all necessary data is loaded and not loading anymore
        // Customer is no longer a strict requirement for printing the report, can be 'N/A'
        if (!isLoading && evaluation && caseData && companyProfile) {
            window.print();
        }
    }, [isLoading, evaluation, caseData, companyProfile]);


    if (isLoading) {
        return <div className="p-10">Loading report...</div>;
    }

    // After loading, check if all required data is available for rendering
    // Customer is no longer a strict requirement for rendering, can be 'N/A'
    if (!evaluation || !caseData || !companyProfile) {
        return <div className="p-10">Report data incomplete or not found. Please ensure all details are available.</div>;
    }

    const device = caseData?.devices.find(d => d.media_serial_number === evaluation.device_serial_number);

    return (
        <>
            <style>{`
                @page { size: A4; margin: 0; }
                @media print {
                    body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
                    .no-print { display: none; }
                    /* Styles for print-container when printing */
                    .print-container {
                        width: 210mm; /* A4 width */
                        min-height: 297mm; /* A4 height */
                        margin: 0 !important; /* Remove auto margins for print */
                        padding: 1.5cm !important; /* Apply A4 page padding */
                        box-shadow: none !important; /* Remove shadow for print */
                        border: none !important; /* Remove border for print */
                        background: white !important; /* Ensure white background */
                    }
                    /* Override screen specific layout for print */
                    .max-w-4xl { max-width: none !important; }
                    .mx-auto { margin-left: 0 !important; margin-right: 0 !important; }
                    .p-4 { padding: 0 !important; }
                    .bg-white { background-color: white !important; }
                }
                body { background-color: #f3f4f6; }
                /* Screen styles for print-container */
                .print-container { background: white; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
            `}</style>
            
            <div className="max-w-4xl mx-auto p-4 bg-white">
                <div className="no-print flex justify-end mb-4">
                    <Button onClick={() => window.print()}><Printer className="mr-2 h-4 w-4" /> Print Report</Button>
                </div>
                <div className="print-container border p-8 rounded-lg font-sans text-gray-900">
                    {/* Elegant Header */}
                    <header className="flex justify-between items-start pb-4 border-b-2 border-gray-100 mb-6">
                        <div className="flex-shrink-0">
                            {companyProfile?.full_logo_url ? (
                                <img src={companyProfile.full_logo_url} alt={`${companyProfile.company_name || ''} Logo`} className="h-16 max-w-xs object-contain" />
                            ) : (
                                <h1 className="text-2xl font-bold text-gray-800">{companyProfile?.logo_text || companyProfile?.company_name || 'Space Recovery'}</h1>
                            )}
                        </div>
                        <div className="text-right text-xs text-gray-600 space-y-1">
                            <p className="font-bold text-base text-gray-800">{companyProfile?.company_name}</p>
                            {companyProfile?.company_address && <p>{companyProfile.company_address}</p>}
                            <div className="flex justify-end space-x-4">
                                {companyProfile?.email && <p>{companyProfile.email}</p>}
                                {companyProfile?.mobile_number_1 && <p> | {companyProfile.mobile_number_1}</p>}
                            </div>
                            {companyProfile?.website && <p className="text-blue-600">{companyProfile.website}</p>}
                            <div className="flex justify-end text-xs mt-1 space-x-2">
                                {companyProfile?.company_registration_number && <span>Reg: {companyProfile.company_registration_number}</span>}
                                {companyProfile?.tax_id && <span>VAT: {companyProfile.tax_id}</span>}
                            </div>
                        </div>
                    </header>

                    {/* Report Title */}
                    <h2 className="text-2xl font-bold text-center mb-6 text-gray-800">Media Evaluation Report</h2>

                    {/* Case & Customer Details */}
                    <section className="grid grid-cols-3 gap-6 my-6 text-sm">
                        <div className="bg-gray-50 p-4 rounded-lg">
                            <h4 className="font-semibold text-gray-500 mb-2">Job ID</h4>
                            <p className="font-bold text-lg">{caseData?.case_number}</p>
                        </div>
                        <div className="bg-gray-50 p-4 rounded-lg">
                            <h4 className="font-semibold text-gray-500 mb-2">Evaluation Date</h4>
                            <p className="font-semibold">{format(new Date(evaluation.evaluation_date), 'dd MMM yyyy')}</p>
                        </div>
                        <div className="bg-gray-50 p-4 rounded-lg">
                            <h4 className="font-semibold text-gray-500 mb-2">Technician</h4>
                            <p className="font-semibold">{evaluation.technician_name}</p>
                        </div>
                        <div className="col-span-2 bg-gray-50 p-4 rounded-lg">
                            <h4 className="font-semibold text-gray-500 mb-2">Client Information</h4>
                            <p><strong>Name:</strong> {customer?.full_name || 'N/A'}</p>
                            <p><strong>Company:</strong> {customer?.company_name || 'N/A'}</p>
                        </div>
                        <div className="bg-gray-50 p-4 rounded-lg">
                            <h4 className="font-semibold text-gray-500 mb-2">Device Details</h4>
                            <p><strong>Type:</strong> {device?.media_type || 'N/A'}</p>
                            <p><strong>S/N:</strong> {evaluation.device_serial_number || 'N/A'}</p>
                        </div>
                    </section>

                    {/* Diagnostic Findings */}
                    <ReportSection title="Diagnostic Findings" icon={Microscope}>
                        <div className="grid grid-cols-2 gap-6">
                            <div>
                                <h4 className="font-semibold mb-2 flex items-center"><Wrench className="w-4 h-4 mr-2 text-red-500"/>Physical Condition</h4>
                                {evaluation.physical_findings && evaluation.physical_findings.length > 0 ? (
                                    <ul className="space-y-1 list-inside">
                                        {evaluation.physical_findings.map((finding, i) => <FindingItem key={i} item={finding} />)}
                                    </ul>
                                ) : <p className="text-gray-500">No major physical faults detected.</p>}
                                {evaluation.physical_findings_notes && <p className="mt-2 text-xs bg-red-50 p-2 rounded">{evaluation.physical_findings_notes}</p>}
                            </div>
                            <div>
                                <h4 className="font-semibold mb-2 flex items-center"><Database className="w-4 h-4 mr-2 text-blue-500"/>Logical Condition</h4>
                                {evaluation.logical_findings && evaluation.logical_findings.length > 0 ? (
                                    <ul className="space-y-1 list-inside">
                                        {evaluation.logical_findings.map((finding, i) => <FindingItem key={i} item={finding} />)}
                                    </ul>
                                ) : <p className="text-gray-500">No major logical faults detected.</p>}
                                {evaluation.logical_findings_notes && <p className="mt-2 text-xs bg-blue-50 p-2 rounded">{evaluation.logical_findings_notes}</p>}
                            </div>
                        </div>
                    </ReportSection>

                    {/* Recovery Plan */}
                    <ReportSection title="Proposed Recovery Plan" icon={ClipboardList}>
                        <p>{evaluation.recovery_plan || 'A standard recovery procedure will be followed.'}</p>
                        {evaluation.required_parts && (
                            <div className="mt-2">
                                <strong>Required Parts/Tools:</strong>
                                <p className="text-xs bg-yellow-50 p-2 rounded">{evaluation.required_parts}</p>
                            </div>
                        )}
                    </ReportSection>

                    {/* Prognosis */}
                    <ReportSection title="Recovery Prognosis" icon={Target}>
                        <div className="grid grid-cols-2 gap-6">
                            <div>
                                <strong>Feasibility:</strong>
                                <p className="font-bold text-blue-700">{evaluation.recovery_feasibility}</p>
                            </div>
                            <div>
                                <strong>Estimated Time:</strong>
                                <p>{evaluation.estimated_completion_time || 'To be determined'}</p>
                            </div>
                        </div>
                    </ReportSection>
                    
                    {evaluation.risk_assessment && (
                        <ReportSection title="Risk Assessment" icon={AlertTriangle}>
                            <p className="text-orange-800 bg-orange-50 p-3 rounded-lg">{evaluation.risk_assessment}</p>
                        </ReportSection>
                    )}

                    {/* Recommendation */}
                    <ReportSection title="Recommendation" icon={FileText}>
                        <p className="font-semibold">{evaluation.recommendation || 'Proceed with recovery based on the quote provided.'}</p>
                    </ReportSection>

                    {/* Footer - Updated with Company Profile name */}
                    <footer className="mt-12 pt-6 border-t-2 border-gray-200 text-center text-xs text-gray-500">
                        <p>This report is based on the initial diagnosis of the media submitted. The feasibility and timeframe are estimates and may change as the recovery process progresses. {companyProfile?.company_name || 'The service provider'} is not liable for any further data loss that may occur during the recovery attempt.</p>
                        <p className="mt-2 font-semibold">{companyProfile?.company_name || 'Your Trusted Data Recovery Partner'} - Your Trusted Data Recovery Partner</p>
                    </footer>
                </div>
            </div>
        </>
    );
}
