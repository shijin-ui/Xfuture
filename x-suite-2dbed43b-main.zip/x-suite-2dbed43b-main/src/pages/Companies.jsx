
import React, { useState, useEffect } from 'react';
import { Company } from '@/api/entities';
import { Customer } from '@/api/entities';
import { Case } from '@/api/entities';
import { Quote } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Building, Users, HardDrive, FileText, CheckCircle, Percent, PlusCircle, Search } from 'lucide-react';
import { EditCompanyDialog } from '../components/case/EditCompanyDialog';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const StatCard = ({ icon: Icon, title, value, color }) => (
    <div className="flex items-center space-x-3">
        <div className={`p-2 rounded-lg bg-${color}-100`}>
            <Icon className={`w-5 h-5 text-${color}-600`} />
        </div>
        <div>
            <p className="text-xs text-gray-500">{title}</p>
            <p className="text-lg font-bold text-gray-800">{value}</p>
        </div>
    </div>
);

export default function CompaniesPage() {
    const [companies, setCompanies] = useState([]);
    const [stats, setStats] = useState({});
    const [isLoading, setIsLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [isAddCompanyOpen, setIsAddCompanyOpen] = useState(false);

    const fetchData = async () => {
        setIsLoading(true);
        try {
            const [companyData, customerData, caseData, quoteData] = await Promise.all([
                Company.list(),
                Customer.list(),
                Case.list(),
                Quote.list(),
            ]);

            const customerMap = customerData.reduce((acc, customer) => {
                if (customer.company_name) {
                    if (!acc[customer.company_name]) {
                        acc[customer.company_name] = [];
                    }
                    acc[customer.company_name].push(customer);
                }
                return acc;
            }, {});

            const caseMap = caseData.reduce((acc, caseItem) => {
                if (caseItem.customer_id) {
                    if (!acc[caseItem.customer_id]) {
                        acc[caseItem.customer_id] = [];
                    }
                    acc[caseItem.customer_id].push(caseItem);
                }
                return acc;
            }, {});
            
            const companyStats = {};
            for (const company of companyData) {
                const companyCustomers = customerMap[company.company_name] || [];
                const customerIds = companyCustomers.map(c => c.id);
                
                const companyCases = customerIds.flatMap(id => caseMap[id] || []);
                const caseIds = companyCases.map(c => c.id);

                const companyQuotes = quoteData.filter(q => caseIds.includes(q.case_id));
                const acceptedQuotes = companyQuotes.filter(q => q.status === 'Accepted').length;
                const totalSentQuotes = companyQuotes.filter(q => ['Sent', 'Accepted', 'Rejected'].includes(q.status)).length;
                const conversionRate = totalSentQuotes > 0 ? Math.round((acceptedQuotes / totalSentQuotes) * 100) : 0;

                companyStats[company.id] = {
                    customerCount: companyCustomers.length,
                    caseCount: companyCases.length,
                    quoteCount: companyQuotes.length,
                    conversionRate: conversionRate,
                };
            }

            setCompanies(companyData);
            setStats(companyStats);
        } catch (error) {
            console.error("Failed to fetch company data:", error);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    const filteredCompanies = companies.filter(company =>
        company.company_name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 p-8">
            <div className="flex justify-between items-center mb-8">
                <div className="flex items-center space-x-4">
                    <div className="p-3 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl shadow-lg">
                        <Building className="w-8 h-8 text-white" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                            Companies Overview
                        </h1>
                        <p className="text-sm text-gray-500 mt-1">
                            {isLoading ? 'Loading companies...' : `Managing ${companies.length} corporate clients`}
                        </p>
                    </div>
                </div>
                <Button 
                    onClick={() => setIsAddCompanyOpen(true)}
                    className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white shadow-lg transform hover:scale-105 transition-all duration-200"
                >
                    <PlusCircle className="w-5 h-5 mr-2" />
                    Add Company
                </Button>
            </div>

            <div className="mb-6 max-w-md">
                <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                        placeholder="Search companies..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-9 bg-white/70 border-gray-200 focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100"
                    />
                </div>
            </div>

            {isLoading ? (
                 <div className="text-center py-12">
                    <div className="flex items-center justify-center space-x-2">
                        <div className="w-6 h-6 bg-indigo-500 rounded-full animate-pulse"></div>
                        <div className="w-6 h-6 bg-purple-500 rounded-full animate-pulse delay-100"></div>
                        <div className="w-6 h-6 bg-pink-500 rounded-full animate-pulse delay-200"></div>
                    </div>
                    <p className="mt-4 text-gray-600">Loading company stats...</p>
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredCompanies.map(company => (
                        <Link to={createPageUrl(`CompanyDetails?id=${company.id}`)} key={company.id}>
                            <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 bg-white/80 backdrop-blur-sm border-0 h-full cursor-pointer">
                                <CardHeader>
                                    <CardTitle className="text-indigo-800 flex items-center space-x-2">
                                        <Building className="w-5 h-5" />
                                        <span>{company.company_name}</span>
                                    </CardTitle>
                                    {company.vat_number && <p className="text-xs text-gray-500">VAT: {company.vat_number}</p>}
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    <div className="grid grid-cols-2 gap-4">
                                        <StatCard icon={Users} title="Customers" value={stats[company.id]?.customerCount || 0} color="blue" />
                                        <StatCard icon={HardDrive} title="Cases" value={stats[company.id]?.caseCount || 0} color="green" />
                                        <StatCard icon={FileText} title="Quotes" value={stats[company.id]?.quoteCount || 0} color="orange" />
                                        <StatCard icon={CheckCircle} title="Conversion" value={`${stats[company.id]?.conversionRate || 0}%`} color="purple" />
                                    </div>
                                    <div>
                                        <div className="flex justify-between items-center mb-1">
                                            <p className="text-xs font-medium text-purple-700">Job Conversion Rate</p>
                                            <p className="text-xs font-bold text-purple-700">{stats[company.id]?.conversionRate || 0}%</p>
                                        </div>
                                        <Progress value={stats[company.id]?.conversionRate || 0} className="h-2 [&>div]:bg-gradient-to-r [&>div]:from-purple-400 [&>div]:to-indigo-500" />
                                    </div>
                                </CardContent>
                            </Card>
                        </Link>
                    ))}
                </div>
            )}
             {isAddCompanyOpen && (
                <EditCompanyDialog
                    open={isAddCompanyOpen}
                    onOpenChange={setIsAddCompanyOpen}
                    company={null}
                    onCompanyUpdate={fetchData}
                />
            )}
        </div>
    );
}
