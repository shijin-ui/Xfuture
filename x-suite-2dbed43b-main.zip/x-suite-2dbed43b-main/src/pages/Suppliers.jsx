import React, { useState, useEffect } from 'react';
import { Supplier } from '@/api/entities';
import { Expense } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { 
    Truck, 
    Plus, 
    Search, 
    Edit, 
    Trash2, 
    Eye, 
    Phone, 
    Mail, 
    Globe, 
    MapPin,
    CreditCard,
    Building,
    Calendar,
    DollarSign
} from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { getDefaultLocale, formatCurrency } from '@/components/utils/currencyFormatter';

const SupplierFormDialog = ({ isOpen, onClose, supplier, onSave }) => {
    const [formData, setFormData] = useState({
        supplier_name: '',
        supplier_code: '',
        contact_person: '',
        email: '',
        phone: '',
        mobile: '',
        address: '',
        city: '',
        country: 'Oman',
        website: '',
        tax_number: '',
        supplier_type: 'Other',
        payment_terms: 'Net 30',
        credit_limit: 0,
        is_active: true,
        notes: '',
        bank_details: ''
    });

    useEffect(() => {
        if (supplier) {
            setFormData(supplier);
        } else {
            // Generate supplier code for new suppliers
            const timestamp = Date.now().toString().slice(-4);
            setFormData(prev => ({
                ...prev,
                supplier_code: `SUP-${timestamp}`
            }));
        }
    }, [supplier, isOpen]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!formData.supplier_name.trim()) {
            alert('Supplier name is required');
            return;
        }

        try {
            if (supplier) {
                await Supplier.update(supplier.id, formData);
            } else {
                await Supplier.create(formData);
            }
            onSave();
            onClose();
        } catch (error) {
            console.error('Failed to save supplier:', error);
            alert('Failed to save supplier');
        }
    };

    const supplierTypes = ['Equipment', 'Software', 'Services', 'Parts', 'Utilities', 'Other'];
    const paymentTerms = ['Cash', 'Net 7', 'Net 15', 'Net 30', 'Net 45', 'Net 60', 'Custom'];
    const countries = ['Oman', 'UAE', 'Saudi Arabia', 'Kuwait', 'Qatar', 'Bahrain', 'Other'];

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle>{supplier ? 'Edit Supplier' : 'Add New Supplier'}</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit}>
                    <div className="grid grid-cols-2 gap-4 py-4">
                        <div className="space-y-4">
                            <div>
                                <Label>Supplier Name <span className="text-red-500">*</span></Label>
                                <Input
                                    value={formData.supplier_name}
                                    onChange={(e) => setFormData({...formData, supplier_name: e.target.value})}
                                    placeholder="Enter supplier name"
                                />
                            </div>
                            
                            <div>
                                <Label>Supplier Code</Label>
                                <Input
                                    value={formData.supplier_code}
                                    onChange={(e) => setFormData({...formData, supplier_code: e.target.value})}
                                    placeholder="SUP-0001"
                                />
                            </div>

                            <div>
                                <Label>Contact Person</Label>
                                <Input
                                    value={formData.contact_person}
                                    onChange={(e) => setFormData({...formData, contact_person: e.target.value})}
                                    placeholder="Main contact person"
                                />
                            </div>

                            <div>
                                <Label>Email</Label>
                                <Input
                                    type="email"
                                    value={formData.email}
                                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                                    placeholder="supplier@example.com"
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-2">
                                <div>
                                    <Label>Phone</Label>
                                    <Input
                                        value={formData.phone}
                                        onChange={(e) => setFormData({...formData, phone: e.target.value})}
                                        placeholder="Phone number"
                                    />
                                </div>
                                <div>
                                    <Label>Mobile</Label>
                                    <Input
                                        value={formData.mobile}
                                        onChange={(e) => setFormData({...formData, mobile: e.target.value})}
                                        placeholder="Mobile number"
                                    />
                                </div>
                            </div>

                            <div>
                                <Label>Website</Label>
                                <Input
                                    value={formData.website}
                                    onChange={(e) => setFormData({...formData, website: e.target.value})}
                                    placeholder="https://supplier-website.com"
                                />
                            </div>
                        </div>

                        <div className="space-y-4">
                            <div>
                                <Label>Address</Label>
                                <Textarea
                                    value={formData.address}
                                    onChange={(e) => setFormData({...formData, address: e.target.value})}
                                    placeholder="Full address"
                                    rows={3}
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-2">
                                <div>
                                    <Label>City</Label>
                                    <Input
                                        value={formData.city}
                                        onChange={(e) => setFormData({...formData, city: e.target.value})}
                                        placeholder="City"
                                    />
                                </div>
                                <div>
                                    <Label>Country</Label>
                                    <Select value={formData.country} onValueChange={(value) => setFormData({...formData, country: value})}>
                                        <SelectTrigger>
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {countries.map(country => (
                                                <SelectItem key={country} value={country}>{country}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                            </div>

                            <div>
                                <Label>Tax Number</Label>
                                <Input
                                    value={formData.tax_number}
                                    onChange={(e) => setFormData({...formData, tax_number: e.target.value})}
                                    placeholder="VAT/Tax registration number"
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-2">
                                <div>
                                    <Label>Supplier Type</Label>
                                    <Select value={formData.supplier_type} onValueChange={(value) => setFormData({...formData, supplier_type: value})}>
                                        <SelectTrigger>
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {supplierTypes.map(type => (
                                                <SelectItem key={type} value={type}>{type}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div>
                                    <Label>Payment Terms</Label>
                                    <Select value={formData.payment_terms} onValueChange={(value) => setFormData({...formData, payment_terms: value})}>
                                        <SelectTrigger>
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {paymentTerms.map(term => (
                                                <SelectItem key={term} value={term}>{term}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                            </div>

                            <div>
                                <Label>Credit Limit</Label>
                                <Input
                                    type="number"
                                    step="0.001"
                                    value={formData.credit_limit}
                                    onChange={(e) => setFormData({...formData, credit_limit: parseFloat(e.target.value) || 0})}
                                    placeholder="0.000"
                                />
                            </div>

                            <div>
                                <Label>Notes</Label>
                                <Textarea
                                    value={formData.notes}
                                    onChange={(e) => setFormData({...formData, notes: e.target.value})}
                                    placeholder="Additional notes about the supplier"
                                    rows={2}
                                />
                            </div>
                        </div>
                    </div>
                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={onClose}>
                            Cancel
                        </Button>
                        <Button type="submit">
                            {supplier ? 'Update Supplier' : 'Add Supplier'}
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
};

export default function SuppliersPage() {
    const [suppliers, setSuppliers] = useState([]);
    const [expenses, setExpenses] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [editingSupplier, setEditingSupplier] = useState(null);
    const [selectedSupplier, setSelectedSupplier] = useState(null);
    const [locale, setLocale] = useState(null);

    useEffect(() => {
        fetchData();
    }, []);

    const fetchData = async () => {
        setIsLoading(true);
        try {
            const [suppliersData, expensesData, localeData] = await Promise.all([
                Supplier.list('-created_date'),
                Expense.list(),
                getDefaultLocale()
            ]);
            setSuppliers(suppliersData);
            setExpenses(expensesData);
            setLocale(localeData);
        } catch (error) {
            console.error('Failed to fetch data:', error);
        } finally {
            setIsLoading(false);
        }
    };

    const handleEdit = (supplier) => {
        setEditingSupplier(supplier);
        setIsDialogOpen(true);
    };

    const handleDelete = async (supplierId) => {
        if (window.confirm('Are you sure you want to delete this supplier?')) {
            try {
                await Supplier.delete(supplierId);
                fetchData();
            } catch (error) {
                console.error('Failed to delete supplier:', error);
                alert('Failed to delete supplier');
            }
        }
    };

    const handleCloseDialog = () => {
        setIsDialogOpen(false);
        setEditingSupplier(null);
    };

    const filteredSuppliers = suppliers.filter(supplier =>
        supplier.supplier_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        supplier.supplier_code?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        supplier.contact_person?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        supplier.supplier_type?.toLowerCase().includes(searchTerm.toLowerCase())
    );

    // Calculate supplier statistics
    const supplierStats = suppliers.reduce((acc, supplier) => {
        const supplierExpenses = expenses.filter(expense => expense.vendor === supplier.supplier_name);
        const totalSpent = supplierExpenses.reduce((sum, expense) => sum + (expense.total_amount || 0), 0);
        const lastPurchase = supplierExpenses.length > 0 
            ? supplierExpenses.sort((a, b) => new Date(b.expense_date) - new Date(a.expense_date))[0].expense_date
            : null;
        
        acc[supplier.id] = {
            totalSpent,
            lastPurchase,
            purchaseCount: supplierExpenses.length
        };
        return acc;
    }, {});

    return (
        <div className="p-8 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
            <div className="flex justify-between items-center mb-8">
                <div className="flex items-center space-x-4">
                    <div className="p-3 bg-gradient-to-r from-orange-500 to-red-600 rounded-xl shadow-lg">
                        <Truck className="w-8 h-8 text-white" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-bold bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">
                            Suppliers
                        </h1>
                        <p className="text-gray-500 mt-1">Manage your suppliers and vendor relationships</p>
                    </div>
                </div>
                <Button onClick={() => setIsDialogOpen(true)} className="bg-orange-500 hover:bg-orange-600">
                    <Plus className="w-5 h-5 mr-2" />
                    Add Supplier
                </Button>
            </div>

            {/* Search Bar */}
            <Card className="shadow-lg bg-white/90 backdrop-blur-sm border-0 mb-6">
                <CardContent className="p-4">
                    <div className="relative">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                        <Input
                            placeholder="Search suppliers by name, code, contact, or type..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="pl-9 bg-white/70"
                        />
                    </div>
                </CardContent>
            </Card>

            {/* Suppliers Table */}
            <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0">
                <CardHeader>
                    <CardTitle>All Suppliers ({filteredSuppliers.length})</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="overflow-x-auto">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Supplier</TableHead>
                                    <TableHead>Contact</TableHead>
                                    <TableHead>Type</TableHead>
                                    <TableHead>Location</TableHead>
                                    <TableHead>Total Spent</TableHead>
                                    <TableHead>Last Purchase</TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead className="text-right">Actions</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {isLoading ? (
                                    <TableRow>
                                        <TableCell colSpan={8} className="text-center py-10">
                                            Loading suppliers...
                                        </TableCell>
                                    </TableRow>
                                ) : filteredSuppliers.length === 0 ? (
                                    <TableRow>
                                        <TableCell colSpan={8} className="text-center py-10">
                                            No suppliers found
                                        </TableCell>
                                    </TableRow>
                                ) : (
                                    filteredSuppliers.map(supplier => {
                                        const stats = supplierStats[supplier.id] || {};
                                        return (
                                            <TableRow key={supplier.id} className="hover:bg-blue-50/50">
                                                <TableCell>
                                                    <div>
                                                        <div className="font-semibold text-gray-900">
                                                            {supplier.supplier_name}
                                                        </div>
                                                        <div className="text-sm text-gray-500">
                                                            {supplier.supplier_code}
                                                        </div>
                                                    </div>
                                                </TableCell>
                                                <TableCell>
                                                    <div>
                                                        {supplier.contact_person && (
                                                            <div className="text-sm font-medium">
                                                                {supplier.contact_person}
                                                            </div>
                                                        )}
                                                        {supplier.email && (
                                                            <div className="text-sm text-gray-500 flex items-center">
                                                                <Mail className="w-3 h-3 mr-1" />
                                                                {supplier.email}
                                                            </div>
                                                        )}
                                                        {supplier.phone && (
                                                            <div className="text-sm text-gray-500 flex items-center">
                                                                <Phone className="w-3 h-3 mr-1" />
                                                                {supplier.phone}
                                                            </div>
                                                        )}
                                                    </div>
                                                </TableCell>
                                                <TableCell>
                                                    <Badge variant="outline">{supplier.supplier_type}</Badge>
                                                </TableCell>
                                                <TableCell>
                                                    <div className="text-sm">
                                                        {supplier.city && supplier.country 
                                                            ? `${supplier.city}, ${supplier.country}`
                                                            : supplier.country || supplier.city || '-'
                                                        }
                                                    </div>
                                                </TableCell>
                                                <TableCell>
                                                    <div className="font-mono">
                                                        {locale ? formatCurrency(stats.totalSpent || 0, locale) : 
                                                         `${(stats.totalSpent || 0).toFixed(3)} OMR`}
                                                    </div>
                                                    {stats.purchaseCount > 0 && (
                                                        <div className="text-xs text-gray-500">
                                                            {stats.purchaseCount} purchases
                                                        </div>
                                                    )}
                                                </TableCell>
                                                <TableCell>
                                                    {stats.lastPurchase ? (
                                                        <div className="text-sm">
                                                            {format(parseISO(stats.lastPurchase), 'dd MMM yyyy')}
                                                        </div>
                                                    ) : (
                                                        <span className="text-gray-400">No purchases</span>
                                                    )}
                                                </TableCell>
                                                <TableCell>
                                                    <Badge className={supplier.is_active 
                                                        ? 'bg-green-100 text-green-800' 
                                                        : 'bg-red-100 text-red-800'
                                                    }>
                                                        {supplier.is_active ? 'Active' : 'Inactive'}
                                                    </Badge>
                                                </TableCell>
                                                <TableCell className="text-right">
                                                    <div className="flex justify-end space-x-1">
                                                        <Button
                                                            variant="ghost"
                                                            size="sm"
                                                            onClick={() => handleEdit(supplier)}
                                                        >
                                                            <Edit className="w-4 h-4" />
                                                        </Button>
                                                        <Button
                                                            variant="ghost"
                                                            size="sm"
                                                            onClick={() => handleDelete(supplier.id)}
                                                            className="text-red-600 hover:bg-red-50"
                                                        >
                                                            <Trash2 className="w-4 h-4" />
                                                        </Button>
                                                    </div>
                                                </TableCell>
                                            </TableRow>
                                        );
                                    })
                                )}
                            </TableBody>
                        </Table>
                    </div>
                </CardContent>
            </Card>

            <SupplierFormDialog
                isOpen={isDialogOpen}
                onClose={handleCloseDialog}
                supplier={editingSupplier}
                onSave={fetchData}
            />
        </div>
    );
}