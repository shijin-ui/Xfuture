import React, { useEffect, useMemo, useState } from 'react';
import { DownloadAsset } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Table, TableHeader, TableHead, TableRow, TableBody, TableCell } from '@/components/ui/table';
import { Upload, Download, Plus } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { UploadFile } from '@/api/integrations';

export default function DownloadCenterPage() {
  const [assets, setAssets] = useState([]);
  const [q, setQ] = useState('');
  const [editing, setEditing] = useState(null);

  const refresh = async () => setAssets(await DownloadAsset.list('-created_date'));
  useEffect(() => { refresh(); }, []);

  const filtered = useMemo(() => {
    const needle = q.toLowerCase();
    return assets.filter(a => [a.title, a.category, (a.tags || []).join(' ')].filter(Boolean).some(s => s.toLowerCase().includes(needle)));
  }, [assets, q]);

  const onFileSelect = async (e) => {
    const f = e.target.files?.[0]; if (!f) return;
    const { file_url } = await UploadFile({ file: f });
    setEditing({ ...(editing || {}), fileUrl: file_url });
  };

  const save = async () => {
    if (editing.id) await DownloadAsset.update(editing.id, editing);
    else await DownloadAsset.create(editing);
    setEditing(null); refresh();
  };

  const exportCSV = () => {
    const headers = ['title','category','visibility','version','fileUrl','tags'];
    const rows = filtered.map(a => headers.map(h => `"${(h==='tags'?(a.tags||[]).join('|'):a[h]||'').toString().replace(/"/g,'""')}"`).join(',')).join('\n');
    const csv = headers.join(',')+'\n'+rows;
    const url = URL.createObjectURL(new Blob([csv],{type:'text/csv'}));
    const a = document.createElement('a'); a.href=url; a.download='download_assets.csv'; a.click(); URL.revokeObjectURL(url);
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Download Center</h1>
        <div className="flex gap-2">
          <Button variant="outline" onClick={exportCSV}><Download className="w-4 h-4 mr-2" />Export CSV</Button>
          <Button onClick={() => setEditing({ title:'', category:'', visibility:'internal', tags:[] })}><Plus className="w-4 h-4 mr-2" />Add</Button>
        </div>
      </div>
      <Card className="mb-4">
        <CardContent className="p-4">
          <Input placeholder="Search by title, tag, category" value={q} onChange={e => setQ(e.target.value)} className="w-80" />
        </CardContent>
      </Card>
      <Card>
        <CardHeader><CardTitle>Assets</CardTitle></CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow><TableHead>Title</TableHead><TableHead>Category</TableHead><TableHead>Visibility</TableHead><TableHead>Version</TableHead><TableHead>Actions</TableHead></TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map(a => (
                <TableRow key={a.id}>
                  <TableCell>{a.title}</TableCell>
                  <TableCell>{a.category || '-'}</TableCell>
                  <TableCell>{a.visibility}</TableCell>
                  <TableCell>{a.version || '-'}</TableCell>
                  <TableCell className="space-x-2">
                    <a href={a.fileUrl} target="_blank" rel="noreferrer"><Button variant="outline" size="sm"><Download className="w-4 h-4 mr-1" />Download</Button></a>
                    <Button variant="outline" size="sm" onClick={() => setEditing(a)}>Edit</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={!!editing} onOpenChange={() => setEditing(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing?.id ? 'Edit Asset' : 'Add Asset'}</DialogTitle></DialogHeader>
          {editing && (
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2"><Label>Title</Label><Input value={editing.title || ''} onChange={e => setEditing({ ...editing, title: e.target.value })} /></div>
              <div><Label>Category</Label><Input value={editing.category || ''} onChange={e => setEditing({ ...editing, category: e.target.value })} /></div>
              <div><Label>Visibility</Label><Input value={editing.visibility || 'internal'} onChange={e => setEditing({ ...editing, visibility: e.target.value })} /></div>
              <div><Label>Version</Label><Input value={editing.version || ''} onChange={e => setEditing({ ...editing, version: e.target.value })} /></div>
              <div className="col-span-2"><Label>Tags (comma separated)</Label><Input value={(editing.tags || []).join(', ')} onChange={e => setEditing({ ...editing, tags: e.target.value.split(',').map(s => s.trim()).filter(Boolean) })} /></div>
              <div className="col-span-2">
                <Label>File</Label>
                <input type="file" onChange={onFileSelect} />
                {editing.fileUrl && <div className="text-xs text-gray-500 mt-1 break-all">{editing.fileUrl}</div>}
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button>
            <Button onClick={save}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}