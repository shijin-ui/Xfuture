import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Cases from "./Cases";

import CaseDetails from "./CaseDetails";

import Customers from "./Customers";

import NewCase from "./NewCase";

import PrintReceipt from "./PrintReceipt";

import PrintLabel from "./PrintLabel";

import PrintCheckout from "./PrintCheckout";

import Users from "./Users";

import Settings from "./Settings";

import Companies from "./Companies";

import CompanyDetails from "./CompanyDetails";

import PrintDeviceCheckout from "./PrintDeviceCheckout";

import PrintEvaluationReport from "./PrintEvaluationReport";

import Inventory from "./Inventory";

import Assets from "./Assets";

import Quotes from "./Quotes";

import Invoices from "./Invoices";

import QuoteDetails from "./QuoteDetails";

import PrintQuote from "./PrintQuote";

import InvoiceDetails from "./InvoiceDetails";

import PrintInvoice from "./PrintInvoice";

import AccountingSettings from "./AccountingSettings";

import CreateQuote from "./CreateQuote";

import CompanyProfile from "./CompanyProfile";

import Transactions from "./Transactions";

import Banking from "./Banking";

import Expenses from "./Expenses";

import SalesDashboard from "./SalesDashboard";

import VatAudit from "./VatAudit";

import Suppliers from "./Suppliers";

import QuotesPage from "./QuotesPage";

import InvoicesPage from "./InvoicesPage";

import Migration from "./Migration";

import MigrationExport from "./MigrationExport";

import Stock from "./Stock";

import HRManagement from "./HRManagement";

import Purchases from "./Purchases";

import DownloadCenter from "./DownloadCenter";

import PasswordManager from "./PasswordManager";

import Reports from "./Reports";

import Tasks from "./Tasks";

import Logs from "./Logs";

import MigrationGuide from "./MigrationGuide";

import DesignMigration from "./DesignMigration";

import SelfHostingGuide from "./SelfHostingGuide";

import AuditReport from "./AuditReport";

import CustomerProfile from "./CustomerProfile";

import ClientPortal from "./ClientPortal";

import PrintAssetLabel from "./PrintAssetLabel";

import DonorSearch from "./DonorSearch";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Cases: Cases,
    
    CaseDetails: CaseDetails,
    
    Customers: Customers,
    
    NewCase: NewCase,
    
    PrintReceipt: PrintReceipt,
    
    PrintLabel: PrintLabel,
    
    PrintCheckout: PrintCheckout,
    
    Users: Users,
    
    Settings: Settings,
    
    Companies: Companies,
    
    CompanyDetails: CompanyDetails,
    
    PrintDeviceCheckout: PrintDeviceCheckout,
    
    PrintEvaluationReport: PrintEvaluationReport,
    
    Inventory: Inventory,
    
    Assets: Assets,
    
    Quotes: Quotes,
    
    Invoices: Invoices,
    
    QuoteDetails: QuoteDetails,
    
    PrintQuote: PrintQuote,
    
    InvoiceDetails: InvoiceDetails,
    
    PrintInvoice: PrintInvoice,
    
    AccountingSettings: AccountingSettings,
    
    CreateQuote: CreateQuote,
    
    CompanyProfile: CompanyProfile,
    
    Transactions: Transactions,
    
    Banking: Banking,
    
    Expenses: Expenses,
    
    SalesDashboard: SalesDashboard,
    
    VatAudit: VatAudit,
    
    Suppliers: Suppliers,
    
    QuotesPage: QuotesPage,
    
    InvoicesPage: InvoicesPage,
    
    Migration: Migration,
    
    MigrationExport: MigrationExport,
    
    Stock: Stock,
    
    HRManagement: HRManagement,
    
    Purchases: Purchases,
    
    DownloadCenter: DownloadCenter,
    
    PasswordManager: PasswordManager,
    
    Reports: Reports,
    
    Tasks: Tasks,
    
    Logs: Logs,
    
    MigrationGuide: MigrationGuide,
    
    DesignMigration: DesignMigration,
    
    SelfHostingGuide: SelfHostingGuide,
    
    AuditReport: AuditReport,
    
    CustomerProfile: CustomerProfile,
    
    ClientPortal: ClientPortal,
    
    PrintAssetLabel: PrintAssetLabel,
    
    DonorSearch: DonorSearch,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Cases" element={<Cases />} />
                
                <Route path="/CaseDetails" element={<CaseDetails />} />
                
                <Route path="/Customers" element={<Customers />} />
                
                <Route path="/NewCase" element={<NewCase />} />
                
                <Route path="/PrintReceipt" element={<PrintReceipt />} />
                
                <Route path="/PrintLabel" element={<PrintLabel />} />
                
                <Route path="/PrintCheckout" element={<PrintCheckout />} />
                
                <Route path="/Users" element={<Users />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/Companies" element={<Companies />} />
                
                <Route path="/CompanyDetails" element={<CompanyDetails />} />
                
                <Route path="/PrintDeviceCheckout" element={<PrintDeviceCheckout />} />
                
                <Route path="/PrintEvaluationReport" element={<PrintEvaluationReport />} />
                
                <Route path="/Inventory" element={<Inventory />} />
                
                <Route path="/Assets" element={<Assets />} />
                
                <Route path="/Quotes" element={<Quotes />} />
                
                <Route path="/Invoices" element={<Invoices />} />
                
                <Route path="/QuoteDetails" element={<QuoteDetails />} />
                
                <Route path="/PrintQuote" element={<PrintQuote />} />
                
                <Route path="/InvoiceDetails" element={<InvoiceDetails />} />
                
                <Route path="/PrintInvoice" element={<PrintInvoice />} />
                
                <Route path="/AccountingSettings" element={<AccountingSettings />} />
                
                <Route path="/CreateQuote" element={<CreateQuote />} />
                
                <Route path="/CompanyProfile" element={<CompanyProfile />} />
                
                <Route path="/Transactions" element={<Transactions />} />
                
                <Route path="/Banking" element={<Banking />} />
                
                <Route path="/Expenses" element={<Expenses />} />
                
                <Route path="/SalesDashboard" element={<SalesDashboard />} />
                
                <Route path="/VatAudit" element={<VatAudit />} />
                
                <Route path="/Suppliers" element={<Suppliers />} />
                
                <Route path="/QuotesPage" element={<QuotesPage />} />
                
                <Route path="/InvoicesPage" element={<InvoicesPage />} />
                
                <Route path="/Migration" element={<Migration />} />
                
                <Route path="/MigrationExport" element={<MigrationExport />} />
                
                <Route path="/Stock" element={<Stock />} />
                
                <Route path="/HRManagement" element={<HRManagement />} />
                
                <Route path="/Purchases" element={<Purchases />} />
                
                <Route path="/DownloadCenter" element={<DownloadCenter />} />
                
                <Route path="/PasswordManager" element={<PasswordManager />} />
                
                <Route path="/Reports" element={<Reports />} />
                
                <Route path="/Tasks" element={<Tasks />} />
                
                <Route path="/Logs" element={<Logs />} />
                
                <Route path="/MigrationGuide" element={<MigrationGuide />} />
                
                <Route path="/DesignMigration" element={<DesignMigration />} />
                
                <Route path="/SelfHostingGuide" element={<SelfHostingGuide />} />
                
                <Route path="/AuditReport" element={<AuditReport />} />
                
                <Route path="/CustomerProfile" element={<CustomerProfile />} />
                
                <Route path="/ClientPortal" element={<ClientPortal />} />
                
                <Route path="/PrintAssetLabel" element={<PrintAssetLabel />} />
                
                <Route path="/DonorSearch" element={<DonorSearch />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}