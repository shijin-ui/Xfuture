

import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import { userCacheManager } from '@/components/utils/userCache';
import ErrorBoundary from '@/components/utils/ErrorBoundary';
import { diagnoseConnectionIssue } from '@/components/utils/connectionTest';
import {
  Home, HardDrive, Users, FileText, Settings, LogOut, ChevronDown, Activity,
  DollarSign, Menu, UserCog, Calculator, ClipboardList, Building, Archive,
  Package, Globe, Landmark, AlertTriangle, RefreshCw, Truck, WifiOff, ChevronRight,
  Minimize2, Maximize2, Search, Sun, Moon, Plus, FilePlus, CheckCircle, Download
} from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import CurrentDateTime from '@/components/common/CurrentDateTime';

const groupedNavLinks = {
  Admin: {
    coreOperations: [
      { name: 'Dashboard', icon: Home, page: 'Dashboard' },
      { name: 'Cases', icon: HardDrive, page: 'Cases' },
      { name: 'Tasks & Calendar', icon: ClipboardList, page: 'Tasks' },
      { name: 'Donor Search', icon: Search, page: 'DonorSearch' },
    ],
    business: [
      { name: 'Companies', icon: Building, page: 'Companies' },
      { name: 'Customers', icon: Users, page: 'Customers' },
      { name: 'Suppliers', icon: Truck, page: 'Suppliers' },
      { name: 'Purchases', icon: Package, page: 'Purchases' },
      { name: 'Quotes', icon: Activity, page: 'Quotes' }
    ],
    finance: [
      { name: 'Invoices', icon: DollarSign, page: 'Invoices' },
      { name: 'Expenses', icon: Calculator, page: 'Expenses' },
      { name: 'Transactions', icon: Calculator, page: 'Transactions' },
      { name: 'Banking', icon: Landmark, page: 'Banking' },
      { name: 'VAT/Audit', icon: FileText, page: 'VatAudit' },
      { name: 'Payments', icon: DollarSign, page: 'Transactions' }
    ],
    resources: [
      { name: 'Assets', icon: Package, page: 'Assets' },
      { name: 'Inventory', icon: Archive, page: 'Inventory' },
      { name: 'Stock', icon: Package, page: 'Stock' },
      { name: 'Download center', icon: FileText, page: 'DownloadCenter' }
    ],
    administration: [
      { name: 'Users', icon: UserCog, page: 'Users' },
      { name: 'HR Management', icon: Users, page: 'HRManagement' },
      { name: 'Reports', icon: FileText, page: 'Reports' },
      { name: 'Password Manager', icon: FileText, page: 'PasswordManager' },
      { name: 'Logs', icon: Activity, page: 'Logs' }, // Updated from 'Settings' to 'Logs'
      { name: 'Settings', icon: Settings, page: 'Settings' }
    ]
  },
  Technician: {
    coreOperations: [
      { name: 'Dashboard', icon: Home, page: 'Dashboard' },
      { name: 'Cases', icon: HardDrive, page: 'Cases' },
      { name: 'Tasks & Calendar', icon: ClipboardList, page: 'Tasks' },
      { name: 'Donor Search', icon: Search, page: 'DonorSearch' },
    ],
    resources: [
      { name: 'Download center', icon: FileText, page: 'DownloadCenter' }
    ]
  },
  Sales: {
    coreOperations: [
      { name: 'Dashboard', icon: Home, page: 'Dashboard' },
      { name: 'Cases', icon: HardDrive, page: 'Cases' },
      { name: 'Tasks & Calendar', icon: ClipboardList, page: 'Tasks' },
    ],
    business: [
      { name: 'Companies', icon: Building, page: 'Companies' },
      { name: 'Customers', icon: Users, page: 'Customers' },
      { name: 'Quotes', icon: Activity, page: 'Quotes' }
    ],
    resources: [
      { name: 'Download center', icon: FileText, page: 'DownloadCenter' }
    ]
  },
  Accounts: {
    coreOperations: [
      { name: 'Dashboard', icon: Home, page: 'Dashboard' },
      { name: 'Cases', icon: HardDrive, page: 'Cases' },
      { name: 'Tasks & Calendar', icon: ClipboardList, page: 'Tasks' },
    ],
    business: [
      { name: 'Suppliers', icon: Truck, page: 'Suppliers' },
    ],
    finance: [
      { name: 'Invoices', icon: DollarSign, page: 'Invoices' },
      { name: 'Expenses', icon: Calculator, page: 'Expenses' },
      { name: 'Transactions', icon: Calculator, page: 'Transactions' },
      { name: 'Banking', icon: Landmark, page: 'Banking' },
      { name: 'VAT/Audit', icon: FileText, page: 'VatAudit' },
      { name: 'Payments', icon: DollarSign, page: 'Transactions' }
    ],
    administration: [
      { name: 'Reports', icon: FileText, page: 'Reports' },
    ],
    resources: [
      { name: 'Download center', icon: FileText, page: 'DownloadCenter' }
    ]
  }
};

const groupLabels = {
  coreOperations: 'CORE OPERATIONS',
  business: 'BUSINESS',
  finance: 'FINANCE',
  resources: 'RESOURCES',
  administration: 'ADMINISTRATION'
};

export default function Layout({ children }) {
  const [user, setUser] = useState(null);
  const [userError, setUserError] = useState(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [expandedGroups, setExpandedGroups] = useState(() => {
    const saved = localStorage.getItem('sidebarExpandedGroups');
    return saved ? JSON.parse(saved) : { coreOperations: true };
  });
  const [darkMode, setDarkMode] = useState(() => {
    const saved = localStorage.getItem('theme');
    return saved ? saved === 'dark' : window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  });
  const [dir, setDir] = useState(() => localStorage.getItem('dir') || 'ltr');
  const [connectionDiagnosis, setConnectionDiagnosis] = useState(null);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
    localStorage.setItem('theme', darkMode ? 'dark' : 'light');
  }, [darkMode]);

  useEffect(() => {
    document.documentElement.setAttribute('dir', dir);
    localStorage.setItem('dir', dir);
  }, [dir]);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        setIsLoading(true);
        setUserError(null);
        const currentUser = await userCacheManager.getUser();
        setUser(currentUser);
      } catch (error) {
        console.error('Failed to fetch user:', error);

        // Diagnose connection issues
        const diagnosis = await diagnoseConnectionIssue();
        setConnectionDiagnosis(diagnosis);

        if (error.message && error.message.toLowerCase().includes('network error')) {
          setUserError("Could not connect to the server. Please check your internet connection and try again.");
        } else if (error.message.includes('Authentication required')) {
          User.loginWithRedirect(window.location.href);
        } else if (error.message.includes('Rate limit')) {
          setUserError("The system is experiencing high traffic. Please wait a moment and refresh the page.");
        } else {
          setUserError("An unexpected error occurred while loading user data. Please refresh the page.");
        }
      } finally {
        setIsLoading(false);
      }
    };
    fetchUser();
  }, []);

  // Auto-expand groups based on current page
  useEffect(() => {
    if (user) {
      const userRoleFromDB = user?.access_role
        ? user.access_role
        : (user?.role === 'admin' ? 'Admin' : 'Technician');

      const standardizedRole = userRoleFromDB.charAt(0).toUpperCase() + userRoleFromDB.slice(1).toLowerCase();
      const userNavGroups = groupedNavLinks[standardizedRole];

      if (userNavGroups) {
        for (const [groupKey, links] of Object.entries(userNavGroups)) {
          const isCurrentPageInGroup = links.some(link => {
            const pageUrl = createPageUrl(link.page);
            return location.pathname.startsWith(pageUrl);
          });

          if (isCurrentPageInGroup && !expandedGroups[groupKey]) {
            setExpandedGroups(prev => {
              const updated = { ...prev, [groupKey]: true };
              localStorage.setItem('sidebarExpandedGroups', JSON.stringify(updated));
              return updated;
            });
          }
        }
      }
    }
  }, [location.pathname, user, expandedGroups]);

  const toggleGroup = (groupKey) => {
    setExpandedGroups(prev => {
      const updated = { ...prev, [groupKey]: !prev[groupKey] };
      localStorage.setItem('sidebarExpandedGroups', JSON.stringify(updated));
      return updated;
    });
  };

  const isPrintPage = location.pathname.includes('/Print') || location.pathname.includes('/AuditReport');
  if (isPrintPage) {
    return <>{children}</>;
  }

  if (isLoading) {
    return (
      <ErrorBoundary>
        <div className="flex h-screen w-full items-center justify-center bg-background">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-primary rounded-full animate-pulse"></div>
              <div className="w-8 h-8 bg-primary/80 rounded-full animate-pulse delay-150"></div>
              <div className="w-8 h-8 bg-primary/60 rounded-full animate-pulse delay-300"></div>
            </div>
            <p className="text-muted-foreground">Loading application...</p>
          </div>
        </div>
      </ErrorBoundary>
    );
  }

  if (userError) {
    return (
      <ErrorBoundary>
        <div className="flex h-screen w-full items-center justify-center bg-background p-4 text-center">
          <div className="bg-card text-card-foreground p-8 rounded-2xl shadow-elevation-xl border border-red-200 max-w-md">
            {userError.toLowerCase().includes('network') ? (
              <WifiOff className="w-12 h-12 text-red-500 mx-auto mb-4" />
            ) : (
              <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
            )}
            <h1 className="text-xl font-semibold">Application Error</h1>
            <p className="text-sm text-muted-foreground mt-2">{userError}</p>

            {connectionDiagnosis && (
              <div className="mt-4 p-3 bg-muted rounded-lg text-sm text-left">
                <h3 className="font-medium mb-2">Diagnosis:</h3>
                <p className="text-muted-foreground mb-2">{connectionDiagnosis.diagnosis.message}</p>
                <ul className="list-disc list-inside text-xs text-muted-foreground space-y-1">
                  {connectionDiagnosis.diagnosis.suggestions.map((suggestion, i) => (
                    <li key={i}>{suggestion}</li>
                  ))}
                </ul>
              </div>
            )}

            <div className="flex space-x-2 mt-6">
              <Button className="flex-1" onClick={() => window.location.reload()}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh Page
              </Button>
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => {
                  userCacheManager.clearCache();
                  window.location.reload();
                }}
              >
                Clear Cache
              </Button>
            </div>
          </div>
        </div>
      </ErrorBoundary>
    );
  }

  const getInitials = (name) => {
    if (!name) return '';
    return name.split(' ').map((n) => n[0]).join('');
  };

  const userRoleFromDB = user?.access_role
    ? user.access_role
    : (user?.role === 'admin' ? 'Admin' : 'Technician');

  const standardizedRole = userRoleFromDB.charAt(0).toUpperCase() + userRoleFromDB.slice(1).toLowerCase();
  const userNavGroups = groupedNavLinks[standardizedRole] || { coreOperations: [] };
  const sidebarWidth = sidebarCollapsed ? 'w-0' : (sidebarOpen ? 'w-64' : 'w-16');

  // Derive current page title for breadcrumb
  const allLinks = Object.values(groupedNavLinks).flatMap(groups =>
    Object.values(groups).flat()
  );
  const currentLink = allLinks.find(l => location.pathname.startsWith(createPageUrl(l.page)));
  const currentTitle = currentLink?.name || 'Dashboard';

  return (
    <ErrorBoundary>
      <div className="flex h-screen bg-background text-foreground font-sans">
        {/* Design tokens and theme variables */}
        <style>{`
          :root {
            --radius: 16px;

            --brand-primary: 230 89% 56%;
            --brand-muted: 230 20% 94%;

            --success: 142 72% 40%;
            --warning: 43 96% 56%;
            --danger: 0 84% 60%;

            --background: 0 0% 100%;
            --foreground: 222 47% 11%;

            --card: 0 0% 100%;
            --card-foreground: 222 47% 11%;

            --muted: 210 16% 96%;
            --muted-foreground: 215 16% 47%;

            --primary: var(--brand-primary);
            --primary-foreground: 0 0% 100%;

            --secondary: 210 16% 96%;
            --secondary-foreground: 222 47% 11%;

            --accent: 210 16% 96%;
            --accent-foreground: 222 47% 11%;

            --border: 214 32% 91%;
            --input: 214 32% 91%;
            --ring: var(--primary);

            --shadow-card: 0 8px 32px rgba(0,0,0,0.06), 0 2px 8px rgba(0,0,0,0.04);
            --shadow-dialog: 0 24px 64px rgba(0,0,0,0.15);
          }
          .dark {
            --background: 224 17% 8%;
            --foreground: 210 20% 98%;

            --card: 222 17% 12%;
            --card-foreground: 210 20% 98%;

            --muted: 220 14% 16%;
            --muted-foreground: 215 16% 70%;

            --primary: 230 89% 66%;
            --primary-foreground: 224 17% 8%;

            --secondary: 220 14% 16%;
            --secondary-foreground: 210 20% 98%;

            --accent: 220 14% 16%;
            --accent-foreground: 210 20% 98%;

            --border: 218 14% 22%;
            --input: 218 14% 22%;
            --ring: var(--primary);
          }
        `}</style>

        {/* Sidebar */}
        <aside className={`${sidebarWidth} flex-shrink-0 bg-card border-r border-border flex flex-col transition-all duration-300 overflow-hidden`}>
          {!sidebarCollapsed && (
            <>
              <div className="h-16 flex items-center px-6 border-b border-border justify-between">
                <div className="flex items-center">
                  <HardDrive className="w-7 h-7 text-primary" />
                  {sidebarOpen && <h1 className="ml-3 text-lg font-semibold">Space Recovery</h1>}
                </div>
              </div>

              <nav className="flex-1 px-3 py-5 space-y-1 overflow-y-auto">
                {Object.entries(userNavGroups).map(([groupKey, links]) => (
                  <div key={groupKey}>
                    {groupKey === 'coreOperations' ? (
                      <>
                        {sidebarOpen && (
                          <div className="px-3 py-2 text-[11px] font-semibold text-muted-foreground uppercase tracking-wide rounded-md mb-2">
                            {groupLabels[groupKey]}
                          </div>
                        )}
                        {links.map((link) => {
                          const pageUrl = createPageUrl(link.page);
                          const isActive = location.pathname.startsWith(pageUrl);
                          return (
                            <Link
                              key={link.name}
                              to={pageUrl}
                              className={`flex items-center px-3 py-2 rounded-lg transition-all duration-200 relative ${
                                isActive
                                  ? 'bg-primary/10 text-primary font-semibold'
                                  : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                              }`}
                              title={link.name}
                            >
                              {isActive && <div className="absolute left-0 top-2 bottom-2 w-1 bg-primary rounded-r-full"></div>}
                              <link.icon className={`w-5 h-5 ${sidebarOpen ? 'mr-3' : 'mx-auto'} ${isActive ? 'text-primary' : ''}`} />
                              {sidebarOpen && <span className="text-sm">{link.name}</span>}
                            </Link>
                          );
                        })}
                      </>
                    ) : (
                      <>
                        {sidebarOpen ? (
                          <button
                            onClick={() => toggleGroup(groupKey)}
                            className="w-full flex items-center justify-between px-3 py-2 text-[11px] font-semibold text-muted-foreground uppercase tracking-wide hover:bg-muted rounded-md transition-colors duration-200"
                          >
                            <span>{groupLabels[groupKey]}</span>
                            <ChevronRight
                              className={`w-4 h-4 transition-transform duration-200 ${expandedGroups[groupKey] ? 'rotate-90' : ''}`}
                            />
                          </button>
                        ) : (
                          <div className="h-8"></div>
                        )}

                        <div className={`transition-all duration-300 overflow-hidden ${
                          expandedGroups[groupKey] ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
                        }`}>
                          <div className="space-y-1 py-1">
                            {links.map((link) => {
                              const pageUrl = createPageUrl(link.page);
                              const isActive = location.pathname.startsWith(pageUrl);
                              return (
                                <Link
                                  key={link.name}
                                  to={pageUrl}
                                  className={`flex items-center px-3 py-2 rounded-lg transition-all duration-200 relative ${
                                    isActive
                                      ? 'bg-primary/10 text-primary font-semibold'
                                      : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                                  }`}
                                  title={link.name}
                                >
                                  {isActive && <div className="absolute left-0 top-2 bottom-2 w-1 bg-primary rounded-r-full"></div>}
                                  <link.icon className={`w-5 h-5 ${sidebarOpen ? 'mr-3' : 'mx-auto'} ${isActive ? 'text-primary' : ''}`} />
                                  {sidebarOpen && <span className="text-sm">{link.name}</span>}
                                </Link>
                              );
                            })}
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                ))}
              </nav>

              {/* User Profile Section */}
              <div className={`p-4 border-t border-border ${!sidebarOpen && 'px-2'}`}>
                <DropdownMenu>
                  <DropdownMenuTrigger className="w-full">
                    <div className={`flex items-center p-2 rounded-lg hover:bg-muted ${!sidebarOpen && 'justify-center'}`}>
                      <Avatar className="h-9 w-9">
                        <AvatarImage src={user?.avatar_url} />
                        <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                          {user ? getInitials(user.full_name) : '...'}
                        </AvatarFallback>
                      </Avatar>
                      {sidebarOpen && (
                        <>
                          <div className="ml-3 text-left flex-1 min-w-0">
                            <p className="text-sm font-semibold truncate">{user?.full_name}</p>
                            <p className="text-xs text-muted-foreground">{user?.access_role || user?.role || 'No Role'}</p>
                          </div>
                          <ChevronDown className="w-4 h-4 text-muted-foreground" />
                        </>
                      )}
                    </div>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-56 mb-2">
                    <DropdownMenuItem onClick={() => {
                      userCacheManager.logout();
                      User.logout();
                    }}>
                      <LogOut className="w-4 h-4 mr-2" />
                      <span>Sign Out</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </>
          )}
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto bg-background dark:bg-slate-900">
          {/* Top Bar */}
          <header className="bg-card/80 dark:bg-card/50 backdrop-blur-sm border-b border-border px-4 md:px-6 py-3 flex items-center justify-between sticky top-0 z-20">
            <div className="flex items-center gap-2 md:gap-3">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSidebarOpen(!sidebarOpen)}
                className={`${sidebarCollapsed ? 'hidden' : ''}`}
                aria-label="Toggle sidebar"
              >
                <Menu className="w-5 h-5" />
              </Button>

              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
                title={sidebarCollapsed ? "Show Sidebar" : "Hide Sidebar"}
                aria-label={sidebarCollapsed ? "Show Sidebar" : "Hide Sidebar"}
              >
                {sidebarCollapsed ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
              </Button>

              <div className="hidden md:flex items-center text-sm text-muted-foreground">
                <Home className="w-4 h-4 mr-2" />
                <span className="truncate">{currentTitle}</span>
              </div>
            </div>

            <div className="flex items-center gap-2 md:gap-3">
              <div className="hidden md:flex items-center gap-2">
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder={dir === 'rtl' ? 'ابحث في النظام' : 'Search across the app'}
                    className="pl-9 w-64 rounded-xl"
                    aria-label="Global search"
                  />
                </div>
                {/* Quick Actions (compact, elegant) */}
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" className="rounded-xl" onClick={() => navigate(createPageUrl('NewCase'))}>
                    <FilePlus className="w-4 h-4 mr-2" />
                    {dir === 'rtl' ? 'قضية جديدة' : 'New Case'}
                  </Button>
                  <Button size="sm" className="rounded-xl" onClick={() => navigate(createPageUrl('Tasks'))}>
                    <CheckCircle className="w-4 h-4 mr-2" />
                    {dir === 'rtl' ? 'مهمة' : 'New Task'}
                  </Button>
                </div>
              </div>

              {/* Live Date/Time */}
              <CurrentDateTime className="hidden md:block mr-2" />

              <Button
                variant="ghost"
                size="icon"
                className="rounded-xl"
                onClick={() => setDarkMode((d) => !d)}
                title={darkMode ? (dir === 'rtl' ? 'وضع فاتح' : 'Light mode') : (dir === 'rtl' ? 'وضع داكن' : 'Dark mode')}
                aria-label="Toggle theme"
              >
                {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </Button>

              <Button
                variant="ghost"
                size="icon"
                className="rounded-xl"
                onClick={() => setDir((p) => (p === 'ltr' ? 'rtl' : 'ltr'))}
                title={dir === 'rtl' ? 'Switch to LTR' : 'التبديل للعربية'}
                aria-label="Toggle language direction"
              >
                <Globe className="w-5 h-5" />
              </Button>
            </div>
          </header>
          {/* Page content now has full width and height control */}
          {children}
        </main>
      </div>
    </ErrorBoundary>
  );
}

