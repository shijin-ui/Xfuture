
import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Quote } from '@/api/entities';
import { Case } from '@/api/entities';
import { Customer } from '@/api/entities';
import { Setting } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Trash2, PlusCircle, Save, Send, ArrowLeft, Loader2, FileText, Calculator, User, BookOpen } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { getDefaultLocale, formatCurrency } from '../components/utils/currencyFormatter';
import SearchableSelect from '../components/SearchableSelect';

const getNextNumber = async (sequenceName) => {
    try {
        const sequences = await Setting.filter({ category: 'Number Sequences', value: sequenceName });
        if (sequences.length > 0) {
            const sequence = sequences[0];
            const nextNumber = (sequence.numeric_value || 0) + 1;
            return { sequence, nextNumber };
        } else {
            const defaultValue = sequenceName === 'Quote Number' ? 1000 : 1000;
            const newSequence = await Setting.create({
                category: 'Number Sequences',
                value: sequenceName,
                numeric_value: defaultValue,
                description: `Last assigned ${sequenceName.toLowerCase()}`
            });
            return { sequence: newSequence, nextNumber: defaultValue + 1 };
        }
    } catch (error) {
        console.error(`Failed to get next ${sequenceName}:`, error);
        return { sequence: null, nextNumber: 1000 };
    }
};

export default function CreateQuotePage() {
    const navigate = useNavigate();
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const [locale, setLocale] = useState(null);
    
    const [allCases, setAllCases] = useState([]);
    const [customers, setCustomers] = useState({});
    const [quoteLineItems, setQuoteLineItems] = useState([]);
    const [quoteTermsOptions, setQuoteTermsOptions] = useState([]); // New state variable
    
    const [selectedCaseId, setSelectedCaseId] = useState('');
    const [selectedCase, setSelectedCase] = useState(null);
    const [selectedCustomer, setSelectedCustomer] = useState(null);
    
    const [quote, setQuote] = useState({
        quote_number: '',
        line_items: [{ description: '', quantity: 1, amount: 0 }],
        quote_terms: [], // New field in quote state
        dealer_discount_percentage: 0,
        vat_rate: 0.05,
        include_vat: true
    });

    useEffect(() => {
        const loadInitialData = async () => {
            try {
                // Modified Promise.all to fetch quote terms
                const [localeData, casesData, customersData, lineItemsData, termsData] = await Promise.all([
                    getDefaultLocale(),
                    Case.list('-created_date'),
                    Customer.list(),
                    Setting.filter({ category: 'Quote Line Items', is_active: true }, 'display_order'),
                    Setting.filter({ category: 'Quote Terms', is_active: true }, 'display_order') // Fetch quote terms
                ]);

                setLocale(localeData);
                setAllCases(casesData);
                setQuoteLineItems(lineItemsData);
                setQuoteTermsOptions(termsData); // Set quote terms options
                
                const customersMap = customersData.reduce((acc, customer) => {
                    acc[customer.id] = customer;
                    return acc;
                }, {});
                setCustomers(customersMap);

                const { nextNumber } = await getNextNumber('Quote Number');
                setQuote(prev => ({ ...prev, quote_number: nextNumber.toString() }));
                
            } catch (error) {
                console.error('Failed to load initial data:', error);
            } finally {
                setIsLoading(false);
            }
        };

        loadInitialData();
    }, []);

    const handleCaseSelect = async (caseId) => {
        setSelectedCaseId(caseId);
        if (caseId) {
            const caseData = allCases.find(c => c.id === caseId);
            const customerData = customers[caseData.customer_id];
            
            setSelectedCase(caseData);
            setSelectedCustomer(customerData);
            
            setQuote(prev => ({
                ...prev,
                case_id: caseId,
                customer_id: caseData.customer_id,
                dealer_discount_percentage: customerData?.dealer_discount_percentage || 0
            }));
        }
    };

    const handleLineItemSelect = (index, settingId) => {
        const selectedOption = quoteLineItems.find(item => item.id === settingId);
        if (!selectedOption) return;

        const newLineItems = [...quote.line_items];
        const newLineItem = {
            description: selectedOption.value,
            quantity: 1,
            amount: selectedOption.default_amount || 0
        };

        // Replace the current line item if it's empty, otherwise add a new one
        if (index === quote.line_items.length - 1 && !quote.line_items[index].description && quote.line_items[index].amount === 0) {
            newLineItems[index] = newLineItem;
        } else {
            newLineItems.splice(index, 1, newLineItem);
        }

        setQuote({ ...quote, line_items: newLineItems });
    };

    const handleLineItemChange = (index, field, value) => {
        const newLineItems = [...quote.line_items];
        if (field === 'quantity' || field === 'amount') {
            newLineItems[index][field] = parseFloat(value) || 0;
        } else {
            newLineItems[index][field] = value;
        }
        setQuote({ ...quote, line_items: newLineItems });
    };

    const addLineItemFromSetting = (settingId) => {
        const selectedOption = quoteLineItems.find(item => item.id === settingId);
        if (!selectedOption) return;

        const newLineItem = {
            description: selectedOption.value,
            quantity: 1,
            amount: selectedOption.default_amount || 0,
        };

        const currentLineItems = [...quote.line_items];
        const lastItem = currentLineItems[currentLineItems.length - 1];

        // If the last item is the initial empty one, replace it. Otherwise, add a new one.
        if (currentLineItems.length === 1 && !lastItem.description && lastItem.amount === 0) {
            currentLineItems[0] = newLineItem;
        } else {
            currentLineItems.push(newLineItem);
        }

        setQuote({ ...quote, line_items: currentLineItems });
    };

    const addLineItem = () => {
        setQuote({
            ...quote,
            line_items: [...quote.line_items, { description: '', quantity: 1, amount: 0 }]
        });
    };

    const removeLineItem = (index) => {
        if (quote.line_items.length > 1) {
            const newLineItems = quote.line_items.filter((_, i) => i !== index);
            setQuote({ ...quote, line_items: newLineItems });
        }
    };

    // New function: handleTermSelect
    const handleTermSelect = (termValue) => {
        const currentTerms = [...quote.quote_terms];
        
        if (currentTerms.includes(termValue)) {
            // Remove term if already selected
            const updatedTerms = currentTerms.filter(term => term !== termValue);
            setQuote({ ...quote, quote_terms: updatedTerms });
        } else {
            // Add term if not selected
            const updatedTerms = [...currentTerms, termValue];
            setQuote({ ...quote, quote_terms: updatedTerms });
        }
    };

    // New function: removeSelectedTerm
    const removeSelectedTerm = (termToRemove) => {
        const updatedTerms = quote.quote_terms.filter(term => term !== termToRemove);
        setQuote({ ...quote, quote_terms: updatedTerms });
    };

    const calculateTotals = () => {
        const subtotal = quote.line_items.reduce((sum, item) => sum + ((item.quantity || 1) * (item.amount || 0)), 0);
        const discountAmount = (subtotal * quote.dealer_discount_percentage) / 100;
        const afterDiscount = subtotal - discountAmount;
        const vatAmount = quote.include_vat ? afterDiscount * quote.vat_rate : 0;
        const total = afterDiscount + vatAmount;

        return { subtotal, discountAmount, afterDiscount, vatAmount, total };
    };

    const handleSave = async (sendQuote = false) => {
        if (!selectedCaseId || quote.line_items.length === 0) {
            alert('Please select a case and add at least one line item.');
            return;
        }

        setIsSaving(true);
        try {
            const totals = calculateTotals();
            const quoteData = {
                ...quote,
                status: sendQuote ? 'Sent' : 'Draft',
                subtotal: totals.subtotal,
                dealer_discount_amount: totals.discountAmount,
                vat_amount: totals.vatAmount,
                total_amount: totals.total,
                sent_date: sendQuote ? new Date().toISOString() : null,
                expiry_date: sendQuote ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() : null
            };

            const newQuote = await Quote.create(quoteData);
            
            const { sequence } = await getNextNumber('Quote Number');
            if (sequence && sequence.numeric_value < parseInt(newQuote.quote_number)) {
                await Setting.update(sequence.id, { numeric_value: parseInt(newQuote.quote_number) });
            }

            navigate(createPageUrl(`QuoteDetails?id=${newQuote.id}`));
            
        } catch (error) {
            console.error('Failed to create quote:', error);
            alert('Failed to create quote');
        } finally {
            setIsSaving(false);
        }
    };
    
    const lineItemOptions = useMemo(() => {
        if (!locale) return [];
        return quoteLineItems.map(setting => ({
            value: setting.id,
            label: setting.value,
            subtitle: `Default Price: ${formatCurrency(setting.default_amount, locale)}`
        }));
    }, [quoteLineItems, locale]);

    const totals = calculateTotals();

    if (isLoading || !locale) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-100 flex items-center justify-center">
                <div className="text-center">
                    <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-blue-600" />
                    <p className="text-gray-600">Loading Quote Creator...</p>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-100 p-8">
            <div className="max-w-6xl mx-auto">
                <div className="flex justify-between items-center mb-6">
                     <Button variant="outline" onClick={() => navigate(-1)}><ArrowLeft className="w-4 h-4 mr-2" /> Back</Button>
                    <h1 className="text-2xl font-bold text-gray-800">
                        Create New Quote #{quote.quote_number}
                    </h1>
                     <div className="flex space-x-2"></div>
                </div>

                <div className="grid lg:grid-cols-3 gap-8">
                    <div className="lg:col-span-2 space-y-6">
                        {/* Case Selector */}
                        <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0">
                            <CardHeader className="bg-gradient-to-r from-blue-100 to-indigo-100">
                                <CardTitle className="text-blue-800 flex items-center"><BookOpen className="w-5 h-5 mr-2" /> 1. Select a Case</CardTitle>
                            </CardHeader>
                            <CardContent className="p-6">
                                <Label htmlFor="case-select" className="sr-only">Select Case</Label>
                                <SearchableSelect
                                    id="case-select"
                                    placeholder="Search by Case # or Client Name..."
                                    searchPlaceholder="Type to search..."
                                    options={allCases.map(c => ({
                                        value: c.id,
                                        label: `Case #${c.case_number}`,
                                        subtitle: `${customers[c.customer_id]?.full_name || 'Unknown'} - ${c.service_type || 'N/A'}`
                                    }))}
                                    value={selectedCaseId}
                                    onValueChange={handleCaseSelect}
                                />
                            </CardContent>
                        </Card>

                        {/* Line Items Card */}
                        <Card className={`shadow-xl bg-white/90 backdrop-blur-sm border-0 ${!selectedCaseId ? 'opacity-50 pointer-events-none' : ''}`}>
                             <CardHeader className="bg-gradient-to-r from-green-100 to-emerald-100">
                                <CardTitle className="flex items-center text-green-800">
                                    <Calculator className="w-5 h-5 mr-2" />
                                    2. Quote Items
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="p-6">
                                <div className="space-y-4">
                                    {quote.line_items.map((item, index) => (
                                        <div key={index} className="grid grid-cols-16 gap-4 items-center p-4 bg-gray-50 rounded-lg">
                                            <div className="col-span-7">
                                                <Input
                                                    placeholder="Service description..."
                                                    value={item.description}
                                                    onChange={(e) => handleLineItemChange(index, 'description', e.target.value)}
                                                    className="bg-white"
                                                />
                                            </div>
                                            <div className="col-span-2">
                                                <Input
                                                    placeholder="1"
                                                    value={item.quantity || 1}
                                                    onChange={(e) => handleLineItemChange(index, 'quantity', e.target.value)}
                                                    className="bg-white text-center"
                                                    type="number"
                                                    min="1"
                                                    step="1"
                                                />
                                            </div>
                                            <div className="col-span-4">
                                                <div className="relative">
                                                    <Input
                                                        placeholder="0.000"
                                                        value={item.amount}
                                                        onChange={(e) => handleLineItemChange(index, 'amount', e.target.value)}
                                                        className="bg-white pr-16"
                                                        type="number"
                                                        step="0.001"
                                                    />
                                                    <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-sm text-gray-500">{locale?.currency_symbol || ''}</span>
                                                </div>
                                            </div>
                                            <div className="col-span-2 text-right">
                                                <span className="text-sm font-medium text-gray-700">
                                                    {formatCurrency((item.quantity || 1) * (item.amount || 0), locale)}
                                                </span>
                                            </div>
                                            <div className="col-span-1 flex justify-end">
                                                <Button
                                                    variant="ghost"
                                                    size="icon"
                                                    onClick={() => removeLineItem(index)}
                                                    disabled={quote.line_items.length === 1}
                                                    className="text-red-500 hover:text-red-700 hover:bg-red-50"
                                                >
                                                    <Trash2 className="w-4 h-4" />
                                                </Button>
                                            </div>
                                        </div>
                                    ))}
                                    <div className="flex gap-2">
                                        <Button
                                            variant="outline"
                                            onClick={addLineItem}
                                            className="w-1/2 border-dashed border-2 border-gray-300 hover:border-green-400 hover:bg-green-50"
                                        >
                                            <PlusCircle className="w-4 h-4 mr-2" />
                                            Add Custom Item
                                        </Button>
                                        <div className="w-1/2">
                                            <SearchableSelect
                                                placeholder="Add from List..."
                                                searchPlaceholder="Search services..."
                                                options={lineItemOptions}
                                                onValueChange={(settingId) => addLineItemFromSetting(settingId)}
                                                value={null}
                                            />
                                        </div>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Quote Terms Card */}
                        <Card className={`shadow-xl bg-white/90 backdrop-blur-sm border-0 ${!selectedCaseId ? 'opacity-50 pointer-events-none' : ''}`}>
                             <CardHeader className="bg-gradient-to-r from-amber-100 to-orange-100">
                                <CardTitle className="flex items-center text-amber-800">
                                    <FileText className="w-5 h-5 mr-2" />
                                    3. Terms & Conditions
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="p-6">
                                <div className="space-y-4">
                                    {/* Selected Terms Display */}
                                    {quote.quote_terms.length > 0 && (
                                        <div className="mb-4">
                                            <Label className="text-sm font-medium text-gray-700 mb-2 block">Selected Terms:</Label>
                                            <div className="flex flex-wrap gap-2">
                                                {quote.quote_terms.map((term, index) => (
                                                    <Badge key={index} variant="secondary" className="flex items-center gap-1">
                                                        {term}
                                                        <button
                                                            type="button"
                                                            onClick={() => removeSelectedTerm(term)}
                                                            className="ml-1 text-gray-500 hover:text-red-600 focus:outline-none"
                                                            aria-label={`Remove term: ${term}`}
                                                        >
                                                            ×
                                                        </button>
                                                    </Badge>
                                                ))}
                                            </div>
                                        </div>
                                    )}
                                    
                                    {/* Terms Selection */}
                                    <div>
                                        <SearchableSelect
                                            placeholder="Add terms & conditions..."
                                            searchPlaceholder="Search terms..."
                                            options={quoteTermsOptions.map(term => ({
                                                value: term.value,
                                                label: term.value
                                            }))}
                                            onValueChange={handleTermSelect}
                                            value={null}
                                        />
                                    </div>
                                    
                                    {quoteTermsOptions.length === 0 && (
                                        <div className="text-center py-4 text-gray-500 text-sm">
                                            No terms available. Add terms in Settings &gt; Quote Terms.
                                        </div>
                                    )}
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                    
                    {/* Summary Sidebar */}
                    <div className={`space-y-6 ${!selectedCaseId ? 'opacity-50 pointer-events-none' : ''}`}>
                         {/* Client Info */}
                        {selectedCustomer && (
                            <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0">
                                <CardHeader className="bg-gradient-to-r from-purple-100 to-pink-100">
                                    <CardTitle className="flex items-center text-purple-800">
                                        <User className="w-5 h-5 mr-2" />
                                        Client Info
                                    </CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-2 text-sm pt-4">
                                    <p><strong>Name:</strong> {selectedCustomer.full_name}</p>
                                    <p><strong>Email:</strong> {selectedCustomer.email}</p>
                                    <p><strong>Group:</strong> <Badge variant="secondary">{selectedCustomer.customer_group}</Badge></p>
                                </CardContent>
                            </Card>
                        )}
                        
                        {/* Quote Summary */}
                        <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0">
                            <CardHeader className="bg-gradient-to-r from-green-100 to-emerald-100">
                                <CardTitle className="text-green-800">Quote Summary</CardTitle>
                            </CardHeader>
                            <CardContent className="p-6">
                                <div className="space-y-3">
                                    <div className="flex justify-between text-sm">
                                        <span className="text-gray-600">Subtotal:</span>
                                        <span className="font-medium">{formatCurrency(totals.subtotal, locale)}</span>
                                    </div>

                                    {quote.dealer_discount_percentage > 0 && (
                                        <div className="flex justify-between text-sm text-orange-600">
                                            <span>Discount ({quote.dealer_discount_percentage}%):</span>
                                            <span>-{formatCurrency(totals.discountAmount, locale)}</span>
                                        </div>
                                    )}

                                    {quote.include_vat && (
                                        <div className="flex justify-between text-sm text-green-600">
                                            <span>VAT ({quote.vat_rate * 100}%):</span>
                                            <span>+{formatCurrency(totals.vatAmount, locale)}</span>
                                        </div>
                                    )}

                                    <div className="border-t pt-3">
                                        <div className="flex justify-between text-lg font-bold text-green-600">
                                            <span>Total Amount:</span>
                                            <span>{formatCurrency(totals.total, locale)}</span>
                                        </div>
                                    </div>
                                    <div className="flex items-center justify-between pt-2">
                                        <Label htmlFor="includeVAT" className="text-sm font-medium">Include {quote.vat_rate * 100}% VAT</Label>
                                        <input
                                            id="includeVAT"
                                            type="checkbox"
                                            checked={quote.include_vat}
                                            onChange={(e) => setQuote({ ...quote, include_vat: e.target.checked })}
                                            className="rounded focus:ring-green-500 text-green-600"
                                        />
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Actions Card */}
                        <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0">
                            <CardContent className="flex justify-end space-x-2 p-4">
                                <Button variant="outline" onClick={() => handleSave(false)} disabled={isSaving}>
                                    {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                                    Save Draft
                                </Button>
                                <Button onClick={() => handleSave(true)} disabled={isSaving} className="bg-blue-600 hover:bg-blue-700">
                                    {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="w-4 h-4 mr-2" />}
                                    Save & Send
                                </Button>
                            </CardContent>
                        </Card>
                    </div>
                </div>
            </div>
        </div>
    );
}
