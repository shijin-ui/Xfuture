
import React, { useState, useEffect } from 'react';
import { Inventory } from '@/api/entities';
import { Case } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Search, AlertTriangle, CheckCircle, Clock, MapPin, HardDrive, Info, Zap, FileSearch, ExternalLink, Archive, History } from 'lucide-react';
import { format, differenceInMonths, parseISO } from 'date-fns';
import SearchableSelect from '../components/SearchableSelect';
import { getSettingsByCategory } from '../components/utils/settingsLoader';
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';

// Enhanced Donor matching algorithm with simple mode
class DonorMatcher {
    static calculateCompatibility(patient, donor, matchMode = 'professional') {
        if (!patient || !donor) {
            return { score: 0, reasons: ['Missing drive information'], category: 'incompatible' };
        }

        // Brand check for both modes
        if (patient.brand !== donor.brand) {
            return { score: 0, reasons: ['Different brand'], category: 'incompatible' };
        }

        // SIMPLE MODE - just model matching
        if (matchMode === 'simple') {
            return this.simpleModelMatch(patient, donor);
        }

        // PROFESSIONAL MODE - full compatibility analysis
        const brand = patient.brand.toLowerCase();
        let score = 0;
        let reasons = [];
        let warnings = [];

        // Universal rules first
        const universalScore = this.checkUniversalRules(patient, donor);
        score += universalScore.score;
        reasons.push(...universalScore.reasons);
        warnings.push(...universalScore.warnings);

        // Brand-specific rules
        let brandScore = { score: 0, reasons: [], warnings: [] };
        
        if (brand.includes('western digital') || brand.includes('wd')) {
            brandScore = this.checkWDRules(patient, donor);
        } else if (brand.includes('seagate')) {
            brandScore = this.checkSeagateRules(patient, donor);
        } else if (brand.includes('samsung')) {
            brandScore = this.checkSamsungRules(patient, donor);
        } else if (brand.includes('hitachi') || brand.includes('ibm')) {
            brandScore = this.checkHitachiRules(patient, donor);
        } else if (brand.includes('toshiba')) {
            brandScore = this.checkToshibaRules(patient, donor);
        } else if (brand.includes('maxtor')) {
            brandScore = this.checkMaxtorRules(patient, donor);
        } else if (brand.includes('fujitsu')) {
            brandScore = this.checkFujitsuRules(patient, donor);
        }

        score += brandScore.score;
        reasons.push(...brandScore.reasons);
        warnings.push(...brandScore.warnings);

        // Determine category
        let category = 'incompatible';
        if (score >= 85) category = 'excellent';
        else if (score >= 70) category = 'good';
        else if (score >= 50) category = 'fair';
        else if (score >= 25) category = 'poor';

        return { score: Math.min(100, score), reasons, warnings, category };
    }

    static simpleModelMatch(patient, donor) {
        let score = 0;
        let reasons = [];
        let warnings = [];

        if (!patient.media_model || !donor.media_model) {
            return { score: 0, reasons: ['Model information missing'], category: 'incompatible' };
        }

        // Exact model match
        if (patient.media_model === donor.media_model) {
            score = 95;
            reasons.push('✓ Exact model match');
        } 
        // Partial model match (first part)
        else if (patient.media_model.split('-')[0] === donor.media_model.split('-')[0]) {
            score = 80;
            reasons.push('✓ Model family match');
            warnings.push('⚠ Model revision may differ');
        }
        // Similar model (contains common substring)
        else if (patient.media_model.substring(0, 6) === donor.media_model.substring(0, 6)) {
            score = 60;
            reasons.push('✓ Similar model detected');
            warnings.push('⚠ Model differs - verify compatibility');
        }
        else {
            score = 0;
            warnings.push('✗ Model mismatch');
        }

        // Bonus points for same capacity
        if (patient.capacity && donor.capacity && patient.capacity === donor.capacity) {
            score += 5;
            reasons.push('✓ Same capacity');
        }

        let category = 'incompatible';
        if (score >= 90) category = 'excellent';
        else if (score >= 75) category = 'good';
        else if (score >= 50) category = 'fair';
        else if (score >= 25) category = 'poor';

        return { score, reasons, warnings, category };
    }

    static checkUniversalRules(patient, donor) {
        let score = 0;
        let reasons = [];
        let warnings = [];

        // PH (head) map - CRITICAL
        if (patient.head_no && donor.head_no) {
            if (patient.head_no === donor.head_no) {
                score += 25;
                reasons.push('✓ Head count matches perfectly');
            } else if (parseInt(donor.head_no) > parseInt(patient.head_no)) {
                score += 15;
                warnings.push('⚠ Donor has more heads (may work)');
            } else {
                warnings.push('✗ Donor has fewer heads (risky)');
            }
        }

        // Date proximity - within ±3 months is ideal
        if (patient.dom && donor.dom) {
            const monthsDiff = this.calculateDateProximity(patient.dom, donor.dom);
            if (monthsDiff <= 1) {
                score += 15;
                reasons.push('✓ Manufacturing dates very close');
            } else if (monthsDiff <= 3) {
                score += 10;
                reasons.push('✓ Manufacturing dates within acceptable range');
            } else if (monthsDiff <= 6) {
                score += 5;
                warnings.push('⚠ Manufacturing dates somewhat distant');
            } else {
                warnings.push('✗ Manufacturing dates far apart');
            }
        }

        // Manufacturing site/country
        if (patient.made_in && donor.made_in) {
            if (patient.made_in === donor.made_in) {
                score += 10;
                reasons.push('✓ Same manufacturing location');
            } else {
                warnings.push('⚠ Different manufacturing locations');
            }
        }

        // Capacity match (not critical but helpful)
        if (patient.capacity && donor.capacity) {
            if (patient.capacity === donor.capacity) {
                score += 5;
                reasons.push('✓ Same capacity');
            }
        }

        return { score, reasons, warnings };
    }

    static checkWDRules(patient, donor) {
        let score = 0;
        let reasons = [];
        let warnings = [];

        // Model matching
        if (patient.media_model && donor.media_model) {
            if (patient.media_model === donor.media_model) {
                score += 20;
                reasons.push('✓ Exact model match (WD)');
            } else {
                // Check for partial match (first part + 3 chars)
                const patientParts = patient.media_model.split('-');
                const donorParts = donor.media_model.split('-');
                
                if (patientParts[0] === donorParts[0] && 
                    patientParts[1]?.substring(0, 3) === donorParts[1]?.substring(0, 3)) {
                    score += 15;
                    reasons.push('✓ Good model match (WD compatible)');
                } else {
                    warnings.push('✗ Model mismatch (WD)');
                }
            }
        }

        // DCM matching (preceding char + J/2)
        if (patient.dcm_mlc && donor.dcm_mlc) {
            if (this.extractDCMCode(patient.dcm_mlc) === this.extractDCMCode(donor.dcm_mlc)) {
                score += 15;
                reasons.push('✓ DCM codes match (WD)');
            } else {
                warnings.push('⚠ DCM codes differ (WD)');
            }
        }

        // Preamp matching for Marvell controllers
        if (patient.preamp && donor.preamp) {
            if (patient.preamp === donor.preamp) {
                score += 10;
                reasons.push('✓ Preamp match (WD Marvell)');
            } else {
                warnings.push('⚠ Preamp mismatch (WD Marvell)');
            }
        }

        return { score, reasons, warnings };
    }

    static checkSeagateRules(patient, donor) {
        let score = 0;
        let reasons = [];
        let warnings = [];

        // Model must be exact
        if (patient.media_model && donor.media_model) {
            if (patient.media_model === donor.media_model) {
                score += 25;
                reasons.push('✓ Exact model match (Seagate)');
            } else {
                warnings.push('✗ Model mismatch (Seagate - must be exact)');
                return { score: 0, reasons, warnings }; // Stop here for Seagate
            }
        }

        // Serial number matching (2nd & 3rd chars)
        if (patient.serial_number && donor.serial_number && 
            patient.serial_number.length >= 3 && donor.serial_number.length >= 3) {
            
            const patientCode = patient.serial_number.substring(1, 3);
            const donorCode = donor.serial_number.substring(1, 3);
            
            if (patientCode === donorCode) {
                score += 15;
                reasons.push('✓ Serial number site code match (Seagate)');
            } else {
                warnings.push('⚠ Serial number site code mismatch (Seagate)');
            }
        }

        // Firmware matching (has "." for Barracuda)
        if (patient.firmware && donor.firmware) {
            const patientHasDot = patient.firmware.includes('.');
            const donorHasDot = donor.firmware.includes('.');
            
            if (patientHasDot === donorHasDot) {
                score += 10;
                reasons.push(`✓ Firmware family match (${patientHasDot ? 'Barracuda' : 'F3'})`);
                
                if (patient.firmware === donor.firmware) {
                    score += 5;
                    reasons.push('✓ Exact firmware match');
                }
            } else {
                warnings.push('⚠ Different Seagate firmware families');
            }
        }

        // Part number matching (first half)
        if (patient.part_number && donor.part_number) {
            const halfLength = Math.floor(patient.part_number.length / 2);
            if (patient.part_number.substring(0, halfLength) === 
                donor.part_number.substring(0, halfLength)) {
                score += 8;
                reasons.push('✓ Part number family match (Seagate)');
            }
        }

        return { score, reasons, warnings };
    }

    static checkSamsungRules(patient, donor) {
        let score = 0;
        let reasons = [];
        let warnings = [];

        // Model must be exact
        if (patient.media_model && donor.media_model) {
            if (patient.media_model === donor.media_model) {
                score += 25;
                reasons.push('✓ Exact model match (Samsung)');
            } else {
                warnings.push('✗ Model mismatch (Samsung - must be exact)');
            }
        }

        // Preamp revision matching for newer Samsung
        if (patient.preamp && donor.preamp) {
            if (patient.preamp === donor.preamp) {
                score += 15;
                reasons.push('✓ Preamp revision match (Samsung)');
            } else {
                warnings.push('⚠ Preamp revision mismatch (Samsung)');
            }
        }

        return { score, reasons, warnings };
    }

    static checkHitachiRules(patient, donor) {
        let score = 0;
        let reasons = [];
        let warnings = [];

        // Model and Part Number must be exact
        if (patient.media_model === donor.media_model && 
            patient.part_number === donor.part_number) {
            score += 30;
            reasons.push('✓ Exact model and part number match (Hitachi/IBM)');
        } else {
            warnings.push('✗ Model or part number mismatch (Hitachi/IBM)');
        }

        // MLC must be exact
        if (patient.mlc && donor.mlc) {
            if (patient.mlc === donor.mlc) {
                score += 15;
                reasons.push('✓ MLC exact match (Hitachi/IBM)');
            } else {
                warnings.push('✗ MLC mismatch (Hitachi/IBM)');
            }
        }

        return { score, reasons, warnings };
    }

    static checkToshibaRules(patient, donor) {
        let score = 0;
        let reasons = [];
        let warnings = [];

        // Model matching (whole number or first 8 digits + family)
        if (patient.media_model && donor.media_model) {
            if (patient.media_model === donor.media_model) {
                score += 25;
                reasons.push('✓ Exact model match (Toshiba)');
            } else if (patient.media_model.substring(0, 8) === donor.media_model.substring(0, 8)) {
                score += 18;
                reasons.push('✓ Model family match (Toshiba)');
            } else {
                warnings.push('⚠ Model mismatch (Toshiba)');
            }
        }

        return { score, reasons, warnings };
    }

    static checkMaxtorRules(patient, donor) {
        let score = 0;
        let reasons = [];
        let warnings = [];

        // Model must be exact
        if (patient.media_model === donor.media_model) {
            score += 25;
            reasons.push('✓ Exact model match (Maxtor)');
        } else {
            warnings.push('✗ Model mismatch (Maxtor - must be exact)');
        }

        return { score, reasons, warnings };
    }

    static checkFujitsuRules(patient, donor) {
        let score = 0;
        let reasons = [];
        let warnings = [];

        // Model and Part Number must be exact
        if (patient.media_model === donor.media_model && 
            patient.part_number === donor.part_number) {
            score += 30;
            reasons.push('✓ Exact model and part number match (Fujitsu)');
        } else {
            warnings.push('✗ Model or part number mismatch (Fujitsu)');
        }

        return { score, reasons, warnings };
    }

    static calculateDateProximity(date1, date2) {
        try {
            // Handle different date formats commonly found on drive labels
            const parseDate = (dateStr) => {
                if (dateStr.includes('W')) { // Week format like "19W25"
                    const year = 2000 + parseInt(dateStr.substring(0, 2));
                    const week = parseInt(dateStr.substring(3));
                    return new Date(year, 0, 1 + (week - 1) * 7);
                } else if (dateStr.length === 5) { // Julian format like "19168"
                    const year = 2000 + parseInt(dateStr.substring(0, 2));
                    const day = parseInt(dateStr.substring(2));
                    return new Date(year, 0, day);
                } else {
                    return new Date(dateStr);
                }
            };

            const d1 = parseDate(date1);
            const d2 = parseDate(date2);
            return Math.abs(differenceInMonths(d1, d2));
        } catch (error) {
            return 999; // Return large number if date parsing fails
        }
    }

    static extractDCMCode(dcm) {
        // Extract the critical DCM matching code
        const match = dcm.match(/([A-Z])([J2])/);
        return match ? match[0] : dcm;
    }
}

export default function DonorSearchPage() {
    const [inventory, setInventory] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [searchResults, setSearchResults] = useState([]);
    const [caseHistoryResults, setCaseHistoryResults] = useState([]);
    const [brands, setBrands] = useState([]);
    const [jobNumber, setJobNumber] = useState('');
    const [isLoadingCase, setIsLoadingCase] = useState(false);
    const [matchMode, setMatchMode] = useState('professional');
    
    // Patient drive specifications
    const [patientSpecs, setPatientSpecs] = useState({
        brand: '',
        media_model: '',
        serial_number: '',
        capacity: '',
        head_no: '',
        dom: '',
        made_in: '',
        dcm_mlc: '',
        preamp: '',
        part_number: '',
        firmware: '',
        mlc: ''
    });

    const getCompatibilityInfo = (compatibility) => {
        if (!compatibility) return { badge: 'No Analysis', details: [], matchCount: 0, positiveReasons: [], warnings: [] };

        const { score, reasons, warnings } = compatibility;
        
        // Focus on what DOES match instead of what doesn't
        const positiveReasons = reasons.filter(r => r.startsWith('✓'));
        const matchCount = positiveReasons.length;
        
        let badge = '';
        let badgeClass = '';
        
        if (matchCount >= 4) {
            badge = `${matchCount} Criteria Match`;
            badgeClass = 'bg-green-100 text-green-800 border border-green-200';
        } else if (matchCount >= 2) {
            badge = `${matchCount} Criteria Match`;
            badgeClass = 'bg-blue-100 text-blue-800 border border-blue-200';
        } else if (matchCount >= 1) {
            badge = `${matchCount} Criteria Match`;
            badgeClass = 'bg-yellow-100 text-yellow-800 border border-yellow-200';
        } else {
            // Even if no perfect matches, show what brand compatibility exists
            if (score > 0) { // Score > 0 usually implies brand matched at least
                badge = 'Same Brand';
                badgeClass = 'bg-orange-100 text-orange-800 border border-orange-200';
            } else {
                badge = 'Different Brand';
                badgeClass = 'bg-red-100 text-red-800 border border-red-200';
            }
        }
        
        return {
            badge,
            badgeClass,
            matchCount,
            positiveReasons,
            warnings
        };
    };

    const getCompatibilityBadge = (compatibility) => {
        const info = getCompatibilityInfo(compatibility);
        return (
            <Badge className={info.badgeClass}>
                {info.badge}
            </Badge>
        );
    };

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        try {
            const [inventoryData, brandsData] = await Promise.all([
                Inventory.list('-created_date'),
                getSettingsByCategory('Brands')
            ]);
            
            // Ensure arrays are properly initialized
            setInventory(Array.isArray(inventoryData) ? inventoryData.filter(item => item.is_donor !== false) : []);
            setBrands(Array.isArray(brandsData) ? [...new Set(brandsData)] : []);
        } catch (error) {
            console.error("Failed to load data:", error);
            // Set empty arrays on error
            setInventory([]);
            setBrands([]);
        }
    };

    const handleJobNumberSearch = async () => {
        if (!jobNumber.trim()) {
            alert('Please enter a job number.');
            return;
        }

        setIsLoadingCase(true);
        try {
            // Search for case by job number
            const cases = await Case.filter({ case_number: jobNumber.trim() });
            
            if (!Array.isArray(cases) || cases.length === 0) {
                alert('Job number not found. Please check and try again.');
                setIsLoadingCase(false);
                return;
            }

            const caseData = cases[0];
            
            // Extract patient drive details from the first device
            if (caseData.devices && Array.isArray(caseData.devices) && caseData.devices.length > 0) {
                const patientDevice = caseData.devices.find(d => d.role === 'Patient') || caseData.devices[0];
                
                const extractedSpecs = {
                    brand: patientDevice.brand || '',
                    media_model: patientDevice.media_model || '',
                    serial_number: patientDevice.media_serial_number || '',
                    capacity: patientDevice.capacity || '',
                    head_no: patientDevice.head_no || patientDevice.ph || '',
                    dom: patientDevice.dom || '',
                    made_in: patientDevice.made_in || '',
                    dcm_mlc: patientDevice.dcm_mlc || '',
                    preamp: patientDevice.preamp || '',
                    part_number: patientDevice.part_no || patientDevice.part_number || '',
                    firmware: patientDevice.firmware || '',
                    mlc: patientDevice.mlc || ''
                };

                setPatientSpecs(extractedSpecs);
                
                // Auto-run search if we have enough information
                if (extractedSpecs.brand && extractedSpecs.media_model) {
                    setTimeout(() => handleSearch(extractedSpecs), 500);
                }
            } else {
                alert('No device information found in this case.');
            }
        } catch (error) {
            console.error("Failed to load case:", error);
            alert('Error loading case data. Please try again.');
        } finally {
            setIsLoadingCase(false);
        }
    };

    const handleSearch = async (specsToUse = null) => {
        const specs = specsToUse || patientSpecs;
        
        if (!specs.brand) {
            alert('Please specify the patient drive brand to search for donors.');
            return;
        }

        setIsLoading(true);

        try {
            // Search inventory (existing functionality)
            const inventoryArray = Array.isArray(inventory) ? inventory : [];
            
            const brandMatches = inventoryArray.filter(item => 
                item.brand === specs.brand && 
                item.quantity > 0 &&
                !item.case_id // Available (not assigned to a case)
            );

            const inventoryResults = brandMatches.map(donor => {
                const compatibility = DonorMatcher.calculateCompatibility(specs, donor, matchMode);
                return { ...donor, compatibility, source: 'inventory' };
            });

            // Search case history (new functionality)
            const allCases = await Case.list('-created_date', 500); // Get recent cases, adjust limit as needed
            const caseResults = [];

            allCases.forEach(caseItem => {
                if (caseItem.devices && Array.isArray(caseItem.devices)) {
                    caseItem.devices.forEach(device => {
                        // Only search patient drives from other cases
                        if (device.brand === specs.brand && device.role === 'Patient') {
                            // Exclude the current case if searching from job number
                            if (jobNumber && caseItem.case_number === jobNumber.trim()) {
                                return;
                            }

                            const compatibility = DonorMatcher.calculateCompatibility(specs, device, matchMode);
                            
                            // Only include if there's some compatibility
                            if (compatibility.score > 0) {
                                caseResults.push({
                                    ...device,
                                    compatibility,
                                    source: 'case',
                                    case_id: caseItem.id,
                                    case_number: caseItem.case_number,
                                    case_status: caseItem.status,
                                    case_created_date: caseItem.created_date,
                                    customer_name: caseItem.customer_name || 'Unknown Customer'
                                });
                            }
                        }
                    });
                }
            });

            // Sort both results by compatibility score (highest first)
            inventoryResults.sort((a, b) => b.compatibility.score - a.compatibility.score);
            caseResults.sort((a, b) => b.compatibility.score - a.compatibility.score);

            setSearchResults(inventoryResults);
            setCaseHistoryResults(caseResults);
        } catch (error) {
            console.error("Search error:", error);
            setSearchResults([]);
            setCaseHistoryResults([]);
        } finally {
            setIsLoading(false);
        }
    };

    const getStatusBadge = (status) => {
        const styles = {
            'Completed': 'bg-green-100 text-green-800',
            'Closed': 'bg-gray-100 text-gray-800',
            'Cancelled': 'bg-red-100 text-red-800',
            'Returned': 'bg-blue-100 text-blue-800',
            'Unrecoverable': 'bg-orange-100 text-orange-800',
            'In Progress': 'bg-blue-100 text-blue-800',
            'Pending': 'bg-yellow-100 text-yellow-800',
            'Awaiting Approval': 'bg-purple-100 text-purple-800'
        };

        return (
            <Badge className={styles[status] || 'bg-yellow-100 text-yellow-800'}>
                {status}
            </Badge>
        );
    };

    // Ensure brands is an array before mapping
    const brandOptions = Array.isArray(brands) ? brands.map(brand => ({ label: brand, value: brand })) : [];

    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-7xl mx-auto">
                <div className="flex items-center justify-between mb-6">
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900">Enhanced Donor Search</h1>
                        <p className="text-gray-600 mt-1">Find compatible donor drives from inventory and case history</p>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Patient Drive Specifications */}
                    <div className="lg:col-span-1">
                        <Card className="sticky top-6">
                            <CardHeader className="bg-blue-50">
                                <CardTitle className="flex items-center text-blue-800">
                                    <HardDrive className="w-5 h-5 mr-2" />
                                    Patient Drive Search
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="p-6">
                                <Tabs defaultValue="manual" className="space-y-4">
                                    <TabsList className="grid w-full grid-cols-2">
                                        <TabsTrigger value="job" className="flex items-center">
                                            <FileSearch className="w-4 h-4 mr-2" />
                                            Job Number
                                        </TabsTrigger>
                                        <TabsTrigger value="manual" className="flex items-center">
                                            <HardDrive className="w-4 h-4 mr-2" />
                                            Manual Entry
                                        </TabsTrigger>
                                    </TabsList>

                                    <TabsContent value="job" className="space-y-4">
                                        <div>
                                            <Label>Job Number</Label>
                                            <div className="flex gap-2">
                                                <Input
                                                    value={jobNumber}
                                                    onChange={(e) => setJobNumber(e.target.value)}
                                                    placeholder="Enter job number (e.g., 25009)"
                                                    onKeyPress={(e) => e.key === 'Enter' && handleJobNumberSearch()}
                                                />
                                                <Button onClick={handleJobNumberSearch} disabled={isLoadingCase}>
                                                    {isLoadingCase ? <Clock className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                                                </Button>
                                            </div>
                                            <p className="text-xs text-gray-500 mt-1">
                                                Enter a job number to automatically fetch patient drive details
                                            </p>
                                        </div>
                                    </TabsContent>

                                    <TabsContent value="manual" className="space-y-4">
                                        <div>
                                            <Label>Brand *</Label>
                                            <SearchableSelect
                                                value={patientSpecs.brand}
                                                onValueChange={(value) => setPatientSpecs({...patientSpecs, brand: value})}
                                                options={brandOptions}
                                                placeholder="Select brand..."
                                            />
                                        </div>
                                        <div>
                                            <Label>Model Number</Label>
                                            <Input
                                                value={patientSpecs.media_model}
                                                onChange={(e) => setPatientSpecs({...patientSpecs, media_model: e.target.value})}
                                                placeholder="e.g., ST2000DM008"
                                            />
                                        </div>
                                        <div>
                                            <Label>Serial Number</Label>
                                            <Input
                                                value={patientSpecs.serial_number}
                                                onChange={(e) => setPatientSpecs({...patientSpecs, serial_number: e.target.value})}
                                                placeholder="e.g., ZFL2KJ9X"
                                            />
                                        </div>
                                        <div className="grid grid-cols-2 gap-2">
                                            <div>
                                                <Label>Capacity</Label>
                                                <Input
                                                    value={patientSpecs.capacity}
                                                    onChange={(e) => setPatientSpecs({...patientSpecs, capacity: e.target.value})}
                                                    placeholder="2TB"
                                                />
                                            </div>
                                            <div>
                                                <Label>Head Count</Label>
                                                <Input
                                                    value={patientSpecs.head_no}
                                                    onChange={(e) => setPatientSpecs({...patientSpecs, head_no: e.target.value})}
                                                    placeholder="4"
                                                />
                                            </div>
                                        </div>
                                        <div className="grid grid-cols-2 gap-2">
                                            <div>
                                                <Label>DOM</Label>
                                                <Input
                                                    value={patientSpecs.dom}
                                                    onChange={(e) => setPatientSpecs({...patientSpecs, dom: e.target.value})}
                                                    placeholder="19168"
                                                />
                                            </div>
                                            <div>
                                                <Label>Made In</Label>
                                                <Input
                                                    value={patientSpecs.made_in}
                                                    onChange={(e) => setPatientSpecs({...patientSpecs, made_in: e.target.value})}
                                                    placeholder="Thailand"
                                                />
                                            </div>
                                        </div>
                                        <div>
                                            <Label>DCM/MLC</Label>
                                            <Input
                                                value={patientSpecs.dcm_mlc}
                                                onChange={(e) => setPatientSpecs({...patientSpecs, dcm_mlc: e.target.value})}
                                                placeholder="DHRNKT2AHB"
                                            />
                                        </div>
                                        <div>
                                            <Label>Preamp</Label>
                                            <Input
                                                value={patientSpecs.preamp}
                                                onChange={(e) => setPatientSpecs({...patientSpecs, preamp: e.target.value})}
                                                placeholder="STM4651F"
                                            />
                                        </div>
                                        <div>
                                            <Label>Part Number</Label>
                                            <Input
                                                value={patientSpecs.part_number}
                                                onChange={(e) => setPatientSpecs({...patientSpecs, part_number: e.target.value})}
                                                placeholder="ST2000DM008-2FR102"
                                            />
                                        </div>
                                        <div>
                                            <Label>Firmware</Label>
                                            <Input
                                                value={patientSpecs.firmware}
                                                onChange={(e) => setPatientSpecs({...patientSpecs, firmware: e.target.value})}
                                                placeholder="0001 or CC26.3"
                                            />
                                        </div>
                                    </TabsContent>
                                </Tabs>

                                {/* Match Mode Selection */}
                                <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                                    <Label className="text-sm font-medium">Matching Mode</Label>
                                    <RadioGroup value={matchMode} onValueChange={setMatchMode} className="mt-2">
                                        <div className="flex items-center space-x-2">
                                            <RadioGroupItem value="professional" id="professional" />
                                            <Label htmlFor="professional" className="cursor-pointer text-sm">
                                                <span className="flex items-center">
                                                    <Zap className="w-4 h-4 mr-1 text-blue-600" />
                                                    Professional Match
                                                </span>
                                                <span className="block text-xs text-gray-500">Full compatibility analysis</span>
                                            </Label>
                                        </div>
                                        <div className="flex items-center space-x-2">
                                            <RadioGroupItem value="simple" id="simple" />
                                            <Label htmlFor="simple" className="cursor-pointer text-sm">
                                                <span className="flex items-center">
                                                    <CheckCircle className="w-4 h-4 mr-1 text-green-600" />
                                                    Simple Match
                                                </span>
                                                <span className="block text-xs text-gray-500">Model number only</span>
                                            </Label>
                                        </div>
                                    </RadioGroup>
                                </div>

                                <Button className="w-full mt-4" onClick={() => handleSearch()} disabled={isLoading}>
                                    <Search className="w-4 h-4 mr-2" />
                                    {isLoading ? 'Searching...' : 'Search Donors'}
                                </Button>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Search Results */}
                    <div className="lg:col-span-2">
                        <Tabs defaultValue="inventory" className="space-y-4">
                            <TabsList className="grid w-full grid-cols-2">
                                <TabsTrigger value="inventory" className="flex items-center">
                                    <Archive className="w-4 h-4 mr-2" />
                                    Inventory ({searchResults.length})
                                </TabsTrigger>
                                <TabsTrigger value="history" className="flex items-center">
                                    <History className="w-4 h-4 mr-2" />
                                    Case History ({caseHistoryResults.length})
                                </TabsTrigger>
                            </TabsList>

                            <TabsContent value="inventory">
                                <Card>
                                    <CardHeader>
                                        <CardTitle className="flex items-center justify-between">
                                            <span>Inventory Results ({searchResults.length})</span>
                                            <div className="flex items-center gap-2">
                                                {searchResults.filter(r => getCompatibilityInfo(r.compatibility).matchCount >= 3).length > 0 && (
                                                    <Badge variant="outline">
                                                        {searchResults.filter(r => getCompatibilityInfo(r.compatibility).matchCount >= 3).length} High Match
                                                    </Badge>
                                                )}
                                                {matchMode === 'simple' && (
                                                    <Badge className="bg-green-100 text-green-800">
                                                        Simple Mode
                                                    </Badge>
                                                )}
                                            </div>
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        {searchResults.length === 0 ? (
                                            <div className="text-center py-12 text-gray-500">
                                                <Archive className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                                                <p>No inventory matches found. Try adjusting search parameters.</p>
                                            </div>
                                        ) : (
                                            <div className="space-y-4">
                                                {searchResults.map((donor, index) => {
                                                    const compatInfo = getCompatibilityInfo(donor.compatibility);
                                                    return (
                                                        <Card key={donor.id || index} className="border-l-4 border-l-green-500">
                                                            <CardContent className="p-4">
                                                                <div className="flex justify-between items-start mb-3">
                                                                    <div>
                                                                        <h3 className="font-semibold text-lg">
                                                                            {donor.brand} {donor.media_model}
                                                                        </h3>
                                                                        <p className="text-sm text-gray-600">
                                                                            S/N: {donor.serial_number} | {donor.capacity} | Qty: {donor.quantity}
                                                                        </p>
                                                                    </div>
                                                                    <div className="flex flex-col items-end gap-2">
                                                                        {getCompatibilityBadge(donor.compatibility)}
                                                                        {compatInfo.matchCount > 0 && (
                                                                            <span className="text-xs text-green-600 font-medium">
                                                                                {compatInfo.matchCount} criteria match
                                                                            </span>
                                                                        )}
                                                                    </div>
                                                                </div>

                                                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
                                                                    <div className="text-sm space-y-1">
                                                                        {donor.pcb_no && <div><strong>PCB:</strong> {donor.pcb_no}</div>}
                                                                        {donor.dom && <div><strong>DOM:</strong> {donor.dom}</div>}
                                                                        {donor.head_no && <div><strong>Heads:</strong> {donor.head_no}</div>}
                                                                        {donor.made_in && <div><strong>Made In:</strong> {donor.made_in}</div>}
                                                                    </div>
                                                                    <div className="text-sm space-y-1">
                                                                        {donor.dcm_mlc && <div><strong>DCM:</strong> {donor.dcm_mlc}</div>}
                                                                        {donor.preamp && <div><strong>Preamp:</strong> {donor.preamp}</div>}
                                                                        {donor.firmware && <div><strong>Firmware:</strong> {donor.firmware}</div>}
                                                                        {donor.location && <div><strong>Location:</strong> {donor.location}</div>}
                                                                    </div>
                                                                </div>

                                                                {/* Enhanced Compatibility Details */}
                                                                <div className="border-t pt-3">
                                                                    <details className="cursor-pointer">
                                                                        <summary className="text-sm font-medium text-gray-700 hover:text-gray-900">
                                                                            <Info className="w-4 h-4 inline mr-1" />
                                                                            Compatibility Analysis - {compatInfo.matchCount} Matches Found
                                                                        </summary>
                                                                        <div className="mt-2 p-3 bg-gray-50 rounded text-xs space-y-2">
                                                                            {compatInfo.positiveReasons.length > 0 && (
                                                                                <div>
                                                                                    <div className="font-semibold text-green-700 mb-1">✅ Compatible Aspects:</div>
                                                                                    {compatInfo.positiveReasons.map((reason, i) => (
                                                                                        <div key={i} className="text-green-700 ml-2">{reason}</div>
                                                                                    ))}
                                                                                </div>
                                                                            )}
                                                                            {compatInfo.warnings.length > 0 && (
                                                                                <div>
                                                                                    <div className="font-semibold text-orange-700 mb-1">⚠️ Consider These Factors:</div>
                                                                                    {compatInfo.warnings.map((warning, i) => (
                                                                                        <div key={i} className="text-orange-600 ml-2">{warning}</div>
                                                                                    ))}
                                                                                </div>
                                                                            )}
                                                                            {compatInfo.positiveReasons.length === 0 && compatInfo.warnings.length === 0 && (
                                                                                <div className="text-gray-600">
                                                                                    Same brand detected - manual evaluation needed for part compatibility
                                                                                </div>
                                                                            )}
                                                                        </div>
                                                                    </details>
                                                                </div>
                                                            </CardContent>
                                                        </Card>
                                                    );
                                                })}
                                            </div>
                                        )}
                                    </CardContent>
                                </Card>
                            </TabsContent>

                            <TabsContent value="history">
                                <Card>
                                    <CardHeader>
                                        <CardTitle className="flex items-center justify-between">
                                            <span>Case History Results ({caseHistoryResults.length})</span>
                                            <div className="flex items-center gap-2">
                                                {caseHistoryResults.filter(r => getCompatibilityInfo(r.compatibility).matchCount >= 3).length > 0 && (
                                                    <Badge variant="outline">
                                                        {caseHistoryResults.filter(r => getCompatibilityInfo(r.compatibility).matchCount >= 3).length} High Match
                                                    </Badge>
                                                )}
                                                {matchMode === 'simple' && (
                                                    <Badge className="bg-green-100 text-green-800">
                                                        Simple Mode
                                                    </Badge>
                                                )}
                                            </div>
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        {!Array.isArray(caseHistoryResults) || caseHistoryResults.length === 0 ? (
                                            <div className="text-center py-12 text-gray-500">
                                                <History className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                                                <p>No similar drives found in case history. Try adjusting search parameters.</p>
                                            </div>
                                        ) : (
                                            <div className="space-y-4">
                                                {caseHistoryResults.map((caseDevice, index) => {
                                                    const compatInfo = getCompatibilityInfo(caseDevice.compatibility);
                                                    return (
                                                        <Card key={`${caseDevice.case_id}-${index}`} className="border-l-4 border-l-blue-500">
                                                            <CardContent className="p-4">
                                                                <div className="flex justify-between items-start mb-3">
                                                                    <div>
                                                                        <div className="flex items-center gap-2 mb-1">
                                                                            <h3 className="font-semibold text-lg">
                                                                                {caseDevice.brand} {caseDevice.media_model}
                                                                            </h3>
                                                                            <Badge variant="outline" className="text-xs">
                                                                                Case #{caseDevice.case_number}
                                                                            </Badge>
                                                                        </div>
                                                                        <div className="flex items-center gap-4 text-sm text-gray-600">
                                                                            <span>S/N: {caseDevice.media_serial_number}</span>
                                                                            <span>{caseDevice.capacity}</span>
                                                                            {caseDevice.case_created_date && <span>{format(new Date(caseDevice.case_created_date), 'MMM yyyy')}</span>}
                                                                        </div>
                                                                    </div>
                                                                    <div className="flex flex-col items-end gap-2">
                                                                        {getCompatibilityBadge(caseDevice.compatibility)}
                                                                        {compatInfo.matchCount > 0 && (
                                                                            <span className="text-xs text-blue-600 font-medium">
                                                                                {compatInfo.matchCount} criteria match
                                                                            </span>
                                                                        )}
                                                                        {getStatusBadge(caseDevice.case_status)}
                                                                    </div>
                                                                </div>

                                                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
                                                                    <div className="text-sm space-y-1">
                                                                        <div><strong>Customer:</strong> {caseDevice.customer_name}</div>
                                                                        {caseDevice.pcb_no && <div><strong>PCB:</strong> {caseDevice.pcb_no}</div>}
                                                                        {caseDevice.dom && <div><strong>DOM:</strong> {caseDevice.dom}</div>}
                                                                        {caseDevice.head_no && <div><strong>Heads:</strong> {caseDevice.head_no}</div>}
                                                                    </div>
                                                                    <div className="text-sm space-y-1">
                                                                        <div><strong>Case Status:</strong> {caseDevice.case_status}</div>
                                                                        {caseDevice.dcm_mlc && <div><strong>DCM:</strong> {caseDevice.dcm_mlc}</div>}
                                                                        {caseDevice.preamp && <div><strong>Preamp:</strong> {caseDevice.preamp}</div>}
                                                                        {caseDevice.firmware && <div><strong>Firmware:</strong> {caseDevice.firmware}</div>}
                                                                    </div>
                                                                </div>

                                                                <div className="flex items-center justify-between border-t pt-3">
                                                                    <div className="text-xs text-gray-500">
                                                                        💡 Parts may be available: PCB, heads, preamp
                                                                    </div>
                                                                    <Link 
                                                                        to={createPageUrl(`CaseDetails?id=${caseDevice.case_id}`)}
                                                                        target="_blank"
                                                                        rel="noopener noreferrer"
                                                                    >
                                                                        <Button variant="outline" size="sm" className="flex items-center gap-2">
                                                                            <ExternalLink className="w-4 h-4" />
                                                                            View Case
                                                                        </Button>
                                                                    </Link>
                                                                </div>

                                                                {/* Enhanced Compatibility Details */}
                                                                <div className="border-t pt-3 mt-3">
                                                                    <details className="cursor-pointer">
                                                                        <summary className="text-sm font-medium text-gray-700 hover:text-gray-900">
                                                                            <Info className="w-4 h-4 inline mr-1" />
                                                                            Compatibility Analysis - {compatInfo.matchCount} Matches Found
                                                                        </summary>
                                                                        <div className="mt-2 p-3 bg-gray-50 rounded text-xs space-y-2">
                                                                            {compatInfo.positiveReasons.length > 0 && (
                                                                                <div>
                                                                                    <div className="font-semibold text-green-700 mb-1">✅ Compatible Aspects:</div>
                                                                                    {compatInfo.positiveReasons.map((reason, i) => (
                                                                                        <div key={i} className="text-green-700 ml-2">{reason}</div>
                                                                                    ))}
                                                                                </div>
                                                                            )}
                                                                            {compatInfo.warnings.length > 0 && (
                                                                                <div>
                                                                                    <div className="font-semibold text-orange-700 mb-1">⚠️ Consider These Factors:</div>
                                                                                    {compatInfo.warnings.map((warning, i) => (
                                                                                        <div key={i} className="text-orange-600 ml-2">{warning}</div>
                                                                                    ))}
                                                                                </div>
                                                                            )}
                                                                            {compatInfo.positiveReasons.length === 0 && compatInfo.warnings.length === 0 && (
                                                                                <div className="text-gray-600">
                                                                                    Same brand detected - manual evaluation needed for part compatibility
                                                                                </div>
                                                                            )}
                                                                        </div>
                                                                    </details>
                                                                </div>
                                                            </CardContent>
                                                        </Card>
                                                    );
                                                })}
                                            </div>
                                        )}
                                    </CardContent>
                                </Card>
                            </TabsContent>
                        </Tabs>
                    </div>
                </div>

                {/* Help Section */}
                <Alert className="mt-6">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertDescription>
                        <strong>Enhanced Search:</strong> This tool now searches both inventory stock and case history. 
                        Results show specific compatibility criteria that match, helping you identify which parts (PCB, heads, preamp) 
                        might be safely extractable from previous cases. Always verify case status and customer approval before extracting parts.
                    </AlertDescription>
                </Alert>
            </div>
        </div>
    );
}
