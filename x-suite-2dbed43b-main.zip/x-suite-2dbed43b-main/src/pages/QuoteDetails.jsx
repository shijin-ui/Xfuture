
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { Quote } from '@/api/entities';
import { Case } from '@/api/entities';
import { Customer } from '@/api/entities';
import { Company } from '@/api/entities';
import { Setting } from '@/api/entities';
import { CompanyProfile } from '@/api/entities';
import { User } from '@/api/entities';
import { createPageUrl } from '@/utils';
import { getDefaultLocale, formatCurrency } from '@/components/utils/currencyFormatter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { format } from 'date-fns';
import { Save, Plus, Trash2, AlertCircle, ArrowLeft, FileText, User as UserIcon, Calculator, Settings, Building, Receipt, Calendar as CalendarIcon, Download, Loader2 } from 'lucide-react';
import SearchableSelect from '@/components/SearchableSelect';

export default function QuoteDetailsPage() {
    const location = useLocation();
    const navigate = useNavigate();
    const { id } = useParams();
    const searchParams = new URLSearchParams(location.search);
    const quoteId = id || searchParams.get('id');
    const caseIdFromUrl = searchParams.get('caseId');

    const [selectedCaseId, setSelectedCaseId] = useState(caseIdFromUrl || '');
    const [selectedCase, setSelectedCase] = useState(null);
    const [selectedCustomer, setSelectedCustomer] = useState(null);
    const [selectedCompany, setSelectedCompany] = useState(null);
    const [formMode, setFormMode] = useState('new'); // 'new' or 'edit'

    const [quote, setQuote] = useState({
        case_id: caseIdFromUrl || '',
        customer_id: '',
        quote_number: '',
        status: 'Draft',
        line_items: [{ description: '', unit: 'Each', quantity: 1, unit_price: 0, amount: 0 }],
        quote_terms: [],
        discount_type: 'percentage',
        discount_value: 0,
        discount_amount: 0,
        subtotal: 0,
        dealer_discount_percentage: 0,
        dealer_discount_amount: 0,
        include_vat: true,
        vat_rate: 0.05,
        vat_amount: 0,
        total_amount: 0,
        sent_date: null,
        issued_date: format(new Date(), 'yyyy-MM-dd'), // New field as per outline
        expiry_date: format(new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd'), // Default to 30 days from now
        bank_account_selected: 'bank_account_1'
    });
    
    const [companyProfile, setCompanyProfile] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const [hasError, setHasError] = useState(false);
    const [errorMessage, setErrorMessage] = useState('');
    const [dataWarning, setDataWarning] = useState(null);
    const [includeVAT, setIncludeVAT] = useState(true);
    const [localeSettings, setLocaleSettings] = useState(null); // Renamed from locale
    const [allCases, setAllCases] = useState([]);
    const [customers, setCustomers] = useState({});
    const [quoteLineItemOptions, setQuoteLineItemOptions] = useState([]);
    const [quoteTermsOptions, setQuoteTermsOptions] = useState([]);
    const [quoteNumberSequence, setQuoteNumberSequence] = useState(null);

    // Load default locale on component mount
    useEffect(() => {
        const loadDefaultLocale = async () => {
            try {
                const defaultLocale = await getDefaultLocale();
                setLocaleSettings(defaultLocale);
            } catch (error) {
                console.error('Failed to load default locale:', error);
                // Use fallback locale
                setLocaleSettings({
                    country_name: 'Oman',
                    currency_code: 'OMR',
                    currency_symbol: 'OMR',
                    decimal_places: 3,
                    decimal_separator: '.',
                    thousand_separator: ',',
                    currency_position: 'after',
                    tax_name: 'VAT',
                    tax_rate: 0.05
                });
            }
        };
        loadDefaultLocale();
    }, []);

    const calculateTotals = useCallback(() => {
        const lineItemsTotal = quote.line_items.reduce((sum, item) => {
            const itemAmount = (item.quantity || 0) * (item.unit_price || 0);
            return sum + itemAmount;
        }, 0);

        const discountAmount = quote.discount_type === 'percentage' 
            ? (lineItemsTotal * (quote.discount_value || 0)) / 100
            : (quote.discount_value || 0);

        const dealerDiscountAmount = (lineItemsTotal * (quote.dealer_discount_percentage || 0)) / 100;
        const totalDiscountAmount = discountAmount + dealerDiscountAmount;
        
        const subtotalAfterDiscount = lineItemsTotal - totalDiscountAmount;
        const vatAmount = includeVAT ? (subtotalAfterDiscount * (localeSettings?.tax_rate || 0.05)) : 0;
        const total = subtotalAfterDiscount + vatAmount;

        setQuote(prev => ({
            ...prev,
            subtotal: lineItemsTotal,
            discount_amount: discountAmount,
            dealer_discount_amount: dealerDiscountAmount,
            vat_amount: vatAmount,
            total_amount: total
        }));
    }, [quote.line_items, quote.discount_type, quote.discount_value, quote.dealer_discount_percentage, includeVAT, localeSettings]);

    // Recalculate totals when relevant fields change
    useEffect(() => {
        if (localeSettings) {
            calculateTotals();
        }
    }, [calculateTotals, localeSettings]);

    // Load initial quote/case/customer data once locale is available
    useEffect(() => {
        const loadInitialData = async () => {
            if (!localeSettings) return;

            setIsLoading(true);
            setHasError(false);
            setErrorMessage('');
            setDataWarning(null);

            try {
                // Fetch all required data with comprehensive error handling
                const [casesResult, lineItemsResult, numberSequenceResult, termsResult, companyResult] = await Promise.allSettled([
                    Case.list().catch(err => {
                        console.warn('Failed to fetch cases:', err);
                        return [];
                    }),
                    Setting.filter({ category: 'Quote Line Items' }).catch(err => {
                        console.warn('Failed to fetch line items:', err);
                        return [];
                    }),
                    Setting.filter({ category: 'Number Sequences', value: 'Quote Number' }).catch(err => {
                        console.warn('Failed to fetch quote number sequence:', err);
                        return [];
                    }),
                    Setting.filter({ category: 'Quote Terms' }).catch(err => {
                        console.warn('Failed to fetch quote terms:', err);
                        return [];
                    }),
                    CompanyProfile.list().catch(err => {
                        console.warn('Failed to fetch company profile:', err);
                        return [];
                    })
                ]);

                const casesData = casesResult.status === 'fulfilled' ? casesResult.value : [];
                const lineItemsData = lineItemsResult.status === 'fulfilled' ? lineItemsResult.value : [];
                const sequenceData = numberSequenceResult.status === 'fulfilled' ? numberSequenceResult.value : [];
                const termsData = termsResult.status === 'fulfilled' ? termsResult.value : [];
                const companyProfileData = companyResult.status === 'fulfilled' ? companyResult.value : [];

                setAllCases(casesData);
                setQuoteLineItemOptions(lineItemsData);
                setQuoteTermsOptions(termsData);
                setQuoteNumberSequence(sequenceData.length > 0 ? sequenceData[0] : null);
                setCompanyProfile(companyProfileData.length > 0 ? companyProfileData[0] : null);

                // Fetch customers associated with cases
                const customerIdsFromCases = [...new Set(casesData.map(c => c.customer_id).filter(Boolean))];
                if (customerIdsFromCases.length > 0) {
                    try {
                        const customersArray = await Customer.filter({id: {$in: customerIdsFromCases}});
                        const customersMap = customersArray.reduce((acc, curr) => {
                            if (curr) acc[curr.id] = curr;
                            return acc;
                        }, {});
                        setCustomers(customersMap);
                    } catch (error) {
                        console.warn('Failed to fetch customers:', error);
                        setCustomers({});
                    }
                }

                if (quoteId) {
                    // Editing existing quote
                    setFormMode('edit');
                    try {
                        const existingQuote = await Quote.get(quoteId);
                        
                        // Robustly fetch case by ID or case_number
                        let caseInfo = null;
                        if (existingQuote.case_id) {
                            const caseRef = existingQuote.case_id;
                            if (caseRef && /^\d+$/.test(caseRef)) {
                                console.warn(`Case reference "${caseRef}" looks like a case_number. Attempting filter.`);
                                const cases = await Case.filter({ case_number: caseRef });
                                if (cases && cases.length > 0) caseInfo = cases[0];
                            } else if (caseRef) {
                                try { caseInfo = await Case.get(caseRef); } catch (e) { console.error(`Could not get case by ID ${caseRef}`, e); }
                            }
                        }

                        // Robustly fetch customer by ID or customer_code
                        let customerInfo = null;
                        let companyInfo = null;
                        if (existingQuote.customer_id) {
                            const customerRef = existingQuote.customer_id;
                            try {
                                // Check if this looks like a customer code (starts with letters or contains dashes)
                                if (customerRef && (customerRef.startsWith('CUST-') || customerRef.length < 20 || /^[A-Z]/.test(customerRef))) {
                                    console.warn(`Customer reference "${customerRef}" looks like a customer_code. Using filter.`);
                                    const customers = await Customer.filter({ customer_code: customerRef });
                                    if (customers && customers.length > 0) {
                                        customerInfo = customers[0];
                                    } else {
                                        // Also try by ID in case it's actually an ID that just looks like a code
                                        try {
                                            customerInfo = await Customer.get(customerRef);
                                        } catch (getError) {
                                            console.error(`Could not find customer by code or ID: ${customerRef}`, getError);
                                        }
                                    }
                                } else if (customerRef) {
                                    // Looks like a real ObjectId, use get()
                                    customerInfo = await Customer.get(customerRef);
                                }
                            } catch (customerError) {
                                console.error(`Could not get customer by ID ${customerRef}:`, customerError);
                                customerInfo = null;
                            }
                        }

                        // Set data warnings if case or customer are not found
                        if (!caseInfo && existingQuote.case_id) {
                            setDataWarning(prev => ({
                                type: 'case',
                                message: `The case associated with this quote (Ref: ${existingQuote.case_id}) could not be found.`,
                                action: 'You must select a new case to save the quote.'
                            }));
                        }
                        if (!customerInfo && existingQuote.customer_id) {
                            setDataWarning(prev => ({ 
                                type: prev?.type || 'customer',
                                message: (prev?.message ? prev.message + '\n\n' : '') + `The customer (Ref: ${existingQuote.customer_id}) could not be found. This quote has an orphaned customer reference.`,
                                action: (prev?.action ? prev.action + ' ' : '') + 'Customer information will not be available. Please select a new case to fix this.'
                            }));
                        }

                        // Try to fetch company info only if customer exists
                        if (customerInfo && customerInfo.company_name) {
                            try {
                                const companies = await Company.filter({ company_name: customerInfo.company_name });
                                companyInfo = companies[0] || null;
                            } catch (companyError) {
                                console.warn('Failed to fetch company:', companyError);
                                companyInfo = null;
                            }
                        }

                        // Set state variables with found data
                        setSelectedCase(caseInfo);
                        setSelectedCustomer(customerInfo);
                        setSelectedCompany(companyInfo);
                        setSelectedCaseId(caseInfo?.id || ''); // Update selectedCaseId for the SearchableSelect

                        // Set quote data with safe fallbacks and ensure line_items is an array
                        setQuote({
                            ...existingQuote,
                            case_id: caseInfo?.id || '', // Clear if case not found
                            customer_id: customerInfo?.id || '', // Clear if customer not found
                            line_items: existingQuote.line_items || [], // Ensure line_items is an array
                        });
                        setIncludeVAT(existingQuote.include_vat !== false);

                    } catch (quoteError) {
                        console.error('Failed to load existing quote:', quoteError);
                        setHasError(true);
                        setErrorMessage(`Failed to load quote data: ${quoteError.message || 'Unknown error'}. The quote may have been deleted or you may not have access to it.`);
                    }
                } else if (caseIdFromUrl) {
                    // Creating new quote from case
                    setFormMode('new');
                    try {
                        let caseInfo = null;
                        const caseRef = caseIdFromUrl;
                        if (caseRef && /^\d+$/.test(caseRef)) {
                             const cases = await Case.filter({ case_number: caseRef });
                             if (cases.length > 0) caseInfo = cases[0];
                        } else if (caseRef) {
                             try { caseInfo = await Case.get(caseRef); } catch(e) { console.error(`Could not get case by ID ${caseRef}`, e); }
                        }

                        if (caseInfo) {
                            let customerInfo = null;
                            const customerRef = caseInfo.customer_id;
                            if (customerRef) {
                                try {
                                    // Same logic for customer fetching in new quote creation
                                    if (customerRef && (customerRef.startsWith('CUST-') || customerRef.length < 20 || /^[A-Z]/.test(customerRef))) {
                                        console.warn(`Customer reference "${customerRef}" looks like a customer_code. Using filter.`);
                                        const customers = await Customer.filter({ customer_code: customerRef });
                                        if (customers && customers.length > 0) {
                                            customerInfo = customers[0];
                                        } else {
                                            try {
                                                customerInfo = await Customer.get(customerRef);
                                            } catch (getError) {
                                                console.error(`Could not find customer by code or ID: ${customerRef}`, getError);
                                            }
                                        }
                                    } else {
                                        customerInfo = await Customer.get(customerRef);
                                    }
                                } catch(customerError) {
                                    console.error(`Could not get customer by ID ${customerRef}:`, customerError);
                                    // Set a warning about orphaned customer reference
                                    setDataWarning({
                                        type: 'customer',
                                        message: `The case you selected has a customer reference (${customerRef}) that no longer exists.`,
                                        action: 'Customer information is not available for this case.'
                                    });
                                }
                            }
                            
                            let companyInfo = null;
                            if (customerInfo && customerInfo.company_name) {
                                try {
                                    const companies = await Company.filter({ company_name: customerInfo.company_name });
                                    companyInfo = companies[0] || null;
                                } catch (companyError) {
                                    console.warn('Failed to fetch company:', companyError);
                                    companyInfo = null;
                                }
                            }

                            setSelectedCase(caseInfo);
                            setSelectedCustomer(customerInfo);
                            setSelectedCompany(companyInfo);
                            setSelectedCaseId(caseInfo.id); // Set selectedCaseId for the SearchableSelect
                            
                            // Pre-fill from case
                            const newQuoteNumber = await generateQuoteNumber();
                            setQuote(prev => ({
                                ...prev,
                                case_id: caseInfo.id,
                                customer_id: customerInfo?.id || '',
                                quote_number: newQuoteNumber,
                                issued_date: format(new Date(), 'yyyy-MM-dd'),
                                expiry_date: format(new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd'),
                                dealer_discount_percentage: customerInfo?.dealer_discount_percentage || 0,
                                include_vat: true,
                                vat_rate: localeSettings?.tax_rate || 0.05
                            }));
                            setIncludeVAT(true);

                        } else { // Case not found, but caseIdFromUrl was provided
                             console.error('Failed to load case for new quote: Case not found');
                             setHasError(true);
                             setErrorMessage(`The case you're trying to create a quote for no longer exists (Case ID: ${caseIdFromUrl}). It may have been deleted. Please go back to the Cases page and select a different case.`);
                        }

                    } catch (caseError) {
                        console.error('Failed to load case for new quote:', caseError);
                        setHasError(true);
                        setErrorMessage(`Failed to load case details for new quote: ${caseError.message || 'Unknown error'}. Please go back to the Cases page and select a different case.`);
                    }
                } else {
                    // Creating a completely new quote
                    setFormMode('new');
                    try {
                        const newQuoteNumber = await generateQuoteNumber();
                        setQuote(prev => ({
                            ...prev,
                            quote_number: newQuoteNumber,
                            issued_date: format(new Date(), 'yyyy-MM-dd'),
                            expiry_date: format(new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd'),
                            include_vat: true,
                            vat_rate: localeSettings?.tax_rate || 0.05
                        }));
                        setIncludeVAT(true);
                    } catch (error) {
                        console.error('Failed to generate quote number:', error);
                        setQuote(prev => ({
                            ...prev,
                            quote_number: `QUO-${Date.now()}`,
                            issued_date: format(new Date(), 'yyyy-MM-dd'),
                            expiry_date: format(new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd'),
                            include_vat: true,
                            vat_rate: localeSettings?.tax_rate || 0.05
                        }));
                        setIncludeVAT(true);
                    }
                }

            } catch (error) {
                console.error('Failed to fetch initial data:', error);
                setHasError(true);
                setErrorMessage(`Failed to load required data: ${error.message || 'Unknown error'}`);
            } finally {
                setIsLoading(false);
            }
        };

        loadInitialData();
    }, [quoteId, caseIdFromUrl, localeSettings]);

    const generateQuoteNumber = async () => {
        try {
            if (quoteNumberSequence) {
                const currentNumber = quoteNumberSequence.numeric_value || 1000;
                const newNumber = `QUO-${String(currentNumber).padStart(4, '0')}`;
                
                // Update the sequence
                await Setting.update(quoteNumberSequence.id, {
                    numeric_value: currentNumber + 1
                });
                
                return newNumber;
            } else {
                // Fallback: generate based on current date
                const date = new Date();
                const year = date.getFullYear();
                const month = String(date.getMonth() + 1).padStart(2, '0');
                const day = String(date.getDate()).padStart(2, '0');
                const random = Math.floor(Math.random() * 1000);
                return `QUO-${year}${month}${day}-${random}`;
            }
        } catch (error) {
            console.error('Failed to generate quote number:', error);
            return `QUO-${Date.now()}`;
        }
    };

    const handleLineItemChange = (index, field, value) => {
        const updatedItems = [...quote.line_items];
        updatedItems[index] = { ...updatedItems[index], [field]: value };

        // Calculate amount when quantity or unit_price changes
        if (field === 'quantity' || field === 'unit_price') {
            const quantity = parseFloat(updatedItems[index].quantity) || 0;
            const unitPrice = parseFloat(updatedItems[index].unit_price) || 0;
            updatedItems[index].amount = quantity * unitPrice;
        }

        setQuote(prev => ({ ...prev, line_items: updatedItems }));
    };

    const addLineItem = () => {
        setQuote(prev => ({
            ...prev,
            line_items: [...prev.line_items, { description: '', unit: 'Each', quantity: 1, unit_price: 0, amount: 0 }]
        }));
    };

    const removeLineItem = (index) => {
        if (quote.line_items.length > 1) {
            const updatedItems = quote.line_items.filter((_, i) => i !== index);
            setQuote(prev => ({ ...prev, line_items: updatedItems }));
        }
    };

    const handleCaseChange = async (caseId) => {
        setSelectedCaseId(caseId);
        if (caseId) {
            try {
                const selectedCaseData = allCases.find(c => c.id === caseId);
                if (selectedCaseData) {
                    setSelectedCase(selectedCaseData);
                    
                    // Load customer and company data
                    if (selectedCaseData.customer_id) {
                        try {
                            const customerRef = selectedCaseData.customer_id;
                            let customerData = null;

                            // FIX: Implement robust customer fetching logic here as well
                            if (customerRef && (customerRef.startsWith('CUST-') || customerRef.length < 20 || /^[A-Z]/.test(customerRef))) {
                                console.warn(`Customer reference "${customerRef}" looks like a customer_code. Using filter.`);
                                const customers = await Customer.filter({ customer_code: customerRef });
                                if (customers && customers.length > 0) {
                                    customerData = customers[0];
                                } else {
                                    try {
                                        customerData = await Customer.get(customerRef);
                                    } catch (getError) {
                                        console.error(`Could not find customer by code or ID: ${customerRef}`, getError);
                                    }
                                }
                            } else if (customerRef) {
                                customerData = await Customer.get(customerRef);
                            }
                            
                            setSelectedCustomer(customerData);
                            
                            if (customerData?.company_name) {
                                try {
                                    const companies = await Company.filter({ company_name: customerData.company_name });
                                    setSelectedCompany(companies.length > 0 ? companies[0] : null);
                                } catch (companyError) {
                                    console.warn('Failed to fetch company:', companyError);
                                    setSelectedCompany(null);
                                }
                            } else {
                                setSelectedCompany(null);
                            }
                            
                            setQuote(prev => ({
                                ...prev,
                                case_id: caseId,
                                customer_id: customerData?.id || selectedCaseData.customer_id, // Use the correct ID if found
                                dealer_discount_percentage: customerData?.dealer_discount_percentage || 0
                            }));
                        } catch (customerError) {
                            console.warn('Failed to fetch customer:', customerError);
                            setSelectedCustomer(null);
                            setSelectedCompany(null);
                            setQuote(prev => ({
                                ...prev,
                                case_id: caseId, // Still keep the case_id
                                customer_id: '', // Clear customer_id if not found
                                dealer_discount_percentage: 0 // Reset dealer discount
                            }));
                        }
                    } else {
                        // Case has no customer_id
                        setSelectedCustomer(null);
                        setSelectedCompany(null);
                        setQuote(prev => ({
                            ...prev,
                            case_id: caseId,
                            customer_id: '',
                            dealer_discount_percentage: 0
                        }));
                    }
                } else {
                     setSelectedCase(null);
                     setSelectedCustomer(null);
                     setSelectedCompany(null);
                     setQuote(prev => ({ ...prev, case_id: '', customer_id: '', dealer_discount_percentage: 0 }));
                }
            } catch (error) {
                console.error('Failed to load case details:', error);
                setSelectedCase(null);
                setSelectedCustomer(null);
                setSelectedCompany(null);
                setQuote(prev => ({ ...prev, case_id: '', customer_id: '', dealer_discount_percentage: 0 }));
            }
        } else {
            setSelectedCase(null);
            setSelectedCustomer(null);
            setSelectedCompany(null);
            setQuote(prev => ({ ...prev, case_id: '', customer_id: '', dealer_discount_percentage: 0 }));
        }
    };

    const handleTermSelect = (termValue) => {
        const currentTerms = [...quote.quote_terms];
        
        if (currentTerms.includes(termValue)) {
            // Remove term if already selected
            const updatedTerms = currentTerms.filter(term => term !== termValue);
            setQuote({ ...quote, quote_terms: updatedTerms });
        } else {
            // Add term if not selected
            const updatedTerms = [...currentTerms, termValue];
            setQuote({ ...quote, quote_terms: updatedTerms });
        }
    };

    const removeSelectedTerm = (termToRemove) => {
        const updatedTerms = quote.quote_terms.filter(term => term !== termToRemove);
        setQuote({ ...quote, quote_terms: updatedTerms });
    };

    const handleSave = async () => {
        if (!quote.quote_number.trim()) {
            alert('Quote number is required');
            return;
        }

        if (!selectedCaseId) {
            alert('Please select a case');
            return;
        }

        setIsSaving(true);
        try {
            const quoteData = {
                ...quote,
                case_id: selectedCaseId, // Ensure we use the selected case ID
                include_vat: includeVAT,
                vat_rate: includeVAT ? (localeSettings?.tax_rate || 0.05) : 0,
            };

            if (quoteId) {
                await Quote.update(quoteId, quoteData);
            } else {
                await Quote.create(quoteData);
            }

            navigate(createPageUrl('Quotes'));
        } catch (error) {
            console.error('Failed to save quote:', error);
            alert(`Failed to save quote: ${error.message}`);
        } finally {
            setIsSaving(false);
        }
    };

    const lineItemOptions = useMemo(() => {
        if (!localeSettings) return [];
        return quoteLineItemOptions.map(setting => ({
            value: setting.value, // Changed from setting.id to setting.value as per common use for select/typeable settings
            label: setting.value,
            subtitle: `Default Price: ${formatCurrency(setting.default_amount, localeSettings)}`
        }));
    }, [quoteLineItemOptions, localeSettings]);

    const bankAccountOptions = useMemo(() => {
        if (!companyProfile) return [];
        const options = [];
        
        if (companyProfile.bank_account_1_name) {
            options.push({
                value: 'bank_account_1',
                label: companyProfile.bank_account_1_name,
                subtitle: companyProfile.bank_account_1_number || ''
            });
        }
        
        if (companyProfile.bank_account_2_name) {
            options.push({
                value: 'bank_account_2',
                label: companyProfile.bank_account_2_name,
                subtitle: companyProfile.bank_account_2_number || ''
            });
        }
        
        return options;
    }, [companyProfile]);

    if (isLoading) {
        return (
            <div className="flex h-screen items-center justify-center">
                <div className="text-center">
                    <div className="flex items-center justify-center space-x-2 mb-4">
                        <div className="w-8 h-8 bg-blue-500 rounded-full animate-pulse"></div>
                        <div className="w-8 h-8 bg-indigo-500 rounded-full animate-pulse delay-150"></div>
                        <div className="w-8 h-8 bg-purple-500 rounded-full animate-pulse delay-300"></div>
                    </div>
                    <p className="text-gray-600">Loading quote details...</p>
                </div>
            </div>
        );
    }

    if (hasError) {
        return (
            <div className="p-8 text-center">
                <div className="max-w-md mx-auto bg-white rounded-lg shadow-lg p-6 border border-red-200">
                    <AlertCircle className="w-12 h-12 mx-auto mb-4 text-red-500" />
                    <h1 className="text-2xl font-bold mb-2 text-red-600">Unable to Load Quote</h1>
                    <p className="mb-6 text-gray-700">{errorMessage}</p>
                    <div className="space-y-3">
                        <Button onClick={() => navigate(createPageUrl('Quotes'))} className="w-full">
                            <ArrowLeft className="w-4 h-4 mr-2" />
                            Back to Quotes
                        </Button>
                        <Button variant="outline" onClick={() => navigate(createPageUrl('Cases'))} className="w-full">
                            View Cases Instead
                        </Button>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="p-4 md:p-8 bg-gradient-to-br from-slate-50 to-indigo-100 min-h-screen">
            <div className="max-w-6xl mx-auto">
                <div className="flex justify-between items-center mb-6">
                    <h1 className="text-3xl font-bold text-gray-800">
                        {quoteId ? 'Edit Quote' : 'Create Quote'}
                    </h1>
                    <div className="flex items-center space-x-2">
                        {quoteId && (
                             <Button variant="outline" onClick={() => window.open(createPageUrl(`PrintQuote?id=${quoteId}`), '_blank')}>
                                <Download className="w-4 h-4 mr-2"/> Download
                            </Button>
                        )}
                        {quoteId && (
                            <Button variant="outline" onClick={() => window.open(createPageUrl(`PrintQuote?id=${quoteId}`), '_blank')}>
                                <FileText className="w-4 h-4 mr-2"/> Print
                            </Button>
                        )}
                        <Button onClick={handleSave} disabled={isLoading || isSaving}>
                            {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : <Save className="w-4 h-4 mr-2"/>}
                            {quoteId ? 'Save Changes' : 'Create Quote'}
                        </Button>
                    </div>
                </div>

                {/* Data Warning */}
                {dataWarning && (
                    <div className="mb-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg shadow-sm">
                        <div className="flex items-start">
                            <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5 mr-3" />
                            <div>
                                <h3 className="font-semibold text-yellow-800 mb-1">Data Warning</h3>
                                <p className="text-yellow-700 text-sm mb-2">{dataWarning.message}</p>
                                <p className="text-yellow-600 text-sm">{dataWarning.action}</p>
                            </div>
                        </div>
                    </div>
                )}

                {/* Modern Tabbed Interface */}
                <Tabs defaultValue="basic" className="space-y-6">
                    <TabsList className="grid w-full grid-cols-4 bg-white/80 backdrop-blur-sm shadow-sm rounded-xl p-1">
                        <TabsTrigger value="basic" className="flex items-center gap-2 data-[state=active]:bg-blue-500 data-[state=active]:text-white">
                            <FileText className="w-4 h-4" />
                            Basic Info
                        </TabsTrigger>
                        <TabsTrigger value="items" className="flex items-center gap-2 data-[state=active]:bg-blue-500 data-[state=active]:text-white">
                            <Calculator className="w-4 h-4" />
                            Line Items
                        </TabsTrigger>
                        <TabsTrigger value="terms" className="flex items-center gap-2 data-[state=active]:bg-blue-500 data-[state=active]:text-white">
                            <Settings className="w-4 h-4" />
                            Terms & Settings
                        </TabsTrigger>
                        <TabsTrigger value="summary" className="flex items-center gap-2 data-[state=active]:bg-blue-500 data-[state=active]:text-white">
                            <Receipt className="w-4 h-4" />
                            Summary
                        </TabsTrigger>
                    </TabsList>

                    {/* Basic Information Tab */}
                    <TabsContent value="basic">
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            {/* Quote Details */}
                            <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0">
                                <CardHeader className="bg-gradient-to-r from-blue-100 to-indigo-100">
                                    <CardTitle className="text-blue-800 flex items-center">
                                        <FileText className="w-5 h-5 mr-2" />
                                        Quote Information
                                    </CardTitle>
                                </CardHeader>
                                <CardContent className="space-y-4 p-6">
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div>
                                            <Label htmlFor="quote_number">Quote Number *</Label>
                                            <Input
                                                id="quote_number"
                                                value={quote.quote_number}
                                                onChange={(e) => setQuote(prev => ({ ...prev, quote_number: e.target.value }))}
                                                placeholder="QUO-0001"
                                                className="bg-white"
                                            />
                                        </div>
                                        <div>
                                            <Label htmlFor="status">Status</Label>
                                            <Select value={quote.status} onValueChange={(value) => setQuote(prev => ({ ...prev, status: value }))}>
                                                <SelectTrigger className="bg-white">
                                                    <SelectValue />
                                                </SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="Draft">Draft</SelectItem>
                                                    <SelectItem value="Sent">Sent</SelectItem>
                                                    <SelectItem value="Accepted">Accepted</SelectItem>
                                                    <SelectItem value="Rejected">Rejected</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>
                                    </div>

                                    <div>
                                        <Label htmlFor="case_select">Associated Case *</Label>
                                        <SearchableSelect
                                            value={selectedCaseId}
                                            onValueChange={handleCaseChange}
                                            placeholder="Select a case..."
                                            options={allCases.map(caseItem => ({
                                                value: caseItem.id,
                                                label: `${caseItem.case_number} - ${caseItem.service_type}`,
                                                subtitle: customers[caseItem.customer_id]?.full_name || 'Unknown Customer'
                                            }))}
                                            searchPlaceholder="Search cases..."
                                        />
                                    </div>
                                </CardContent>
                            </Card>

                            {/* Customer Information */}
                            {selectedCustomer && (
                                <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0">
                                    <CardHeader className="bg-gradient-to-r from-green-100 to-emerald-100">
                                        <CardTitle className="text-green-800 flex items-center">
                                            <UserIcon className="w-5 h-5 mr-2" />
                                            Customer Information
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-3 p-6 text-sm">
                                        <div>
                                            <strong>Name:</strong> {selectedCustomer.full_name}
                                        </div>
                                        <div>
                                            <strong>Email:</strong> {selectedCustomer.email}
                                        </div>
                                        <div>
                                            <strong>Phone:</strong> {selectedCustomer.phone_number}
                                        </div>
                                        {selectedCustomer.company_name && (
                                            <div>
                                                <strong>Company:</strong> {selectedCustomer.company_name}
                                            </div>
                                        )}
                                        <div>
                                            <strong>Group:</strong> 
                                            <Badge variant="secondary" className="ml-2">
                                                {selectedCustomer.customer_group}
                                            </Badge>
                                        </div>
                                        {selectedCompany?.vat_number && (
                                            <div>
                                                <strong>{localeSettings?.tax_number_label || 'VAT Number'}:</strong> {selectedCompany.vat_number}
                                            </div>
                                        )}
                                    </CardContent>
                                </Card>
                            )}

                            {/* Case Information */}
                            {selectedCase && (
                                <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0">
                                    <CardHeader className="bg-gradient-to-r from-purple-100 to-pink-100">
                                        <CardTitle className="text-purple-800 flex items-center">
                                            <Building className="w-5 h-5 mr-2" />
                                            Case Information
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent className="space-y-2 p-6 text-sm">
                                        <div>
                                            <strong>Case #:</strong> {selectedCase.case_number}
                                        </div>
                                        <div>
                                            <strong>Service:</strong> {selectedCase.service_type}
                                        </div>
                                        <div>
                                            <strong>Status:</strong> 
                                            <Badge variant="secondary" className="ml-2">
                                                {selectedCase.status}
                                            </Badge>
                                        </div>
                                        {selectedCase.client_reference && (
                                            <div>
                                                <strong>Client Ref:</strong> {selectedCase.client_reference}
                                            </div>
                                        )}
                                    </CardContent>
                                </Card>
                            )}
                        </div>
                    </TabsContent>

                    {/* Line Items Tab */}
                    <TabsContent value="items">
                        <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0">
                            <CardHeader className="bg-gradient-to-r from-green-100 to-emerald-100">
                                <CardTitle className="flex items-center justify-between text-green-800">
                                    <div className="flex items-center">
                                        <Calculator className="w-5 h-5 mr-2" />
                                        Quote Items
                                    </div>
                                    <Button onClick={addLineItem} size="sm" className="bg-green-600 hover:bg-green-700">
                                        <Plus className="w-4 h-4 mr-2" />
                                        Add Item
                                    </Button>
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="p-6">
                                <div className="space-y-4">
                                    {/* Header Row */}
                                    <div className="grid grid-cols-12 gap-3 text-sm font-medium text-gray-600 pb-2 border-b">
                                        <div className="col-span-4">Description</div>
                                        <div className="col-span-2">Unit</div>
                                        <div className="col-span-1 text-center">Qty</div>
                                        <div className="col-span-2 text-right">Unit Price ({localeSettings?.currency_symbol || 'OMR'})</div>
                                        <div className="col-span-2 text-right">Amount</div>
                                        <div className="col-span-1 text-center">Actions</div>
                                    </div>

                                    {quote.line_items.map((item, index) => (
                                        <div key={index} className="grid grid-cols-12 gap-3 items-center p-4 bg-gray-50 rounded-lg">
                                            <div className="col-span-4">
                                                <SearchableSelect
                                                    value={item.description}
                                                    onValueChange={(value) => {
                                                        const selectedOption = quoteLineItemOptions.find(opt => opt.value === value);
                                                        if (selectedOption && selectedOption.default_amount !== undefined) { // Check for undefined
                                                            handleLineItemChange(index, 'unit_price', selectedOption.default_amount);
                                                        }
                                                        handleLineItemChange(index, 'description', value);
                                                    }}
                                                    options={lineItemOptions}
                                                    placeholder="Select or type description..."
                                                />
                                            </div>
                                            <div className="col-span-2">
                                                <Input
                                                    value={item.unit}
                                                    onChange={(e) => handleLineItemChange(index, 'unit', e.target.value)}
                                                    placeholder="Each"
                                                    className="bg-white"
                                                />
                                            </div>
                                            <div className="col-span-1">
                                                <Input
                                                    type="number"
                                                    value={item.quantity}
                                                    onChange={(e) => handleLineItemChange(index, 'quantity', e.target.value)}
                                                    min="1"
                                                    className="bg-white text-center"
                                                />
                                            </div>
                                            <div className="col-span-2">
                                                <Input
                                                    type="number"
                                                    value={item.unit_price}
                                                    onChange={(e) => handleLineItemChange(index, 'unit_price', e.target.value)}
                                                    step="0.001"
                                                    className="bg-white text-right"
                                                />
                                            </div>
                                            <div className="col-span-2 text-right">
                                                <div className="h-10 flex items-center justify-end text-sm font-medium">
                                                    {formatCurrency(item.amount, localeSettings)}
                                                </div>
                                            </div>
                                            <div className="col-span-1 text-center">
                                                <Button
                                                    variant="ghost"
                                                    size="icon"
                                                    onClick={() => removeLineItem(index)}
                                                    disabled={quote.line_items.length === 1}
                                                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                                >
                                                    <Trash2 className="w-4 h-4" />
                                                </Button>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    {/* Terms & Settings Tab */}
                    <TabsContent value="terms">
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            {/* Terms & Conditions */}
                            <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0">
                                <CardHeader className="bg-gradient-to-r from-amber-100 to-orange-100">
                                    <CardTitle className="text-amber-800 flex items-center">
                                        <Settings className="w-5 h-5 mr-2" />
                                        Terms & Conditions
                                    </CardTitle>
                                </CardHeader>
                                <CardContent className="p-6 space-y-4">
                                    {quote.quote_terms.length > 0 && (
                                        <div>
                                            <Label className="text-sm font-medium text-gray-700 mb-2 block">Selected Terms:</Label>
                                            <div className="flex flex-wrap gap-2 mb-4">
                                                {quote.quote_terms.map((term, index) => (
                                                    <Badge key={index} variant="secondary" className="flex items-center gap-1">
                                                        {term}
                                                        <button
                                                            type="button"
                                                            onClick={() => removeSelectedTerm(term)}
                                                            className="ml-1 text-gray-500 hover:text-red-600 focus:outline-none"
                                                        >
                                                            ×
                                                        </button>
                                                    </Badge>
                                                ))}
                                            </div>
                                        </div>
                                    )}
                                    
                                    <div>
                                        <Label>Add Terms & Conditions</Label>
                                        <SearchableSelect
                                            placeholder="Add terms & conditions..."
                                            searchPlaceholder="Search terms..."
                                            options={quoteTermsOptions.map(term => ({
                                                value: term.value,
                                                label: term.value
                                            }))}
                                            onValueChange={handleTermSelect}
                                            value={null}
                                        />
                                    </div>
                                </CardContent>
                            </Card>

                            {/* Bank Details & Discounts */}
                            <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0">
                                <CardHeader className="bg-gradient-to-r from-indigo-100 to-purple-100">
                                    <CardTitle className="text-indigo-800 flex items-center">
                                        <Building className="w-5 h-5 mr-2" />
                                        Bank & Discount Settings
                                    </CardTitle>
                                </CardHeader>
                                <CardContent className="p-6 space-y-4">
                                    {/* Bank Account Selection */}
                                    <div>
                                        <Label>Bank Account</Label>
                                        <SearchableSelect
                                            value={quote.bank_account_selected}
                                            onValueChange={(value) => setQuote(prev => ({ ...prev, bank_account_selected: value }))}
                                            placeholder="Select bank account..."
                                            options={bankAccountOptions}
                                        />
                                    </div>

                                    <Separator />

                                    {/* Discount Settings */}
                                    <div className="space-y-4">
                                        <h4 className="font-medium text-gray-800">Discount Settings</h4>
                                        
                                        <div className="grid grid-cols-2 gap-4">
                                            <div>
                                                <Label>Discount Type</Label>
                                                <Select 
                                                    value={quote.discount_type} 
                                                    onValueChange={(value) => setQuote(prev => ({ ...prev, discount_type: value, discount_value: 0 }))}
                                                >
                                                    <SelectTrigger className="bg-white">
                                                        <SelectValue />
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="percentage">Percentage (%)</SelectItem>
                                                        <SelectItem value="fixed">Fixed Amount ({localeSettings?.currency_symbol || 'OMR'})</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                            <div>
                                                <Label>Discount Value</Label>
                                                <Input
                                                    type="number"
                                                    value={quote.discount_value}
                                                    onChange={(e) => setQuote(prev => ({ ...prev, discount_value: parseFloat(e.target.value) || 0 }))}
                                                    step={quote.discount_type === 'percentage' ? '1' : '0.001'}
                                                    min="0"
                                                    max={quote.discount_type === 'percentage' ? '100' : undefined}
                                                    className="bg-white"
                                                />
                                            </div>
                                        </div>

                                        {selectedCustomer?.dealer_discount_percentage > 0 && (
                                            <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                                                <p className="text-sm text-blue-700">
                                                    <strong>Dealer Discount Applied:</strong> {selectedCustomer.dealer_discount_percentage}%
                                                </p>
                                            </div>
                                        )}
                                    </div>

                                    <Separator />

                                    {/* VAT Settings */}
                                    <div className="flex items-center space-x-2">
                                        <Checkbox
                                            id="include_vat"
                                            checked={includeVAT}
                                            onCheckedChange={setIncludeVAT}
                                        />
                                        <Label htmlFor="include_vat">
                                            Include {localeSettings?.tax_name || 'VAT'} ({((localeSettings?.tax_rate || 0.05) * 100).toFixed(0)}%)
                                        </Label>
                                    </div>
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>

                    {/* Summary Tab */}
                    <TabsContent value="summary">
                        <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0">
                            <CardHeader className="bg-gradient-to-r from-green-100 to-emerald-100">
                                <CardTitle className="text-green-800 flex items-center">
                                    <Receipt className="w-5 h-5 mr-2" />
                                    Quote Summary
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="p-6">
                                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                                    {/* Financial Summary */}
                                    <div className="space-y-4">
                                        <h3 className="text-lg font-semibold text-gray-800 mb-4">Financial Summary</h3>
                                        
                                        <div className="space-y-3 text-lg">
                                            <div className="flex justify-between py-2 border-b border-gray-100">
                                                <span className="text-gray-600">Subtotal:</span>
                                                <span className="font-medium">{formatCurrency(quote.subtotal, localeSettings)}</span>
                                            </div>
                                            
                                            {quote.discount_amount > 0 && (
                                                <div className="flex justify-between py-2 border-b border-gray-100 text-orange-600">
                                                    <span>Discount ({quote.discount_type === 'percentage' ? `${quote.discount_value}%` : 'Fixed'}):</span>
                                                    <span>-{formatCurrency(quote.discount_amount, localeSettings)}</span>
                                                </div>
                                            )}
                                            
                                            {quote.dealer_discount_amount > 0 && (
                                                <div className="flex justify-between py-2 border-b border-gray-100 text-blue-600">
                                                    <span>Dealer Discount ({quote.dealer_discount_percentage}%):</span>
                                                    <span>-{formatCurrency(quote.dealer_discount_amount, localeSettings)}</span>
                                                </div>
                                            )}
                                            
                                            {includeVAT && (
                                                <div className="flex justify-between py-2 border-b border-gray-100 text-green-600">
                                                    <span>{localeSettings?.tax_name || 'VAT'} ({((localeSettings?.tax_rate || 0.05) * 100).toFixed(0)}%):</span>
                                                    <span>+{formatCurrency(quote.vat_amount, localeSettings)}</span>
                                                </div>
                                            )}
                                            
                                            <div className="flex justify-between py-4 border-t-2 border-gray-200">
                                                <span className="text-xl font-bold text-gray-800">Total Amount:</span>
                                                <span className="text-xl font-bold text-green-600">{formatCurrency(quote.total_amount, localeSettings)}</span>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Quote Details */}
                                    <div className="space-y-4">
                                        <h3 className="text-lg font-semibold text-gray-800 mb-4">Quote Details</h3>
                                        
                                        <div className="space-y-3">
                                            <div>
                                                <Label className="text-sm font-medium text-gray-600">Quote Number</Label>
                                                <p className="text-lg font-semibold text-blue-600">{quote.quote_number}</p>
                                            </div>
                                            
                                            <div>
                                                <Label className="text-sm font-medium text-gray-600">Status</Label>
                                                <Badge className="ml-2">{quote.status}</Badge>
                                            </div>
                                            
                                            <div>
                                                <Label className="text-sm font-medium text-gray-600">Line Items</Label>
                                                <p className="text-gray-800">{quote.line_items.length} item(s)</p>
                                            </div>
                                            
                                            {quote.quote_terms.length > 0 && (
                                                <div>
                                                    <Label className="text-sm font-medium text-gray-600">Terms Applied</Label>
                                                    <p className="text-gray-800">{quote.quote_terms.length} term(s) selected</p>
                                                </div>
                                            )}
                                            
                                            {quote.bank_account_selected && bankAccountOptions.length > 0 && (
                                                <div>
                                                    <Label className="text-sm font-medium text-gray-600">Bank Account</Label>
                                                    <p className="text-gray-800">
                                                        {bankAccountOptions.find(opt => opt.value === quote.bank_account_selected)?.label || 'Not selected'}
                                                    </p>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>
                </Tabs>
            </div>
        </div>
    );
}
