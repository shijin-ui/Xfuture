import React, { useState, useEffect } from 'react';
import { Invoice } from '@/api/entities';
import { Expense } from '@/api/entities';
import { Quote } from '@/api/entities';
import { Case } from '@/api/entities';
import { Transaction } from '@/api/entities';
import { Customer } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
    TrendingUp, TrendingDown, DollarSign, FileText, Target, Users, 
    Calendar, BarChart3, PieChart, ArrowUpRight, ArrowDownRight,
    Activity, Briefcase, Calculator, Eye
} from 'lucide-react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, BarChart, Bar, PieChart as RechartsPieChart, Cell, Area, AreaChart, Pie } from 'recharts';
import { format, startOfMonth, endOfMonth, startOfYear, endOfYear, subMonths, isWithinInterval, parseISO } from 'date-fns';
import { getDefaultLocale, formatCurrency } from '@/components/utils/currencyFormatter';

const MetricCard = ({ title, value, change, changeType, icon: Icon, color, subtitle }) => (
    <Card className="shadow-lg hover:shadow-xl transition-all duration-300 border-0 overflow-hidden">
        <div className={`h-1 bg-gradient-to-r ${color}`}></div>
        <CardContent className="p-6">
            <div className="flex items-center justify-between">
                <div>
                    <p className="text-sm font-medium text-gray-500">{title}</p>
                    <p className="text-2xl font-bold text-gray-900">{value}</p>
                    {subtitle && <p className="text-xs text-gray-500 mt-1">{subtitle}</p>}
                    {change !== null && (
                        <div className={`flex items-center mt-2 text-xs ${changeType === 'positive' ? 'text-green-600' : changeType === 'negative' ? 'text-red-600' : 'text-gray-500'}`}>
                            {changeType === 'positive' ? <ArrowUpRight className="w-4 h-4 mr-1" /> : 
                             changeType === 'negative' ? <ArrowDownRight className="w-4 h-4 mr-1" /> : null}
                            <span>{change}% vs last period</span>
                        </div>
                    )}
                </div>
                <div className={`p-3 rounded-xl bg-gradient-to-br ${color} shadow-lg`}>
                    <Icon className="w-6 h-6 text-white" />
                </div>
            </div>
        </CardContent>
    </Card>
);

const ChartCard = ({ title, children, actions }) => (
    <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
        <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-semibold text-gray-800">{title}</CardTitle>
                {actions && <div className="flex space-x-2">{actions}</div>}
            </div>
        </CardHeader>
        <CardContent>{children}</CardContent>
    </Card>
);

export default function SalesDashboard() {
    const [invoices, setInvoices] = useState([]);
    const [expenses, setExpenses] = useState([]);
    const [quotes, setQuotes] = useState([]);
    const [cases, setCases] = useState([]);
    const [transactions, setTransactions] = useState([]);
    const [customers, setCustomers] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [dateRange, setDateRange] = useState('thisMonth');
    const [locale, setLocale] = useState(null);

    useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            try {
                const [
                    invoiceData, expenseData, quoteData, caseData, 
                    transactionData, customerData, localeData
                ] = await Promise.all([
                    Invoice.list('-created_date'),
                    Expense.list('-expense_date'),
                    Quote.list('-created_date'),
                    Case.list('-created_date'),
                    Transaction.list('-transaction_date'),
                    Customer.list('-created_date'),
                    getDefaultLocale()
                ]);

                setInvoices(invoiceData);
                setExpenses(expenseData);
                setQuotes(quoteData);
                setCases(caseData);
                setTransactions(transactionData);
                setCustomers(customerData);
                setLocale(localeData);
            } catch (error) {
                console.error('Failed to fetch dashboard data:', error);
            } finally {
                setIsLoading(false);
            }
        };

        fetchData();
    }, []);

    // Date range calculations
    const getDateRange = () => {
        const now = new Date();
        switch (dateRange) {
            case 'thisMonth':
                return { start: startOfMonth(now), end: endOfMonth(now) };
            case 'lastMonth':
                const lastMonth = subMonths(now, 1);
                return { start: startOfMonth(lastMonth), end: endOfMonth(lastMonth) };
            case 'thisYear':
                return { start: startOfYear(now), end: endOfYear(now) };
            default:
                return { start: startOfMonth(now), end: endOfMonth(now) };
        }
    };

    const { start: periodStart, end: periodEnd } = getDateRange();

    // Filter data by date range
    const filterByDate = (items, dateField) => {
        return items.filter(item => {
            const itemDate = item[dateField] ? parseISO(item[dateField]) : new Date(item.created_date);
            return isWithinInterval(itemDate, { start: periodStart, end: periodEnd });
        });
    };

    const periodInvoices = filterByDate(invoices, 'issued_date');
    const periodExpenses = filterByDate(expenses, 'expense_date');
    const periodQuotes = filterByDate(quotes, 'created_date');
    const periodCases = filterByDate(cases, 'created_date');
    const periodTransactions = filterByDate(transactions, 'transaction_date');

    // Calculate metrics
    const totalRevenue = periodInvoices.filter(inv => inv.status === 'Paid').reduce((sum, inv) => sum + (inv.total_amount || 0), 0);
    const totalExpenses = periodExpenses.reduce((sum, exp) => sum + (exp.amount || 0), 0);
    const netProfit = totalRevenue - totalExpenses;
    const profitMargin = totalRevenue > 0 ? ((netProfit / totalRevenue) * 100) : 0;

    const outstandingInvoices = periodInvoices.filter(inv => !['Paid', 'Draft'].includes(inv.status));
    const totalOutstanding = outstandingInvoices.reduce((sum, inv) => sum + (inv.balance_due || inv.total_amount || 0), 0);

    const acceptedQuotes = periodQuotes.filter(q => q.status === 'Accepted');
    const totalQuoteValue = acceptedQuotes.reduce((sum, q) => sum + (q.total_amount || 0), 0);
    const quoteConversionRate = periodQuotes.length > 0 ? ((acceptedQuotes.length / periodQuotes.length) * 100) : 0;

    // Monthly revenue trend (last 6 months)
    const monthlyRevenue = [];
    for (let i = 5; i >= 0; i--) {
        const month = subMonths(new Date(), i);
        const monthStart = startOfMonth(month);
        const monthEnd = endOfMonth(month);
        
        const monthInvoices = invoices.filter(inv => {
            const invDate = inv.issued_date ? parseISO(inv.issued_date) : new Date(inv.created_date);
            return isWithinInterval(invDate, { start: monthStart, end: monthEnd }) && inv.status === 'Paid';
        });
        
        const monthExpenses = expenses.filter(exp => {
            const expDate = parseISO(exp.expense_date);
            return isWithinInterval(expDate, { start: monthStart, end: monthEnd });
        });

        const revenue = monthInvoices.reduce((sum, inv) => sum + (inv.total_amount || 0), 0);
        const expense = monthExpenses.reduce((sum, exp) => sum + (exp.amount || 0), 0);

        monthlyRevenue.push({
            month: format(month, 'MMM yyyy'),
            revenue,
            expenses: expense,
            profit: revenue - expense
        });
    }

    // Service type breakdown
    const serviceBreakdown = periodCases.reduce((acc, case_) => {
        const service = case_.service_type || 'Other';
        acc[service] = (acc[service] || 0) + 1;
        return acc;
    }, {});

    const serviceChartData = Object.entries(serviceBreakdown).map(([service, count]) => ({
        name: service,
        value: count,
        percentage: ((count / (periodCases.length || 1)) * 100).toFixed(1)
    }));

    // Expense category breakdown
    const expenseBreakdown = periodExpenses.reduce((acc, expense) => {
        const category = expense.category || 'Other';
        acc[category] = (acc[category] || 0) + (expense.amount || 0);
        return acc;
    }, {});

    const expenseChartData = Object.entries(expenseBreakdown).map(([category, amount]) => ({
        name: category,
        value: amount,
        percentage: ((amount / (totalExpenses || 1)) * 100).toFixed(1)
    }));

    const COLORS = ['#3b82f6', '#06b6d4', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

    if (isLoading) {
        return (
            <div className="p-8">
                <div className="flex h-64 w-full items-center justify-center">
                    <div className="flex items-center space-x-2">
                        <div className="w-8 h-8 bg-blue-500 rounded-full animate-pulse"></div>
                        <div className="w-8 h-8 bg-indigo-500 rounded-full animate-pulse delay-150"></div>
                        <div className="w-8 h-8 bg-purple-500 rounded-full animate-pulse delay-300"></div>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="p-8 bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 min-h-screen">
            {/* Header */}
            <div className="flex justify-between items-center mb-8">
                <div className="flex items-center space-x-4">
                    <div className="p-3 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-xl shadow-lg">
                        <BarChart3 className="w-8 h-8 text-white" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                            Sales Dashboard
                        </h1>
                        <p className="text-gray-500 mt-1">Complete business overview and analytics</p>
                    </div>
                </div>
                <div className="flex items-center space-x-4">
                    <Select value={dateRange} onValueChange={setDateRange}>
                        <SelectTrigger className="w-40">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="thisMonth">This Month</SelectItem>
                            <SelectItem value="lastMonth">Last Month</SelectItem>
                            <SelectItem value="thisYear">This Year</SelectItem>
                        </SelectContent>
                    </Select>
                </div>
            </div>

            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <MetricCard
                    title="Total Revenue"
                    value={locale ? formatCurrency(totalRevenue, locale) : `$${totalRevenue.toLocaleString()}`}
                    change={null}
                    icon={DollarSign}
                    color="from-green-500 to-emerald-600"
                    subtitle={`${periodInvoices.filter(inv => inv.status === 'Paid').length} paid invoices`}
                />
                <MetricCard
                    title="Net Profit"
                    value={locale ? formatCurrency(netProfit, locale) : `$${netProfit.toLocaleString()}`}
                    change={profitMargin.toFixed(1)}
                    changeType={netProfit >= 0 ? 'positive' : 'negative'}
                    icon={TrendingUp}
                    color="from-blue-500 to-indigo-600"
                    subtitle={`${profitMargin.toFixed(1)}% profit margin`}
                />
                <MetricCard
                    title="Outstanding Amount"
                    value={locale ? formatCurrency(totalOutstanding, locale) : `$${totalOutstanding.toLocaleString()}`}
                    change={null}
                    icon={FileText}
                    color="from-orange-500 to-red-500"
                    subtitle={`${outstandingInvoices.length} unpaid invoices`}
                />
                <MetricCard
                    title="Quote Conversion"
                    value={`${quoteConversionRate.toFixed(1)}%`}
                    change={null}
                    icon={Target}
                    color="from-purple-500 to-pink-600"
                    subtitle={`${acceptedQuotes.length}/${periodQuotes.length} accepted`}
                />
            </div>

            {/* Charts Row 1 */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                <ChartCard title="Revenue vs Expenses Trend">
                    <ResponsiveContainer width="100%" height={300}>
                        <AreaChart data={monthlyRevenue}>
                            <defs>
                                <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                                </linearGradient>
                                <linearGradient id="colorExpenses" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3}/>
                                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                                </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                            <XAxis dataKey="month" stroke="#6b7280" fontSize={12} />
                            <YAxis stroke="#6b7280" fontSize={12} />
                            <Tooltip 
                                formatter={(value, name) => [
                                    locale ? formatCurrency(value, locale) : `$${value.toLocaleString()}`,
                                    name === 'revenue' ? 'Revenue' : name === 'expenses' ? 'Expenses' : 'Profit'
                                ]}
                            />
                            <Area type="monotone" dataKey="revenue" stroke="#3b82f6" fillOpacity={1} fill="url(#colorRevenue)" strokeWidth={2} />
                            <Area type="monotone" dataKey="expenses" stroke="#ef4444" fillOpacity={1} fill="url(#colorExpenses)" strokeWidth={2} />
                        </AreaChart>
                    </ResponsiveContainer>
                </ChartCard>

                <ChartCard title="Service Type Distribution">
                    <ResponsiveContainer width="100%" height={300}>
                        <RechartsPieChart>
                            <Pie
                                data={serviceChartData}
                                cx="50%"
                                cy="50%"
                                innerRadius={60}
                                outerRadius={120}
                                paddingAngle={5}
                                dataKey="value"
                                label={({ name, percentage }) => `${name}: ${percentage}%`}
                                labelLine={false}
                            >
                                {serviceChartData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                            </Pie>
                            <Tooltip />
                        </RechartsPieChart>
                    </ResponsiveContainer>
                </ChartCard>
            </div>

            {/* Summary Cards Row */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <Card className="shadow-lg border-0">
                    <CardHeader>
                        <CardTitle className="flex items-center text-gray-700">
                            <Briefcase className="w-5 h-5 mr-2" />
                            Business Summary
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            <div className="flex justify-between">
                                <span className="text-gray-600">New Cases</span>
                                <Badge variant="outline">{periodCases.length}</Badge>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-gray-600">New Customers</span>
                                <Badge variant="outline">{filterByDate(customers, 'created_date').length}</Badge>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-gray-600">Active Quotes</span>
                                <Badge variant="outline">{periodQuotes.filter(q => q.status === 'Sent').length}</Badge>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-gray-600">Completed Cases</span>
                                <Badge className="bg-green-100 text-green-800">{periodCases.filter(c => c.status === 'Completed').length}</Badge>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="shadow-lg border-0">
                    <CardHeader>
                        <CardTitle className="flex items-center text-gray-700">
                            <Calculator className="w-5 h-5 mr-2" />
                            Financial Health
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            <div className="flex justify-between items-center">
                                <span className="text-gray-600">Revenue Growth</span>
                                <div className="flex items-center text-green-600">
                                    <TrendingUp className="w-4 h-4 mr-1" />
                                    <span className="font-semibold">+12.5%</span>
                                </div>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-gray-600">Total Expenses</span>
                                <span className="font-semibold">{locale ? formatCurrency(totalExpenses, locale) : `$${totalExpenses.toLocaleString()}`}</span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-gray-600">Cash Flow</span>
                                <span className={`font-semibold ${netProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                                    {locale ? formatCurrency(netProfit, locale) : `$${netProfit.toLocaleString()}`}
                                </span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-gray-600">Avg. Invoice Value</span>
                                <span className="font-semibold">
                                    {locale ? formatCurrency(totalRevenue / (periodInvoices.length || 1), locale) : `$${(totalRevenue / (periodInvoices.length || 1)).toLocaleString()}`}
                                </span>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="shadow-lg border-0">
                    <CardHeader>
                        <CardTitle className="flex items-center text-gray-700">
                            <Activity className="w-5 h-5 mr-2" />
                            Performance KPIs
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            <div className="flex justify-between">
                                <span className="text-gray-600">Quote-to-Close</span>
                                <Badge className="bg-blue-100 text-blue-800">{quoteConversionRate.toFixed(1)}%</Badge>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-gray-600">Avg. Case Value</span>
                                <span className="font-semibold">
                                    {locale ? formatCurrency(totalRevenue / (periodCases.length || 1), locale) : `$${(totalRevenue / (periodCases.length || 1)).toLocaleString()}`}
                                </span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-gray-600">Payment Collection</span>
                                <Badge className="bg-green-100 text-green-800">
                                    {((periodTransactions.length / (periodInvoices.length || 1)) * 100).toFixed(1)}%
                                </Badge>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-gray-600">Customer Satisfaction</span>
                                <Badge className="bg-purple-100 text-purple-800">98.5%</Badge>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Expense Breakdown Chart */}
            <div className="grid grid-cols-1 gap-6">
                <ChartCard title="Expense Category Breakdown">
                    <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={expenseChartData} layout="horizontal">
                            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                            <XAxis type="number" stroke="#6b7280" fontSize={12} />
                            <YAxis dataKey="name" type="category" stroke="#6b7280" fontSize={12} />
                            <Tooltip 
                                formatter={(value) => [
                                    locale ? formatCurrency(value, locale) : `$${value.toLocaleString()}`,
                                    'Amount'
                                ]}
                            />
                            <Bar dataKey="value" fill="#3b82f6" radius={[0, 4, 4, 0]} />
                        </BarChart>
                    </ResponsiveContainer>
                </ChartCard>
            </div>
        </div>
    );
}