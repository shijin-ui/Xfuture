
import React, { useState, useEffect, useMemo } from 'react';
import { Expense } from '@/api/entities';
import { Bank } from '@/api/entities';
import { Supplier } from '@/api/entities';
import { Setting } from '@/api/entities';
import { Transaction } from '@/api/entities';
import { User } from '@/api/entities'; // Added User import
import { UploadFile } from '@/api/integrations';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Calculator, Plus, Search, Edit, Trash2, TrendingUp, DollarSign, CreditCard, Building, Check, X, Hash, Upload, FileText, Loader2, Eye, User as UserIcon } from 'lucide-react'; // Added User icon
import { format, parseISO } from 'date-fns';
import { getDefaultLocale, formatCurrency } from '@/components/utils/currencyFormatter';
import SearchableSelect from '@/components/SearchableSelect';
import { Switch } from '@/components/ui/switch';

// Helper function to get next expense number
const getNextExpenseNumber = async () => {
    try {
        const sequences = await Setting.filter({ category: 'Number Sequences', value: 'Expense Number' });
        if (sequences.length > 0) {
            const sequence = sequences[0];
            const nextNumber = (sequence.numeric_value || 0) + 1;
            return { sequence, nextNumber: `EXP-${nextNumber.toString().padStart(4, '0')}` };
        } else {
            const newSequence = await Setting.create({
                category: 'Number Sequences',
                value: 'Expense Number',
                numeric_value: 1000,
                description: 'Last assigned expense number'
            });
            return { sequence: newSequence, nextNumber: 'EXP-1001' };
        }
    } catch (error) {
        console.error('Failed to get next expense number:', error);
        return { sequence: null, nextNumber: 'EXP-0001' };
    }
};

const ExpenseFormDialog = ({ isOpen, onClose, expense, onSave, banks, suppliers, categories, locale }) => {
    const [formData, setFormData] = useState({
        expense_number: '',
        description: '',
        amount: '',
        apply_vat: true,
        vat_rate: 0.05,
        is_vat_claimable: true,
        category: 'Other',
        expense_date: format(new Date(), 'yyyy-MM-dd'),
        bank_id: '',
        supplier_id: '',
        vendor: '',
        reference_number: '',
        attachment_url: ''
    });

    const [calculated, setCalculated] = useState({
        vat_amount: 0,
        total_amount: 0,
    });

    const [isUploading, setIsUploading] = useState(false);

    useEffect(() => {
        const initializeForm = async () => {
            if (expense) {
                setFormData({
                    ...expense,
                    amount: expense.amount !== undefined && expense.amount !== null ? expense.amount.toString() : '',
                    apply_vat: expense.vat_rate > 0,
                    is_vat_claimable: expense.is_vat_claimable !== false,
                    expense_date: expense.expense_date ? format(parseISO(expense.expense_date), 'yyyy-MM-dd') : format(new Date(), 'yyyy-MM-dd'),
                    attachment_url: expense.attachment_url || ''
                });
            } else {
                const { nextNumber } = await getNextExpenseNumber();
                setFormData({
                    expense_number: nextNumber,
                    description: '',
                    amount: '',
                    apply_vat: true,
                    is_vat_claimable: true,
                    vat_rate: locale?.tax_rate || 0.05,
                    category: 'Other',
                    expense_date: format(new Date(), 'yyyy-MM-dd'),
                    bank_id: '',
                    supplier_id: '',
                    vendor: '',
                    reference_number: '',
                    attachment_url: ''
                });
            }
        };

        if (isOpen) {
            initializeForm();
        }
    }, [expense, isOpen, locale]);

    useEffect(() => {
        const amount = parseFloat(formData.amount) || 0;
        const vatRate = formData.apply_vat ? (parseFloat(formData.vat_rate) || 0) : 0;
        const vatAmount = amount * vatRate;
        const totalAmount = amount + vatAmount;

        setCalculated({ vat_amount: vatAmount, total_amount: totalAmount });
    }, [formData.amount, formData.apply_vat, formData.vat_rate]);

    useEffect(() => {
        if (formData.supplier_id) {
            const selectedSupplier = suppliers.find(s => s.id === formData.supplier_id);
            if (selectedSupplier) {
                setFormData(prev => ({
                    ...prev,
                    vendor: selectedSupplier.supplier_name
                }));
            }
        }
    }, [formData.supplier_id, suppliers]);
    
    const handleFileUpload = async (file) => {
        if (!file) return;

        setIsUploading(true);
        try {
            const { file_url } = await UploadFile({ file });
            setFormData(prev => ({ ...prev, attachment_url: file_url }));
        } catch (error) {
            console.error('Failed to upload file:', error);
            alert('Failed to upload file');
        } finally {
            setIsUploading(false);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!formData.description.trim() || !formData.amount || !formData.bank_id) {
            alert('Description, Amount, and Bank Account are required.');
            return;
        }

        if (formData.apply_vat && formData.is_vat_claimable && !formData.supplier_id && !formData.vendor) {
            alert('Vendor information is required for VAT claimable expenses.');
            return;
        }

        try {
            const user = await User.me(); // Fetch current user
            const expenseData = {
                ...formData,
                amount: parseFloat(formData.amount),
                vat_rate: formData.apply_vat ? parseFloat(formData.vat_rate) : 0,
                vat_amount: calculated.vat_amount,
                total_amount: calculated.total_amount,
                is_vat_claimable: formData.apply_vat ? formData.is_vat_claimable : false,
            };

            delete expenseData.apply_vat;

            let savedExpense;
            if (expense) {
                await Expense.update(expense.id, expenseData);
                savedExpense = { ...expense, ...expenseData };
            } else {
                savedExpense = await Expense.create(expenseData);
                const { sequence } = await getNextExpenseNumber();
                if (sequence) {
                    const numericPart = parseInt(formData.expense_number.split('-')[1]);
                    await Setting.update(sequence.id, { numeric_value: numericPart });
                }
            }

            // Create transaction record with user info
            try {
                await Transaction.create({
                    expense_id: savedExpense.id,
                    bank_id: expenseData.bank_id,
                    payment_method: 'Expense',
                    transaction_type: 'Expense', // Added transaction_type
                    amount: -Math.abs(expenseData.total_amount),
                    transaction_date: expenseData.expense_date,
                    reference_number: expenseData.reference_number || expenseData.expense_number,
                    notes: `Expense: ${expenseData.description}`,
                    status: 'Completed',
                    processed_by: user.email // Added processed_by
                });
            } catch (transactionError) {
                console.error('Failed to create transaction record:', transactionError);
            }

            onSave();
            onClose();
        } catch (error) {
            console.error('Failed to save expense:', error);
            alert('Failed to save expense');
        }
    };

    const supplierOptions = suppliers.map(supplier => ({
        value: supplier.id,
        label: supplier.supplier_name,
        subtitle: supplier.supplier_type
    }));

    const categoryOptions = categories.map(category => ({
        value: category,
        label: category
    }));

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="max-w-4xl max-h-[85vh] overflow-hidden">
                <DialogHeader className="pb-3">
                    <div className="flex items-center justify-between">
                        <div>
                            <DialogTitle className="text-xl font-bold bg-gradient-to-r from-red-600 to-pink-600 bg-clip-text text-transparent">
                                {expense ? 'Edit Expense' : 'Add New Expense'}
                            </DialogTitle>
                        </div>
                        {formData.expense_number && (
                            <div className="flex items-center bg-gray-100 px-3 py-1 rounded-lg border">
                                <Hash className="w-4 h-4 text-gray-500 mr-1" />
                                <span className="font-mono text-sm font-semibold text-gray-700">{formData.expense_number}</span>
                            </div>
                        )}
                    </div>
                </DialogHeader>
                
                <form id="expense-form" onSubmit={handleSubmit} className="grid grid-cols-12 gap-6 py-3">
                    {/* Left Card - Compact */}
                    <div className="col-span-7 space-y-4 p-4 bg-white rounded-xl shadow-md border">
                        <div className="space-y-3">
                           <h3 className="text-md font-semibold text-gray-800 border-b pb-1">Expense Details</h3>
                            <div className="grid grid-cols-2 gap-3 items-center">
                                <div>
                                    <Label className="text-xs font-medium">Apply VAT?</Label>
                                </div>
                                <div className="flex items-center justify-end">
                                     <Switch
                                        checked={formData.apply_vat}
                                        onCheckedChange={(checked) => setFormData({...formData, apply_vat: checked})}
                                        className="scale-75"
                                    />
                                </div>
                            </div>
                             <div className={`grid grid-cols-2 gap-3 items-center transition-opacity ${!formData.apply_vat ? 'opacity-50' : ''}`}>
                                <div>
                                    <Label className="text-xs font-medium">VAT Claimable?</Label>
                                </div>
                                <div className="flex items-center justify-end">
                                     <Switch
                                        checked={formData.is_vat_claimable}
                                        onCheckedChange={(checked) => setFormData({...formData, is_vat_claimable: checked})}
                                        disabled={!formData.apply_vat}
                                        className="scale-75"
                                    />
                                </div>
                            </div>
                        </div>

                        <div className="space-y-3">
                            <div className="grid grid-cols-2 gap-3">
                                <div className="space-y-1">
                                     <Label className="text-xs font-semibold">Description <span className="text-red-500">*</span></Label>
                                    <Input
                                        value={formData.description}
                                        onChange={(e) => setFormData({...formData, description: e.target.value})}
                                        placeholder="Expense description..."
                                        className="h-8"
                                    />
                                </div>
                                <div className="space-y-1">
                                    <Label className="text-xs font-semibold">Category</Label>
                                    <SearchableSelect
                                        value={formData.category}
                                        onValueChange={(value) => setFormData({...formData, category: value})}
                                        placeholder="Select category..."
                                        options={categoryOptions}
                                        searchPlaceholder="Search categories..."
                                        className="h-8"
                                    />
                                </div>
                            </div>
                            <div className="space-y-1">
                                <Label className="text-xs font-semibold">Amount <span className="text-red-500">*</span></Label>
                                <div className="relative">
                                    <Input
                                        type="number"
                                        step="0.001"
                                        value={formData.amount}
                                        onChange={(e) => setFormData({...formData, amount: e.target.value})}
                                        placeholder="0.000"
                                        className="text-lg font-mono pr-12 h-9 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
                                    />
                                    <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                                        <span className="text-gray-500 text-sm font-medium">{locale?.currency_symbol || 'OMR'}</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="space-y-3">
                            <h3 className="text-md font-semibold text-gray-800 border-b pb-1">Vendor Information</h3>
                            <div className="space-y-1">
                                <Label className="text-xs font-semibold">Vendor {formData.apply_vat && formData.is_vat_claimable && <span className="text-red-500">*</span>}</Label>
                                {suppliers.length > 0 ? (
                                    <SearchableSelect
                                        value={formData.supplier_id}
                                        onValueChange={(value) => setFormData({...formData, supplier_id: value})}
                                        placeholder="Select supplier..."
                                        options={supplierOptions}
                                        searchPlaceholder="Search suppliers..."
                                        className="h-8"
                                    />
                                ) : (
                                    <Input
                                        value={formData.vendor}
                                        onChange={(e) => setFormData({...formData, vendor: e.target.value})}
                                        placeholder="Vendor name"
                                        className="h-8"
                                    />
                                )}
                            </div>
                        </div>
                    </div>
                    
                    {/* Right Card - Compact */}
                    <div className="col-span-5 space-y-4">
                        <div className="p-4 bg-white rounded-xl shadow-md border space-y-4">
                             <h3 className="text-md font-semibold text-gray-800 border-b pb-1">Administration</h3>
                            <div className="space-y-1">
                                <Label className="text-xs font-semibold">Date <span className="text-red-500">*</span></Label>
                                <Input
                                    type="date"
                                    value={formData.expense_date}
                                    onChange={(e) => setFormData({...formData, expense_date: e.target.value})}
                                    className="h-8"
                                />
                            </div>
                            <div className="space-y-1">
                                <Label className="text-xs font-semibold">Invoice/Reference</Label>
                                <Input
                                    value={formData.reference_number}
                                    onChange={(e) => setFormData({...formData, reference_number: e.target.value})}
                                    placeholder="Invoice #, Receipt #"
                                    className="h-8"
                                />
                            </div>
                            <div className="space-y-1">
                                <Label className="text-xs font-semibold">Paid From <span className="text-red-500">*</span></Label>
                                <Select value={formData.bank_id} onValueChange={(value) => setFormData({...formData, bank_id: value})}>
                                    <SelectTrigger className="h-8">
                                        <SelectValue placeholder="Select bank account" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {banks.map(bank => (
                                            <SelectItem key={bank.id} value={bank.id}>
                                                <div className="flex items-center">
                                                    <Building className="w-3 h-3 mr-2 text-gray-400" />
                                                    <span className="text-xs font-medium">{bank.bank_name} - {bank.account_name}</span>
                                                </div>
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-1">
                                <Label className="text-xs font-semibold">Attach Bill/Receipt</Label>
                                <div className="relative">
                                    <input
                                        type="file"
                                        accept="image/*,.pdf"
                                        onChange={(e) => handleFileUpload(e.target.files[0])}
                                        className="hidden"
                                        id="file-upload"
                                    />
                                    <div className="flex gap-1">
                                        <Button
                                            type="button"
                                            variant="outline"
                                            className="flex-1 h-8 text-xs"
                                            onClick={() => document.getElementById('file-upload').click()}
                                            disabled={isUploading}
                                        >
                                            {isUploading ? <Loader2 className="w-3 h-3 mr-1 animate-spin" /> : <Upload className="w-3 h-3 mr-1" />}
                                            {formData.attachment_url ? 'Change' : 'Upload'}
                                        </Button>
                                        {formData.attachment_url && (
                                            <Button
                                                type="button"
                                                variant="outline"
                                                className="px-2 h-8 text-blue-600 border-blue-200 hover:bg-blue-50"
                                                onClick={() => window.open(formData.attachment_url, '_blank')}
                                            >
                                                <Eye className="w-3 h-3" />
                                            </Button>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </div>

                         <div className="p-4 bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 rounded-xl border-2 border-blue-200 shadow-md">
                            <h3 className="text-md font-bold text-gray-800 mb-3 flex items-center">
                                <Calculator className="w-4 h-4 mr-2 text-blue-600" />
                                Summary
                            </h3>
                            <div className="space-y-1">
                                <div className="flex justify-between items-center text-xs">
                                    <span className="text-gray-600 font-medium">Base Amount</span>
                                    <span className="font-mono font-semibold text-gray-800">
                                        {locale ? formatCurrency(parseFloat(formData.amount) || 0, locale) : `${(parseFloat(formData.amount) || 0).toFixed(3)} OMR`}
                                    </span>
                                </div>
                                <div className="flex justify-between items-center text-xs">
                                    <span className="text-gray-600 font-medium">VAT ({formData.apply_vat ? ((formData.vat_rate || 0) * 100).toFixed(1) : 0}%)</span>
                                    <span className="font-mono font-semibold text-gray-800">
                                        {locale ? formatCurrency(calculated.vat_amount, locale) : `${calculated.vat_amount.toFixed(3)} OMR`}
                                    </span>
                                </div>
                                <div className="border-t border-gray-300 pt-1 mt-1">
                                    <div className="flex justify-between items-center">
                                        <span className="text-sm font-bold text-gray-900">Total Amount</span>
                                        <span className="font-mono text-lg font-bold text-red-600">
                                            {locale ? formatCurrency(calculated.total_amount, locale) : `${calculated.total_amount.toFixed(3)} OMR`}
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                
                <DialogFooter className="pt-3 border-t">
                    <Button type="button" variant="outline" onClick={onClose} className="px-6 py-1 h-8">
                        Cancel
                    </Button>
                    <Button 
                        type="submit" 
                        form="expense-form" 
                        className="px-8 py-1 h-8 bg-gradient-to-r from-red-500 to-pink-600 hover:from-red-600 hover:to-pink-700 text-white font-semibold shadow-lg text-sm"
                        disabled={!formData.description.trim() || !formData.amount || !formData.bank_id}
                    >
                        {expense ? 'Update Expense' : 'Add Expense'}
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
};

export default function ExpensesPage() {
    const [expenses, setExpenses] = useState([]);
    const [banks, setBanks] = useState([]);
    const [suppliers, setSuppliers] = useState([]);
    const [categories, setCategories] = useState([]);
    const [users, setUsers] = useState([]); // Added users state
    const [isLoading, setIsLoading] = useState(true);
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [editingExpense, setEditingExpense] = useState(null);
    const [locale, setLocale] = useState(null);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        fetchData();
    }, []);

    const fetchData = async () => {
        setIsLoading(true);
        try {
            const [expensesData, banksData, suppliersData, categoriesData, usersData, localeData] = await Promise.all([
                Expense.list('-expense_date'),
                Bank.list(),
                Supplier.list(),
                Setting.filter({ category: 'Expense Categories' }),
                User.list(), // Fetch users
                getDefaultLocale()
            ]);
            setExpenses(expensesData);
            setBanks(banksData);
            setSuppliers(suppliersData);
            setCategories(categoriesData.map(c => c.value));
            setUsers(usersData); // Set users state
            setLocale(localeData);
        } catch (error) {
            console.error('Failed to fetch data:', error);
        } finally {
            setIsLoading(false);
        }
    };

    const handleOpenDialog = (expense = null) => {
        setEditingExpense(expense);
        setIsDialogOpen(true);
    };

    const handleCloseDialog = () => {
        setIsDialogOpen(false);
        setEditingExpense(null);
    };

    const handleDelete = async (expenseId) => {
        if (window.confirm('Are you sure you want to delete this expense?')) {
            try {
                await Expense.delete(expenseId);
                fetchData();
            } catch (error) {
                console.error('Failed to delete expense:', error);
                alert('Failed to delete expense');
            }
        }
    };

    const filteredExpenses = useMemo(() => {
        return expenses.filter(expense => {
            const searchLower = searchTerm.toLowerCase();
            return (
                expense.description?.toLowerCase().includes(searchLower) ||
                expense.vendor?.toLowerCase().includes(searchLower) ||
                expense.category?.toLowerCase().includes(searchLower) ||
                expense.reference_number?.toLowerCase().includes(searchLower) ||
                expense.expense_number?.toLowerCase().includes(searchLower)
            );
        });
    }, [expenses, searchTerm]);

    const totals = useMemo(() => {
        return filteredExpenses.reduce((acc, expense) => {
            acc.totalAmount += expense.amount || 0;
            acc.totalVAT += expense.vat_amount || 0;
            acc.totalWithVAT += expense.total_amount || 0;
            return acc;
        }, { totalAmount: 0, totalVAT: 0, totalWithVAT: 0 });
    }, [filteredExpenses]);

    const getSupplierName = (expense) => {
        if (expense.supplier_id) {
            const supplier = suppliers.find(s => s.id === expense.supplier_id);
            return supplier ? supplier.supplier_name : expense.vendor || 'Unknown Supplier';
        }
        return expense.vendor || 'No Vendor';
    };

    const getBankName = (bankId) => {
        const bank = banks.find(b => b.id === bankId);
        return bank ? `${bank.bank_name} - ${bank.account_name}` : 'N/A';
    };

    // Helper function to get user's full name from email
    const getUserName = (email) => {
        const user = users.find(u => u.email === email);
        return user ? user.full_name : email?.split('@')[0] || 'System';
    };

    return (
        <div className="p-6 bg-gradient-to-br from-slate-50 to-indigo-100 min-h-screen">
            <div className="flex justify-between items-center mb-6">
                <div className="flex items-center space-x-4">
                    <div className="p-3 bg-gradient-to-r from-red-500 to-pink-600 rounded-xl shadow-lg">
                        <Calculator className="w-8 h-8 text-white" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-bold bg-gradient-to-r from-red-600 to-pink-600 bg-clip-text text-transparent">
                            Expenses
                        </h1>
                        <p className="text-gray-500 mt-1">Track and manage business expenses</p>
                    </div>
                </div>
                <Button onClick={() => handleOpenDialog()} className="bg-red-500 hover:bg-red-600">
                    <Plus className="w-5 h-5 mr-2" />
                    Add Expense
                </Button>
            </div>

            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <Card className="shadow-lg border-0 bg-white/90 backdrop-blur-sm">
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm font-medium text-gray-500">Total Expenses (Pre-VAT)</p>
                                <p className="text-2xl font-bold text-gray-900">
                                    {locale ? formatCurrency(totals.totalAmount, locale) : `${totals.totalAmount.toFixed(3)} OMR`}
                                </p>
                            </div>
                            <div className="p-3 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 shadow-lg">
                                <DollarSign className="w-6 h-6 text-white" />
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="shadow-lg border-0 bg-white/90 backdrop-blur-sm">
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm font-medium text-gray-500">Total VAT Paid</p>
                                <p className="text-2xl font-bold text-gray-900">
                                    {locale ? formatCurrency(totals.totalVAT, locale) : `${totals.totalVAT.toFixed(3)} OMR`}
                                </p>
                            </div>
                            <div className="p-3 rounded-xl bg-gradient-to-br from-green-500 to-emerald-600 shadow-lg">
                                <TrendingUp className="w-6 h-6 text-white" />
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="shadow-lg border-0 bg-white/90 backdrop-blur-sm">
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-sm font-medium text-gray-500">Total with VAT</p>
                                <p className="text-2xl font-bold text-gray-900">
                                    {locale ? formatCurrency(totals.totalWithVAT, locale) : `${totals.totalWithVAT.toFixed(3)} OMR`}
                                </p>
                            </div>
                            <div className="p-3 rounded-xl bg-gradient-to-br from-purple-500 to-pink-600 shadow-lg">
                                <CreditCard className="w-6 h-6 text-white" />
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Search Bar */}
            <Card className="shadow-lg bg-white/90 backdrop-blur-sm border-0 mb-6">
                <CardContent className="p-4">
                    <div className="relative">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                        <Input
                            placeholder="Search expenses by description, vendor, category, reference, or expense number..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="pl-9 bg-white/70"
                        />
                    </div>
                </CardContent>
            </Card>

            {/* Expenses Table */}
            <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0">
                <CardHeader>
                    <CardTitle>All Expenses ({filteredExpenses.length})</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="overflow-x-auto">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Expense #</TableHead>
                                    <TableHead>Date</TableHead>
                                    <TableHead>Description</TableHead>
                                    <TableHead>Supplier/Vendor</TableHead>
                                    <TableHead>Paid From</TableHead>
                                    <TableHead className="text-right">Amount</TableHead>
                                    <TableHead>Claimable</TableHead>
                                    <TableHead className="text-right">Total</TableHead>
                                    <TableHead>Added By</TableHead> {/* New column header */}
                                    <TableHead className="text-right">Actions</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {isLoading ? (
                                    <TableRow>
                                        <TableCell colSpan={10} className="text-center py-10"> {/* Updated colSpan */}
                                            Loading expenses...
                                        </TableCell>
                                    </TableRow>
                                ) : filteredExpenses.length === 0 ? (
                                    <TableRow>
                                        <TableCell colSpan={10} className="text-center py-10"> {/* Updated colSpan */}
                                            No expenses found
                                        </TableCell>
                                    </TableRow>
                                ) : (
                                    filteredExpenses.map(expense => (
                                        <TableRow key={expense.id} className="hover:bg-blue-50/50">
                                            <TableCell className="font-mono text-sm">
                                                {expense.expense_number || '-'}
                                            </TableCell>
                                            <TableCell>
                                                {format(parseISO(expense.expense_date), 'dd MMM yyyy')}
                                            </TableCell>
                                            <TableCell>
                                                <div>
                                                    <div className="font-medium">{expense.description}</div>
                                                    {expense.reference_number && (
                                                        <div className="text-sm text-gray-500">
                                                            Ref: {expense.reference_number}
                                                        </div>
                                                    )}
                                                </div>
                                            </TableCell>
                                            <TableCell>
                                                <div className="flex items-center">
                                                    {expense.supplier_id && <Building className="w-4 h-4 mr-1 text-gray-400" />}
                                                    {getSupplierName(expense)}
                                                </div>
                                            </TableCell>
                                            <TableCell>
                                                <div className="flex items-center text-sm">
                                                    <CreditCard className="w-4 h-4 mr-2 text-gray-400 flex-shrink-0" />
                                                    <span className="truncate">{getBankName(expense.bank_id)}</span>
                                                </div>
                                            </TableCell>
                                            <TableCell className="text-right font-mono">
                                                {locale ? formatCurrency(expense.amount || 0, locale) : 
                                                 `${(expense.amount || 0).toFixed(3)} OMR`}
                                            </TableCell>
                                            <TableCell>
                                                {expense.is_vat_claimable !== false ? (
                                                    <Badge className="bg-green-100 text-green-800"><Check className="w-3 h-3 mr-1"/> Yes</Badge>
                                                ) : (
                                                    <Badge variant="destructive" className="bg-red-100 text-red-800"><X className="w-3 h-3 mr-1"/> No</Badge>
                                                )}
                                            </TableCell>
                                            <TableCell className="text-right font-mono font-semibold">
                                                {locale ? formatCurrency(expense.total_amount || 0, locale) : 
                                                 `${(expense.total_amount || 0).toFixed(3)} OMR`}
                                            </TableCell>
                                            <TableCell> {/* New cell for Added By */}
                                                <div className="flex items-center text-sm">
                                                    <UserIcon className="w-3 h-3 mr-1 text-gray-400" />
                                                    <span className="truncate">{getUserName(expense.created_by)}</span>
                                                </div>
                                            </TableCell>
                                            <TableCell className="text-right">
                                                <div className="flex justify-end space-x-1">
                                                    <Button
                                                        variant="ghost"
                                                        size="sm"
                                                        onClick={() => handleOpenDialog(expense)}
                                                    >
                                                        <Edit className="w-4 h-4" />
                                                    </Button>
                                                    <Button
                                                        variant="ghost"
                                                        size="sm"
                                                        onClick={() => handleDelete(expense.id)}
                                                        className="text-red-600 hover:bg-red-50"
                                                    >
                                                        <Trash2 className="w-4 h-4" />
                                                    </Button>
                                                </div>
                                            </TableCell>
                                        </TableRow>
                                    ))
                                )}
                            </TableBody>
                        </Table>
                    </div>
                </CardContent>
            </Card>

            <ExpenseFormDialog
                isOpen={isDialogOpen}
                onClose={handleCloseDialog}
                expense={editingExpense}
                onSave={fetchData}
                banks={banks}
                suppliers={suppliers}
                categories={categories}
                locale={locale}
            />
        </div>
    );
}
