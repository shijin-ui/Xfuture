
import React, { useState, useEffect, useMemo } from 'react';
import { Quote } from '@/api/entities';
import { Case } from '@/api/entities';
import { Customer } from '@/api/entities';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Activity, PlusCircle, Search, Eye, Edit, FileText, MoreHorizontal, Download } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { format, parseISO } from 'date-fns';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const statusColors = {
  Draft: 'bg-gray-200 text-gray-800',
  Sent: 'bg-blue-100 text-blue-800',
  Accepted: 'bg-green-100 text-green-800',
  Rejected: 'bg-red-100 text-red-800',
};

export default function QuotesPage() {
  const [quotes, setQuotes] = useState([]);
  const [cases, setCases] = useState({});
  const [customers, setCustomers] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        const [quoteData, caseData, customerData] = await Promise.all([
          Quote.list('-created_date'),
          Case.list(),
          Customer.list(),
        ]);
        
        setQuotes(quoteData);
        setCases(caseData.reduce((acc, c) => ({ ...acc, [c.id]: c }), {}));
        setCustomers(customerData.reduce((acc, c) => ({ ...acc, [c.id]: c }), {}));

      } catch (error) {
        console.error('Failed to fetch data:', error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, []);

  const filteredQuotes = useMemo(() => {
    if (!searchTerm) return quotes;
    const lowercasedFilter = searchTerm.toLowerCase();
    return quotes.filter(quote => {
      const caseInfo = cases[quote.case_id];
      const customerInfo = customers[quote.customer_id];
      return (
        quote.quote_number?.toLowerCase().includes(lowercasedFilter) ||
        quote.status?.toLowerCase().includes(lowercasedFilter) ||
        caseInfo?.case_number?.toLowerCase().includes(lowercasedFilter) ||
        customerInfo?.full_name?.toLowerCase().includes(lowercasedFilter)
      );
    });
  }, [searchTerm, quotes, cases, customers]);

  const handleDownload = (quote) => {
    // This will open the print page in a new tab. The PrintQuote page
    // will automatically set the document title for the PDF filename
    // and trigger the print dialog.
    window.open(createPageUrl(`PrintQuote?id=${quote.id}`), '_blank');
  };

  return (
    <div className="p-8 bg-gradient-to-br from-slate-50 to-indigo-100 min-h-screen">
      <div className="flex justify-between items-center mb-8">
        <div className="flex items-center space-x-4">
          <div className="p-3 bg-gradient-to-r from-teal-500 to-cyan-600 rounded-xl shadow-lg">
            <Activity className="w-8 h-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-teal-600 to-cyan-600 bg-clip-text text-transparent">
              Quotes
            </h1>
            <p className="text-gray-500 mt-1">Manage all quotes for your clients.</p>
          </div>
        </div>
        <Link to={createPageUrl('CreateQuote')}>
          <Button className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white shadow-lg">
            <PlusCircle className="w-5 h-5 mr-2" />
            Create Quote
          </Button>
        </Link>
      </div>

      <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0 overflow-hidden">
        <div className="p-4 border-b bg-gray-50/50">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold text-gray-800">All Quotes</h2>
            <div className="relative w-72">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search by quote #, case #, client..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 h-9 bg-white/70"
              />
            </div>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-100/80">
                <TableHead>Quote #</TableHead>
                <TableHead>Case #</TableHead>
                <TableHead>Client</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Total</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow><TableCell colSpan={7} className="text-center py-10">Loading quotes...</TableCell></TableRow>
              ) : filteredQuotes.length === 0 ? (
                <TableRow><TableCell colSpan={7} className="text-center py-10">No quotes found.</TableCell></TableRow>
              ) : (
                filteredQuotes.map(quote => {
                  const caseInfo = cases[quote.case_id];
                  const customerInfo = customers[quote.customer_id];
                  return (
                    <TableRow key={quote.id} className="hover:bg-blue-50/50">
                      <TableCell className="font-semibold text-blue-600">
                        <Link to={createPageUrl(`QuoteDetails?id=${quote.id}`)}>
                          {quote.quote_number}
                        </Link>
                      </TableCell>
                      <TableCell>{caseInfo?.case_number || 'N/A'}</TableCell>
                      <TableCell>{customerInfo?.full_name || 'N/A'}</TableCell>
                      <TableCell>{format(parseISO(quote.created_date), 'dd MMM yyyy')}</TableCell>
                      <TableCell>${(quote.total_amount || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}</TableCell>
                      <TableCell>
                        <Badge className={`${statusColors[quote.status] || 'bg-gray-200 text-gray-800'} font-medium`}>
                          {quote.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreHorizontal className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => navigate(createPageUrl(`QuoteDetails?id=${quote.id}`))}>
                              <Edit className="w-4 h-4 mr-2" /> Edit / View
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => window.open(createPageUrl(`PrintQuote?id=${quote.id}`), '_blank')}>
                              <FileText className="w-4 h-4 mr-2" /> Print Quote
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleDownload(quote)}>
                              <Download className="w-4 h-4 mr-2" /> Download PDF
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
}
