
import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Invoice } from '@/api/entities';
import { Case } from '@/api/entities';
import { Customer } from '@/api/entities';
import { Company } from '@/api/entities';
import { CompanyProfile } from '@/api/entities';
import { getDefaultLocale, formatCurrency } from '@/components/utils/currencyFormatter';
import { format, parseISO } from 'date-fns';
import { Loader2, User, FileText as FileTextIcon, Landmark } from 'lucide-react';

export default function PrintInvoicePage() {
    const [invoice, setInvoice] = useState(null);
    const [caseData, setCaseData] = useState(null);
    const [customer, setCustomer] = useState(null);
    const [company, setCompany] = useState(null);
    const [companyProfile, setCompanyProfile] = useState(null);
    const [locale, setLocale] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [isImageLoaded, setIsImageLoaded] = useState(false); // Added for image loading check
    const location = useLocation();

    useEffect(() => {
        const fetchData = async () => {
            try {
                setIsLoading(true);
                const invoiceId = new URLSearchParams(location.search).get('id');
                if (!invoiceId) throw new Error("Invoice ID not found");

                const [fetchedInvoice, fetchedProfile, defaultLocale] = await Promise.all([
                    Invoice.get(invoiceId),
                    CompanyProfile.list().then(p => p[0] || null),
                    getDefaultLocale()
                ]);

                if (!fetchedInvoice) throw new Error("Invoice not found");
                
                setInvoice(fetchedInvoice);
                setCompanyProfile(fetchedProfile);
                setLocale(defaultLocale);

                const [fetchedCase, fetchedCustomer] = await Promise.all([
                    Case.get(fetchedInvoice.case_id).catch(() => null),
                    Customer.get(fetchedInvoice.customer_id).catch(() => null)
                ]);

                setCaseData(fetchedCase);
                setCustomer(fetchedCustomer);

                // Fetch company data if customer has company_name
                if (fetchedCustomer?.company_name) {
                    try {
                        const companies = await Company.filter({ company_name: fetchedCustomer.company_name });
                        if (companies.length > 0) {
                            setCompany(companies[0]);
                        }
                    } catch (error) {
                        console.warn('Failed to fetch company data:', error);
                    }
                }

            } catch (error) {
                console.error("Failed to fetch print data:", error);
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, [location.search]);

    // Auto-trigger print
    useEffect(() => {
        // Trigger print only when data is loaded AND (image is loaded OR there is no logo URL)
        if (!isLoading && invoice && caseData && (isImageLoaded || !companyProfile?.full_logo_url)) {
            document.title = `${invoice.is_proforma ? 'Proforma' : 'Invoice'}#${invoice.invoice_number} [Job ID ${caseData.case_number || 'N/A'}].pdf`;
            const printTimeout = setTimeout(() => {
                window.print();
            }, 500); // Decreased timeout for faster print initiation
            return () => clearTimeout(printTimeout);
        }
    }, [isLoading, invoice, caseData, isImageLoaded, companyProfile]); // Added isImageLoaded and companyProfile to dependencies

    if (isLoading) {
        return (
            <div className="flex h-screen items-center justify-center">
                <Loader2 className="h-8 w-8 animate-spin" />
                <p className="ml-2">Loading Invoice for Print...</p>
            </div>
        );
    }
    
    if (!invoice || !caseData || !customer || !companyProfile) {
        return <div className="p-8 text-center text-red-500">Could not load all necessary data for the invoice. Please check if case, customer, and company profile are set up correctly.</div>;
    }

    const InfoRow = ({ label, value }) => (
        <div className="flex">
            <span className="w-28 text-gray-500 font-medium text-xs">{label}:</span>
            <span className="text-gray-800 font-medium text-xs">{value || 'N/A'}</span>
        </div>
    );

    const DetailCard = ({ title, arabicTitle, icon: Icon, children }) => (
        <div className="border border-gray-200 rounded-lg bg-white">
            <div className="px-3 py-1.5 border-b bg-gray-50 flex justify-between items-center rounded-t-lg">
                <h3 className="font-bold text-gray-800 text-xs flex items-center">
                    <Icon className="w-3 h-3 mr-1.5 text-gray-500" />
                    {title}
                </h3>
                <h3 className="font-bold text-gray-800 text-xs" dir="rtl">{arabicTitle}</h3>
            </div>
            <div className="p-3 space-y-1 text-xs">
                {children}
            </div>
        </div>
    );

    return (
        <>
            <style>{`
                @page {
                    size: A4;
                    margin: 0.5in;
                }
                body {
                    -webkit-print-color-adjust: exact !important;
                    color-adjust: exact !important;
                    background-color: #ffffff !important;
                }
                img {
                    print-color-adjust: exact !important;
                    -webkit-print-color-adjust: exact !important;
                }
                @media screen {
                  body {
                    background-color: #f1f5f9; /* Tailwind gray-100 */
                  }
                  .print-container {
                    width: 210mm;
                    min-height: 297mm;
                    margin: 1rem auto;
                    padding: 0.5in;
                    box-sizing: border-box;
                    background: white;
                    box-shadow: 0 0 15px rgba(0,0,0,0.1);
                  }
                }
            `}</style>
            
            <div className="print-container">
                {/* Header */}
                <header className="flex justify-between items-start pb-6 border-b border-gray-200">
                    <div>
                        {companyProfile.full_logo_url ? (
                             <img 
                                src={companyProfile.full_logo_url} 
                                alt={`${companyProfile.company_name} Logo`} 
                                className="h-16 w-auto"
                                onLoad={() => setIsImageLoaded(true)} // Set image loaded state on success
                                onError={() => setIsImageLoaded(true)} // Set image loaded state even on error to prevent infinite loading
                            />
                        ) : (
                            <div className="text-2xl font-bold text-blue-600">{companyProfile.company_name}</div>
                        )}
                    </div>
                    <div className="text-right text-xs leading-tight">
                        <div className="font-bold text-sm text-gray-900 mb-0.5">{companyProfile.company_name}</div>
                        <div className="text-gray-600 mb-0.5">
                            {companyProfile.company_registration_number && `Reg No: ${companyProfile.company_registration_number}`}
                            {companyProfile.company_registration_number && companyProfile.tax_id && ' | '}
                            {companyProfile.tax_id && `VAT No: ${companyProfile.tax_id}`}
                        </div>
                        {companyProfile.company_address && <div className="text-gray-600 leading-tight">{companyProfile.company_address}</div>}
                        {companyProfile.phone_number && <div className="text-gray-600">Tel: {companyProfile.phone_number}</div>}
                        {companyProfile.email && <div className="text-gray-600">Email: {companyProfile.email}</div>}
                    </div>
                </header>

                {/* Title */}
                <div className="text-center py-6 my-4">
                    <h1 className="text-2xl font-bold tracking-wide text-gray-800">
                        {invoice.is_proforma ? 'PROFORMA INVOICE | فاتورة أولية' : 
                         invoice.include_vat ? 'TAX INVOICE | فاتورة ضريبية' : 'INVOICE | فاتورة'}
                    </h1>
                </div>

                {/* Customer and Invoice Details */}
                <div className="grid grid-cols-2 gap-4 mb-8">
                    <DetailCard title="Customer Information" arabicTitle="معلومات العميل" icon={User}>
                        {customer.company_name && <InfoRow label="Company" value={customer.company_name} />}
                        {customer.company_name && company?.vat_number && <InfoRow label="VAT No" value={company.vat_number} />}
                        <InfoRow label="Name" value={customer.full_name} />
                        <InfoRow label="Phone" value={customer.phone_number} />
                        <InfoRow label="Email" value={customer.email} />
                    </DetailCard>

                    <DetailCard title="Invoice Details" arabicTitle="تفاصيل الفاتورة" icon={FileTextIcon}>
                        <InfoRow label="Invoice No" value={invoice.invoice_number} />
                        <InfoRow label="Date" value={format(parseISO(invoice.issued_date || invoice.created_date), 'dd MMM yyyy')} />
                        <InfoRow label="Status" value={invoice.status} />
                        <InfoRow label="Job ID" value={caseData?.case_number} />
                        {caseData?.client_reference && <InfoRow label="Client Ref" value={caseData.client_reference} />}
                    </DetailCard>
                </div>
                
                {/* Line Items Table */}
                <div className="mb-8">
                     <table className="w-full border-collapse">
                        <thead>
                            <tr className="bg-gray-100">
                                <th className="p-1.5 text-left font-bold text-[11px] text-gray-700">Description / الوصف</th>
                                <th className="p-1.5 text-center font-bold text-[11px] text-gray-700 w-16">Qty</th>
                                <th className="p-1.5 text-right font-bold text-[11px] text-gray-700 w-28">Unit Price</th>
                                <th className="p-1.5 text-right font-bold text-[11px] text-gray-700 w-28">Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            {invoice.line_items?.map((item, index) => (
                                <tr key={index} className="hover:bg-gray-50">
                                    <td className="p-1.5 text-[11px] border-b">{item.description}</td>
                                    <td className="p-1.5 text-center text-[11px] border-b">{item.quantity}</td>
                                    <td className="p-1.5 text-right text-[11px] font-mono border-b">{formatCurrency(item.unit_price || 0, locale)}</td>
                                    <td className="p-1.5 text-right text-[11px] font-mono font-medium border-b">{formatCurrency(item.amount || 0, locale)}</td>
                                </tr>
                            )) || (
                                <tr>
                                    <td colSpan="4" className="p-1.5 text-center text-gray-500 text-xs border-b">No line items</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>

                {/* Totals Section */}
                <div className="mb-8">
                    <div className="flex justify-end">
                        <div className="w-80 space-y-2">
                            <div className="flex justify-between text-sm border-b pb-2">
                                <span className="font-medium text-gray-600">Subtotal:</span>
                                <span className="font-mono">{formatCurrency(invoice.subtotal || 0, locale)}</span>
                            </div>
                            
                            {invoice.discount_amount > 0 && (
                                <div className="flex justify-between text-sm text-red-600 border-b pb-2">
                                    <span>Discount ({invoice.discount_type === 'percentage' ? `${invoice.discount_value}%` : 'Fixed'}):</span>
                                    <span className="font-mono">-{formatCurrency(invoice.discount_amount, locale)}</span>
                                </div>
                            )}
                                                        
                            {invoice.include_vat && invoice.vat_amount > 0 && (
                                <div className="flex justify-between text-sm text-green-600 border-b pb-2">
                                    <span>{locale?.tax_name || 'VAT'} ({((invoice.vat_rate || 0.05) * 100).toFixed(0)}%):</span>
                                    <span className="font-mono">+{formatCurrency(invoice.vat_amount, locale)}</span>
                                </div>
                            )}
                            
                            <div className="flex justify-between items-center text-lg font-bold pt-2 border-t-2 border-gray-800">
                                <span className="whitespace-nowrap">Total / الإجمالي:</span>
                                <span className="font-mono text-right">{formatCurrency(invoice.total_amount || 0, locale)}</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Footer with Terms and Bank Details */}
                <footer className="mt-auto grid grid-cols-2 gap-8 pt-6 border-t border-gray-200">
                    {/* Terms & Conditions */}
                    <div>
                        <h3 className="font-bold text-sm text-gray-800 mb-3">Terms & Conditions / الشروط والأحكام</h3>
                        <div className="text-xs text-gray-600 space-y-1">
                            <div>• Payment is due within 30 days of invoice date</div>
                        </div>
                    </div>

                    {/* Bank Account Details */}
                    <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                        <h3 className="font-bold text-sm text-gray-800 mb-3">Bank Account / تفاصيل البنك</h3>
                        <div className="text-xs text-gray-700 space-y-1">
                            <div className="flex">
                                <span className="font-medium w-24">Account Name:</span>
                                <span>{companyProfile.bank_account_1_account_name || companyProfile.company_name}</span>
                            </div>
                            <div className="flex">
                                <span className="font-medium w-24">Bank Name:</span>
                                <span>{companyProfile.bank_account_1_name || 'Not specified'}</span>
                            </div>
                            <div className="flex">
                                <span className="font-medium w-24">Account No:</span>
                                <span className="font-mono">{companyProfile.bank_account_1_number || 'Not specified'}</span>
                            </div>
                            <div className="flex">
                                <span className="font-medium w-24">IBAN:</span>
                                <span className="font-mono text-xs">{companyProfile.bank_account_1_iban || 'Not specified'}</span>
                            </div>
                        </div>
                    </div>
                </footer>
                
                <div className="mt-8 pt-4 border-t border-gray-300 text-center text-xs text-gray-600">
                    <p className="font-bold text-blue-600">Trusted Data Recovery in Oman for over 10 years.</p>
                    <p>{companyProfile.website || 'www.spacedatarecovery.com'}</p>
                </div>
            </div>
        </>
    );
}
