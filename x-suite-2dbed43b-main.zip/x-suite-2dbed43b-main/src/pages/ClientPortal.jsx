
import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Customer } from '@/api/entities';
import { Case } from '@/api/entities';
import { Quote } from '@/api/entities';
import { Invoice } from '@/api/entities';
import { CaseFile } from '@/api/entities';
import { Communication } from '@/api/entities';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
    HardDrive, FileText, DollarSign, Download, CheckCircle, XCircle,
    MessageSquare, User, FileArchive // Added FileArchive for evaluations
} from 'lucide-react';
import { format } from 'date-fns';
import CaseStatusTracker from '../components/case/CaseStatusTracker';
import { AccountingLocale } from '@/api/entities'; // Import AccountingLocale
import { MediaEvaluation } from '@/api/entities'; // Import MediaEvaluation

export default function ClientPortalPage() {
    const [customer, setCustomer] = useState(null);
    const [cases, setCases] = useState([]);
    const [quotes, setQuotes] = useState([]);
    const [invoices, setInvoices] = useState([]);
    const [files, setFiles] = useState([]);
    const [communications, setCommunications] = useState([]);
    const [evaluations, setEvaluations] = useState([]); // State for evaluations
    const [localeSettings, setLocaleSettings] = useState(null); // State for locale settings
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const location = useLocation();

    const getTokenFromURL = () => {
        const urlParams = new URLSearchParams(location.search);
        return urlParams.get('token');
    };

    const fetchData = async () => {
        const token = getTokenFromURL();
        if (!token) {
            setError('Invalid access link. Please contact support.');
            setLoading(false);
            return;
        }

        try {
            // Find customer by portal token
            const customers = await Customer.filter({ client_portal_token: token });
            if (customers.length === 0) {
                setError('Access link expired or invalid. Please contact support.');
                setLoading(false);
                return;
            }

            const customerData = customers[0];
            if (!customerData.client_portal_enabled) {
                setError('Portal access has been disabled. Please contact support.');
                setLoading(false);
                return;
            }

            setCustomer(customerData);

            // Fetch all data concurrently
            const [
                casesData,
                quotesData,
                invoicesData,
                commsData,
                defaultLocale
            ] = await Promise.all([
                Case.filter({ customer_id: customerData.id }, '-created_date'),
                Quote.filter({ customer_id: customerData.id }, '-created_date'),
                Invoice.filter({ customer_id: customerData.id }, '-created_date'),
                Communication.filter({ customer_id: customerData.id }, '-communication_date'),
                AccountingLocale.filter({ is_default: true }, null, 1).then(res => res[0]) // Fetch default locale
            ]);

            setCases(casesData || []);
            setQuotes(quotesData || []);
            setInvoices(invoicesData || []);
            setCommunications(commsData || []);
            setLocaleSettings(defaultLocale); // Set locale settings

            // Then fetch files and evaluations, depending on fetched cases IDs
            const customerCaseIds = (casesData || []).map(c => c.id);
            if (customerCaseIds.length > 0) {
                const [filesData, evalData] = await Promise.all([
                    CaseFile.filter({ case_id: { $in: customerCaseIds } }),
                    MediaEvaluation.filter({ case_id: { $in: customerCaseIds } })
                ]);
                setFiles(filesData || []);
                setEvaluations(evalData || []);
            }

        } catch (err) {
            console.error('Failed to fetch client portal data:', err);
            setError('Failed to load your data. Please try again later.');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, [location.search]);

    const handleQuoteAction = async (quoteId, action) => {
        try {
            const newStatus = action === 'approve' ? 'Accepted' : 'Rejected';
            const updateData = { 
                status: newStatus,
                ...(action === 'approve' && { approved_date: new Date().toISOString() }),
                ...(action === 'reject' && { rejected_date: new Date().toISOString() })
            };
            await Quote.update(quoteId, updateData);

            // Refresh quotes
            const updatedQuotes = await Quote.filter({ customer_id: customer.id }, '-created_date');
            setQuotes(updatedQuotes);

            alert(`Quote ${action === 'approve' ? 'approved' : 'rejected'} successfully!`);
        } catch (error) {
            console.error(`Failed to ${action} quote:`, error);
            alert(`Failed to ${action} quote. Please try again.`);
        }
    };

    const formatCurrency = (amount) => {
        if (amount === null || amount === undefined) return 'N/A';
        const symbol = localeSettings?.currency_symbol || '$';
        const position = localeSettings?.currency_position || 'before';
        const formattedAmount = Number(amount).toLocaleString(undefined, {
            minimumFractionDigits: localeSettings?.decimal_places || 2,
            maximumFractionDigits: localeSettings?.decimal_places || 2
        });
        return position === 'before' ? `${symbol}${formattedAmount}` : `${formattedAmount} ${symbol}`;
    };

    const getStatusColor = (status) => {
        const colors = {
            'Received': 'bg-blue-100 text-blue-800',
            'In Lab': 'bg-purple-100 text-purple-800',
            'Diagnosis': 'bg-orange-100 text-orange-800',
            'Quoted': 'bg-yellow-100 text-yellow-800',
            'Approved': 'bg-indigo-100 text-indigo-800',
            'In Progress': 'bg-cyan-100 text-cyan-800',
            'Data Ready': 'bg-emerald-100 text-emerald-800',
            'Payment Pending': 'bg-amber-100 text-amber-800',
            'Completed': 'bg-green-100 text-green-800',
            'Closed': 'bg-gray-100 text-gray-800',
            'No Data': 'bg-red-100 text-red-800',
            'Low': 'bg-orange-100 text-orange-800',
            'Medium': 'bg-yellow-100 text-yellow-800',
            'High': 'bg-green-100 text-green-800'
        };
        return colors[status] || 'bg-gray-100 text-gray-800';
    };

    // Helper function to create URLs for print views
    // Assumes print reports are accessible via direct paths from the root
    const createPageUrl = (pathWithQuery) => `/${pathWithQuery}`;

    return (
        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
            {/* Header */}
            <header className="bg-white shadow-sm border-b">
                <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                        <HardDrive className="w-8 h-8 text-blue-600" />
                        <div>
                            <h1 className="text-xl font-bold text-gray-800">Space Recovery</h1>
                            <p className="text-sm text-gray-500">Client Portal</p>
                        </div>
                    </div>
                    {customer && (
                        <div className="text-right">
                            <p className="font-medium text-gray-800">{customer.full_name}</p>
                            <p className="text-sm text-gray-500">{customer.email}</p>
                        </div>
                    )}
                </div>
            </header>

            <main className="max-w-6xl mx-auto px-4 py-6">
                {loading ? (
                    <div className="flex justify-center items-center py-20">
                        <div className="text-center">
                            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                            <p className="text-gray-600">Loading your data...</p>
                        </div>
                    </div>
                ) : error ? (
                    <Card><CardContent className="p-6 text-center text-red-600">{error}</CardContent></Card>
                ) : (
                    <div className="space-y-6">
                        {/* Welcome Section */}
                        <Card className="bg-white shadow-lg">
                            <CardContent className="p-6">
                                <div className="flex items-center space-x-4">
                                    <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
                                        <User className="w-8 h-8 text-blue-600" />
                                    </div>
                                    <div>
                                        <h2 className="text-2xl font-bold text-gray-800">
                                            Welcome, {customer?.full_name}
                                        </h2>
                                        <p className="text-gray-600">
                                            Track your cases, view quotes, and manage your account
                                        </p>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>

                        <Tabs defaultValue="cases" className="w-full">
                            <TabsList className="grid w-full grid-cols-6">
                                <TabsTrigger value="cases">Cases</TabsTrigger>
                                <TabsTrigger value="evaluations">Evaluations</TabsTrigger>
                                <TabsTrigger value="quotes">Quotes</TabsTrigger>
                                <TabsTrigger value="invoices">Invoices</TabsTrigger>
                                <TabsTrigger value="files">Files</TabsTrigger>
                                <TabsTrigger value="communications">Messages</TabsTrigger>
                            </TabsList>

                            <TabsContent value="cases" className="space-y-4">
                                {cases.length === 0 ? (
                                    <Card><CardContent className="p-6 text-center text-gray-500">No cases found.</CardContent></Card>
                                ) : (
                                    cases.map(caseItem => {
                                        // Get quotes for this specific case
                                        const caseQuotes = quotes.filter(q => q.case_id === caseItem.id);
                                        
                                        return (
                                            <Card key={caseItem.id} className="shadow-lg">
                                                <CardHeader>
                                                    <div className="flex justify-between items-start">
                                                        <div>
                                                            <CardTitle className="text-lg">Case #{caseItem.case_number}</CardTitle>
                                                            <p className="text-sm text-gray-500 mt-1">
                                                                {caseItem.service_type} - {caseItem.priority} Priority
                                                            </p>
                                                            <p className="text-xs text-gray-400 mt-1">
                                                                Created: {format(new Date(caseItem.created_date), 'MMM dd, yyyy')}
                                                            </p>
                                                        </div>
                                                        <Badge className={`${getStatusColor(caseItem.status)} px-3 py-1`}>
                                                            {caseItem.status}
                                                        </Badge>
                                                    </div>
                                                </CardHeader>
                                                <CardContent className="pb-6">
                                                    {/* Case Status Tracker with quotes data */}
                                                    {caseItem.client_portal_status_visible !== false && (
                                                        <div className="mb-6">
                                                            <CaseStatusTracker
                                                                currentStatus={caseItem.status}
                                                                caseData={caseItem}
                                                                quotes={caseQuotes}
                                                                showDates={true}
                                                            />
                                                        </div>
                                                    )}

                                                    {/* Device Details */}
                                                    {caseItem.devices && caseItem.devices.length > 0 && (
                                                        <div className="mt-4 border-t pt-4">
                                                            <h4 className="font-medium text-gray-700 mb-2">Device Details:</h4>
                                                            {caseItem.devices.map((device, idx) => (
                                                                <div key={idx} className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg mb-2 last:mb-0">
                                                                    <p><strong>Type:</strong> {device.media_type}</p>
                                                                    {device.brand && <p><strong>Brand:</strong> {device.brand}</p>}
                                                                    {device.media_model && <p><strong>Model:</strong> {device.media_model}</p>}
                                                                    {device.capacity && <p><strong>Capacity:</strong> {device.capacity}</p>}
                                                                    {device.device_status && <p><strong>Status:</strong> {device.device_status}</p>}
                                                                </div>
                                                            ))}
                                                        </div>
                                                    )}

                                                    {/* Problem Description */}
                                                    {caseItem.device_problem && (
                                                        <div className="mt-4 border-t pt-4">
                                                            <h4 className="font-medium text-gray-700">Problem Description:</h4>
                                                            <p className="text-sm text-gray-600 mt-1">{caseItem.device_problem}</p>
                                                        </div>
                                                    )}

                                                    {/* Important Data */}
                                                    {caseItem.important_data && (
                                                        <div className="mt-4 border-t pt-4">
                                                            <h4 className="font-medium text-gray-700">Important Data:</h4>
                                                            <p className="text-sm text-gray-600 mt-1">{caseItem.important_data}</p>
                                                        </div>
                                                    )}
                                                </CardContent>
                                            </Card>
                                        );
                                    })
                                )}
                            </TabsContent>

                            <TabsContent value="evaluations" className="space-y-4">
                                {evaluations.length === 0 ? (
                                    <Card><CardContent className="p-6 text-center text-gray-500">No evaluation reports found.</CardContent></Card>
                                ) : (
                                    evaluations.map(report => (
                                        <Card key={report.id} className="shadow-md">
                                            <CardHeader>
                                                <div className="flex justify-between items-start">
                                                    <CardTitle className="flex items-center gap-2 text-md">
                                                        <FileArchive className="w-5 h-5 text-indigo-600" />
                                                        Evaluation for S/N: {report.device_serial_number}
                                                    </CardTitle>
                                                    <Badge className={getStatusColor(report.recovery_feasibility)}>{report.recovery_feasibility}</Badge>
                                                </div>
                                            </CardHeader>
                                            <CardContent>
                                                <p className="text-sm text-gray-600 mb-4">
                                                    Evaluated by {report.technician_name} on {format(new Date(report.evaluation_date), 'MMM dd, yyyy')}
                                                </p>
                                                <Button 
                                                    onClick={() => window.open(createPageUrl(`PrintEvaluationReport?id=${report.id}`), '_blank')}
                                                >
                                                    <Download className="w-4 h-4 mr-2" />
                                                    View & Download Report
                                                </Button>
                                            </CardContent>
                                        </Card>
                                    ))
                                )}
                            </TabsContent>

                            <TabsContent value="quotes" className="space-y-6">
                                <div className="grid gap-6">
                                    {quotes.length === 0 ? (
                                        <Card><CardContent className="p-6 text-center text-gray-500">No quotes available.</CardContent></Card>
                                    ) : (
                                        quotes.map(quote => (
                                            <Card key={quote.id} className="shadow-md">
                                                <CardHeader>
                                                    <div className="flex items-center justify-between">
                                                        <CardTitle className="flex items-center gap-2">
                                                            <FileText className="w-5 h-5" />
                                                            Quote #{quote.quote_number}
                                                        </CardTitle>
                                                        <Badge variant={quote.status === 'Sent' ? 'default' : 'outline'}>
                                                            {quote.status}
                                                        </Badge>
                                                    </div>
                                                </CardHeader>
                                                <CardContent>
                                                    <div className="space-y-3">
                                                        <div className="flex items-center justify-between">
                                                            <div>
                                                                <p className="text-2xl font-bold text-green-600">
                                                                    {formatCurrency(quote.total_amount)}
                                                                </p>
                                                            </div>
                                                            {quote.status === 'Sent' && (
                                                                <div className="flex gap-3">
                                                                    <Button
                                                                        variant="outline"
                                                                        onClick={() => handleQuoteAction(quote.id, 'reject')}
                                                                        className="text-red-600 border-red-600 hover:bg-red-50"
                                                                    >
                                                                        <XCircle className="w-4 h-4 mr-2" />
                                                                        Reject
                                                                    </Button>
                                                                    <Button
                                                                        onClick={() => handleQuoteAction(quote.id, 'approve')}
                                                                        className="bg-green-600 hover:bg-green-700"
                                                                    >
                                                                        <CheckCircle className="w-4 h-4 mr-2" />
                                                                        Approve
                                                                    </Button>
                                                                </div>
                                                            )}
                                                        </div>
                                                        <div className="text-xs text-gray-500 border-t pt-2 space-y-1">
                                                            <p>Created: {format(new Date(quote.created_date), 'MMM dd, yyyy HH:mm')}</p>
                                                            {quote.sent_date && <p>Sent: {format(new Date(quote.sent_date), 'MMM dd, yyyy HH:mm')}</p>}
                                                            {quote.approved_date && <p className="text-green-600 font-medium">Approved: {format(new Date(quote.approved_date), 'MMM dd, yyyy HH:mm')}</p>}
                                                            {quote.rejected_date && <p className="text-red-600 font-medium">Rejected: {format(new Date(quote.rejected_date), 'MMM dd, yyyy HH:mm')}</p>}
                                                        </div>
                                                    </div>
                                                </CardContent>
                                                <CardFooter>
                                                    <Button variant="outline" size="sm" className="w-full" onClick={() => window.open(createPageUrl(`PrintQuote?id=${quote.id}`), '_blank')}>
                                                        <Download className="w-4 h-4 mr-2" />
                                                        View & Download PDF
                                                    </Button>
                                                </CardFooter>
                                            </Card>
                                        ))
                                    )}
                                </div>
                            </TabsContent>

                            <TabsContent value="invoices" className="space-y-6">
                                <div className="grid gap-6">
                                    {invoices.length === 0 ? (
                                        <Card><CardContent className="p-6 text-center text-gray-500">No invoices available.</CardContent></Card>
                                    ) : (
                                        invoices.map(invoice => (
                                            <Card key={invoice.id} className="shadow-md">
                                                <CardHeader>
                                                    <div className="flex items-center justify-between">
                                                        <CardTitle className="flex items-center gap-2">
                                                            <DollarSign className="w-5 h-5" />
                                                            Invoice #{invoice.invoice_number}
                                                        </CardTitle>
                                                        <Badge variant={invoice.status === 'Paid' ? 'default' : 'outline'}>
                                                            {invoice.status}
                                                        </Badge>
                                                    </div>
                                                </CardHeader>
                                                <CardContent>
                                                    <div className="space-y-3">
                                                        <div className="flex items-center justify-between">
                                                            <div>
                                                                <p className="text-2xl font-bold">
                                                                    {formatCurrency(invoice.total_amount)}
                                                                </p>
                                                                <p className="text-sm text-gray-500">
                                                                    Amount Paid: {formatCurrency(invoice.amount_paid)}
                                                                </p>
                                                            </div>
                                                            <div className="flex gap-3">
                                                                <Button variant="outline">
                                                                    <Download className="w-4 h-4 mr-2" />
                                                                    Download PDF
                                                                </Button>
                                                                {invoice.status !== 'Paid' && (
                                                                    <Button className="bg-blue-600 hover:bg-blue-700">
                                                                        <DollarSign className="w-4 h-4 mr-2" />
                                                                        Pay Now
                                                                    </Button>
                                                                )}
                                                            </div>
                                                        </div>
                                                        <div className="text-xs text-gray-500 border-t pt-2 space-y-1">
                                                            <p>Issued: {format(new Date(invoice.issued_date), 'MMM dd, yyyy')}</p>
                                                            <p>Due: {format(new Date(invoice.due_date), 'MMM dd, yyyy')}</p>
                                                            {invoice.sent_date && <p>Sent: {format(new Date(invoice.sent_date), 'MMM dd, yyyy HH:mm')}</p>}
                                                            {invoice.payments?.map((p, i) => (
                                                                <p key={i} className="text-green-600 font-medium">
                                                                    Paid {formatCurrency(p.amount)} on {format(new Date(p.date), 'MMM dd, yyyy HH:mm')}
                                                                </p>
                                                            ))}
                                                        </div>
                                                    </div>
                                                </CardContent>
                                                <CardFooter>
                                                    <Button variant="outline" size="sm" className="w-full" onClick={() => window.open(createPageUrl(`PrintInvoice?id=${invoice.id}`), '_blank')}>
                                                        <Download className="w-4 h-4 mr-2" />
                                                        View & Download PDF
                                                    </Button>
                                                </CardFooter>
                                            </Card>
                                        ))
                                    )}
                                </div>
                            </TabsContent>

                            <TabsContent value="files" className="space-y-6">
                                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                                    {files.length === 0 ? (
                                        <Card className="col-span-full"><CardContent className="p-6 text-center text-gray-500">No files available.</CardContent></Card>
                                    ) : (
                                        files.map(file => (
                                            <Card key={file.id} className="shadow-md hover:shadow-lg transition-shadow">
                                                <CardContent className="p-4">
                                                    <div className="flex items-center gap-3">
                                                        <FileText className="w-8 h-8 text-blue-600" />
                                                        <div className="flex-1 min-w-0">
                                                            <p className="font-medium text-sm truncate">{file.file_name}</p>
                                                            <p className="text-xs text-gray-500">
                                                                {format(new Date(file.upload_date), 'MMM dd, yyyy')}
                                                            </p>
                                                        </div>
                                                        <Button size="sm" variant="ghost">
                                                            <Download className="w-4 h-4" />
                                                        </Button>
                                                    </div>
                                                </CardContent>
                                            </Card>
                                        ))
                                    )}
                                </div>
                            </TabsContent>

                            <TabsContent value="communications" className="space-y-6">
                                <div className="space-y-4">
                                    {communications.length === 0 ? (
                                        <Card><CardContent className="p-6 text-center text-gray-500">No messages available.</CardContent></Card>
                                    ) : (
                                        communications.map(comm => (
                                            <Card key={comm.id} className="shadow-md">
                                                <CardContent className="p-4">
                                                    <div className="flex items-start gap-3">
                                                        <MessageSquare className="w-5 h-5 text-blue-600 mt-1" />
                                                        <div className="flex-1">
                                                            <div className="flex items-center justify-between mb-2">
                                                                <h4 className="font-semibold">{comm.subject}</h4>
                                                                <div className="flex items-center gap-2">
                                                                    <Badge variant="outline">{comm.type}</Badge>
                                                                    <span className="text-sm text-gray-500">
                                                                        {format(new Date(comm.communication_date), 'MMM dd, yyyy HH:mm')}
                                                                    </span>
                                                                </div>
                                                            </div>
                                                            <p className="text-gray-700">{comm.content}</p>
                                                        </div>
                                                    </div>
                                                </CardContent>
                                            </Card>
                                        ))
                                    )}
                                </div>
                            </TabsContent>
                        </Tabs>
                    </div>
                )}
            </main>
        </div>
    );
}
