import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Clipboard } from 'lucide-react';

const schemasContent = `{
  "Case": {
    "name": "Case",
    "type": "object",
    "properties": {
      "customer_id": { "type": "string" },
      "case_number": { "type": "string", "description": "The unique Job ID" },
      "client_reference": { "type": "string" },
      "service_type": { "type": "string", "enum": ["Data Recovery", "Data Destruction", "Forensic Analysis", "Hardware Repair", "IT Services", "CCTV Installation", "Networking", "System Setup", "Consultation"], "default": "Data Recovery" },
      "status": { "type": "string", "enum": ["Received", "In Lab", "Diagnosis", "Quoted", "Approved", "In Progress", "Data Ready", "Payment Pending", "Shipped", "Returned", "Completed", "Closed", "On-Site", "Scheduled"], "default": "Received" },
      "priority": { "type": "string", "enum": ["Low", "Normal", "High Priority", "Urgent"], "default": "Low" },
      "assigned_engineer": { "type": "string", "description": "The engineer assigned to this case" },
      "welcome_email": { "type": "boolean", "default": true },
      "welcome_sms": { "type": "boolean", "default": false },
      "device_problem": { "type": "string", "description": "Device problem or service requirement" },
      "important_data": { "type": "string", "description": "Important data or service requirements" },
      "service_location": { "type": "string", "enum": ["In Lab", "On-Site", "Remote"], "default": "In Lab" },
      "service_description": { "type": "string", "description": "Detailed description of IT service required" },
      "devices": {
        "type": "array",
        "items": {
          "type": "object",
          "properties": {
            "media_type": { "type": "string" },
            "brand": { "type": "string" },
            "media_model": { "type": "string" },
            "media_serial_number": { "type": "string" },
            "capacity": { "type": "string" },
            "condition": { "type": "string" },
            "role": { "type": "string", "enum": ["Patient", "Backup", "Donor", "Clone"], "default": "Patient" },
            "accessories": { "type": "string" }
          }
        },
        "default": []
      },
      "media_type": { "type": "string" },
      "media_model": { "type": "string" },
      "media_serial_number": { "type": "string" },
      "media_capacity": { "type": "string" },
      "device_password": { "type": "string" }
    },
    "required": ["customer_id", "case_number", "status"]
  },
  "Customer": {
    "name": "Customer",
    "type": "object",
    "properties": {
      "full_name": { "type": "string" },
      "customer_code": { "type": "string" },
      "email": { "type": "string", "format": "email" },
      "phone_number": { "type": "string" },
      "company_name": { "type": "string" },
      "customer_group": { "type": "string" }
    },
    "required": ["full_name", "email"]
  },
  "User": {
    "name": "User",
    "type": "object",
    "properties": {
      "access_role": { "type": "string", "enum": ["Admin", "Technician", "Sales", "Accounts"], "default": "Technician" },
      "avatar_url": { "type": "string" }
    },
    "required": []
  },
  "Quote": {
    "name": "Quote",
    "type": "object",
    "properties": {
        "case_id": { "type": "string" },
        "customer_id": { "type": "string" },
        "quote_number": { "type": "string" },
        "status": { "type": "string", "enum": ["Draft", "Sent", "Accepted", "Rejected"], "default": "Draft" },
        "line_items": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "description": { "type": "string" },
                    "quantity": { "type": "number", "default": 1 },
                    "unit_price": { "type": "number" },
                    "amount": { "type": "number" }
                }
            }
        },
        "total_amount": { "type": "number" }
    },
    "required": ["case_id", "customer_id", "quote_number"]
  },
  "Invoice": {
      "name": "Invoice",
      "type": "object",
      "properties": {
          "case_id": { "type": "string" },
          "customer_id": { "type": "string" },
          "invoice_number": { "type": "string" },
          "status": { "type": "string", "enum": ["Draft", "Sent", "Unpaid", "Partially Paid", "Paid", "Overdue"], "default": "Unpaid" },
          "line_items": { "type": "array", "items": { "type": "object", "properties": { "description": { "type": "string" }, "quantity": { "type": "number", "default": 1 }, "unit_price": { "type": "number" }, "amount": { "type": "number" } } } },
          "total_amount": { "type": "number" },
          "amount_paid": { "type": "number", "default": 0 },
          "balance_due": { "type": "number" },
          "issued_date": { "type": "string", "format": "date" },
          "due_date": { "type": "string", "format": "date" }
      },
      "required": ["case_id", "customer_id", "invoice_number"]
  },
  "Setting": {
      "name": "Setting",
      "type": "object",
      "properties": {
          "category": { "type": "string" },
          "value": { "type": "string" },
          "numeric_value": { "type": "number" },
          "display_order": { "type": "number", "default": 0 },
          "is_active": { "type": "boolean", "default": true }
      },
      "required": ["category", "value"]
  }
}
`;

const openapiContent = \`
openapi: 3.0.3
info:
  title: Space Recovery Suite - Self-Hosted API
  description: This OpenAPI specification outlines the API needed to power the Space Recovery Suite frontend. It's designed to be implemented by a self-hosted backend (e.g., Node.js/Express).
  version: 1.0.0
servers:
  - url: https://your-backend-domain.com/api/v1
    description: Production Server
components:
  securitySchemes:
    bearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT
  schemas:
    Case:
      type: object
      properties:
        id: { type: string, format: uuid, readOnly: true }
        created_date: { type: string, format: date-time, readOnly: true }
        updated_date: { type: string, format: date-time, readOnly: true }
        created_by: { type: string, readOnly: true }
        customer_id: { type: string, format: uuid }
        case_number: { type: string }
        status: { type: string, enum: ["Received", "In Lab", "Diagnosis", "Quoted", "Approved", "In Progress", "Data Ready", "Payment Pending", "Shipped", "Returned", "Completed", "Closed", "On-Site", "Scheduled"] }
        priority: { type: string, enum: ["Low", "Normal", "High Priority", "Urgent"] }
        assigned_engineer: { type: string, format: email }
    Customer:
      type: object
      properties:
        id: { type: string, format: uuid, readOnly: true }
        full_name: { type: string }
        email: { type: string, format: email }
security:
  - bearerAuth: []
paths:
  /auth/login:
    post:
      summary: User Login
      requestBody:
        required: true
        content:
          application/json:
            schema:
              type: object
              properties:
                email: { type: string, format: email }
                password: { type: string }
      responses:
        '200':
          description: Login successful
          content:
            application/json:
              schema:
                type: object
                properties:
                  token: { type: string }
  /cases:
    get:
      summary: List Cases
      parameters:
        - { name: status, in: query, schema: { type: string } }
        - { name: sortBy, in: query, schema: { type: string, default: "-created_date" } }
        - { name: limit, in: query, schema: { type: integer, default: 20 } }
        - { name: page, in: query, schema: { type: integer, default: 1 } }
      responses:
        '200': { description: A paginated list of cases }
    post:
      summary: Create Case
      responses:
        '201': { description: Case created }
  /cases/{id}:
    get:
      summary: Get Case by ID
      parameters: [ { name: id, in: path, required: true, schema: { type: string, format: uuid } } ]
      responses:
        '200': { description: Case data }
    put:
      summary: Update Case
      parameters: [ { name: id, in: path, required: true, schema: { type: string, format: uuid } } ]
      responses:
        '200': { description: Case updated }
    delete:
      summary: Delete Case
      parameters: [ { name: id, in: path, required: true, schema: { type: string, format: uuid } } ]
      responses:
        '204': { description: Case deleted }
\`;

const guideContent = \`
# Self-Hosting Migration Guide
This guide provides recommendations for replicating Base44 platform features in your self-hosted environment.

## 1. Authentication
- **Current Method**: \`User.me()\`, \`User.loginWithRedirect()\`
- **Recommendation**: JWT (JSON Web Tokens).
  - **Backend**: Implement a \`/api/auth/login\` endpoint that validates credentials and returns a signed JWT. Use middleware to protect all other endpoints.
  - **Frontend**: Create a login page. Store the received JWT in \`localStorage\`. Modify your API service layer to include the \`Authorization: Bearer <token>\` header.

## 2. RBAC
- **Current Method**: User entity has an \`access_role\` property.
- **Recommendation**: Your JWT payload should include the user's role. API middleware should check this role against the required permissions for the endpoint.

## 3. File Uploads
- **Current Method**: \`UploadFile\` integration.
- **Recommendation**:
  - **Backend**: Use a library like **\`multer\`** for Express.js. Create a \`POST /api/upload\` endpoint.
  - **Frontend**: Replace calls to \`UploadFile\` with a \`fetch\` call to your new endpoint.

## 4. Email
- **Current Method**: \`SendEmail\` integration.
- **Recommendation**:
  - **Backend**: Use a library like **\`Nodemailer\`**. Store SMTP credentials in a \`.env\` file. The backend sends all emails.

## 5. Search, Sort, and Pagination
- **Current Method**: \`Case.filter(filters, sort, limit, offset)\`
- **Recommendation**:
  - **Backend**: Accept query parameters like \`?status=Open&sortBy=-created_date&limit=20&page=1\`. Translate these into SQL \`WHERE\`, \`ORDER BY\`, \`LIMIT\`, and \`OFFSET\` clauses.
\`;


const BlueprintCard = ({ title, content }) => {
  const copyToClipboard = () => {
    navigator.clipboard.writeText(content);
    // You can add a toast notification here to confirm copy
  };

  return (
    <Card className="mb-8">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>{title}</CardTitle>
        <Button variant="outline" size="sm" onClick={copyToClipboard}>
          <Clipboard className="w-4 h-4 mr-2" />
          Copy
        </Button>
      </CardHeader>
      <CardContent>
        <Textarea readOnly value={content} className="h-[400px] font-mono text-xs bg-gray-50" />
      </CardContent>
    </Card>
  );
};

export default function MigrationPage() {
  return (
    <div className="p-8 bg-gray-100 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-800">Migration Blueprints</h1>
            <p className="text-gray-600 mt-2">This page contains the necessary assets and guides for migrating your application to a self-hosted environment. Copy the content from each section and provide it to your development team.</p>
        </div>
        
        <BlueprintCard title="Entity Schemas (schemas.json)" content={schemasContent} />
        <BlueprintCard title="API Specification (openapi.yaml)" content={openapiContent} />
        <BlueprintCard title="Self-Hosting Guide (guide.md)" content={guideContent} />
        
      </div>
    </div>
  );
}