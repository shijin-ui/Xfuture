
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Setting } from '@/api/entities';
import { User } from '@/api/entities';
import { Case } from '@/api/entities';
import { Customer } from '@/api/entities';
import { Quote } from '@/api/entities';
import { Invoice } from '@/api/entities';
import { JobHistory } from '@/api/entities';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Settings as SettingsIcon, Plus, Search, HardDrive, Briefcase, Users, DollarSign, ListChecks, ArrowRight, Edit, Trash2, AlertTriangle, CheckCircle, Loader2, Globe, Archive, Download, FileText, Database } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const groupedCategories = [
    {
        groupName: 'Device & Media',
        icon: HardDrive,
        color: 'from-blue-500 to-cyan-600',
        categories: ['Device Types', 'Brands', 'Capacities', 'Accessories', 'Device Conditions', 'Device Roles', 'Device Interface', 'Device Made In', 'Device Encryption', 'Device Platter No', 'Device Head No']
    },
    {
        groupName: 'Case & Service',
        icon: Briefcase,
        color: 'from-emerald-500 to-teal-600',
        categories: ['Service Types', 'Service Problems', 'Case Priorities', 'Case Statuses', 'Service Locations']
    },
    {
        groupName: 'Client & Financial',
        icon: Users,
        color: 'from-purple-500 to-indigo-600',
        categories: ['Customer Groups', 'Industries', 'Expense Categories', 'Quote Statuses', 'Invoice Statuses', 'Proforma Invoice Statuses', 'Invoice Line Items', 'Quote Line Items', 'Proforma Invoice Line Items', 'Quote Terms']
    },
    {
        groupName: 'System & Numbers',
        icon: ListChecks,
        color: 'from-indigo-500 to-purple-600',
        categories: ['Number Sequences']
    },
    {
        groupName: 'General',
        icon: ListChecks,
        color: 'from-orange-500 to-red-600',
        categories: ['Countries', 'Cities', 'Communication Types']
    },
    {
        groupName: 'Localization',
        icon: Globe,
        color: 'from-cyan-500 to-blue-600',
        categories: ['Accounting Locales']
    },
    {
        groupName: 'Company Details',
        icon: SettingsIcon,
        color: 'from-gray-500 to-slate-600',
        categories: ['Company Profile']
    },
    {
        groupName: 'Migration & Export',
        icon: Archive,
        color: 'from-red-500 to-pink-600',
        categories: ['Migration'],
        adminOnly: true
    },
    {
        groupName: 'Audit Report',
        icon: FileText,
        color: 'from-green-500 to-emerald-600',
        categories: ['Audit Report'],
        adminOnly: true
    }
];

const allCategories = groupedCategories.flatMap(g => g.categories);

const CategoryCard = ({ group, settingsCount, onCategorySelect }) => {
    const totalCount = group.categories.reduce((sum, cat) => sum + (settingsCount[cat] || 0), 0);

    return (
        <Card className="group hover:shadow-xl transition-all duration-300 cursor-pointer border-0 shadow-lg overflow-hidden">
            <div className={`h-2 bg-gradient-to-r ${group.color}`}></div>
            <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                    <div className={`p-3 rounded-xl bg-gradient-to-r ${group.color} shadow-lg`}>
                        <group.icon className="w-6 h-6 text-white" />
                    </div>
                    <Badge variant="secondary" className="text-sm px-3 py-1">
                        {totalCount} items
                    </Badge>
                </div>
                <h3 className="text-lg font-semibold text-gray-800 mb-3">{group.groupName}</h3>

                <Button
                    variant="ghost"
                    className="w-full group-hover:bg-gray-100 transition-colors"
                    onClick={() => onCategorySelect(group)}
                >
                    Manage Categories
                    <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
            </CardContent>
        </Card>
    );
};

const CategoryDetailView = ({ settings, onAdd, onEdit, onDelete, category, showDefaultAmount }) => {
    const settingsForCategory = useMemo(() => {
        return settings.filter(s => s.category === category).sort((a, b) => (a.display_order || 0) - (b.display_order || 0));
    }, [settings, category]);

    return (
        <Card>
            <CardHeader>
                <CardTitle className="flex justify-between items-center">
                    <span>{category} ({settingsForCategory.length})</span>
                    <Button size="sm" onClick={() => onAdd(category)}>
                        <Plus className="w-4 h-4 mr-2" />
                        Add New
                    </Button>
                </CardTitle>
            </CardHeader>
            <CardContent>
                {settingsForCategory.length > 0 ? (
                    <div className="space-y-2">
                        <div className="grid grid-cols-12 gap-4 py-3 px-4 bg-gray-100 rounded-lg font-semibold text-sm text-gray-700">
                            <div className="col-span-2 text-center">Order</div>
                            <div className="col-span-5">Value</div>
                            {showDefaultAmount && <div className="col-span-2 text-right">Default Price</div>}
                            <div className="col-span-3 text-center">Actions</div>
                        </div>

                        {settingsForCategory.map(setting => (
                            <div key={setting.id} className="grid grid-cols-12 gap-4 items-center py-4 px-4 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                                <div className="col-span-2 text-center">
                                    <Badge variant="outline" className="text-sm font-mono">
                                        {setting.display_order || 0}
                                    </Badge>
                                </div>
                                <div className="col-span-5 font-medium text-gray-800">
                                    {setting.value}
                                </div>
                                {showDefaultAmount &&
                                    <div className="col-span-2 font-mono text-right text-gray-600">
                                        {(setting.default_amount || 0).toFixed(3)} OMR
                                    </div>
                                }
                                <div className="col-span-3 flex justify-center space-x-2">
                                    <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => onEdit(setting)}
                                        className="h-8 w-8 p-0 hover:bg-blue-100"
                                    >
                                        <Edit className="w-4 h-4 text-blue-600" />
                                    </Button>
                                    <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => onDelete(setting.id)}
                                        className="h-8 w-8 p-0 hover:bg-red-100"
                                    >
                                        <Trash2 className="w-4 h-4 text-red-500" />
                                    </Button>
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-12 text-gray-500 bg-gray-50 rounded-lg">
                        <ListChecks className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                        <p className="text-lg font-medium mb-1">No options found</p>
                        <p className="text-sm">Add your first option for this category</p>
                    </div>
                )}
            </CardContent>
        </Card>
    );
};

const NumberSequenceManager = ({ settings, onRefresh, category }) => {
    const [editingSequence, setEditingSequence] = useState(null);
    const [isInitializing, setIsInitializing] = useState(false);
    const [verificationStep, setVerificationStep] = useState(0);
    const [verificationCode, setVerificationCode] = useState('');
    const [generatedCode, setGeneratedCode] = useState('');
    const [confirmationText, setConfirmationText] = useState('');
    const [isCleaningDuplicates, setIsCleaningDuplicates] = useState(false);

    // Process settings to remove duplicates before rendering
    const sequences = useMemo(() => {
        if (!settings) return [];

        const sequencesMap = new Map();

        settings
            .filter(s => s.category === 'Number Sequences')
            .forEach(s => {
                const existing = sequencesMap.get(s.value);
                if (!existing || (s.numeric_value || 0) > (existing.numeric_value || 0)) {
                    sequencesMap.set(s.value, s);
                }
            });

        return Array.from(sequencesMap.values());
    }, [settings]);

    // Standardized number sequences (all use "Number" naming)
    const defaultSequences = [
        { value: 'Case Number', numeric_value: 25449, description: 'Last assigned case number' },
        { value: 'Quote Number', numeric_value: 1000, description: 'Last assigned quote number' },
        { value: 'Invoice Number', numeric_value: 1000, description: 'Last assigned invoice number' },
        { value: 'Proforma Invoice Number', numeric_value: 1000, description: 'Last assigned proforma invoice number' },
        { value: 'Asset Number', numeric_value: 1000, description: 'Last assigned asset number' },
        { value: 'Inventory Number', numeric_value: 1000, description: 'Last assigned inventory item number' },
        { value: 'Expense Number', numeric_value: 1000, description: 'Last assigned expense number' },
        { value: 'Transfer Number', numeric_value: 1000, description: 'Last assigned bank transfer number' },
        { value: 'Deposit Number', numeric_value: 1000, description: 'Last assigned bank deposit number' },
        { value: 'Customer Number', numeric_value: 10000, description: 'Last assigned customer number' },
        { value: 'Company Number', numeric_value: 10000, description: 'Last assigned company number' },
        { value: 'Supplier Number', numeric_value: 10000, description: 'Last assigned supplier number' },
        { value: 'Stock Number', numeric_value: 10000, description: 'Last assigned stock item number' },
        { value: 'PO Number', numeric_value: 10000, description: 'Last assigned purchase order number' },
        { value: 'Employee Number', numeric_value: 10000, description: 'Last assigned employee number' },
        { value: 'User Number', numeric_value: 10000, description: 'Last assigned user number' },
        { value: 'Document Number', numeric_value: 10000, description: 'Last assigned document number' }
    ];

    const missingSequences = defaultSequences.filter(
        defaultSeq => !sequences.some(s => s.value === defaultSeq.value)
    );

    const initializeSequences = async () => {
        setIsInitializing(true);
        try {
            const existingSequencesFromDB = await Setting.filter({ category: 'Number Sequences' });
            const existingValues = new Set(existingSequencesFromDB.map(s => s.value));

            for (const seq of defaultSequences) {
                if (!existingValues.has(seq.value)) {
                    await Setting.create({
                        category: 'Number Sequences',
                        value: seq.value,
                        numeric_value: seq.numeric_value,
                        description: seq.description,
                        display_order: defaultSequences.indexOf(seq)
                    });
                }
            }
            onRefresh();
        } catch (error) {
            console.error('Failed to initialize sequences:', error);
        } finally {
            setIsInitializing(false);
        }
    };

    // NEW: Function to specifically clean up Code/Number duplicates
    const cleanupCodeNumberDuplicates = async () => {
        setIsCleaningDuplicates(true);
        try {
            let allNumberSequences = await Setting.filter({ category: 'Number Sequences' });

            // Map of old "Code" names to new "Number" names
            const codeToNumberMapping = {
                'Customer Code': 'Customer Number',
                'Company Code': 'Company Number',
                'Supplier Code': 'Supplier Number',
                'Employee Code': 'Employee Number',
                'Asset Code': 'Asset Number',
                'Inventory Code': 'Inventory Number'
            };

            let deletedCount = 0;
            let updatedCount = 0;

            // First pass: Handle Code -> Number migrations
            for (const [oldCodeName, newNumberName] of Object.entries(codeToNumberMapping)) {
                const codeEntries = allNumberSequences.filter(s => s.value === oldCodeName);
                const numberEntries = allNumberSequences.filter(s => s.value === newNumberName);

                if (codeEntries.length > 0 && numberEntries.length === 0) {
                    // Migrate: Rename Code to Number
                    const bestCodeEntry = codeEntries.reduce((max, s) =>
                        ((s.numeric_value || 0) > (max.numeric_value || 0) ? s : max), codeEntries[0]);

                    if (bestCodeEntry) { // Ensure there is an entry to update
                        await Setting.update(bestCodeEntry.id, {
                            value: newNumberName,
                            description: `Last assigned ${newNumberName.toLowerCase()}`
                        });
                        updatedCount++;

                        // Delete other code entries
                        for (const codeEntry of codeEntries) {
                            if (codeEntry.id !== bestCodeEntry.id) {
                                await Setting.delete(codeEntry.id);
                                deletedCount++;
                            }
                        }
                    }
                } else if (codeEntries.length > 0 && numberEntries.length > 0) {
                    // Both exist: Keep the Number entry with highest value, delete all Code entries
                    const bestNumberEntry = numberEntries.reduce((max, s) =>
                        ((s.numeric_value || 0) > (max.numeric_value || 0) ? s : max), numberEntries[0]);
                    const bestCodeEntry = codeEntries.reduce((max, s) =>
                        ((s.numeric_value || 0) > (max.numeric_value || 0) ? s : max), codeEntries[0]);

                    if (bestNumberEntry && bestCodeEntry) { // Ensure both entries exist
                        // If code entry has higher number, update the number entry
                        if ((bestCodeEntry.numeric_value || 0) > (bestNumberEntry.numeric_value || 0)) {
                            await Setting.update(bestNumberEntry.id, {
                                numeric_value: bestCodeEntry.numeric_value
                            });
                            updatedCount++;
                        }

                        // Delete all code entries
                        for (const codeEntry of codeEntries) {
                            await Setting.delete(codeEntry.id);
                            deletedCount++;
                        }

                        // Delete duplicate number entries (keep only the best one)
                        for (const numberEntry of numberEntries) {
                            if (numberEntry.id !== bestNumberEntry.id) {
                                await Setting.delete(numberEntry.id);
                                deletedCount++;
                            }
                        }
                    }
                }
            }

            // After potential migrations, re-fetch all sequences to get the current state
            allNumberSequences = await Setting.filter({ category: 'Number Sequences' });

            // Second pass: Clean up regular duplicates (same name, multiple entries)
            const groupedSequences = {};

            allNumberSequences.forEach(seq => {
                if (!groupedSequences[seq.value]) {
                    groupedSequences[seq.value] = [];
                }
                groupedSequences[seq.value].push(seq);
            });

            for (const [sequenceName, sequenceArray] of Object.entries(groupedSequences)) {
                if (sequenceArray.length > 1) {
                    // Sort by numeric_value descending, keep first (highest)
                    const sorted = sequenceArray.sort((a, b) => (b.numeric_value || 0) - (a.numeric_value || 0));
                    const toKeep = sorted[0];
                    const toDelete = sorted.slice(1);

                    console.log(`Cleaning ${sequenceName}: Keeping ID ${toKeep.id} (value: ${toKeep.numeric_value}), deleting ${toDelete.length} duplicates`);

                    // Delete the duplicates
                    for (const duplicate of toDelete) {
                        await Setting.delete(duplicate.id);
                        deletedCount++;
                    }
                }
            }

            alert(`Cleanup complete!\n- Deleted ${deletedCount} duplicate/old entries\n- Updated ${updatedCount} entries\n- All sequences now use standardized "Number" naming`);
            onRefresh();
        } catch (error) {
            console.error('Failed to cleanup duplicates:', error);
            alert('Failed to cleanup duplicates. Please try again.');
        } finally {
            setIsCleaningDuplicates(false);
        }
    };

    const generateVerificationCode = () => {
        return Math.floor(100000 + Math.random() * 900000).toString();
    };

    const handleEditClick = (sequence) => {
        const code = generateVerificationCode();
        setEditingSequence({...sequence});
        setGeneratedCode(code);
        setVerificationStep(1);
        setVerificationCode('');
        setConfirmationText('');

        alert(`Verification Required!\n\nTo modify the "${sequence.value}", please enter this code in the next step:\n\n${code}\n\nThis is a security measure to protect critical business data.`);
    };

    const handleVerificationStep1 = () => {
        if (verificationCode !== generatedCode) {
            alert('Invalid verification code. Please check the code and try again.');
            return;
        }
        setVerificationStep(2);
    };

    const handleVerificationStep2 = () => {
        const expectedText = `CHANGE ${editingSequence?.value?.toUpperCase()}`;
        if (confirmationText.toUpperCase() !== expectedText) {
            alert(`Confirmation text doesn't match. Please type exactly: ${expectedText}`);
            return;
        }
        setVerificationStep(3);
    };

    const handleUpdateSequence = async () => {
        if (!editingSequence) return;

        try {
            const currentDbSequence = await Setting.get(editingSequence.id);

            if (editingSequence.numeric_value < currentDbSequence.numeric_value) {
                alert(`Error: The new number (${editingSequence.numeric_value}) cannot be less than the current stored number (${currentDbSequence.numeric_value}) for "${editingSequence.value}". This is to prevent data conflicts.`);
                setEditingSequence(currentDbSequence);
                return;
            }

            await Setting.update(editingSequence.id, {
                numeric_value: editingSequence.numeric_value
            });

            setEditingSequence(null);
            setVerificationStep(0);
            setVerificationCode('');
            setGeneratedCode('');
            setConfirmationText('');

            onRefresh();
            alert(`${editingSequence.value} has been successfully updated!`);
        } catch (error) {
            console.error('Failed to update sequence:', error);
            alert('Failed to update number sequence');
        }
    };

    const handleCloseDialog = () => {
        setEditingSequence(null);
        setVerificationStep(0);
        setVerificationCode('');
        setGeneratedCode('');
        setConfirmationText('');
    };

    const showInitializationPrompt = sequences.length === 0 || missingSequences.length > 0;

    const hasCodeNumberDuplicates = useMemo(() => {
        const allNumberSettings = settings?.filter(s => s.category === 'Number Sequences') || [];
        const codeNames = ['Customer Code', 'Company Code', 'Supplier Code', 'Employee Code', 'Asset Code', 'Inventory Code'];

        // Check for presence of 'Code' names
        if (allNumberSettings.some(s => codeNames.includes(s.value))) {
            return true;
        }

        // Check for generic duplicates (multiple entries for the same 'Number' name)
        const counts = {};
        for (const s of allNumberSettings) {
            counts[s.value] = (counts[s.value] || 0) + 1;
        }
        return Object.values(counts).some(count => count > 1);
    }, [settings]);


    return (
        <>
            {hasCodeNumberDuplicates && (
                <div className="text-center py-4 bg-red-50 border-2 border-red-200 rounded-lg mb-4">
                    <h3 className="text-lg font-semibold text-red-800 mb-2">⚠️ Code/Number Duplicates Detected</h3>
                    <p className="text-sm text-red-700 mb-4">
                        There are old "Code" based sequences (e.g., Customer Code) and/or duplicate number sequence records in the database.
                        This action will standardize all sequences to use "Number" naming and remove any exact duplicates,
                        keeping the highest numeric value.
                    </p>
                    <Button
                        onClick={cleanupCodeNumberDuplicates}
                        disabled={isCleaningDuplicates}
                        className="bg-red-600 hover:bg-red-700"
                    >
                        {isCleaningDuplicates ? 'Cleaning...' : 'Clean Up Code/Number Duplicates'}
                    </Button>
                </div>
            )}

            {showInitializationPrompt && (
                <div className="text-center py-6 bg-blue-50 border-2 border-dashed border-blue-200 rounded-lg mb-6">
                    <div className="mb-4">
                        <ListChecks className="w-12 h-12 mx-auto text-blue-400 mb-3" />
                        <h3 className="text-lg font-semibold text-gray-800 mb-2">
                            {sequences.length === 0 ? "Number Sequences Not Initialized" : "Missing System Sequences"}
                        </h3>
                        <p className="text-gray-600 mb-4 px-4 max-w-2xl mx-auto">
                            {sequences.length === 0
                                ? "Initialize the system number sequences for Cases, Quotes, Invoices, Proforma Invoices, Assets, Inventory, Expenses, Transfers, and Deposits."
                                : `The following sequences are missing: ${missingSequences.map(s => s.value).join(', ')}. Initialize them to ensure proper system functionality.`
                            }
                        </p>
                    </div>
                    <Button onClick={initializeSequences} disabled={isInitializing}>
                        {isInitializing ? 'Initializing...' : (sequences.length === 0 ? 'Initialize All Sequences' : 'Initialize Missing Sequences')}
                    </Button>
                </div>
            )}

            <div className="space-y-2 mb-4">
                <div className="grid grid-cols-12 gap-4 py-3 px-4 bg-gradient-to-r from-indigo-100 to-purple-100 rounded-lg font-semibold text-sm text-gray-700">
                    <div className="col-span-4">Sequence Type</div>
                    <div className="col-span-3 text-center">Current Number</div>
                    <div className="col-span-3 text-center">Next Number</div>
                    <div className="col-span-2 text-center">Actions</div>
                </div>

                {sequences
                    .sort((a, b) => (a.display_order || 0) - (b.display_order || 0))
                    .map(sequence => (
                        <div key={sequence.id} className="grid grid-cols-12 gap-4 items-center py-4 px-4 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                            <div className="col-span-4">
                                <div className="font-semibold text-gray-800">{sequence.value}</div>
                                {sequence.description && (
                                    <div className="text-xs text-gray-500 mt-1">{sequence.description}</div>
                                )}
                            </div>
                            <div className="col-span-3 text-center">
                                <Badge variant="outline" className="text-lg font-mono px-3 py-1">
                                    {sequence.numeric_value || 0}
                                </Badge>
                            </div>
                            <div className="col-span-3 text-center">
                                <Badge className="bg-green-100 text-green-800 text-lg font-mono px-3 py-1">
                                    {(sequence.numeric_value || 0) + 1}
                                </Badge>
                            </div>
                            <div className="col-span-2 text-center">
                                <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => handleEditClick(sequence)}
                                    className="h-8 w-8 p-0 hover:bg-blue-100"
                                >
                                    <Edit className="w-4 h-4 text-blue-600" />
                                </Button>
                            </div>
                        </div>
                    ))}
            </div>

            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mt-4">
                <div className="flex items-start">
                    <div className="flex-shrink-0">
                        <svg className="w-5 h-5 text-yellow-600 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                        </svg>
                    </div>
                    <div className="ml-3">
                        <h3 className="text-sm font-medium text-yellow-800">Important Note</h3>
                        <p className="text-sm text-yellow-700 mt-1">
                            These numbers represent the last assigned values. The system will automatically use the next number when creating new cases, quotes, invoices, assets, inventory items, transfers, or deposits. Only modify these if you need to adjust the sequence.
                        </p>
                    </div>
                </div>
            </div>

            {/* Two-Step Verification Dialog */}
            <Dialog open={verificationStep > 0} onOpenChange={handleCloseDialog}>
                <DialogContent>
                    {verificationStep === 1 && (
                        <>
                            <DialogHeader>
                                <DialogTitle className="flex items-center text-red-600">
                                    <AlertTriangle className="w-6 h-6 mr-2" />
                                    Security Verification Required
                                </DialogTitle>
                            </DialogHeader>
                            <div className="py-4 space-y-4">
                                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                                    <h3 className="font-semibold text-red-800 mb-2">⚠️ Critical System Change</h3>
                                    <p className="text-sm text-red-700">
                                        You are about to modify <strong>{editingSequence?.value}</strong>.
                                        This affects business operations and audit trails.
                                    </p>
                                </div>

                                <div>
                                    <Label>Enter the 6-digit verification code shown in the alert:</Label>
                                    <Input
                                        type="text"
                                        value={verificationCode}
                                        onChange={(e) => setVerificationCode(e.target.value)}
                                        placeholder="Enter 6-digit code"
                                        className="text-center text-lg font-mono tracking-wider"
                                        maxLength={6}
                                    />
                                    <p className="text-xs text-gray-500 mt-1">
                                        Code was displayed in the previous alert popup.
                                    </p>
                                </div>
                            </div>
                            <DialogFooter>
                                <Button variant="outline" onClick={handleCloseDialog}>Cancel</Button>
                                <Button
                                    onClick={handleVerificationStep1}
                                    disabled={verificationCode.length !== 6}
                                    className="bg-blue-600 hover:bg-blue-700"
                                >
                                    Verify Code
                                </Button>
                            </DialogFooter>
                        </>
                    )}

                    {verificationStep === 2 && (
                        <>
                            <DialogHeader>
                                <DialogTitle className="flex items-center text-orange-600">
                                    <AlertTriangle className="w-6 h-6 mr-2" />
                                    Final Confirmation Required
                                </DialogTitle>
                            </DialogHeader>
                            <div className="py-4 space-y-4">
                                <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                                    <h3 className="font-semibold text-orange-800 mb-2">🔐 Step 2 of 2</h3>
                                    <p className="text-sm text-orange-700">
                                        To confirm this critical change, please type the exact phrase below:
                                    </p>
                                    <div className="mt-3 p-2 bg-white border rounded text-center font-mono font-bold">
                                        CHANGE {editingSequence?.value?.toUpperCase()}
                                    </div>
                                </div>

                                <div>
                                    <Label>Type the confirmation phrase exactly:</Label>
                                    <Input
                                        type="text"
                                        value={confirmationText}
                                        onChange={(e) => setConfirmationText(e.target.value)}
                                        placeholder={`Type: CHANGE ${editingSequence?.value?.toUpperCase()}`}
                                        className="text-center font-mono"
                                    />
                                </div>
                            </div>
                            <DialogFooter>
                                <Button variant="outline" onClick={handleCloseDialog}>Cancel</Button>
                                <Button
                                    onClick={handleVerificationStep2}
                                    disabled={confirmationText.toUpperCase() !== `CHANGE ${editingSequence?.value?.toUpperCase()}`}
                                    className="bg-orange-600 hover:bg-orange-700"
                                >
                                    Confirm Change
                                </Button>
                            </DialogFooter>
                        </>
                    )}

                    {verificationStep === 3 && (
                        <>
                            <DialogHeader>
                                <DialogTitle>Edit {editingSequence?.value}</DialogTitle>
                            </DialogHeader>
                            {editingSequence && (
                                <div className="py-4 space-y-4">
                                    <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                                        <p className="text-sm text-green-700 flex items-center">
                                            <CheckCircle className="w-4 h-4 mr-2" />
                                            Verification completed successfully
                                        </p>
                                    </div>

                                    <div>
                                        <Label>Current Number</Label>
                                        <Input
                                            type="number"
                                            value={editingSequence.numeric_value || 0}
                                            onChange={(e) => setEditingSequence({
                                                ...editingSequence,
                                                numeric_value: parseInt(e.target.value) || 0
                                            })}
                                        />
                                        <p className="text-xs text-gray-500 mt-1">
                                            Next {editingSequence.value.toLowerCase()} will be: <strong>{(editingSequence.numeric_value || 0) + 1}</strong>
                                        </p>
                                    </div>

                                    <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                                        <p className="text-xs text-yellow-800">
                                            <strong>Important:</strong> This change will affect all future {editingSequence.value.toLowerCase()}s.
                                            Make sure this number is correct to avoid conflicts.
                                        </p>
                                    </div>
                                </div>
                            )}
                            <DialogFooter>
                                <Button variant="outline" onClick={handleCloseDialog}>Cancel</Button>
                                <Button
                                    onClick={handleUpdateSequence}
                                    className="bg-red-600 hover:bg-red-700"
                                >
                                    Save Changes
                                </Button>
                            </DialogFooter>
                        </>
                    )}
                </DialogContent>
            </Dialog>
        </>
    );
};

const createPageUrl = (pageName) => {
    if (pageName === 'Company Profile') {
        return '/CompanyProfile';
    }
    if (pageName === 'Accounting Locales') {
        return '/AccountingSettings';
    }
    if (pageName === 'Migration') {
        return '/MigrationExport';
    }
    if (pageName === 'Audit Report') {
        return '/AuditReport';
    }
    return '/';
};

const CategoryManagement = ({ group, settings, onBack, onRefresh }) => {
    const [activeCategory, setActiveCategory] = useState(group.categories[0]);
    const [editingSetting, setEditingSetting] = useState(null);
    const [showBulkAddDialog, setShowBulkAddDialog] = useState(false);
    const [bulkAddValues, setBulkAddValues] = useState('');
    const [isBulkAdding, setIsBulkAdding] = useState(false);
    const [isExporting, setIsExporting] = useState(false); // Declared here
    const [isGeneratingReport, setIsGeneratingReport] = useState(false); // Declared here

    const showDefaultAmount = ['Invoice Line Items', 'Quote Line Items', 'Proforma Invoice Line Items'].includes(activeCategory);

    // Export functionality
    const exportProjectFiles = async (type) => {
        setIsExporting(true);
        try {
            let data = {};
            let filename = '';

            switch(type) {
                case 'entities':
                    data = {
                        entities: {
                            Case: await Case.schema(),
                            Customer: await Customer.schema(),
                            Quote: await Quote.schema(),
                            Invoice: await Invoice.schema(),
                            Setting: await Setting.schema(),
                        },
                        exported_at: new Date().toISOString(),
                        version: '1.0.0'
                    };
                    filename = 'entities-export.json';
                    break;

                case 'settings':
                    const allSettings = await Setting.list();
                    data = {
                        settings: allSettings,
                        categories: [...new Set(allSettings.map(s => s.category))],
                        exported_at: new Date().toISOString()
                    };
                    filename = 'settings-export.json';
                    break;

                case 'workflows':
                    const workflows = await JobHistory.list('-timestamp', 1000);
                    data = {
                        workflows: workflows,
                        workflow_types: [...new Set(workflows.map(w => w.action_type))],
                        exported_at: new Date().toISOString()
                    };
                    filename = 'workflows-export.json';
                    break;

                case 'full':
                    const [allCases, allCustomers, allQuotes, allInvoices, allSettingsData, allWorkflows] = await Promise.all([
                        Case.list(),
                        Customer.list(),
                        Quote.list(),
                        Invoice.list(),
                        Setting.list(),
                        JobHistory.list('-timestamp', 1000)
                    ]);

                    data = {
                        metadata: {
                            exported_at: new Date().toISOString(),
                            version: '1.0.0',
                            total_records: {
                                cases: allCases.length,
                                customers: allCustomers.length,
                                quotes: allQuotes.length,
                                invoices: allInvoices.length,
                                settings: allSettingsData.length,
                                workflows: allWorkflows.length
                            }
                        },
                        data: {
                            cases: allCases,
                            customers: allCustomers,
                            quotes: allQuotes,
                            invoices: allInvoices,
                            settings: allSettingsData,
                            workflows: allWorkflows
                        },
                        schemas: {
                            Case: await Case.schema(),
                            Customer: await Customer.schema(),
                            Quote: await Quote.schema(),
                            Invoice: await Invoice.schema(),
                            Setting: await Setting.schema()
                        }
                    };
                    filename = 'full-project-export.json';
                    break;
                default:
                    throw new Error('Unknown export type');
            }

            const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);

        } catch (error) {
            console.error('Export failed:', error);
            alert('Export failed. Please try again.');
        } finally {
            setIsExporting(false);
        }
    };

    const generateAuditReportPDF = async () => {
        setIsGeneratingReport(true);
        try {
            const reportWindow = window.open(createPageUrl('Audit Report'), '_blank');

            reportWindow.onload = () => {
                const printStyles = `
                    <style>
                        @media print {
                            .no-print { display: none !important; }
                            body { font-size: 12px; }
                            .card { break-inside: avoid; margin-bottom: 20px; }
                            .prose { max-width: none; }
                        }
                    </style>
                `;
                reportWindow.document.head.insertAdjacentHTML('beforeend', printStyles);

                setTimeout(() => {
                    reportWindow.print();
                }, 1000);
            };

        } catch (error) {
            console.error('Failed to generate audit report:', error);
            alert('Failed to generate audit report. Please try again.');
        } finally {
            setIsGeneratingReport(false);
        }
    };

    const handleBulkAddSettings = async () => {
        if (!bulkAddValues.trim()) {
            alert('Please enter at least one value.');
            return;
        }

        setIsBulkAdding(true);
        const newValues = bulkAddValues.split('\n').map(line => line.trim()).filter(line => line.length > 0);
        const currentCategorySettings = settings.filter(s => s.category === activeCategory);
        let currentMaxOrder = currentCategorySettings.length > 0
            ? Math.max(...currentCategorySettings.map(s => s.display_order || 0))
            : -1; // Start from 0 or highest existing order + 1

        try {
            for (const line of newValues) {
                currentMaxOrder++;
                let value = line;
                let defaultAmount = 0;

                if (showDefaultAmount && line.includes(':')) {
                    const parts = line.split(':');
                    value = parts[0].trim();
                    const amountPart = parts.slice(1).join(':').trim(); // Join back in case amount has colons
                    const parsedAmount = parseFloat(amountPart);
                    if (!isNaN(parsedAmount)) {
                        defaultAmount = parsedAmount;
                    }
                }

                if (value) { // Ensure value is not empty after parsing
                    await Setting.create({
                        category: activeCategory,
                        value: value,
                        display_order: currentMaxOrder,
                        default_amount: defaultAmount,
                        is_active: true // Assuming is_active is true by default for new settings
                    });
                }
            }
            setBulkAddValues('');
            setShowBulkAddDialog(false);
            onRefresh(); // Refresh the list after adding
        } catch (error) {
            console.error('Failed to add settings in bulk:', error);
            alert('Failed to add options. Please try again.');
        } finally {
            setIsBulkAdding(false);
        }
    };

    const handleEditSetting = async () => {
        if (!editingSetting?.value.trim()) {
            alert('Please enter a value');
            return;
        }

        try {
            await Setting.update(editingSetting.id, {
                value: editingSetting.value,
                display_order: editingSetting.display_order,
                default_amount: editingSetting.default_amount,
            });
            setEditingSetting(null);
            onRefresh();
        } catch (error) {
            console.error('Failed to update setting:', error);
            alert('Failed to update setting');
        }
    };

    const handleDeleteSetting = async (settingId) => {
        if (window.confirm('Are you sure you want to delete this setting?')) {
            try {
                await Setting.delete(settingId);
                onRefresh();
            } catch (error) {
                console.error('Failed to delete setting:', error);
                alert('Failed to delete setting.');
            }
        }
    };

    // Direct redirects for specific categories
    if (activeCategory === 'Company Profile') {
        window.location.href = createPageUrl('Company Profile');
        return null;
    }

    if (activeCategory === 'Accounting Locales') {
        window.location.href = createPageUrl('Accounting Locales');
        return null;
    }

    if (activeCategory === 'Migration' && group.groupName === 'Migration & Export') {
        // This handles the specific "Migration" category within "Migration & Export" group
        // If it's the top-level group, we render the specific export UI below
    } else if (activeCategory === 'Migration') {
        // Fallback for unexpected 'Migration' category outside its group, though unlikely
        window.location.href = createPageUrl('Migration');
        return null;
    }

    if (activeCategory === 'Audit Report' && group.groupName === 'Audit Report') {
        // This handles the specific "Audit Report" category within "Audit Report" group
        // If it's the top-level group, we render the specific audit UI below
    } else if (activeCategory === 'Audit Report') {
        // Fallback for unexpected 'Audit Report' category outside its group
        window.location.href = createPageUrl('Audit Report');
        return null;
    }


    if (group.groupName === 'Audit Report') { // Check the group name for specific rendering
        return (
            <div>
                <div className="flex items-center justify-between mb-6">
                    <Button variant="ghost" onClick={onBack} className="p-2">
                        ← Back
                    </Button>
                    <div className="flex items-center space-x-4">
                        <div className={`p-2 rounded-lg bg-gradient-to-r ${group.color}`}>
                            <group.icon className="w-6 h-6 text-white" />
                        </div>
                        <div>
                            <h2 className="text-2xl font-bold text-gray-800">{group.groupName}</h2>
                            <p className="text-gray-500">Generate and download comprehensive audit reports</p>
                        </div>
                    </div>
                    <div></div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card className="shadow-lg">
                        <CardHeader>
                            <CardTitle className="flex items-center">
                                <FileText className="w-5 h-5 mr-2 text-blue-600" />
                                View Audit Report
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-gray-600 mb-4">View the comprehensive audit report online with full interactivity.</p>
                            <Button
                                onClick={() => window.open(createPageUrl('Audit Report'), '_blank')}
                                className="w-full bg-blue-600 hover:bg-blue-700"
                            >
                                Open Report Online
                            </Button>
                        </CardContent>
                    </Card>

                    <Card className="shadow-lg">
                        <CardHeader>
                            <CardTitle className="flex items-center">
                                <Download className="w-5 h-5 mr-2 text-green-600" />
                                Print/Save as PDF
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-gray-600 mb-4">Generate a printer-friendly version that can be saved as PDF.</p>
                            <Button
                                onClick={generateAuditReportPDF}
                                className="w-full bg-green-600 hover:bg-green-700"
                                disabled={isGeneratingReport}
                            >
                                {isGeneratingReport ? (
                                    <>
                                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                        Generating...
                                    </>
                                ) : (
                                    <>
                                        <Download className="w-4 h-4 mr-2" />
                                        Generate PDF Report
                                    </>
                                )}
                            </Button>
                        </CardContent>
                    </Card>
                </div>

                <div className="mt-8 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <h3 className="font-semibold text-blue-800 mb-2">📋 About the Audit Report</h3>
                    <ul className="text-sm text-blue-700 space-y-1">
                        <li>• Complete analysis of your application structure and workflows</li>
                        <li>• Detailed breakdown of entities, relationships, and business logic</li>
                        <li>• User roles, permissions, and access control overview</li>
                        <li>• Perfect for documentation, compliance, or migration planning</li>
                    </ul>
                </div>
            </div>
        );
    }

    if (group.groupName === 'Migration & Export') { // Check the group name for specific rendering
        return (
            <div>
                <div className="flex items-center justify-between mb-6">
                    <Button variant="ghost" onClick={onBack} className="p-2">
                        ← Back
                    </Button>
                    <div className="flex items-center space-x-4">
                        <div className={`p-2 rounded-lg bg-gradient-to-r ${group.color}`}>
                            <group.icon className="w-6 h-6 text-white" />
                        </div>
                        <div>
                            <h2 className="text-2xl font-bold text-gray-800">{group.groupName}</h2>
                            <p className="text-gray-500">Export data and generate reports</p>
                        </div>
                    </div>
                    <div></div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card className="shadow-lg">
                        <CardHeader>
                            <CardTitle className="flex items-center">
                                <Archive className="w-5 h-5 mr-2 text-blue-600" />
                                Migration Guide
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-gray-600 mb-4">Access the complete migration guide and self-hosting instructions.</p>
                            <Button
                                onClick={() => window.location.href = createPageUrl('Migration')}
                                className="w-full bg-blue-600 hover:bg-blue-700"
                            >
                                Open Migration Guide
                            </Button>
                        </CardContent>
                    </Card>

                    <Card className="shadow-lg">
                        <CardHeader>
                            <CardTitle className="flex items-center">
                                <Database className="w-5 h-5 mr-2 text-purple-600" />
                                Data Export
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-gray-600 mb-4">Export your project data in various formats.</p>
                            <div className="space-y-2">
                                <Button
                                    onClick={() => exportProjectFiles('entities')}
                                    variant="outline"
                                    className="w-full"
                                    disabled={isExporting}
                                >
                                    {isExporting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Download className="w-4 h-4 mr-2" />}
                                    {isExporting ? 'Exporting...' : 'Export Entities'}
                                </Button>
                                <Button
                                    onClick={() => exportProjectFiles('settings')}
                                    variant="outline"
                                    className="w-full"
                                    disabled={isExporting}
                                >
                                    {isExporting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <SettingsIcon className="w-4 h-4 mr-2" />}
                                    {isExporting ? 'Exporting...' : 'Export Settings'}
                                </Button>
                                <Button
                                    onClick={() => exportProjectFiles('workflows')}
                                    variant="outline"
                                    className="w-full"
                                    disabled={isExporting}
                                >
                                    {isExporting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <FileText className="w-4 h-4 mr-2" />}
                                    {isExporting ? 'Exporting...' : 'Export Workflows'}
                                </Button>
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="shadow-lg">
                        <CardHeader>
                            <CardTitle className="flex items-center">
                                <Archive className="w-5 h-5 mr-2 text-red-600" />
                                Complete Export
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-gray-600 mb-4">Export everything - all data, settings, schemas, and workflows in one file.</p>
                            <Button
                                onClick={() => exportProjectFiles('full')}
                                className="w-full bg-red-600 hover:bg-red-700"
                                disabled={isExporting}
                            >
                                {isExporting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Download className="w-4 h-4 mr-2" />}
                                {isExporting ? 'Exporting...' : 'Full Project Export'}
                            </Button>
                            <p className="text-xs text-gray-500 mt-2">
                                This may take a few moments for large datasets.
                            </p>
                        </CardContent>
                    </Card>
                </div>

                <div className="mt-8 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <h3 className="font-semibold text-yellow-800 mb-2">⚠️ Important Notes</h3>
                    <ul className="text-sm text-yellow-700 space-y-1">
                        <li>• Exports include all your data - keep files secure</li>
                        <li>• Large datasets may take time to export</li>
                        <li>• Use the Migration Guide for self-hosting setup</li>
                        <li>• Audit Report can be printed or saved as PDF</li>
                    </ul>
                </div>
            </div>
        );
    }


    return (
        <div>
            <div className="flex items-center justify-between mb-6">
                <Button variant="ghost" onClick={onBack} className="p-2">
                    ← Back
                </Button>
                <div className="flex items-center space-x-4">
                    <div className={`p-2 rounded-lg bg-gradient-to-r ${group.color}`}>
                        <group.icon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                        <h2 className="text-2xl font-bold text-gray-800">{group.groupName}</h2>
                        <p className="text-gray-500">Manage {activeCategory.toLowerCase()}</p>
                    </div>
                </div>
                {activeCategory !== 'Number Sequences' && activeCategory !== 'Company Profile' && activeCategory !== 'Accounting Locales' && activeCategory !== 'Migration' && activeCategory !== 'Audit Report' && (
                    <Button onClick={() => setShowBulkAddDialog(true)}>
                        <Plus className="w-4 h-4 mr-2" />
                        Add Options
                    </Button>
                )}
            </div>

            <Tabs value={activeCategory} onValueChange={setActiveCategory} className="space-y-6">
                <TabsList className="grid w-full grid-cols-3 lg:grid-cols-6">
                    {group.categories.map(category => (
                        <TabsTrigger key={category} value={category} className="text-xs">
                            {category.replace(/([A-Z])/g, ' $1').trim()}
                        </TabsTrigger>
                    ))}
                </TabsList>

                <TabsContent value={activeCategory}>
                    {(activeCategory === 'Company Profile' || activeCategory === 'Accounting Locales' || activeCategory === 'Migration' || activeCategory === 'Audit Report') ? (
                        <Card>
                            <CardContent className="p-6 text-center">
                                <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2" />
                                <p className="text-gray-600">Redirecting to {activeCategory.replace(/([A-Z])/g, ' $1').trim()}...</p>
                            </CardContent>
                        </Card>
                    ) : activeCategory === 'Number Sequences' ? (
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex justify-between items-center">
                                    <span>{activeCategory} {`(${settings.filter(s => s.category === activeCategory).length})`}</span>
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <NumberSequenceManager
                                    settings={settings}
                                    onRefresh={onRefresh}
                                    category={activeCategory}
                                />
                            </CardContent>
                        </Card>
                    ) : (
                        <CategoryDetailView
                            category={activeCategory}
                            settings={settings}
                            onAdd={() => setShowBulkAddDialog(true)}
                            onEdit={setEditingSetting}
                            onDelete={handleDeleteSetting}
                            showDefaultAmount={showDefaultAmount}
                        />
                    )}
                </TabsContent>
            </Tabs>

            <Dialog open={showBulkAddDialog} onOpenChange={setShowBulkAddDialog}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Add Multiple Options to {activeCategory}</DialogTitle>
                    </DialogHeader>
                    <div className="py-4 space-y-4">
                        <div>
                            <Label htmlFor="bulk-values">Enter new options (one per line) *</Label>
                            <textarea
                                id="bulk-values"
                                className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                                value={bulkAddValues}
                                onChange={(e) => setBulkAddValues(e.target.value)}
                                placeholder={`e.g.\nOption 1\nOption 2\nOption 3`}
                                rows={8}
                            />
                            <p className="text-xs text-gray-500 mt-1">
                                Each line will be added as a new option.
                                <br />
                                For line items, you can specify default amount using: `Value:Amount` (e.g., `Repair:25.000`)
                            </p>
                        </div>
                        {showDefaultAmount && (
                            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm text-blue-800">
                                <p className="font-semibold mb-1">Tip for Line Items:</p>
                                <p>Enter items as <code>Value:Amount</code> (e.g., <code>Labor:50.000</code>). If no amount is specified, it defaults to 0.</p>
                            </div>
                        )}
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setShowBulkAddDialog(false)}>Cancel</Button>
                        <Button onClick={handleBulkAddSettings} disabled={isBulkAdding || !bulkAddValues.trim()}>
                            {isBulkAdding ? 'Adding...' : 'Add Options'}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            <Dialog open={!!editingSetting && activeCategory !== 'Number Sequences' && activeCategory !== 'Company Profile' && activeCategory !== 'Accounting Locales' && activeCategory !== 'Migration' && activeCategory !== 'Audit Report'} onOpenChange={() => setEditingSetting(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Edit Option</DialogTitle>
                    </DialogHeader>
                    {editingSetting && (
                        <div className="py-4 space-y-4">
                            <div>
                                <Label>Value *</Label>
                                <Input
                                    value={editingSetting.value}
                                    onChange={(e) => setEditingSetting({ ...editingSetting, value: e.target.value })}
                                />
                            </div>
                            {showDefaultAmount && (
                                <div>
                                    <Label>Default Amount (OMR)</Label>
                                    <Input
                                        type="number"
                                        step="0.001"
                                        value={editingSetting.default_amount}
                                        onChange={(e) => setEditingSetting({ ...editingSetting, default_amount: Number(e.target.value) })}
                                    />
                                </div>
                            )}
                            <div>
                                <Label>Display Order</Label>
                                <Input
                                    type="number"
                                    value={editingSetting.display_order}
                                    onChange={(e) => setEditingSetting({ ...editingSetting, display_order: Number(e.target.value) })}
                                />
                            </div>
                        </div>
                    )}
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setEditingSetting(null)}>Cancel</Button>
                        <Button onClick={handleEditSetting}>Save Changes</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
};

export default function SettingsPage() {
    const [settings, setSettings] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [selectedGroup, setSelectedGroup] = useState(null);
    const [currentUser, setCurrentUser] = useState(null);

    const fetchSettings = useCallback(async () => {
        try {
            const allSettings = await Setting.list('display_order');
            setSettings(allSettings);
        } catch (error) {
            console.error('Failed to fetch settings:', error);
        }
    }, []);

    useEffect(() => {
        const fetchUserAndSettings = async () => {
            setIsLoading(true);
            try {
                const [user, allSettings] = await Promise.all([
                    User.me(),
                    Setting.list('display_order')
                ]);
                setCurrentUser(user);
                setSettings(allSettings);
            } catch (error) {
                console.error('Failed to fetch user or settings:', error);
            } finally {
                setIsLoading(false);
            }
        };
        fetchUserAndSettings();
    }, [fetchSettings]); // Added fetchSettings to dependency array

    const initializeDefaultSettings = useCallback(async () => {
        const requiredDeviceTypes = ['Memory Card'];
        try {
            const existingDeviceTypes = await Setting.filter({ category: 'Device Types' });
            const existingValues = new Set(existingDeviceTypes.map(s => s.value));

            let settingsAdded = false;
            for (const type of requiredDeviceTypes) {
                if (!existingValues.has(type)) {
                    await Setting.create({
                        category: 'Device Types',
                        value: type,
                        is_active: true,
                        display_order: 99
                    });
                    settingsAdded = true;
                }
            }
            if (settingsAdded) {
                fetchSettings(); // Refresh after adding defaults
            }
        } catch (error) {
            console.error('Failed to initialize default settings:', error);
        }
    }, [fetchSettings]);

    useEffect(() => {
        initializeDefaultSettings();
    }, [initializeDefaultSettings]);


    const settingsCountByCategory = settings.reduce((acc, setting) => {
        acc[setting.category] = (acc[setting.category] || 0) + 1;
        return acc;
    }, {});

    const visibleCategories = groupedCategories.filter(group => {
        if (group.adminOnly) {
            return currentUser?.role === 'admin';
        }
        return true;
    });

    if (selectedGroup) {
        return (
            <div className="p-8 bg-gradient-to-br from-gray-50 to-blue-50 min-h-screen">
                <CategoryManagement
                    group={selectedGroup}
                    settings={settings}
                    onBack={() => setSelectedGroup(null)}
                    onRefresh={fetchSettings}
                />
            </div>
        );
    }

    return (
        <div className="p-8 bg-gradient-to-br from-gray-50 to-blue-50 min-h-screen">
            <div className="mb-8">
                <div className="flex items-center space-x-4 mb-4">
                    <div className="p-3 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-xl shadow-lg">
                        <SettingsIcon className="w-8 h-8 text-white" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                            System Settings
                        </h1>
                        <p className="text-gray-500 mt-1">Configure and manage your system options</p>
                    </div>
                </div>
            </div>

            {isLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {[1, 2, 3, 4].map(i => (
                        <Card key={i} className="animate-pulse">
                            <CardContent className="p-6">
                                <div className="h-32 bg-gray-200 rounded"></div>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {visibleCategories.map(group => (
                        <CategoryCard
                            key={group.groupName}
                            group={group}
                            settingsCount={settingsCountByCategory}
                            onCategorySelect={setSelectedGroup}
                        />
                    ))}
                </div>
            )}
        </div>
    );
}
