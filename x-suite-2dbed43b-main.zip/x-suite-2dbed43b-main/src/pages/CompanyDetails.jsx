
import React, { useState, useEffect } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { Company } from '@/api/entities';
import { Customer } from '@/api/entities';
import { Case } from '@/api/entities';
import { Quote } from '@/api/entities'; // Kept as it's used for totalRevenue
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge'; // Kept because activeCases is still used, though recent activity card is removed
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import {
    ArrowLeft, Building, Globe, Phone, Mail, MapPin, Users,
    DollarSign, TrendingUp, Edit, QrCode, Plus, X, ExternalLink, Copy, HardDrive
} from 'lucide-react';
// import { format } from 'date-fns'; // Removed as no longer used
import { createPageUrl } from '@/utils';
import EditCompanyDialog from '../components/case/EditCompanyDialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'; // Import Tabs components

export default function CompanyDetailsPage() {
    const [company, setCompany] = useState(null);
    const [customers, setCustomers] = useState([]);
    const [cases, setCases] = useState([]);
    const [quotes, setQuotes] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isEditCompanyOpen, setIsEditCompanyOpen] = useState(false); // Renamed from isEditOpen
    const [showQRDialog, setShowQRDialog] = useState(false);
    const [newQRCode, setNewQRCode] = useState({ label: '', url: '' });
    const location = useLocation();

    const getCompanyId = () => new URLSearchParams(location.search).get('id');

    const fetchData = async () => {
        const companyId = getCompanyId();
        if (!companyId) {
            setIsLoading(false);
            return;
        }

        try {
            const [companyData] = await Promise.all([
                Company.get(companyId),
                // Customer.filter({ company_name: '' }) // This line was problematic/redundant, removed
            ]);

            setCompany(companyData);

            if (companyData) {
                // Get customers for this company
                const companyCustomers = await Customer.filter({ company_name: companyData.company_name });
                setCustomers(companyCustomers);

                // Get cases and quotes for all customers of this company
                if (companyCustomers.length > 0) {
                    const customerIds = companyCustomers.map(c => c.id);
                    const [casesData, quotesData] = await Promise.all([
                        Case.filter({ customer_id: { $in: customerIds } }),
                        Quote.filter({ customer_id: { $in: customerIds } })
                    ]);
                    setCases(casesData);
                    setQuotes(quotesData);
                } else {
                    setCases([]);
                    setQuotes([]);
                }
            } else {
                setCustomers([]);
                setCases([]);
                setQuotes([]);
            }
        } catch (error) {
            console.error('Failed to fetch company details:', error);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, [location.search]);

    const handleAddQRCode = async () => {
        if (!newQRCode.label || !newQRCode.url) {
            alert('Please provide both label and URL for the QR code');
            return;
        }

        try {
            const currentQRCodes = company.qr_codes || [];
            // Use a simple unique ID for client-side rendering
            const updatedQRCodes = [...currentQRCodes, { ...newQRCode, id: `qr_${Date.now()}` }];

            await Company.update(company.id, { qr_codes: updatedQRCodes });
            setNewQRCode({ label: '', url: '' });
            setShowQRDialog(false);
            fetchData();
        } catch (error) {
            console.error('Failed to add QR code:', error);
            alert('Failed to add QR code');
        }
    };

    const handleRemoveQRCode = async (qrCodeId) => {
        try {
            const updatedQRCodes = (company.qr_codes || []).filter(qr => qr.id !== qrCodeId);
            await Company.update(company.id, { qr_codes: updatedQRCodes });
            fetchData();
        } catch (error) {
            console.error('Failed to remove QR code:', error);
            alert('Failed to remove QR code');
        }
    };

    const totalRevenue = quotes.reduce((sum, quote) => sum + (quote.total_amount || 0), 0);
    const activeCases = cases.filter(c => !['Completed', 'Closed'].includes(c.status)).length;

    if (isLoading) {
        return <div className="p-6">Loading company details...</div>;
    }

    if (!company) {
        return <div className="p-6">Company not found.</div>;
    }

    return (
        <div className="p-6 bg-gray-50 min-h-screen">
            {/* Header */}
            <header className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-4">
                    <Button
                        variant="outline"
                        onClick={() => window.history.back()}
                        className="h-10 w-10 p-0"
                    >
                        <ArrowLeft className="w-5 h-5" />
                    </Button>
                    <div>
                        <h1 className="text-2xl font-bold text-gray-800">{company.company_name}</h1>
                        <p className="text-sm text-gray-500">Company Profile</p>
                    </div>
                </div>
                <Button onClick={() => setIsEditCompanyOpen(true)} className="bg-blue-600 hover:bg-blue-700">
                    <Edit className="w-4 h-4 mr-2" />
                    Edit Company
                </Button>
            </header>

            {/* Company Info Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                <Card>
                    <CardContent className="p-4 flex items-center">
                        <Users className="w-6 h-6 text-blue-500 mr-4" />
                        <div>
                            <p className="text-xs text-gray-500">Customers</p>
                            <p className="font-semibold">{customers.length}</p>
                        </div>
                    </CardContent>
                </Card>
                <Card>
                    <CardContent className="p-4 flex items-center">
                        <Building className="w-6 h-6 text-green-500 mr-4" />
                        <div>
                            <p className="text-xs text-gray-500">Active Cases</p>
                            <p className="font-semibold">{activeCases}</p>
                        </div>
                    </CardContent>
                </Card>
                <Card>
                    <CardContent className="p-4 flex items-center">
                        <DollarSign className="w-6 h-6 text-purple-500 mr-4" />
                        <div>
                            <p className="text-xs text-gray-500">Total Revenue</p>
                            <p className="font-semibold">${totalRevenue.toFixed(2)}</p>
                        </div>
                    </CardContent>
                </Card>
                <Card>
                    <CardContent className="p-4 flex items-center">
                        <TrendingUp className="w-6 h-6 text-orange-500 mr-4" />
                        <div>
                            <p className="text-xs text-gray-500">Total Cases</p>
                            <p className="font-semibold">{cases.length}</p>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Main Content Grid - Now using Tabs */}
            <Tabs defaultValue="details" className="w-full">
                <TabsList>
                    <TabsTrigger value="details">Company Details</TabsTrigger>
                    <TabsTrigger value="qr_codes">QR Codes & Links</TabsTrigger>
                </TabsList>
                <TabsContent value="details">
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center">
                                <Building className="w-5 h-5 mr-2" />
                                Company Information
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <Label className="text-sm font-medium text-gray-600">Company Name</Label>
                                    <p className="font-semibold">{company.company_name}</p>
                                </div>
                                {company.vat_number && (
                                    <div>
                                        <Label className="text-sm font-medium text-gray-600">VAT Number</Label>
                                        <p className="font-semibold">{company.vat_number}</p>
                                    </div>
                                )}
                                {company.contact_person && (
                                    <div>
                                        <Label className="text-sm font-medium text-gray-600">Contact Person</Label>
                                        <p className="font-semibold">{company.contact_person}</p>
                                    </div>
                                )}
                                {company.industry && (
                                    <div>
                                        <Label className="text-sm font-medium text-gray-600">Industry</Label>
                                        <p className="font-semibold">{company.industry}</p>
                                    </div>
                                )}
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t">
                                {company.email && (
                                    <div className="flex items-center">
                                        <Mail className="w-4 h-4 text-gray-400 mr-2" />
                                        <a href={`mailto:${company.email}`} className="text-blue-600 hover:underline">
                                            {company.email}
                                        </a>
                                    </div>
                                )}
                                {company.phone && (
                                    <div className="flex items-center">
                                        <Phone className="w-4 h-4 text-gray-400 mr-2" />
                                        <a href={`tel:${company.phone}`} className="text-blue-600 hover:underline">
                                            {company.phone}
                                        </a>
                                    </div>
                                )}
                                {company.url && (
                                    <div className="flex items-center">
                                        <Globe className="w-4 h-4 text-gray-400 mr-2" />
                                        <a href={company.url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">
                                            {company.url}
                                        </a>
                                    </div>
                                )}
                                {company.address && (
                                    <div className="flex items-start">
                                        <MapPin className="w-4 h-4 text-gray-400 mr-2 mt-0.5" />
                                        <p className="text-gray-700">{company.address}</p>
                                    </div>
                                )}
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>
                <TabsContent value="qr_codes">
                    <Card>
                        <CardHeader className="flex flex-row items-center justify-between">
                            <CardTitle className="flex items-center">
                                <QrCode className="w-5 h-5 mr-2 text-blue-600" />
                                Manage QR Codes
                            </CardTitle>
                            <Button onClick={() => setShowQRDialog(true)} size="sm">
                                <Plus className="w-4 h-4 mr-2" />
                                Add QR Code
                            </Button>
                        </CardHeader>
                        <CardContent>
                            {company?.qr_codes && company.qr_codes.length > 0 ? (
                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                    {company.qr_codes.map((qr, index) => (
                                        <div key={qr.id || index} className="border rounded-lg p-4 bg-white shadow-sm">
                                            <div className="flex items-start justify-between mb-3">
                                                <h4 className="font-medium text-gray-800">{qr.label}</h4>
                                                <Button
                                                    variant="ghost"
                                                    size="sm"
                                                    className="text-red-500 hover:text-red-700 h-7 w-7 p-0"
                                                    onClick={() => handleRemoveQRCode(qr.id)}
                                                >
                                                    <X className="w-4 h-4" />
                                                </Button>
                                            </div>
                                            <div className="text-center">
                                                <div className="inline-block p-2 bg-gray-100 rounded-lg">
                                                    <QrCode className="w-20 h-20 text-gray-600" />
                                                </div>
                                                <p className="text-xs text-gray-500 mt-2 break-all">{qr.url}</p>
                                                <div className="flex space-x-2 mt-3 justify-center">
                                                    <Button
                                                        variant="outline"
                                                        size="sm"
                                                        onClick={() => window.open(qr.url, '_blank')}
                                                    >
                                                        <ExternalLink className="w-3 h-3 mr-1" />
                                                        Visit Link
                                                    </Button>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <div className="text-center py-8 text-gray-500">
                                    <QrCode className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                                    <p>No QR codes have been added yet.</p>
                                    <Button
                                        variant="outline"
                                        onClick={() => setShowQRDialog(true)}
                                        className="mt-3"
                                    >
                                        Add Your First QR Code
                                    </Button>
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>

            {/* Edit Company Dialog */}
            <EditCompanyDialog
                open={isEditCompanyOpen}
                onOpenChange={setIsEditCompanyOpen}
                company={company}
                onCompanyUpdate={fetchData}
            />

            {/* Add QR Code Dialog */}
            <Dialog open={showQRDialog} onOpenChange={setShowQRDialog}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Add New QR Code</DialogTitle>
                    </DialogHeader>
                    <div className="py-4 space-y-4">
                        <div>
                            <Label htmlFor="qr-label">Label</Label>
                            <Input
                                id="qr-label"
                                value={newQRCode.label}
                                onChange={(e) => setNewQRCode({ ...newQRCode, label: e.target.value })}
                                placeholder="e.g., Company Website"
                            />
                        </div>
                        <div>
                            <Label htmlFor="qr-url">URL</Label>
                            <Input
                                id="qr-url"
                                value={newQRCode.url}
                                onChange={(e) => setNewQRCode({ ...newQRCode, url: e.target.value })}
                                placeholder="https://example.com"
                            />
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setShowQRDialog(false)}>Cancel</Button>
                        <Button onClick={handleAddQRCode}>Save QR Code</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

        </div>
    );
}
