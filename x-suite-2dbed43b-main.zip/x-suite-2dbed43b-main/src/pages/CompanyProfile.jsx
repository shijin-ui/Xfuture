
import React, { useState, useEffect } from 'react';
import { CompanyProfile } from '@/api/entities';
import { Setting } from '@/api/entities';
import { UploadFile } from '@/api/integrations';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Building, Save, Upload, ArrowLeft, Loader2, MapPin, Mail, Phone, CreditCard, Image, Globe } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import SearchableSelect from '../components/SearchableSelect';

export default function CompanyProfilePage() {
    const navigate = useNavigate();
    const [companyData, setCompanyData] = useState({
        company_name: '',
        brand_name: '',
        company_registration_number: '',
        country: '',
        city: '',
        email: '',
        phone_number: '',
        mobile_number_1: '',
        mobile_number_2: '',
        company_address: '',
        website: '',
        tax_id: '',
        bank_account_1_number: '',
        bank_account_1_name: '',
        bank_account_1_account_name: '', // Added field
        bank_account_1_branch: '',
        bank_account_1_iban: '',
        bank_account_2_number: '',
        bank_account_2_name: '',
        bank_account_2_account_name: '', // Added field
        bank_account_2_branch: '',
        bank_account_2_iban: '',
        logo_text: '',
        full_logo_url: '',
        logo_icon_url: '',
        facebook_url: '',
        twitter_url: '',
        linkedin_url: '',
        instagram_url: '',
        youtube_url: '',
        privacy_policy_url: '',
        terms_of_service_url: ''
    });
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const [existingProfile, setExistingProfile] = useState(null);
    const [isUploadingFullLogo, setIsUploadingFullLogo] = useState(false);
    const [isUploadingIconLogo, setIsUploadingIconLogo] = useState(false);
    const [countries, setCountries] = useState([]);
    const [cities, setCities] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const [profiles, countriesData, citiesData] = await Promise.all([
                    CompanyProfile.list(),
                    Setting.filter({ category: 'Countries', is_active: true }, 'display_order'),
                    Setting.filter({ category: 'Cities', is_active: true }, 'display_order')
                ]);

                setCountries(countriesData.map(c => c.value));
                setCities(citiesData.map(c => c.value));

                if (profiles.length > 0) {
                    const profile = profiles[0];
                    setCompanyData(profile);
                    setExistingProfile(profile);
                }
            } catch (error) {
                console.error('Failed to fetch data:', error);
            } finally {
                setIsLoading(false);
            }
        };

        fetchData();
    }, []);

    const handleInputChange = (field, value) => {
        setCompanyData(prev => ({ ...prev, [field]: value }));
    };

    const handleFileUpload = async (file, type) => {
        if (!file) return;

        const setUploading = type === 'full' ? setIsUploadingFullLogo : setIsUploadingIconLogo;
        
        setUploading(true);
        try {
            const { file_url } = await UploadFile({ file });
            const urlField = type === 'full' ? 'full_logo_url' : 'logo_icon_url';
            handleInputChange(urlField, file_url);
        } catch (error) {
            console.error('Failed to upload file:', error);
            alert('Failed to upload file');
        } finally {
            setUploading(false);
        }
    };

    const handleSave = async () => {
        if (!companyData.company_name.trim()) {
            alert('Company name is required');
            return;
        }

        setIsSaving(true);
        try {
            if (existingProfile) {
                await CompanyProfile.update(existingProfile.id, companyData);
            } else {
                const newProfile = await CompanyProfile.create(companyData);
                setExistingProfile(newProfile);
            }
            alert('Company details saved successfully');
        } catch (error) {
            console.error('Failed to save company profile:', error);
            alert('Failed to save company details');
        } finally {
            setIsSaving(false);
        }
    };

    if (isLoading) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 flex items-center justify-center">
                <div className="text-center">
                    <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-blue-600" />
                    <p className="text-gray-600">Loading Company Profile...</p>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 p-8">
            <div className="max-w-6xl mx-auto">
                <div className="flex items-center justify-between mb-8">
                    <Button variant="outline" onClick={() => navigate(createPageUrl('Settings'))} className="bg-white/80 backdrop-blur-sm hover:bg-white border-gray-200">
                        <ArrowLeft className="w-4 h-4 mr-2" />
                        Back to Settings
                    </Button>
                    <div className="text-center">
                        <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent flex items-center">
                            <Building className="w-8 h-8 mr-3 text-blue-600" />
                            Company Details
                        </h1>
                        <p className="text-gray-500 mt-1">Manage your company information and branding</p>
                    </div>
                    <Button onClick={handleSave} disabled={isSaving} className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-lg">
                        {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                        Save Changes
                    </Button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                    {/* Basic Information */}
                    <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0 hover:shadow-2xl transition-all duration-300">
                        <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-t-lg">
                            <CardTitle className="flex items-center text-blue-700">
                                <Building className="w-5 h-5 mr-2" />
                                Basic Information
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="p-6 space-y-4">
                            <div>
                                <Label className="text-sm font-medium text-gray-700">Company Name *</Label>
                                <Input
                                    value={companyData.company_name}
                                    onChange={(e) => handleInputChange('company_name', e.target.value)}
                                    placeholder="Enter company name"
                                    className="mt-1 border-gray-200 focus:border-blue-500 focus:ring-blue-200"
                                />
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-700">Brand Name</Label>
                                <Input
                                    value={companyData.brand_name}
                                    onChange={(e) => handleInputChange('brand_name', e.target.value)}
                                    placeholder="Enter brand name"
                                    className="mt-1 border-gray-200 focus:border-blue-500 focus:ring-blue-200"
                                />
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-700">Registration Number</Label>
                                <Input
                                    value={companyData.company_registration_number}
                                    onChange={(e) => handleInputChange('company_registration_number', e.target.value)}
                                    placeholder="Enter registration number"
                                    className="mt-1 border-gray-200 focus:border-blue-500 focus:ring-blue-200"
                                />
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-700">TAX ID</Label>
                                <Input
                                    value={companyData.tax_id}
                                    onChange={(e) => handleInputChange('tax_id', e.target.value)}
                                    placeholder="Enter tax identification number"
                                    className="mt-1 border-gray-200 focus:border-blue-500 focus:ring-blue-200"
                                />
                            </div>
                        </CardContent>
                    </Card>

                    {/* Location & Address */}
                    <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0 hover:shadow-2xl transition-all duration-300">
                        <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-t-lg">
                            <CardTitle className="flex items-center text-green-700">
                                <MapPin className="w-5 h-5 mr-2" />
                                Location & Address
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="p-6 space-y-4">
                            <div>
                                <Label className="text-sm font-medium text-gray-700">Country</Label>
                                <SearchableSelect
                                    value={companyData.country}
                                    onValueChange={(value) => handleInputChange('country', value)}
                                    placeholder="Select or search country..."
                                    options={countries}
                                    searchPlaceholder="Search countries..."
                                    className="mt-1"
                                />
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-700">City</Label>
                                <SearchableSelect
                                    value={companyData.city}
                                    onValueChange={(value) => handleInputChange('city', value)}
                                    placeholder="Select or search city..."
                                    options={cities}
                                    searchPlaceholder="Search cities..."
                                    className="mt-1"
                                />
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-700">Complete Address</Label>
                                <Textarea
                                    value={companyData.company_address}
                                    onChange={(e) => handleInputChange('company_address', e.target.value)}
                                    placeholder="Enter complete business address"
                                    rows={3}
                                    className="mt-1 border-gray-200 focus:border-green-500 focus:ring-green-200"
                                />
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-700">Website</Label>
                                <Input
                                    value={companyData.website}
                                    onChange={(e) => handleInputChange('website', e.target.value)}
                                    placeholder="https://www.example.com"
                                    className="mt-1 border-gray-200 focus:border-green-500 focus:ring-green-200"
                                />
                            </div>
                        </CardContent>
                    </Card>

                    {/* Contact Information */}
                    <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0 hover:shadow-2xl transition-all duration-300">
                        <CardHeader className="bg-gradient-to-r from-purple-50 to-indigo-50 rounded-t-lg">
                            <CardTitle className="flex items-center text-purple-700">
                                <Phone className="w-5 h-5 mr-2" />
                                Contact Information
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="p-6 space-y-4">
                            <div>
                                <Label className="text-sm font-medium text-gray-700">Email Address</Label>
                                <Input
                                    type="email"
                                    value={companyData.email}
                                    onChange={(e) => handleInputChange('email', e.target.value)}
                                    placeholder="contact@company.com"
                                    className="mt-1 border-gray-200 focus:border-purple-500 focus:ring-purple-200"
                                />
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-700">Phone Number</Label>
                                <Input
                                    value={companyData.phone_number}
                                    onChange={(e) => handleInputChange('phone_number', e.target.value)}
                                    placeholder="+968 1234 5678"
                                    className="mt-1 border-gray-200 focus:border-purple-500 focus:ring-purple-200"
                                />
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-700">Mobile Number 1</Label>
                                <Input
                                    value={companyData.mobile_number_1}
                                    onChange={(e) => handleInputChange('mobile_number_1', e.target.value)}
                                    placeholder="+968 9876 5432"
                                    className="mt-1 border-gray-200 focus:border-purple-500 focus:ring-purple-200"
                                />
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-700">Mobile Number 2</Label>
                                <Input
                                    value={companyData.mobile_number_2}
                                    onChange={(e) => handleInputChange('mobile_number_2', e.target.value)}
                                    placeholder="+968 5555 1234"
                                    className="mt-1 border-gray-200 focus:border-purple-500 focus:ring-purple-200"
                                />
                            </div>
                        </CardContent>
                    </Card>

                    {/* Bank Account Details 1 */}
                    <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0 hover:shadow-2xl transition-all duration-300">
                        <CardHeader className="bg-gradient-to-r from-orange-50 to-amber-50 rounded-t-lg">
                            <CardTitle className="flex items-center text-orange-700">
                                <CreditCard className="w-5 h-5 mr-2" />
                                Primary Bank Account
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="p-6 space-y-4">
                            <div>
                                <Label className="text-sm font-medium text-gray-700">Account Name</Label>
                                <Input
                                    value={companyData.bank_account_1_account_name}
                                    onChange={(e) => handleInputChange('bank_account_1_account_name', e.target.value)}
                                    placeholder="Enter account holder name"
                                    className="mt-1 border-gray-200 focus:border-orange-500 focus:ring-orange-200"
                                />
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-700">Bank Name</Label>
                                <Input
                                    value={companyData.bank_account_1_name}
                                    onChange={(e) => handleInputChange('bank_account_1_name', e.target.value)}
                                    placeholder="Enter bank name"
                                    className="mt-1 border-gray-200 focus:border-orange-500 focus:ring-orange-200"
                                />
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-700">Account Number</Label>
                                <Input
                                    value={companyData.bank_account_1_number}
                                    onChange={(e) => handleInputChange('bank_account_1_number', e.target.value)}
                                    placeholder="Enter account number"
                                    className="mt-1 border-gray-200 focus:border-orange-500 focus:ring-orange-200"
                                />
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-700">Branch</Label>
                                <Input
                                    value={companyData.bank_account_1_branch}
                                    onChange={(e) => handleInputChange('bank_account_1_branch', e.target.value)}
                                    placeholder="Enter branch name"
                                    className="mt-1 border-gray-200 focus:border-orange-500 focus:ring-orange-200"
                                />
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-700">IBAN</Label>
                                <Input
                                    value={companyData.bank_account_1_iban}
                                    onChange={(e) => handleInputChange('bank_account_1_iban', e.target.value)}
                                    placeholder="Enter IBAN"
                                    className="mt-1 border-gray-200 focus:border-orange-500 focus:ring-orange-200"
                                />
                            </div>
                        </CardContent>
                    </Card>

                    {/* Bank Account Details 2 */}
                    <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0 hover:shadow-2xl transition-all duration-300">
                        <CardHeader className="bg-gradient-to-r from-teal-50 to-cyan-50 rounded-t-lg">
                            <CardTitle className="flex items-center text-teal-700">
                                <CreditCard className="w-5 h-5 mr-2" />
                                Secondary Bank Account
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="p-6 space-y-4">
                            <div>
                                <Label className="text-sm font-medium text-gray-700">Account Name</Label>
                                <Input
                                    value={companyData.bank_account_2_account_name}
                                    onChange={(e) => handleInputChange('bank_account_2_account_name', e.target.value)}
                                    placeholder="Enter account holder name"
                                    className="mt-1 border-gray-200 focus:border-teal-500 focus:ring-teal-200"
                                />
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-700">Bank Name</Label>
                                <Input
                                    value={companyData.bank_account_2_name}
                                    onChange={(e) => handleInputChange('bank_account_2_name', e.target.value)}
                                    placeholder="Enter bank name"
                                    className="mt-1 border-gray-200 focus:border-teal-500 focus:ring-teal-200"
                                />
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-700">Account Number</Label>
                                <Input
                                    value={companyData.bank_account_2_number}
                                    onChange={(e) => handleInputChange('bank_account_2_number', e.target.value)}
                                    placeholder="Enter account number"
                                    className="mt-1 border-gray-200 focus:border-teal-500 focus:ring-teal-200"
                                />
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-700">Branch</Label>
                                <Input
                                    value={companyData.bank_account_2_branch}
                                    onChange={(e) => handleInputChange('bank_account_2_branch', e.target.value)}
                                    placeholder="Enter branch name"
                                    className="mt-1 border-gray-200 focus:border-teal-500 focus:ring-teal-200"
                                />
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-700">IBAN</Label>
                                <Input
                                    value={companyData.bank_account_2_iban}
                                    onChange={(e) => handleInputChange('bank_account_2_iban', e.target.value)}
                                    placeholder="Enter IBAN"
                                    className="mt-1 border-gray-200 focus:border-teal-500 focus:ring-teal-200"
                                />
                            </div>
                        </CardContent>
                    </Card>

                    {/* Logo Settings */}
                    <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0 hover:shadow-2xl transition-all duration-300">
                        <CardHeader className="bg-gradient-to-r from-pink-50 to-rose-50 rounded-t-lg">
                            <CardTitle className="flex items-center text-pink-700">
                                <Image className="w-5 h-5 mr-2" />
                                Logo & Branding
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="p-6 space-y-4">
                            <div>
                                <Label className="text-sm font-medium text-gray-700">Logo Text</Label>
                                <Input
                                    value={companyData.logo_text}
                                    onChange={(e) => handleInputChange('logo_text', e.target.value)}
                                    placeholder="Enter logo text"
                                    className="mt-1 border-gray-200 focus:border-pink-500 focus:ring-pink-200"
                                />
                            </div>

                            <div>
                                <Label className="text-sm font-medium text-gray-700">Full Logo</Label>
                                <div className="mt-2 space-y-3">
                                    <input
                                        type="file"
                                        accept="image/png,image/jpg,image/jpeg,image/svg+xml"
                                        onChange={(e) => handleFileUpload(e.target.files[0], 'full')}
                                        className="hidden"
                                        id="full-logo-upload"
                                    />
                                    <Button 
                                        variant="outline" 
                                        disabled={isUploadingFullLogo} 
                                        className="w-full border-gray-200 hover:border-pink-500"
                                        onClick={() => document.getElementById('full-logo-upload').click()}
                                        type="button"
                                    >
                                        {isUploadingFullLogo ? (
                                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                        ) : (
                                            <Upload className="w-4 h-4 mr-2" />
                                        )}
                                        Upload Full Logo
                                    </Button>
                                    {companyData.full_logo_url && (
                                        <div className="border rounded-lg p-3 bg-gray-50">
                                            <img src={companyData.full_logo_url} alt="Full Logo" className="max-h-16 mx-auto" />
                                        </div>
                                    )}
                                </div>
                            </div>

                            <div>
                                <Label className="text-sm font-medium text-gray-700">Logo Icon</Label>
                                <div className="mt-2 space-y-3">
                                    <input
                                        type="file"
                                        accept="image/png,image/jpg,image/jpeg,image/svg+xml"
                                        onChange={(e) => handleFileUpload(e.target.files[0], 'icon')}
                                        className="hidden"
                                        id="icon-logo-upload"
                                    />
                                    <Button 
                                        variant="outline" 
                                        disabled={isUploadingIconLogo} 
                                        className="w-full border-gray-200 hover:border-pink-500"
                                        onClick={() => document.getElementById('icon-logo-upload').click()}
                                        type="button"
                                    >
                                        {isUploadingIconLogo ? (
                                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                        ) : (
                                            <Upload className="w-4 h-4 mr-2" />
                                        )}
                                        Upload Logo Icon
                                    </Button>
                                    {companyData.logo_icon_url && (
                                        <div className="border rounded-lg p-3 bg-gray-50">
                                            <img src={companyData.logo_icon_url} alt="Logo Icon" className="max-h-16 mx-auto" />
                                        </div>
                                    )}
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Social Media & Policies */}
                    <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0 hover:shadow-2xl transition-all duration-300">
                        <CardHeader className="bg-gradient-to-r from-violet-50 to-purple-50 rounded-t-lg">
                            <CardTitle className="flex items-center text-violet-700">
                                <Globe className="w-5 h-5 mr-2" />
                                Social Media & Policies
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="p-6 space-y-4">
                            <div>
                                <Label className="text-sm font-medium text-gray-700">Facebook URL</Label>
                                <Input
                                    value={companyData.facebook_url}
                                    onChange={(e) => handleInputChange('facebook_url', e.target.value)}
                                    placeholder="https://facebook.com/yourpage"
                                    className="mt-1 border-gray-200 focus:border-violet-500 focus:ring-violet-200"
                                />
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-700">X URL</Label>
                                <Input
                                    value={companyData.twitter_url}
                                    onChange={(e) => handleInputChange('twitter_url', e.target.value)}
                                    placeholder="https://x.com/yourhandle"
                                    className="mt-1 border-gray-200 focus:border-violet-500 focus:ring-violet-200"
                                />
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-700">LinkedIn URL</Label>
                                <Input
                                    value={companyData.linkedin_url}
                                    onChange={(e) => handleInputChange('linkedin_url', e.target.value)}
                                    placeholder="https://linkedin.com/company/yourcompany"
                                    className="mt-1 border-gray-200 focus:border-violet-500 focus:ring-violet-200"
                                />
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-700">Instagram URL</Label>
                                <Input
                                    value={companyData.instagram_url}
                                    onChange={(e) => handleInputChange('instagram_url', e.target.value)}
                                    placeholder="https://instagram.com/yourhandle"
                                    className="mt-1 border-gray-200 focus:border-violet-500 focus:ring-violet-200"
                                />
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-700">YouTube URL</Label>
                                <Input
                                    value={companyData.youtube_url}
                                    onChange={(e) => handleInputChange('youtube_url', e.target.value)}
                                    placeholder="https://youtube.com/c/yourchannel"
                                    className="mt-1 border-gray-200 focus:border-violet-500 focus:ring-violet-200"
                                />
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-700">Privacy Policy URL</Label>
                                <Input
                                    value={companyData.privacy_policy_url}
                                    onChange={(e) => handleInputChange('privacy_policy_url', e.target.value)}
                                    placeholder="https://yourwebsite.com/privacy"
                                    className="mt-1 border-gray-200 focus:border-violet-500 focus:ring-violet-200"
                                />
                            </div>
                            <div>
                                <Label className="text-sm font-medium text-gray-700">Terms of Service URL</Label>
                                <Input
                                    value={companyData.terms_of_service_url}
                                    onChange={(e) => handleInputChange('terms_of_service_url', e.target.value)}
                                    placeholder="https://yourwebsite.com/terms"
                                    className="mt-1 border-gray-200 focus:border-violet-500 focus:ring-violet-200"
                                />
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}
