
import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Case } from '@/api/entities';
import { Customer } from '@/api/entities';
import { Quote } from '@/api/entities';
import { Invoice } from '@/api/entities';
import { Communication } from '@/api/entities';
import { User } from '@/api/entities';
import { Company } from '@/api/entities';
import { JobHistory } from '@/api/entities';
import { MediaEvaluation } from '@/api/entities'; // Import MediaEvaluation
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
    HardDrive, CheckCircle, Tag, Package, Server, Activity, User as UserIcon,
    ArrowLeft, ArrowRightToLine, LayoutDashboard, ClipboardCheck, FileText, Paperclip, History, Printer,
    Copy, Loader2, MessageCircle, Users, MessageSquare
} from 'lucide-react';
import { format } from 'date-fns';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { getNextCaseNumber } from '../components/utils/caseNumberGenerator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';

import CaseOverviewTab from '../components/case/CaseOverviewTab';
import ClientDetailsTab from '../components/case/ClientDetailsTab';
import DeviceInfoTab from '../components/case/DeviceInfoTab';
import MediaEvaluationTab from '../components/case/MediaEvaluationTab';
import FilesTab from '../components/case/FilesTab';
import JobHistoryTab from '../components/case/JobHistoryTab';
import QuotesInvoicesTab from '../components/case/QuotesInvoicesTab';
import CaseStatusTracker from '../components/case/CaseStatusTracker';
import { getSettingsByCategory } from '../components/utils/settingsLoader';
import EngineersTab from '../components/case/EngineersTab';
import InternalNotesTab from '../components/case/InternalNotesTab';

const statusColors = {
    Intake: 'bg-gray-100 text-gray-800 border border-gray-200',
    Diagnosis: 'bg-blue-100 text-blue-800 border border-blue-200',
    Quoted: 'bg-yellow-100 text-yellow-800 border border-yellow-200',
    'In Progress': 'bg-indigo-100 text-indigo-800 border border-indigo-200',
    'Awaiting Payment': 'bg-orange-100 text-orange-800 border border-orange-200',
    Completed: 'bg-green-100 text-green-800 border border-green-200',
    Closed: 'bg-red-100 text-red-800 border border-red-200',
    default: 'bg-gray-100 text-gray-800 border border-gray-200',
};

export default function CaseDetailsPage() {
  const [caseData, setCaseData] = useState(null);
  const [customer, setCustomer] = useState(null);
  const [creatorUser, setCreatorUser] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [company, setCompany] = useState(null);
  const [quotes, setQuotes] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [evaluations, setEvaluations] = useState([]); // Add state for evaluations
  const [isLoading, setIsLoading] = useState(true);
  const [showCheckoutDialog, setShowCheckoutDialog] = useState(false);
  const [selectedDevices, setSelectedDevices] = useState([]);
  const [checkoutFormData, setCheckoutFormData] = useState({
      collected_by_name: '',
      collected_by_mobile: '',
      collected_by_id: '',
      collection_date: ''
  });
  const [isCheckingIn, setIsCheckingIn] = useState(false);
  const [isDuplicateDialogOpen, setIsDuplicateDialogOpen] = useState(false);
  const [isDuplicating, setIsDuplicating] = useState(false);
  const [showWhatsappDialog, setShowWhatsappDialog] = useState(false);
  const [whatsappTemplate, setWhatsappTemplate] = useState('');
  const [whatsappMessage, setWhatsappMessage] = useState('');
  const [caseStatuses, setCaseStatuses] = useState([]);


  const location = useLocation();
  const navigate = useNavigate();

  const caseId = new URLSearchParams(location.search).get('id');

  const getActiveTab = () => new URLSearchParams(location.search).get('tab') || 'overview';

  const [activeTab, setActiveTab] = useState(getActiveTab());

  const updateCurrentTab = (newTab) => {
    const currentParams = new URLSearchParams(location.search);
    currentParams.set('tab', newTab);
    window.history.pushState(null, '', `${location.pathname}?${currentParams.toString()}`);
    setActiveTab(newTab);
  };

  const fetchCaseDetails = async () => {
    if (!caseId) {
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    try {
      const [
        caseDetails,
        user,
        statuses,
        quotesResult,
        invoicesResult,
        evaluationsResult, // Fetch evaluations
        allUsers,
      ] = await Promise.all([
        Case.get(caseId),
        User.me(),
        getSettingsByCategory('Case Statuses'),
        Quote.filter({ case_id: caseId }, '-created_date'), // Sort by date
        Invoice.filter({ case_id: caseId }, '-created_date'), // Sort by date
        MediaEvaluation.filter({ case_id: caseId }, '-evaluation_date'), // Fetch and sort evaluations
        User.list(),
      ]);

      setCaseData(caseDetails);
      setCurrentUser(user);
      setQuotes(quotesResult);
      setInvoices(invoicesResult);
      setEvaluations(evaluationsResult); // Set evaluations state
      setCaseStatuses(statuses);

      if (caseDetails) {
          const creator = allUsers.find(u => u.email === caseDetails.created_by);
          setCreatorUser(creator);

          const customerId = caseDetails.customer_id;
          if (customerId) {
            let customerRes = null;
            if (typeof customerId === 'string' && customerId.startsWith('CUST-')) {
              console.warn(`Customer ID "${customerId}" looks like a customer_code. Using filter.`);
              const customerResults = await Customer.filter({ customer_code: customerId });
              if (customerResults && customerResults.length > 0) {
                customerRes = customerResults[0];
              } else {
                 console.error(`Could not find customer by customer_code: "${customerId}"`);
              }
            } else {
              try {
                customerRes = await Customer.get(customerId);
              } catch (error) {
                console.error(`Customer.get by ID "${customerId}" failed unexpectedly. It might be a missing record.`, error);
              }
            }

            setCustomer(customerRes);

            if (customerRes && customerRes.company_name) {
              const companies = await Company.filter({ company_name: customerRes.company_name });
              if (companies.length > 0) {
                setCompany(companies[0]);
              }
            }
          }
      }
    } catch (error) {
      console.error("Failed to fetch case details:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (caseId) {
        fetchCaseDetails();
    }
  }, [caseId, location.search]); // location.search is kept to re-fetch on tab changes if tab affects data

  const handleUpdateCaseField = async (field, value) => {
    if (!caseData || !currentUser) return;

    const originalValue = caseData[field];
    if (originalValue === value) return; // No change

    try {
      await Case.update(caseData.id, { [field]: value });
      setCaseData(prev => ({ ...prev, [field]: value })); // Optimistic update

      if (field === 'status') {
        await JobHistory.create({
          case_id: caseData.id,
          action_type: "Status Changed",
          description: `Case status changed from "${originalValue}" to "${value}".`,
          old_value: originalValue,
          new_value: value,
          performed_by: currentUser.email,
          timestamp: new Date().toISOString()
        });
      }
      // Re-fetch everything to ensure all related data (e.g., status timeline) is consistent
      fetchCaseDetails();
    } catch (error) {
      console.error(`Failed to update ${field}:`, error);
      alert(`Failed to update ${field}.`);
      // Revert optimistic update on error
      setCaseData(prev => ({ ...prev, [field]: originalValue }));
    }
  };


  const handleCheckIn = async () => {
      setIsCheckingIn(true);
      try {
          await Case.update(caseData.id, { status: 'In Lab' });
          await JobHistory.create({
              case_id: caseData.id,
              action_type: "Status Changed",
              description: `Case checked into lab. Status changed to "In Lab".`,
              old_value: caseData.status,
              new_value: 'In Lab',
              performed_by: currentUser.email,
              timestamp: new Date().toISOString()
          });
          await fetchCaseDetails();
      } catch (error) {
          console.error("Failed to check in case:", error);
          alert('Failed to check in case.');
      } finally {
          setIsCheckingIn(false);
      }
  };

  const handleDuplicateCase = async () => {
    if (!caseData) return;
    setIsDuplicating(true);
    try {
        const newCaseNumber = await getNextCaseNumber();
        
        // Create new case data with all existing details but new job number
        const newCaseData = {
            ...caseData,
            case_number: newCaseNumber,
            status: 'Received', // Reset to initial status
            created_date: new Date().toISOString(),
            // Set client reference to the previous job number for easy tracking
            client_reference: caseData.case_number, // Previous job number becomes client reference
            // Clear any completion-related fields that shouldn't be copied
            completed_date: null,
            shipped_date: null,
            collection_date: null,
            collected_by_name: null,
            collected_by_mobile: null,
            collected_by_id: null,
        };
        
        // Remove the ID so a new record is created
        delete newCaseData.id;
        
        // Reset device statuses to 'In Lab' for all devices
        if (newCaseData.devices && newCaseData.devices.length > 0) {
            newCaseData.devices = newCaseData.devices.map(device => ({
                ...device,
                device_status: 'In Lab',
                collection_date: null,
                collected_by_name: null,
                collected_by_mobile: null,
                collected_by_id: null,
                registered_date: new Date().toISOString(),
                registered_by: currentUser?.email || 'System'
            }));
        }

        const createdCase = await Case.create(newCaseData);
        
        // Create job history entry for the new duplicated case
        await JobHistory.create({
            case_id: createdCase.id,
            action_type: "Case Created",
            description: `Case #${newCaseNumber} created as duplicate of #${caseData.case_number}. Customer: ${customer?.full_name || 'Unknown'}. All device details and problem description copied from original case.`,
            performed_by: currentUser?.email || 'System',
            timestamp: new Date().toISOString()
        });

        // Show success message with clear information
        const message = `✅ New Job Created Successfully!\n\nNew Job ID: #${createdCase.case_number}\nOriginal Job ID: #${caseData.case_number}\n\nAll customer details, device information, and problem description have been copied to the new job.`;
        alert(message);
        
        // Navigate to the new case
        navigate(createPageUrl(`CaseDetails?id=${createdCase.id}`));
    } catch (error) {
        console.error("Failed to duplicate case:", error);
        alert('❌ Failed to duplicate case. Please try again or contact support.');
    } finally {
        setIsDuplicating(false);
    }
  };

  const toggleStatusVisibility = async (checked) => {
    try {
        await Case.update(caseData.id, { client_portal_status_visible: checked });
        await fetchCaseDetails();
    } catch (error) {
        console.error("Failed to update status visibility:", error);
        alert('Failed to update setting.');
    }
  };

  const handleDeviceSelectionChange = (deviceId) => {
    setSelectedDevices(prev =>
      prev.includes(deviceId) ? prev.filter(id => id !== deviceId) : [...prev, deviceId]
    );
  };

  const handleCheckoutSubmit = async () => {
      const updatedDevices = caseData.devices.map(device => {
          if (selectedDevices.includes(device.media_serial_number)) {
              return {
                  ...device,
                  device_status: 'Collected',
                  ...checkoutFormData,
                  collection_date: new Date().toISOString()
              };
          }
          return device;
      });

      try {
          await Case.update(caseData.id, { devices: updatedDevices });
          await JobHistory.create({
              case_id: caseData.id,
              action_type: "Device Collected",
              description: `Devices collected by ${checkoutFormData.collected_by_name}: ${selectedDevices.join(', ')}`,
              performed_by: currentUser.email,
              timestamp: new Date().toISOString()
          });
          setShowCheckoutDialog(false);
          fetchCaseDetails();
      } catch (error) {
          console.error("Failed to update devices for checkout:", error);
          alert("Failed to checkout devices.");
      }
  };

  const openWhatsappDialog = () => {
    setWhatsappTemplate('');
    setWhatsappMessage('');
    setShowWhatsappDialog(true);
  };

  const handleTemplateChange = (templateKey) => {
    setWhatsappTemplate(templateKey);
    let message = '';
    const customerName = customer?.full_name?.split(' ')[0] || 'Customer';
    const caseNumber = caseData?.case_number;
    const socialLinks = "Stay connected with us for updates and insights:\n🔗 https://www.instagram.com/spacedatarecovery";

    switch(templateKey) {
        case 'completed':
            message = `✅ STATUS UPDATE: DATA RECOVERY COMPLETED #${caseNumber}\n\nGood morning ${customerName},\nYour data recovery has been successfully completed.\n\nPlease submit an empty backup drive for the data transfer.\n\n--\n${socialLinks}`;
            break;
        case 'progress':
            message = `⏳ STATUS UPDATE: RECOVERY IN PROGRESS #${caseNumber}\n\nHi ${customerName},\nJust a quick update: your data recovery is currently in progress. We will notify you as soon as it's complete.\n\n--\n${socialLinks}`;
            break;
        case 'quote_sent':
             message = `📄 QUOTE READY: CASE #${caseNumber}\n\nHi ${customerName},\nYour quote is ready for review. Please check your client portal or email to approve it.\n\n--\n${socialLinks}`;
            break;
        default:
            message = '';
            break;
    }
    setWhatsappMessage(message);
  };

  const sendWhatsappMessage = () => {
      if (!whatsappMessage || !customer?.phone_number) {
          alert('Message or customer phone number is missing.');
          return;
      }
      const phoneNumber = customer.phone_number.replace(/\D/g, '');
      const encodedMessage = encodeURIComponent(whatsappMessage);
      const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;
      window.open(whatsappUrl, '_blank');
      setShowWhatsappDialog(false);
  };

  if (isLoading) {
    return <div className="p-8">Loading case details...</div>;
  }

  if (!caseData) {
    return <div className="p-8">Case not found.</div>;
  }

  const handlePrint = (type, id, deviceId = null) => {
      let url = '';
      let formType = '';
      
      if (type === 'label') {
          url = createPageUrl(`PrintLabel?id=${id}&deviceId=${deviceId}`);
          formType = 'Device Label';
      } else if (type === 'receipt') {
          url = createPageUrl(`PrintReceipt?id=${id}&deviceId=${deviceId}`);
          formType = 'Receipt';
      } else if (type === 'checkout') {
          url = createPageUrl(`PrintCheckout?id=${id}&devices=${selectedDevices.join(',')}`);
          formType = 'Checkout Form';
      } else if (type === 'device-checkout') {
          url = createPageUrl(`PrintDeviceCheckout?id=${id}&devices=${selectedDevices.join(',')}`);
          formType = 'Device Checkout Form';
      }

      if (url && formType) {
        // Check if this form has been printed before
        const printHistory = caseData.print_history || [];
        const previousPrints = printHistory.filter(p => p.form_type === formType);
        
        if (previousPrints.length > 0) {
          const confirmReprint = window.confirm(
            `⚠️ REPRINT WARNING\n\n` +
            `This ${formType} has been printed ${previousPrints.length} time(s) before.\n` +
            `Last printed: ${format(new Date(previousPrints[previousPrints.length - 1].print_date), 'MMM dd, yyyy h:mm a')}\n\n` +
            `Do you want to proceed with reprinting?`
          );
          
          if (!confirmReprint) return;
        }
        
        // Record the print in history
        const updatedPrintHistory = [
          ...printHistory,
          {
            form_type: formType,
            printed_by: currentUser?.email || 'Unknown',
            print_date: new Date().toISOString(),
            is_reprint: previousPrints.length > 0
          }
        ];
        
        // Update case with print history - fire and forget
        Case.update(caseData.id, { print_history: updatedPrintHistory }).catch(error => {
            console.error("Failed to update case print history:", error);
        });
        
        // Log the print action - fire and forget
        JobHistory.create({
          case_id: caseData.id,
          action_type: "Form Printed",
          description: `${formType} ${previousPrints.length > 0 ? 're' : ''}printed${previousPrints.length > 0 ? ` (${previousPrints.length + 1} times total)` : ''}`,
          performed_by: currentUser?.email || 'Unknown',
          timestamp: new Date().toISOString()
        }).catch(error => {
            console.error("Failed to create JobHistory for print:", error);
        });

        window.open(url, '_blank');
      }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      {/* New Header */}
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-4">
          <Button variant="outline" onClick={() => navigate(createPageUrl('Cases'))} className="h-10 w-10 p-0">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-bold text-gray-800">Case #{caseData.case_number}</h1>
              <Badge variant="outline" className={`py-1 ${statusColors[caseData.status] || statusColors.default}`}>{caseData.status}</Badge>
            </div>
            <p className="text-sm text-gray-500 mt-1">
              Created {format(new Date(caseData.created_date), 'MMMM d, yyyy')} by {creatorUser ? creatorUser.full_name : caseData.created_by}
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
            <Button className="bg-cyan-500 hover:bg-cyan-600 text-white" onClick={openWhatsappDialog}>
                <MessageCircle className="w-4 h-4 mr-2" />
                WhatsApp
            </Button>
          <Button
            className="bg-green-500 hover:bg-green-600 text-white"
            onClick={handleCheckIn}
            disabled={isCheckingIn || caseData.status !== 'Received'}
          >
            {isCheckingIn ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <ArrowRightToLine className="w-4 h-4 mr-2" />}
            Check-in
          </Button>
          <Button className="bg-orange-500 hover:bg-orange-600 text-white" onClick={() => handlePrint('label', caseData.id, caseData.devices[0]?.media_serial_number)}>
            <Tag className="w-4 h-4 mr-2" />
            Label
          </Button>
          <Button className="bg-purple-600 hover:bg-purple-700 text-white" onClick={() => setShowCheckoutDialog(true)}>
            <CheckCircle className="w-4 h-4 mr-2" />
            Checkout
          </Button>
          <Button className="bg-blue-600 hover:bg-blue-700 text-white" onClick={handleDuplicateCase} disabled={isDuplicating}>
            {isDuplicating ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : <Copy className="w-4 h-4 mr-2" />}
            Duplicate
          </Button>
        </div>
      </div>

      {/* New Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card><CardContent className="p-4 flex items-center"><UserIcon className="w-6 h-6 text-gray-400 mr-4" /><div><p className="text-xs text-gray-500">Customer</p><p className="font-semibold">{customer ? customer.full_name : 'Unknown'}</p></div></CardContent></Card>
        <Card><CardContent className="p-4 flex items-center"><Server className="w-6 h-6 text-gray-400 mr-4" /><div><p className="text-xs text-gray-500">Service</p><p className="font-semibold">{caseData.service_type || 'N/A'}</p></div></CardContent></Card>
        <Card><CardContent className="p-4 flex items-center"><Package className="w-6 h-6 text-gray-400 mr-4" /><div><p className="text-xs text-gray-500">Devices</p><p className="font-semibold">{caseData.devices?.length || 0} items</p></div></CardContent></Card>
        <Card><CardContent className="p-4 flex items-center"><Activity className="w-6 h-6 text-gray-400 mr-4" /><div><p className="text-xs text-gray-500">Priority</p><p className="font-semibold">{caseData.priority || 'N/A'}</p></div></CardContent></Card>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-12 gap-8">
        <div className="col-span-12">
            <Tabs value={activeTab} onValueChange={updateCurrentTab} className="w-full">
                <TabsList className="grid w-full grid-cols-10 mb-4">
                    <TabsTrigger value="overview"><LayoutDashboard className="w-4 h-4 mr-2"/>Overview</TabsTrigger>
                    <TabsTrigger value="client"><UserIcon className="w-4 h-4 mr-2"/>Client</TabsTrigger>
                    <TabsTrigger value="device"><HardDrive className="w-4 h-4 mr-2"/>Devices</TabsTrigger>
                    <TabsTrigger value="evaluation"><ClipboardCheck className="w-4 h-4 mr-2"/>Evaluation</TabsTrigger>
                    <TabsTrigger value="engineers"><Users className="w-4 h-4 mr-2"/>Engineers</TabsTrigger>
                    <TabsTrigger value="internal_notes"><MessageSquare className="w-4 h-4 mr-2"/>Internal Notes</TabsTrigger>
                    <TabsTrigger value="quotes_invoices"><FileText className="w-4 h-4 mr-2"/>Quotes/Invoices</TabsTrigger>
                    <TabsTrigger value="portal_settings"><Activity className="w-4 h-4 mr-2"/>Client Portal</TabsTrigger>
                    <TabsTrigger value="files"><Paperclip className="w-4 h-4 mr-2"/>Files</TabsTrigger>
                    <TabsTrigger value="history"><History className="w-4 h-4 mr-2"/>History</TabsTrigger>
                </TabsList>

                <TabsContent value="overview">
                  <CaseOverviewTab 
                    caseData={caseData} 
                    customer={customer} 
                    onDataUpdate={fetchCaseDetails}
                    quotes={quotes}
                    invoices={invoices}
                    evaluations={evaluations}
                  />
                </TabsContent>
                <TabsContent value="client">
                    <ClientDetailsTab caseData={caseData} customer={customer} company={company} onDataUpdate={fetchCaseDetails} />
                    <div className="col-span-2 mt-4">
                        <Label>Status</Label>
                        <Select value={caseData.status} onValueChange={(value) => handleUpdateCaseField('status', value)}>
                            <SelectTrigger className="mt-1">
                                <SelectValue placeholder="Select status" />
                            </SelectTrigger>
                            <SelectContent>
                                {caseStatuses.map(status => (
                                    <SelectItem key={status} value={status}>{status}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                </TabsContent>
                <TabsContent value="device"><DeviceInfoTab caseData={caseData} onRefresh={fetchCaseDetails} /></TabsContent>
                <TabsContent value="evaluation"><MediaEvaluationTab caseId={caseData.id} /></TabsContent>
                
                <TabsContent value="engineers">
                    <EngineersTab caseData={caseData} onDataUpdate={fetchCaseDetails} />
                </TabsContent>
                
                <TabsContent value="internal_notes">
                    <InternalNotesTab caseId={caseData.id} />
                </TabsContent>

                <TabsContent value="quotes_invoices"><QuotesInvoicesTab caseId={caseData.id} caseData={caseData} customer={customer} onDataRefresh={fetchCaseDetails} /></TabsContent>
                
                <TabsContent value="portal_settings">
                  <div className="space-y-6">
                    <Card>
                        <CardHeader><CardTitle>Client Portal Settings</CardTitle></CardHeader>
                        <CardContent className="space-y-4">
                            <div className="flex items-center justify-between">
                                <Label htmlFor="status-visibility" className="font-medium">Show Status Timeline in Client Portal</Label>
                                <Switch
                                    id="status-visibility"
                                    checked={caseData.client_portal_status_visible !== false}
                                    onCheckedChange={toggleStatusVisibility}
                                />
                            </div>
                            <p className="text-xs text-gray-500">Enable or disable the detailed status timeline for this case in the client's dashboard.</p>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardHeader><CardTitle>Case Progress Timeline</CardTitle></CardHeader>
                        <CardContent>
                            <CaseStatusTracker 
                                currentStatus={caseData.status} 
                                caseData={caseData}
                                quotes={quotes}
                                showDates={true}
                            />
                        </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                <TabsContent value="files"><FilesTab caseId={caseData.id} /></TabsContent>
                <TabsContent value="history"><JobHistoryTab caseId={caseData.id} /></TabsContent>
            </Tabs>
        </div>
      </div>

      <Dialog open={showCheckoutDialog} onOpenChange={setShowCheckoutDialog}>
          <DialogContent>
              <DialogHeader>
                  <DialogTitle>Device Checkout</DialogTitle>
              </DialogHeader>
              <div className="py-4 space-y-4">
                  <div className="space-y-2">
                      <Label>Select Devices to Checkout:</Label>
                      {caseData.devices?.map(device => (
                          <div key={device.media_serial_number} className="flex items-center space-x-2">
                              <Checkbox
                                id={device.media_serial_number}
                                onCheckedChange={() => handleDeviceSelectionChange(device.media_serial_number)}
                                checked={selectedDevices.includes(device.media_serial_number)}
                              />
                              <label htmlFor={device.media_serial_number} className="text-sm">
                                {device.brand} {device.media_model} (SN: {device.media_serial_number})
                              </label>
                          </div>
                      ))}
                  </div>
                  <div>
                      <Label>Collected By Name</Label>
                      <Input value={checkoutFormData.collected_by_name} onChange={e => setCheckoutFormData({...checkoutFormData, collected_by_name: e.target.value})} />
                  </div>
                  <div>
                      <Label>Collected By Mobile</Label>
                      <Input value={checkoutFormData.collected_by_mobile} onChange={e => setCheckoutFormData({...checkoutFormData, collected_by_mobile: e.target.value})} />
                  </div>
                  <div>
                      <Label>Collected By ID</Label>
                      <Input value={checkoutFormData.collected_by_id} onChange={e => setCheckoutFormData({...checkoutFormData, collected_by_id: e.target.value})} />
                  </div>
              </div>
              <DialogFooter>
                  <Button variant="outline" onClick={() => setShowCheckoutDialog(false)}>Cancel</Button>
                  <Button onClick={handleCheckoutSubmit}>Save Checkout</Button>
                  <Button variant="secondary" onClick={() => handlePrint('device-checkout', caseData.id)}>Print Checkout Form</Button>
              </DialogFooter>
          </DialogContent>
      </Dialog>

      <Dialog open={showWhatsappDialog} onOpenChange={setShowWhatsappDialog}>
          <DialogContent>
              <DialogHeader>
                  <DialogTitle>Send WhatsApp Update</DialogTitle>
              </DialogHeader>
              <div className="py-4 space-y-4">
                  <div>
                      <Label>Select a Template</Label>
                      <Select onValueChange={handleTemplateChange} value={whatsappTemplate}>
                          <SelectTrigger>
                              <SelectValue placeholder="Choose a message template..." />
                          </SelectTrigger>
                          <SelectContent>
                              <SelectItem value="completed">Recovery Completed</SelectItem>
                              <SelectItem value="progress">In Progress</SelectItem>
                              <SelectItem value="quote_sent">Quote Ready</SelectItem>
                          </SelectContent>
                      </Select>
                  </div>
                  <div>
                      <Label>Message</Label>
                      <Textarea 
                          value={whatsappMessage}
                          onChange={e => setWhatsappMessage(e.target.value)}
                          rows={8}
                          className="whitespace-pre-wrap"
                      />
                  </div>
              </div>
              <DialogFooter>
                  <Button variant="outline" onClick={() => setShowWhatsappDialog(false)}>Cancel</Button>
                  <Button onClick={sendWhatsappMessage}>Send via WhatsApp</Button>
              </DialogFooter>
          </DialogContent>
      </Dialog>
    </div>
  );
}
