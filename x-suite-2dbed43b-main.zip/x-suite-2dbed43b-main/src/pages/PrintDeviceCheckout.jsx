
import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Case } from '@/api/entities';
import { Customer } from '@/api/entities';
import { CompanyProfile } from '@/api/entities';
import { User } from '@/api/entities'; // Added User entity import
import { format } from 'date-fns'; // Corrected syntax: from instead of =
import { Button } from '@/components/ui/button';
import { Download, Printer, UserCircle, ClipboardCheck, Laptop, HardDrive, Server, Smartphone, Database, Usb, MemoryStick, Disc, Monitor, PackageCheck } from 'lucide-react';

// Helper function to get device-specific icons
const getDeviceIcon = (mediaType) => {
    if (!mediaType) return HardDrive; // Default icon
    const type = mediaType.toLowerCase();
    
    if (type.includes('laptop') || type.includes('macbook')) return Laptop;
    if (type.includes('hdd') || type.includes('hard drive')) return HardDrive;
    if (type.includes('ssd')) return Database;
    if (type.includes('server') || type.includes('nas')) return Server;
    if (type.includes('mobile') || type.includes('phone') || type.includes('ipad')) return Smartphone;
    if (type.includes('desktop') || type.includes('imac') || type.includes('computer')) return Monitor;
    if (type.includes('usb') || type.includes('flash')) return Usb;
    if (type.includes('memory card') || type.includes('sd')) return MemoryStick;
    if (type.includes('cd') || type.includes('dvd')) return Disc;

    return HardDrive; // Fallback icon
};

export default function PrintDeviceCheckout() {
    const location = useLocation();
    const searchParams = new URLSearchParams(location.search);
    const caseId = searchParams.get('caseId') || searchParams.get('id'); // Check both parameters
    const deviceIndices = searchParams.get('deviceIndices')?.split(',').map(Number); // Parse deviceIndices directly to array of numbers
    const collectorName = searchParams.get('collectorName');
    const collectorMobile = searchParams.get('collectorMobile');
    const collectorId = searchParams.get('collectorId');
    
    const [caseDetails, setCaseDetails] = useState(null);
    const [customer, setCustomer] = useState(null);
    const [companyProfile, setCompanyProfile] = useState(null);
    const [currentUser, setCurrentUser] = useState(null); // Changed from createdByUser to currentUser
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        if (!caseId) {
            setError('Case ID is missing.');
            setIsLoading(false);
            return;
        }

        const fetchData = async () => {
            try {
                // Fetch current user along with other data
                const [caseData, profileData, loggedInUser] = await Promise.all([
                    Case.get(caseId),
                    CompanyProfile.list().then(list => list[0]).catch(() => null),
                    User.me().catch(() => null) // Fetch the current logged-in user
                ]);

                setCaseDetails(caseData);
                setCompanyProfile(profileData);
                setCurrentUser(loggedInUser); // Set the logged-in user

                if (caseData?.customer_id) {
                    const customerData = await Customer.get(caseData.customer_id).catch(() => null);
                    setCustomer(customerData);
                }
            } catch (err) {
                console.error("Failed to fetch data:", err);
                setError('Failed to load document data. Please check the Case ID and try again.');
            } finally {
                setIsLoading(false);
            }
        };

        fetchData();
    }, [caseId]);

    const handleDownloadPDF = () => {
        if (window.html2pdf) {
            const element = document.getElementById('checkout-document');
            const opt = {
                margin: 0.5,
                filename: `checkout-${caseDetails?.case_number || 'document'}.pdf`,
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2 },
                jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' }
            };
            window.html2pdf().set(opt).from(element).save();
        } else {
            window.print();
        }
    };

    if (isLoading) {
        return <div className="flex items-center justify-center h-screen font-sans">Loading Checkout Form...</div>;
    }

    if (error) {
        return <div className="flex items-center justify-center h-screen font-sans text-red-600">{error}</div>;
    }

    // Get selected devices or all devices
    let devicesToCheckOut = [];
    if (deviceIndices && Array.isArray(deviceIndices) && deviceIndices.length > 0 && caseDetails?.devices) { // Updated logic for deviceIndices as an array
        devicesToCheckOut = deviceIndices.map(index => caseDetails.devices[index]).filter(Boolean);
    } else {
        devicesToCheckOut = caseDetails?.devices?.length > 0
            ? caseDetails.devices
            : [{
                media_type: caseDetails?.media_type,
                brand: caseDetails?.brand,
                media_model: caseDetails?.media_model,
                media_serial_number: caseDetails?.media_serial_number,
                capacity: caseDetails?.media_capacity,
                role: 'Patient'
            }];
    }

    return (
        <>
            <style jsx global>{`
                @import url('https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&family=Inter:wght@400;500;600;700&display=swap');
                @page {
                    size: A4;
                    margin: 0.5in;
                }
                @media print {
                    body {
                        -webkit-print-color-adjust: exact;
                        print-color-adjust: exact;
                        color-adjust: exact;
                        background-color: #fff !important;
                    }
                    .no-print {
                        display: none !important;
                    }
                }
                .font-tajawal { font-family: 'Tajawal', sans-serif; }
                .font-inter { font-family: 'Inter', sans-serif; }
                .info-box {
                    border: 1px solid #d1d5db; /* Light gray border */
                    border-radius: 6px;
                    padding: 12px;
                }
                .data-field {
                    border: 1px solid #d1d5db; /* Light gray border */
                    border-radius: 3px;
                    padding: 3px 6px;
                    font-weight: 500;
                    color: #111827; /* Darker text */
                    display: inline-block;
                    min-width: 120px;
                }
            `}</style>
            
            <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>

            {/* No Print Buttons */}
            <div className="no-print fixed top-4 right-4 flex gap-2 z-50">
                <Button onClick={() => window.print()} className="bg-blue-600 hover:bg-blue-700">
                    <Printer className="w-4 h-4 mr-2" />
                    Print
                </Button>
                <Button onClick={handleDownloadPDF} variant="outline">
                    <Download className="w-4 h-4 mr-2" />
                    Download PDF
                </Button>
            </div>

            <div id="checkout-document" className="max-w-4xl mx-auto bg-white font-inter text-sm leading-tight p-4">
                {/* Header */}
                <div className="flex justify-between items-start mb-6">
                    <div className="flex items-center space-x-4">
                        {companyProfile?.full_logo_url ? (
                            <img src={companyProfile.full_logo_url} alt="Company Logo" className="h-12"/>
                        ) : (
                            <div className="text-left">
                                <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-teal-600 bg-clip-text text-transparent leading-tight">
                                    {companyProfile?.logo_text || 'SPACE RECOVERY'}
                                </h1>
                            </div>
                        )}
                    </div>
                    <div className="text-right text-xs text-gray-600 leading-tight">
                        <div className="font-semibold text-gray-800 mb-1">{companyProfile?.company_name || 'Future Space LLC'}</div>
                        <div>{companyProfile?.company_address || '#204, 2nd Floor, Azaiba Mall, Azaiba, Muscat, Oman'}</div>
                        <div>Tel: {companyProfile?.phone_number || '+968 96313467'}</div>
                        <div>Email: {companyProfile?.email || 'info@spacedatarecovery.com'}</div>
                        <div className="text-blue-600">{companyProfile?.website || 'www.spacedatarecovery.com'}</div>
                    </div>
                </div>

                {/* Line separator */}
                <div className="border-t border-gray-300 mb-4"></div>

                {/* Title Section */}
                <div className="text-center mb-4">
                    <h1 className="text-xl font-bold text-gray-900 mb-1">DEVICE CHECKOUT FORM</h1>
                    <h2 className="text-lg font-bold text-gray-700 font-tajawal">نموذج استلام الأجهزة</h2>
                </div>
                
                {/* Job Details Bar - Updated with color */}
                <div className="text-center mb-4 p-2 border rounded">
                    <strong className="text-blue-600">Job ID:</strong> <span className="font-mono text-blue-800 font-semibold">{caseDetails?.case_number}</span>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-4">
                    {/* Customer Information */}
                    <div className="info-box">
                        <div className="flex justify-between items-center mb-3 pb-2 border-b border-gray-300">
                            <h3 className="font-bold text-gray-900 text-sm flex items-center gap-2">
                                <UserCircle className="w-4 h-4 text-gray-500" />
                                Customer Information
                            </h3>
                            <h3 className="font-bold text-gray-900 text-sm font-tajawal">معلومات العميل</h3>
                        </div>
                        <div className="space-y-2 text-xs">
                            <div className="flex">
                                <span className="font-medium w-20">Name:</span>
                                <span className="flex-1 pl-2">{customer?.full_name || 'N/A'}</span>
                            </div>
                            {customer?.company_name && (
                                <div className="flex">
                                    <span className="font-medium w-20">Company:</span>
                                    <span className="flex-1 pl-2">{customer.company_name}</span>
                                </div>
                            )}
                            <div className="flex">
                                <span className="font-medium w-20">Phone:</span>
                                <span className="flex-1 pl-2">{customer?.phone_number || 'N/A'}</span>
                            </div>
                            <div className="flex">
                                <span className="font-medium w-20">Email:</span>
                                <span className="flex-1 pl-2">{customer?.email || 'N/A'}</span>
                            </div>
                        </div>
                    </div>

                    {/* Collection Information */}
                    <div className="info-box">
                        <div className="flex justify-between items-center mb-3 pb-2 border-b border-gray-300">
                            <h3 className="font-bold text-gray-900 text-sm flex items-center gap-2">
                                <ClipboardCheck className="w-4 h-4 text-gray-500" />
                                Collection Details
                            </h3>
                            <h3 className="font-bold text-gray-900 text-sm font-tajawal">معلومات المستلم</h3>
                        </div>
                        <div className="space-y-2 text-xs">
                            <div className="flex">
                                <span className="font-medium w-20">Name:</span>
                                <span className="flex-1 pl-2">{collectorName || 'N/A'}</span>
                            </div>
                            <div className="flex">
                                <span className="font-medium w-20">Mobile:</span>
                                <span className="flex-1 pl-2">{collectorMobile || 'N/A'}</span>
                            </div>
                            <div className="flex">
                                <span className="font-medium w-20">National ID:</span>
                                <span className="flex-1 pl-2">{collectorId || 'N/A'}</span>
                            </div>
                            <div className="flex">
                                <span className="font-medium w-20">Date:</span>
                                <span className="flex-1 pl-2">{format(new Date(), 'dd MMM yyyy, HH:mm')}</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Device Checkout Table */}
                <div className="mb-6">
                    <div className="flex justify-between items-center mb-3">
                        <h3 className="font-bold text-gray-900 text-sm flex items-center">
                            <PackageCheck className="w-4 h-4 mr-2 text-blue-600" />
                            Device(s) Returned
                        </h3>
                        <h3 className="font-bold text-gray-900 text-sm font-tajawal">الأجهزة المُسَلَّمة</h3>
                    </div>
                    
                    <div className="border border-gray-300 rounded overflow-hidden">
                        <table className="w-full text-xs">
                            <thead>
                                <tr className="border-b-2 border-gray-300">
                                    <th className="border-r border-gray-300 px-2 py-1 text-left font-semibold">Type</th>
                                    <th className="border-r border-gray-300 px-2 py-1 text-left font-semibold">Brand</th>
                                    <th className="border-r border-gray-300 px-2 py-1 text-left font-semibold">Model</th>
                                    <th className="border-r border-gray-300 px-2 py-1 text-left font-semibold">Serial Number</th>
                                    <th className="px-2 py-1 text-left font-semibold">Role</th>
                                </tr>
                            </thead>
                            <tbody>
                                {devicesToCheckOut.map((device, index) => {
                                    const DeviceIcon = getDeviceIcon(device.media_type);
                                    return (
                                        <tr key={index}>
                                            <td className="border-t border-r border-gray-300 px-2 py-1 font-medium">
                                                <div className="flex items-center gap-2">
                                                    <DeviceIcon className="w-4 h-4 text-gray-500 flex-shrink-0" />
                                                    <span>{device.media_type || 'N/A'}</span>
                                                </div>
                                            </td>
                                            <td className="border-t border-r border-gray-300 px-2 py-1">{device.brand || 'N/A'}</td>
                                            <td className="border-t border-r border-gray-300 px-2 py-1">{device.media_model || 'N/A'}</td>
                                            <td className="border-t border-r border-gray-300 px-2 py-1 font-mono">{device.media_serial_number || 'N/A'}</td>
                                            <td className="border-t border-gray-300 px-2 py-1">
                                                <span className={`px-1 py-0.5 rounded text-xs font-medium ${
                                                    device.role === 'Patient' ? 'bg-red-100 text-red-800' : 
                                                    device.role === 'Backup' ? 'bg-green-100 text-green-800' :
                                                    'text-gray-800'
                                                }`}>
                                                    {device.role || 'Patient'}
                                                </span>
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                </div>

                {/* Terms & Conditions */}
                <div className="mb-6">
                    <div className="flex justify-between items-center mb-3">
                        <h3 className="font-bold text-gray-900 text-sm">Terms & Conditions</h3>
                        <h3 className="font-bold text-gray-900 text-sm font-tajawal">الشروط والأحكام</h3>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 text-xs leading-relaxed text-gray-700 mb-4">
                        <div>
                            <p>By signing, I confirm receipt of the listed device(s) and the recovery outcome (full, partial, unrecoverable, or declined). From collection, all risk and responsibility for the device(s) and any data transfer to me; {companyProfile?.company_name || 'Future Space LLC'} ({companyProfile?.brand_name || 'Space Recovery'}) has no further liability. Devices are returned as-is after diagnostics; any approved diagnostic/parts fees remain payable.</p>
                        </div>
                        <div className="font-tajawal text-right">
                            <p>بتوقيعي، أؤكد استلام الجهاز/الأجهزة المدرجة ونتيجة الاستعادة (كاملة، جزئية، غير قابلة للاستعادة، أو مرفوضة). من لحظة الجمع، جميع المخاطر والمسؤولية عن الجهاز/الأجهزة وأي نقل للبيانات تنتقل إلي؛ {companyProfile?.company_name || 'فيوتشر سبيس ذ.م.م'} ({companyProfile?.brand_name || 'سبيس ريكافري'}) ليس لها أي مسؤولية أخرى. يتم إرجاع الأجهزة كما هي بعد التشخيص؛ أي رسوم تشخيص/قطع غيار معتمدة تبقى مستحقة الدفع.</p>
                        </div>
                    </div>
                </div>

                {/* Signature Section */}
                <div className="grid grid-cols-2 gap-8 pt-12">
                    <div className="text-center">
                         {/* Placeholder for alignment */}
                        <div className="h-5 mb-1"></div>
                        <div className="border-t-2 border-dotted border-gray-400 pt-2">
                            <div className="font-bold text-sm">Customer Signature</div>
                            <div className="text-xs text-gray-600 font-tajawal">توقيع العميل</div>
                        </div>
                    </div>
                    <div className="text-center">
                        <div className="text-xs text-gray-500 mb-1 h-5 flex items-end justify-center">
                            <span>Prepared by: {currentUser?.full_name || 'System'}</span> {/* Display currentUser's full_name */}
                        </div>
                        <div className="border-t-2 border-dotted border-gray-400 pt-2">
                            <div className="font-bold text-sm">Company Representative</div>
                            <div className="text-xs text-gray-600 font-tajawal">ممثل الشركة</div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
