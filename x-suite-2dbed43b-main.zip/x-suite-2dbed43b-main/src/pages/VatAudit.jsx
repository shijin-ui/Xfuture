
import React, { useState, useEffect, useMemo } from 'react';
import { Invoice } from '@/api/entities';
import { Expense } from '@/api/entities';
import { CompanyProfile } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Download, ArrowUpRight, ArrowDownRight, Scale, Check, X } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { format, parseISO, getYear, getQuarter, startOfQuarter, endOfQuarter, isWithinInterval } from 'date-fns';
import { getDefaultLocale, formatCurrency } from '@/components/utils/currencyFormatter';

const MetricCard = ({ title, value, icon: Icon, color }) => (
    <Card className="shadow-lg hover:shadow-xl transition-all duration-300 border-0 overflow-hidden">
        <div className={`h-1 bg-gradient-to-r ${color}`}></div>
        <CardContent className="p-6">
            <div className="flex items-center justify-between">
                <div>
                    <p className="text-sm font-medium text-gray-500">{title}</p>
                    <p className="text-2xl font-bold text-gray-900">{value}</p>
                </div>
                <div className={`p-3 rounded-xl bg-gradient-to-br ${color} shadow-lg`}>
                    <Icon className="w-6 h-6 text-white" />
                </div>
            </div>
        </CardContent>
    </Card>
);

const VatReportTable = ({ title, data, type, locale }) => (
    <Card className="shadow-lg">
        <CardHeader>
            <CardTitle>{title}</CardTitle>
        </CardHeader>
        <CardContent>
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Date</TableHead>
                        <TableHead>Reference #</TableHead>
                        <TableHead>Client/Vendor</TableHead>
                        <TableHead className="text-right">Net Amount</TableHead>
                        <TableHead className="text-right">VAT Amount</TableHead>
                        {type === 'purchases' && <TableHead>Claimable</TableHead>}
                        <TableHead className="text-right">Total Amount</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {data.length === 0 ? (
                        <TableRow>
                            <TableCell colSpan={type === 'purchases' ? 7 : 6} className="text-center py-10">
                                No transactions for this period.
                            </TableCell>
                        </TableRow>
                    ) : (
                        data.map(item => (
                            <TableRow key={item.id}>
                                <TableCell>{format(parseISO(item.date), 'dd MMM yyyy')}</TableCell>
                                <TableCell className="font-medium">{item.reference}</TableCell>
                                <TableCell>{item.party}</TableCell>
                                <TableCell className="text-right font-mono">
                                    {formatCurrency(item.netAmount, locale)}
                                </TableCell>
                                <TableCell className="text-right font-mono">
                                    {formatCurrency(item.vatAmount, locale)}
                                </TableCell>
                                {type === 'purchases' && (
                                    <TableCell>
                                        {item.is_vat_claimable !== false ? (
                                            <Badge className="bg-green-100 text-green-800"><Check className="w-3 h-3 mr-1"/> Yes</Badge>
                                        ) : (
                                            <Badge variant="destructive" className="bg-red-100 text-red-800"><X className="w-3 h-3 mr-1"/> No</Badge>
                                        )}
                                    </TableCell>
                                )}
                                <TableCell className="text-right font-mono font-semibold">
                                    {formatCurrency(item.totalAmount, locale)}
                                </TableCell>
                            </TableRow>
                        ))
                    )}
                </TableBody>
            </Table>
        </CardContent>
    </Card>
);

export default function VatAuditPage() {
    const [invoices, setInvoices] = useState([]);
    const [expenses, setExpenses] = useState([]);
    const [profile, setProfile] = useState(null);
    const [locale, setLocale] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [period, setPeriod] = useState(getCurrentPeriod());

    function getCurrentPeriod() {
        const now = new Date();
        const year = getYear(now);
        const quarter = getQuarter(now);
        return `${year}-Q${quarter}`;
    }

    useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            try {
                const [invData, expData, profData, locData] = await Promise.all([
                    Invoice.list('-created_date'),
                    Expense.list('-expense_date'),
                    CompanyProfile.list().then(p => p[0]),
                    getDefaultLocale()
                ]);
                setInvoices(invData);
                setExpenses(expData);
                setProfile(profData);
                setLocale(locData);
            } catch (error) {
                console.error("Failed to fetch VAT data:", error);
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, []);

    const vatData = useMemo(() => {
        if (isLoading) return {
            vatCollected: 0,
            vatPaid: 0,
            netVat: 0,
            vatOnSales: [],
            vatOnPurchases: [],
            dateRange: { start: new Date(), end: new Date() } // Default for loading
        };

        const [yearStr, quarterStr] = period.split('-');
        const year = parseInt(yearStr);
        const quarter = parseInt(quarterStr.replace('Q', ''));
        const dateForQuarter = new Date(year, (quarter - 1) * 3, 1);
        const start = startOfQuarter(dateForQuarter);
        const end = endOfQuarter(dateForQuarter);
        const currentPeriodDateRange = { start, end };

        const filteredInvoices = invoices.filter(inv => inv.created_date && isWithinInterval(parseISO(inv.created_date), currentPeriodDateRange));
        const filteredExpenses = expenses.filter(exp => exp.expense_date && isWithinInterval(parseISO(exp.expense_date), currentPeriodDateRange));

        const totalVatCollected = filteredInvoices.reduce((sum, inv) => sum + (inv.vat_amount || 0), 0);
        // Only sum VAT from claimable expenses
        const totalVatPaid = filteredExpenses
            .filter(exp => exp.is_vat_claimable !== false)
            .reduce((sum, exp) => sum + (exp.vat_amount || 0), 0);

        return {
            vatCollected: totalVatCollected,
            vatPaid: totalVatPaid,
            netVat: totalVatCollected - totalVatPaid,
            vatOnSales: filteredInvoices.map(inv => ({
                id: inv.id,
                date: inv.created_date,
                reference: inv.invoice_number,
                party: inv.customer_id || 'N/A', // Using customer_id for party
                netAmount: inv.subtotal || 0,
                vatAmount: inv.vat_amount || 0,
                totalAmount: inv.total_amount || 0,
            })),
            vatOnPurchases: filteredExpenses.map(exp => ({
                id: exp.id,
                date: exp.expense_date,
                reference: exp.description || exp.id, // Using description or ID as reference
                party: exp.vendor || 'N/A',
                netAmount: exp.amount || 0,
                vatAmount: exp.vat_amount || 0,
                totalAmount: exp.total_amount || 0,
                is_vat_claimable: exp.is_vat_claimable, // Pass the field
            })),
            dateRange: currentPeriodDateRange
        };
    }, [invoices, expenses, period, isLoading]);

    const handleExport = () => {
        let csvContent = 'data:text/csv;charset=utf-8,';

        // Add company details to CSV
        csvContent += `Company Name,${profile?.company_name}\n`;
        csvContent += `Country,${locale?.country_name}\n`;
        csvContent += `Reporting Period,${period.replace('-', ' ')}\n`;
        csvContent += `Period Start,${format(vatData.dateRange.start, 'yyyy-MM-dd')}\n`;
        csvContent += `Period End,${format(vatData.dateRange.end, 'yyyy-MM-dd')}\n`;
        csvContent += `\nVAT Summary\n`;
        csvContent += `VAT Collected (Output VAT),${vatData.vatCollected.toFixed(3)}\n`;
        csvContent += `VAT Paid (Input VAT),${vatData.vatPaid.toFixed(3)}\n`;
        csvContent += `Net VAT Payable / (Refundable),${vatData.netVat.toFixed(3)}\n`;


        // Sales Data
        csvContent += '\nVAT on Sales (Output VAT)\n';
        csvContent += 'Date,Reference #,Customer,Net Amount,VAT Amount,Total Amount\n';
        vatData.vatOnSales.forEach(item => {
            csvContent += `${format(parseISO(item.date), 'yyyy-MM-dd')},"${item.reference}","${item.party}",${item.netAmount.toFixed(3)},${item.vatAmount.toFixed(3)},${item.totalAmount.toFixed(3)}\n`;
        });
        csvContent += `\nTotal Sales (pre-tax),,${vatData.vatOnSales.reduce((s,i) => s + i.netAmount, 0).toFixed(3)}\n`;
        csvContent += `Total VAT Collected,,,${vatData.vatCollected.toFixed(3)}\n`;


        // Purchases Data
        csvContent += '\nVAT on Purchases (Input VAT)\n';
        csvContent += 'Date,Reference #,Vendor,Net Amount,VAT Amount,VAT Claimable,Total Amount\n';
        vatData.vatOnPurchases.forEach(item => {
            const claimable = item.is_vat_claimable !== false ? 'Yes' : 'No';
            csvContent += `${format(parseISO(item.date), 'yyyy-MM-dd')},"${item.reference}","${item.party}",${item.netAmount.toFixed(3)},${item.vatAmount.toFixed(3)},"${claimable}",${item.totalAmount.toFixed(3)}\n`;
        });
        const totalClaimableVat = vatData.vatOnPurchases
            .filter(item => item.is_vat_claimable !== false)
            .reduce((s, i) => s + i.vatAmount, 0);
            
        csvContent += `\nTotal Purchases (pre-tax),,${vatData.vatOnPurchases.reduce((s,i) => s + i.netAmount, 0).toFixed(3)}\n`;
        csvContent += `Total VAT Paid (Claimable),,,${totalClaimableVat.toFixed(3)}\n`;


        const encodedUri = encodeURI(csvContent);
        const link = document.createElement('a');
        link.setAttribute('href', encodedUri);
        link.setAttribute('download', `VAT_Report_${period}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const periodOptions = useMemo(() => {
        const options = [];
        const currentYear = getYear(new Date());
        for (let y = currentYear; y >= currentYear - 3; y--) {
            for (let q = 4; q >= 1; q--) {
                options.push(`${y}-Q${q}`);
            }
        }
        return options;
    }, []);

    if (isLoading) {
        return <div className="p-8">Loading VAT data...</div>;
    }
    
    if (!profile) {
        return <div className="p-8 text-red-500">Company Profile not set. Please configure it in Settings.</div>;
    }

    return (
        <div className="p-8 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
            <div className="flex justify-between items-center mb-8">
                <div>
                    <h1 className="text-3xl font-bold text-gray-800">VAT & Audit Report</h1>
                    <p className="text-gray-500">For {profile.company_name} ({locale?.country_name})</p>
                </div>
                <div className="flex items-center space-x-4">
                    <Select value={period} onValueChange={setPeriod}>
                        <SelectTrigger className="w-[180px]">
                            <SelectValue placeholder="Select period" />
                        </SelectTrigger>
                        <SelectContent>
                            {periodOptions.map(opt => <SelectItem key={opt} value={opt}>{opt.replace('-', ' ')}</SelectItem>)}
                        </SelectContent>
                    </Select>
                    <Button onClick={handleExport}><Download className="w-4 h-4 mr-2" /> Export Reports (CSV)</Button>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <MetricCard title="VAT Collected (Output)" value={formatCurrency(vatData.vatCollected, locale)} icon={ArrowUpRight} color="from-green-500 to-emerald-500" />
                <MetricCard title="VAT Paid (Input)" value={formatCurrency(vatData.vatPaid, locale)} icon={ArrowDownRight} color="from-red-500 to-orange-500" />
                <MetricCard title="Net VAT Payable" value={formatCurrency(vatData.netVat, locale)} icon={Scale} color="from-blue-500 to-indigo-500" />
            </div>

            <Tabs defaultValue="summary">
                <TabsList className="mb-4">
                    <TabsTrigger value="summary">Summary</TabsTrigger>
                    <TabsTrigger value="sales">VAT on Sales (Invoices)</TabsTrigger>
                    <TabsTrigger value="purchases">VAT on Purchases (Expenses)</TabsTrigger>
                </TabsList>
                
                <TabsContent value="summary">
                    <Card className="shadow-lg">
                        <CardHeader>
                            <CardTitle>VAT Summary for {period.replace('-', ' ')}</CardTitle>
                            <p className="text-sm text-gray-500">Period: {format(vatData.dateRange.start, 'dd MMM yyyy')} to {format(vatData.dateRange.end, 'dd MMM yyyy')}</p>
                        </CardHeader>
                        <CardContent>
                            <Table>
                                <TableBody>
                                    <TableRow>
                                        <TableCell className="font-semibold">Total Sales (pre-tax)</TableCell>
                                        <TableCell className="text-right font-mono">{formatCurrency(vatData.vatOnSales.reduce((s, i) => s + i.netAmount, 0), locale)}</TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell className="font-semibold text-green-600">Total VAT Collected (Output VAT)</TableCell>
                                        <TableCell className="text-right font-mono text-green-600">{formatCurrency(vatData.vatCollected, locale)}</TableCell>
                                    </TableRow>
                                    <TableRow>
                                        <TableCell className="font-semibold">Total Purchases (pre-tax)</TableCell>
                                        <TableCell className="text-right font-mono">{formatCurrency(vatData.vatOnPurchases.reduce((s, e) => s + e.netAmount, 0), locale)}</TableCell>
                                    </TableRow>
                                     <TableRow>
                                        <TableCell className="font-semibold text-red-600">Total VAT Paid (Input VAT)</TableCell>
                                        <TableCell className="text-right font-mono text-red-600">{formatCurrency(vatData.vatPaid, locale)}</TableCell>
                                    </TableRow>
                                    <TableRow className="bg-gray-50">
                                        <TableCell className="font-bold text-lg">Net VAT Payable / (Refundable)</TableCell>
                                        <TableCell className="text-right font-mono font-bold text-lg">{formatCurrency(vatData.netVat, locale)}</TableCell>
                                    </TableRow>
                                </TableBody>
                            </Table>
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="sales">
                    <VatReportTable title="VAT on Sales Details" data={vatData.vatOnSales} type="sales" locale={locale} />
                </TabsContent>

                <TabsContent value="purchases">
                    <VatReportTable title="VAT on Purchases Details" data={vatData.vatOnPurchases} type="purchases" locale={locale} />
                </TabsContent>
            </Tabs>
        </div>
    );
}
