
import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { UserPlus, MoreHorizontal, UserCog } from 'lucide-react';
import { format } from 'date-fns';

export default function UsersPage() {
  const [users, setUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isInviteDialogOpen, setIsInviteDialogOpen] = useState(false);
  const [inviteData, setInviteData] = useState({ email: '', access_role: 'Technician', fullName: '' });

  const fetchUsers = async () => {
    setIsLoading(true);
    try {
      const userList = await User.list();
      setUsers(userList);
    } catch (error) {
      console.error("Failed to fetch users:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleSendInvite = async () => {
    if (!inviteData.email || !inviteData.fullName) {
      alert("Please enter the user's full name and email address.");
      return;
    }

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(inviteData.email)) {
      alert("Please enter a valid email address.");
      return;
    }

    // Since SendEmail can't send to external users, we'll provide manual invitation instructions
    const appUrl = window.location.origin;
    const invitationMessage = `
📧 INVITATION DETAILS FOR: ${inviteData.fullName}

Email: ${inviteData.email}
Role: ${inviteData.access_role}
App URL: ${appUrl}

MANUAL INVITATION STEPS:
1. Send the following message to ${inviteData.email} via your email client:

---
Subject: Invitation to join Space Recovery - ${inviteData.access_role} Role

Hello ${inviteData.fullName},

You have been invited to join our Space Recovery application as a ${inviteData.access_role}.

To get started, please:
1. Visit: ${appUrl}
2. Sign up with your Google account
3. Contact your administrator to assign your role

If you have any questions, please contact your administrator.

Best regards,
Space Recovery Team
---

2. After they sign up, their account will appear in the user list
3. You can then change their role using the Actions menu

Would you like to copy this invitation text?`;

    if (confirm(invitationMessage)) {
      // Copy to clipboard if possible
      try {
        await navigator.clipboard.writeText(`Subject: Invitation to join Space Recovery - ${inviteData.access_role} Role

Hello ${inviteData.fullName},

You have been invited to join our Space Recovery application as a ${inviteData.access_role}.

To get started, please:
1. Visit: ${appUrl}
2. Sign up with your Google account
3. Contact your administrator to assign your role

If you have any questions, please contact your administrator.

Best regards,
Space Recovery Team`);
        
        alert("✅ Invitation text copied to clipboard!\n\nPlease paste this into your email client and send it to the user.");
      } catch (error) {
        alert("✅ Please manually copy the invitation text from the previous dialog and send it via email.");
      }
    }
    
    setIsInviteDialogOpen(false);
    setInviteData({ email: '', access_role: 'Technician', fullName: '' });
  };

  const handleRoleChange = async (userId, newRole) => {
    try {
      const builtInRole = newRole === 'Admin' ? 'admin' : 'user';
      // Atomically update both the custom role and the required built-in role
      await User.update(userId, { access_role: newRole, role: builtInRole });
      fetchUsers(); // Refresh user list
    } catch (error) {
      console.error("Failed to update role:", error);
      alert("Failed to update user role.");
    }
  };
  
  const getInitials = (name) => {
    if (!name) return '';
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase();
  };

  const roles = ["Admin", "Technician", "Sales", "Accounts"];

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-800 flex items-center">
          <UserCog className="w-8 h-8 mr-3 text-indigo-600" />
          User Management
        </h1>
        <Dialog open={isInviteDialogOpen} onOpenChange={setIsInviteDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <UserPlus className="w-4 h-4 mr-2" />
              Invite User
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Invite a New User</DialogTitle>
              <DialogDescription>
                Generate invitation details to manually send to the user.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                <p className="text-sm text-blue-800">
                  <strong>Note:</strong> Due to platform limitations, invitations must be sent manually. 
                  Click "Generate Invitation" to get the invitation text to send via your email client.
                </p>
              </div>
              <div>
                <Label htmlFor="fullName">Full Name *</Label>
                <Input
                  id="fullName"
                  value={inviteData.fullName}
                  onChange={(e) => setInviteData({ ...inviteData, fullName: e.target.value })}
                  placeholder="e.g. John Doe"
                  required
                />
              </div>
              <div>
                <Label htmlFor="email">Email Address *</Label>
                <Input
                  id="email"
                  type="email"
                  value={inviteData.email}
                  onChange={(e) => setInviteData({ ...inviteData, email: e.target.value })}
                  placeholder="user@example.com"
                  required
                />
              </div>
              <div>
                <Label htmlFor="role">Role *</Label>
                <Select
                  value={inviteData.access_role}
                  onValueChange={(value) => setInviteData({ ...inviteData, access_role: value })}
                >
                  <SelectTrigger id="role">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {roles.map(role => (
                      <SelectItem key={role} value={role}>{role}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsInviteDialogOpen(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleSendInvite}
                disabled={!inviteData.email || !inviteData.fullName}
              >
                Generate Invitation
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Date Joined</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-10">Loading users...</TableCell>
                </TableRow>
              ) : users.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-10">No users found.</TableCell>
                </TableRow>
              ) : (
                users.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">
                      <div className="flex items-center space-x-3">
                        <Avatar>
                          <AvatarImage src={user.avatar_url} />
                          <AvatarFallback className="bg-gray-200">{getInitials(user.full_name)}</AvatarFallback>
                        </Avatar>
                        <span>{user.full_name}</span>
                      </div>
                    </TableCell>
                    <TableCell>{user.email}</TableCell>
                    <TableCell>
                      <Badge variant={user.access_role === 'Admin' ? 'destructive' : 'secondary'}>
                        {user.access_role || user.role}
                      </Badge>
                    </TableCell>
                    <TableCell>{format(new Date(user.created_date), 'dd MMM yyyy')}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent>
                          {roles.map(role => (
                            <DropdownMenuItem 
                              key={role}
                              onClick={() => handleRoleChange(user.id, role)}
                              disabled={user.access_role === role}
                            >
                              Change role to {role}
                            </DropdownMenuItem>
                          ))}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
