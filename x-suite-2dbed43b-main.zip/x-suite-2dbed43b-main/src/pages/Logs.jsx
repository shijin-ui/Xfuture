import React, { useEffect, useMemo, useState } from "react";
import { LogEvent } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import QuickDateRange from "@/components/common/QuickDateRange";
import DataExportButtons from "@/components/common/DataExportButtons";

export default function LogsPage() {
  const [logs, setLogs] = useState([]);
  const [users, setUsers] = useState([]);
  const [filters, setFilters] = useState({ module: "all", user: "all", action: "", q: "" });
  const [range, setRange] = useState(null);

  useEffect(() => {
    const load = async () => {
      const [ls, us] = await Promise.all([LogEvent.list("-time", 5000), User.list()]);
      setLogs(ls);
      setUsers(us);
    };
    load();
  }, []);

  const modules = ["all", "Case", "Quote", "Invoice", "Payment", "Stock", "PO", "HR", "Tasks", "Password"];
  const filtered = useMemo(() => {
    return logs.filter(l => {
      const byModule = filters.module === "all" || l.module === filters.module;
      const byUser = filters.user === "all" || l.user === filters.user;
      const byAction = !filters.action || (l.action || "").toLowerCase().includes(filters.action.toLowerCase());
      const byText = !filters.q || (l.summary + " " + (l.details || "")).toLowerCase().includes(filters.q.toLowerCase());
      const byDate = !range || (l.time && new Date(l.time) >= range.start && new Date(l.time) <= range.end);
      return byModule && byUser && byAction && byText && byDate;
    });
  }, [logs, filters, range]);

  const toCsv = (rows) => {
    const header = "Time,User,Module,Action,EntityId,Summary";
    const lines = rows.map(r => [
      r.time, r.user, r.module, r.action, r.entityId || "", (r.summary || "").replace(/,/g, ";")
    ].join(","));
    return [header, ...lines].join("\n");
  };

  return (
    <div className="p-6">
      <Card>
        <CardHeader className="flex items-center justify-between">
          <CardTitle>System Logs</CardTitle>
          <div className="flex gap-2 items-center">
            <Input placeholder="Search..." value={filters.q} onChange={e => setFilters({ ...filters, q: e.target.value })} className="w-56" />
            <Input placeholder="Action" value={filters.action} onChange={e => setFilters({ ...filters, action: e.target.value })} className="w-40" />
            <Select value={filters.module} onValueChange={(v) => setFilters({ ...filters, module: v })}>
              <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
              <SelectContent>
                {modules.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}
              </SelectContent>
            </Select>
            <Select value={filters.user} onValueChange={(v) => setFilters({ ...filters, user: v })}>
              <SelectTrigger className="w-48"><SelectValue placeholder="User" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Users</SelectItem>
                {users.map(u => <SelectItem key={u.id} value={u.email}>{u.full_name}</SelectItem>)}
              </SelectContent>
            </Select>
            <QuickDateRange value={range} onChange={setRange} />
            <DataExportButtons rows={filtered} filename="logs" toCsv={toCsv} />
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-auto">
            <table className="w-full text-sm">
              <thead className="sticky top-0 bg-muted">
                <tr>
                  <th className="text-left p-2">Time</th>
                  <th className="text-left p-2">User</th>
                  <th className="text-left p-2">Module</th>
                  <th className="text-left p-2">Action</th>
                  <th className="text-left p-2">Entity Id</th>
                  <th className="text-left p-2">Summary</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(l => (
                  <tr key={l.id} className="hover:bg-muted/50">
                    <td className="p-2">{l.time}</td>
                    <td className="p-2">{l.user}</td>
                    <td className="p-2">{l.module}</td>
                    <td className="p-2">{l.action}</td>
                    <td className="p-2">{l.entityId || ""}</td>
                    <td className="p-2">{l.summary}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}