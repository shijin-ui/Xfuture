
import React, { useState, useEffect } from 'react';
import { useLocation, Link, useNavigate } from 'react-router-dom';
import { Customer } from '@/api/entities';
import { Case } from '@/api/entities';
import { Quote } from '@/api/entities';
import { Invoice } from '@/api/entities';
import { Transaction } from '@/api/entities';
import { CaseFile } from '@/api/entities';
import { Communication } from '@/api/entities';
import { JobHistory } from '@/api/entities';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
    User, ArrowLeft, Mail, Phone, MapPin, Building, Hash, Edit,
    HardDrive, FileText, DollarSign, Activity, MessageSquare,
    ExternalLink, QrCode, Link as LinkIcon, Eye, EyeOff, Calendar,
    CheckCircle, XCircle, Clock, AlertTriangle, Download
} from 'lucide-react';
import { format } from 'date-fns';
import { createPageUrl } from '@/utils';
import EditCustomerDialog from '../components/case/EditCustomerDialog';
import CaseStatusTracker from '../components/case/CaseStatusTracker'; // Import the tracker
import { MediaEvaluation } from '@/api/entities'; // Import MediaEvaluation

const StatCard = ({ icon: Icon, title, value, color, subtitle }) => (
    <Card className={`overflow-hidden border-${color}-200 bg-gradient-to-br from-white to-${color}-50`}>
        <CardContent className="p-4">
            <div className="flex items-center space-x-4">
                <div className={`p-3 rounded-lg bg-${color}-100`}>
                    <Icon className={`w-6 h-6 text-${color}-600`} />
                </div>
                <div>
                    <p className="text-sm font-medium text-gray-500">{title}</p>
                    <p className="text-2xl font-bold text-gray-800">{value}</p>
                    {subtitle && <p className="text-xs text-gray-500">{subtitle}</p>}
                </div>
            </div>
        </CardContent>
    </Card>
);

const DetailRow = ({ icon: Icon, label, value, isLink = false }) => {
    if (!value && value !== 0) return null;
    return (
        <div className="flex items-start py-2">
            <Icon className="w-4 h-4 mr-3 mt-1 text-gray-500" />
            <div>
                <p className="text-xs text-gray-500 mb-0.5">{label}</p>
                {isLink ? (
                    <a href={isLink === 'email' ? `mailto:${value}`: `tel:${value}`} className="text-sm font-medium text-blue-600 hover:underline">{value}</a>
                ) : (
                    <p className="text-sm font-medium text-gray-800">{value}</p>
                )}
            </div>
        </div>
    );
};

export default function CustomerProfilePage() {
    const location = useLocation();
    const navigate = useNavigate();
    const searchParams = new URLSearchParams(location.search);
    const customerId = searchParams.get('id');

    const [customer, setCustomer] = useState(null);
    const [cases, setCases] = useState([]);
    const [quotes, setQuotes] = useState([]);
    const [invoices, setInvoices] = useState([]);
    const [transactions, setTransactions] = useState([]);
    const [files, setFiles] = useState([]);
    const [communications, setCommunications] = useState([]);
    const [jobHistory, setJobHistory] = useState([]); // Renamed from logs
    const [evaluations, setEvaluations] = useState([]); // State for evaluations
    const [loading, setLoading] = useState(true); // Renamed from isLoading
    const [error, setError] = useState(null);
    const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
    const [showPortalToken, setShowPortalToken] = useState(false);

    const fetchData = async () => {
        if (!customerId) {
            setError('No customer ID provided in the URL. Please ensure you have a valid customer ID to view the profile.');
            setLoading(false);
            return;
        }

        setLoading(true);
        setError(null);

        try {
            // Try to fetch customer data with proper error handling
            let customerData = null;
            try {
                customerData = await Customer.get(customerId);
            } catch (customerError) {
                console.error('Failed to fetch customer:', customerError);
                if (customerError.message && customerError.message.includes('Object not found')) {
                    setError('Customer not found. This customer may have been deleted or you may not have permission to view it.');
                } else {
                    setError(`Failed to load customer data: ${customerError.message || 'Unknown error'}`);
                }
                setLoading(false);
                return;
            }

            if (!customerData) {
                setError('Customer data is not available after fetching. This might indicate an issue with the data returned.');
                setLoading(false);
                return;
            }

            setCustomer(customerData);

            const [
                casesData,
                quotesData,
                invoicesData,
                transactionsData,
                filesData,
                commsData,
                historyData
            ] = await Promise.all([
                Case.filter({ customer_id: customerId }, '-created_date'),
                Quote.filter({ customer_id: customerId }, '-created_date'),
                Invoice.filter({ customer_id: customerId }, '-created_date'),
                Transaction.filter({ customer_id: customerId }, '-transaction_date'),
                CaseFile.filter({ customer_id: customerId }, '-upload_date'), // Filter by customer_id
                Communication.filter({ customer_id: customerId }, '-communication_date'),
                JobHistory.filter({ customer_id: customerId }, '-timestamp') // Filter by customer_id
            ]);
            
            setCases(casesData);
            setQuotes(quotesData);
            setInvoices(invoicesData);
            setTransactions(transactionsData);
            setFiles(filesData);
            setCommunications(commsData);
            setJobHistory(historyData); // Renamed state

            // Fetch evaluations for all cases
            const caseIds = casesData.map(c => c.id);
            if (caseIds.length > 0) {
                 const evalData = await MediaEvaluation.filter({ case_id: { $in: caseIds } });
                 setEvaluations(evalData);
            } else {
                 setEvaluations([]); // Ensure evaluations are cleared if no cases
            }

        } catch (error) {
            console.error('Failed to fetch customer profile:', error);
            setError(`An unexpected error occurred while fetching customer profile: ${error.message || 'Unknown error'}`);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, [location.search, customerId]); // Depend on location.search to re-fetch if URL parameter changes

    const generatePortalLink = async () => {
        if (!customer) return;

        try {
            // Generate a secure token
            const token = Math.random().toString(36).substring(2) + Date.now().toString(36);

            await Customer.update(customer.id, {
                client_portal_token: token,
                client_portal_enabled: true
            });

            setCustomer(prev => ({ ...prev, client_portal_token: token, client_portal_enabled: true }));
            alert('Portal link generated successfully!');
        } catch (error) {
            console.error('Failed to generate portal link:', error);
            alert('Failed to generate portal link.');
        }
    };

    const statusColors = {
        'Received': 'bg-blue-100 text-blue-800',
        'In Lab': 'bg-purple-100 text-purple-800',
        'Diagnosis': 'bg-orange-100 text-orange-800',
        'Quoted': 'bg-yellow-100 text-yellow-800',
        'Approved': 'bg-indigo-100 text-indigo-800',
        'In Progress': 'bg-cyan-100 text-cyan-800',
        'Data Ready': 'bg-emerald-100 text-emerald-800',
        'Payment Pending': 'bg-amber-100 text-amber-800',
        'Completed': 'bg-green-100 text-green-800',
        'Closed': 'bg-gray-100 text-gray-800',
        'Returned': 'bg-red-100 text-red-800'
    };

    if (loading) { // Renamed from isLoading
        return (
            <div className="flex h-screen items-center justify-center">
                <div className="text-center">
                    <div className="flex items-center justify-center space-x-2 mb-4">
                        <div className="w-8 h-8 bg-blue-500 rounded-full animate-pulse"></div>
                        <div className="w-8 h-8 bg-indigo-500 rounded-full animate-pulse delay-150"></div>
                        <div className="w-8 h-8 bg-purple-500 rounded-full animate-pulse delay-300"></div>
                    </div>
                    <p className="text-gray-600">Loading customer profile...</p>
                </div>
            </div>
        );
    }

    if (error) {
        return (
            <div className="p-8 text-center">
                <div className="max-w-md mx-auto bg-white rounded-lg shadow-lg p-6 border border-red-200">
                    <AlertTriangle className="w-12 h-12 mx-auto mb-4 text-red-500" />
                    <h1 className="text-2xl font-bold mb-2 text-red-600">Unable to Load Customer</h1>
                    <p className="mb-6 text-gray-700">{error}</p>
                    <div className="space-y-3">
                        <Button onClick={() => navigate(createPageUrl('Customers'))} className="w-full">
                            <ArrowLeft className="w-4 h-4 mr-2" />
                            Back to Customers
                        </Button>
                        <Button variant="outline" onClick={() => window.location.reload()} className="w-full">
                            Try Again
                        </Button>
                    </div>
                </div>
            </div>
        );
    }

    if (!customer) {
        return (
            <div className="p-8 text-center">
                <div className="max-w-md mx-auto bg-white rounded-lg shadow-lg p-6">
                    <h1 className="text-xl font-bold mb-2">Customer Not Found</h1>
                    <p className="mb-4 text-gray-600">The customer you're looking for doesn't exist or has been removed.</p>
                    <Button onClick={() => navigate(createPageUrl('Customers'))}>
                        <ArrowLeft className="w-4 h-4 mr-2" />
                        Back to Customers
                    </Button>
                </div>
            </div>
        );
    }

    // Derived stats for StatCards
    const totalCases = cases.length;
    const openCases = cases.filter(c => !['Completed', 'Closed', 'Returned'].includes(c.status)).length;
    const totalRevenue = invoices.filter(i => i.status === 'Paid').reduce((sum, i) => sum + (i.total_amount || 0), 0);
    const pendingQuotes = quotes.filter(q => q.status === 'Sent').length;


    const portalUrl = customer.client_portal_token ?
        `${window.location.origin}${createPageUrl(`ClientPortal?token=${customer.client_portal_token}`)}` :
        null;

    return (
        <div className="p-8 bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 min-h-screen">
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-4">
                    <Link to={createPageUrl('Customers')}>
                        <Button variant="outline" size="icon">
                            <ArrowLeft className="w-4 h-4" />
                        </Button>
                    </Link>
                    <div>
                        <h1 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                            {customer.full_name}
                        </h1>
                        <div className="flex items-center gap-4 text-sm text-gray-600 mt-1">
                            <div className="flex items-center gap-2">
                                <Hash className="w-4 h-4 text-gray-400" />
                                <span className="font-mono text-gray-600">{customer.customer_code || 'N/A'}</span>
                            </div>
                            <Badge variant="outline">{customer.customer_group}</Badge>
                            {customer.company_name && <span>• {customer.company_name}</span>}
                        </div>
                    </div>
                </div>
                <div className="flex items-center gap-3">
                    <Button onClick={() => setIsEditDialogOpen(true)}>
                        <Edit className="w-4 h-4 mr-2" />
                        Edit Details
                    </Button>
                    <Button variant="outline" onClick={generatePortalLink}>
                        <QrCode className="w-4 h-4 mr-2" />
                        Generate Portal Link
                    </Button>
                </div>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <StatCard icon={HardDrive} title="Total Cases" value={totalCases || 0} color="blue" />
                <StatCard icon={Clock} title="Open Cases" value={openCases || 0} color="orange" />
                <StatCard icon={DollarSign} title="Total Revenue" value={`$${(totalRevenue || 0).toLocaleString()}`} color="green" />
                <StatCard icon={FileText} title="Pending Quotes" value={pendingQuotes || 0} color="purple" />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Left Column - Customer Details */}
                <div className="lg:col-span-1">
                    <Card className="shadow-lg border-0 mb-6">
                        <CardHeader className="bg-blue-50">
                            <CardTitle className="flex items-center"><User className="w-5 h-5 mr-2"/>Customer Details</CardTitle>
                        </CardHeader>
                        <CardContent className="pt-4 space-y-0 divide-y divide-gray-100">
                            <DetailRow icon={Mail} label="Primary Email" value={customer.email} isLink="email" />
                            <DetailRow icon={Phone} label="Primary Phone" value={customer.phone_number} isLink="tel" />
                            {customer.secondary_email && (
                                <DetailRow icon={Mail} label="Secondary Email" value={customer.secondary_email} isLink="email" />
                            )}
                            {customer.secondary_phone && (
                                <DetailRow icon={Phone} label="Secondary Phone" value={customer.secondary_phone} isLink="tel" />
                            )}
                            <DetailRow icon={MapPin} label="City" value={customer.city} />
                            <DetailRow icon={MapPin} label="Country" value={customer.country} />
                            <DetailRow icon={Building} label="Company" value={customer.company_name} />
                            <DetailRow icon={Hash} label="Customer Group" value={customer.customer_group} />
                            {customer.notes && <DetailRow icon={FileText} label="Notes" value={customer.notes} />}
                        </CardContent>
                    </Card>

                    {/* Portal Access */}
                    {customer.client_portal_enabled && (
                        <Card className="shadow-lg border-0">
                            <CardHeader className="bg-green-50">
                                <CardTitle className="flex items-center"><LinkIcon className="w-5 h-5 mr-2"/>Client Portal Access</CardTitle>
                            </CardHeader>
                            <CardContent className="pt-4">
                                <div className="space-y-3">
                                    <div>
                                        <Label className="text-xs text-gray-500">Portal URL</Label>
                                        <div className="flex items-center gap-2 mt-1">
                                            <Input
                                                value={showPortalToken ? portalUrl : '●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●●'}
                                                readOnly
                                                className="text-xs font-mono"
                                            />
                                            <Button
                                                variant="ghost"
                                                size="sm"
                                                onClick={() => setShowPortalToken(!showPortalToken)}
                                            >
                                                {showPortalToken ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                                            </Button>
                                        </div>
                                    </div>
                                    {customer.last_portal_access && (
                                        <div>
                                            <Label className="text-xs text-gray-500">Last Access</Label>
                                            <p className="text-sm font-medium">{format(new Date(customer.last_portal_access), 'MMM dd, yyyy HH:mm')}</p>
                                        </div>
                                    )}
                                </div>
                            </CardContent>
                        </Card>
                    )}
                </div>

                {/* Right Column - Tabbed Content */}
                <div className="lg:col-span-2">
                    <Tabs defaultValue="cases" className="w-full">
                        <TabsList className="grid w-full grid-cols-7">
                            <TabsTrigger value="cases">Cases</TabsTrigger>
                            <TabsTrigger value="quotes">Quotes</TabsTrigger>
                            <TabsTrigger value="invoices">Invoices</TabsTrigger>
                            <TabsTrigger value="transactions">Transactions</TabsTrigger>
                            <TabsTrigger value="files">Files</TabsTrigger>
                            <TabsTrigger value="communications">Communications</TabsTrigger>
                            <TabsTrigger value="logs">Logs</TabsTrigger>
                        </TabsList>

                        <TabsContent value="cases" className="mt-4">
                            <Card>
                                <CardHeader><CardTitle>Cases ({cases.length})</CardTitle></CardHeader>
                                <CardContent className="space-y-6">
                                    {cases.length === 0 ? (
                                        <p className="text-center text-gray-500">No cases found for this customer.</p>
                                    ) : cases.map(caseItem => {
                                        const caseQuotes = quotes.filter(q => q.case_id === caseItem.id);
                                        const caseEvaluations = evaluations.filter(e => e.case_id === caseItem.id);
                                        return (
                                            <div key={caseItem.id} className="border p-4 rounded-lg bg-gray-50/50">
                                                <div className="flex justify-between items-start mb-4">
                                                    <div>
                                                        <Link to={createPageUrl(`CaseDetails?id=${caseItem.id}`)} className="text-lg font-semibold text-blue-600 hover:underline">
                                                            Case #{caseItem.case_number}
                                                        </Link>
                                                        <p className="text-sm text-gray-500">{caseItem.service_type}</p>
                                                    </div>
                                                    <Badge className={statusColors[caseItem.status] || 'bg-gray-100 text-gray-800'}>
                                                        {caseItem.status}
                                                    </Badge>
                                                </div>
                                                
                                                {/* Case Status Tracker */}
                                                <div className="mb-4">
                                                    <CaseStatusTracker
                                                        currentStatus={caseItem.status}
                                                        caseData={caseItem}
                                                        quotes={caseQuotes}
                                                        showDates={true}
                                                    />
                                                </div>

                                                {/* Evaluation Reports for this case */}
                                                {caseEvaluations.length > 0 && (
                                                    <div className="mt-4 border-t pt-4">
                                                        <h4 className="font-medium text-gray-700 mb-2">Evaluation Reports:</h4>
                                                        <ul className="space-y-2">
                                                            {caseEvaluations.map(report => (
                                                                <li key={report.id} className="flex items-center justify-between text-sm bg-white p-2 rounded-md shadow-sm">
                                                                    <span>Report for S/N: {report.device_serial_number}</span>
                                                                    <Button 
                                                                        variant="outline" 
                                                                        size="sm"
                                                                        onClick={() => window.open(createPageUrl(`PrintEvaluationReport?id=${report.id}`), '_blank')}
                                                                    >
                                                                        View Report
                                                                    </Button>
                                                                </li>
                                                            ))}
                                                        </ul>
                                                    </div>
                                                )}

                                            </div>
                                        )
                                    })}
                                </CardContent>
                            </Card>
                        </TabsContent>

                        <TabsContent value="quotes" className="mt-4">
                            <Card>
                                <CardHeader><CardTitle>Quotes ({quotes.length})</CardTitle></CardHeader>
                                <CardContent>
                                    {quotes.length === 0 ? (
                                        <p className="text-center text-gray-500">No quotes found for this customer.</p>
                                    ) : (
                                        <Table>
                                            <TableHeader>
                                                <TableRow>
                                                    <TableHead>Quote #</TableHead>
                                                    <TableHead>Amount</TableHead>
                                                    <TableHead>Status</TableHead>
                                                    <TableHead>Date</TableHead>
                                                    <TableHead>Actions</TableHead>
                                                </TableRow>
                                            </TableHeader>
                                            <TableBody>
                                                {quotes.map(q => (
                                                    <TableRow key={q.id}>
                                                        <TableCell>{q.quote_number}</TableCell>
                                                        <TableCell>${q.total_amount?.toLocaleString()}</TableCell>
                                                        <TableCell>
                                                            <Badge variant={q.status === 'Accepted' ? 'default' : 'secondary'}>{q.status}</Badge>
                                                        </TableCell>
                                                        <TableCell>{q.sent_date ? format(new Date(q.sent_date), 'dd MMM yyyy') : 'N/A'}</TableCell>
                                                        <TableCell className="space-x-1">
                                                            <Button variant="outline" size="sm" onClick={() => window.open(createPageUrl(`QuoteDetails?id=${q.id}`), '_blank')}>View</Button>
                                                            <Button variant="outline" size="sm" onClick={() => window.open(createPageUrl(`PrintQuote?id=${q.id}`), '_blank')}>Download</Button>
                                                        </TableCell>
                                                    </TableRow>
                                                ))}
                                            </TableBody>
                                        </Table>
                                    )}
                                </CardContent>
                            </Card>
                        </TabsContent>

                        <TabsContent value="invoices" className="mt-4">
                            <Card>
                                <CardHeader><CardTitle>Invoices ({invoices.length})</CardTitle></CardHeader>
                                <CardContent>
                                    {invoices.length === 0 ? (
                                        <p className="text-center text-gray-500">No invoices found for this customer.</p>
                                    ) : (
                                        <Table>
                                            <TableHeader>
                                                <TableRow>
                                                    <TableHead>Invoice #</TableHead>
                                                    <TableHead>Amount</TableHead>
                                                    <TableHead>Status</TableHead>
                                                    <TableHead>Date</TableHead>
                                                    <TableHead>Actions</TableHead>
                                                </TableRow>
                                            </TableHeader>
                                            <TableBody>
                                                {invoices.map(i => (
                                                    <TableRow key={i.id}>
                                                        <TableCell>{i.invoice_number}</TableCell>
                                                        <TableCell>${i.total_amount?.toLocaleString()}</TableCell>
                                                        <TableCell>
                                                            <Badge variant={i.status === 'Paid' ? 'success' : 'destructive'}>{i.status}</Badge>
                                                        </TableCell>
                                                        <TableCell>{i.issued_date ? format(new Date(i.issued_date), 'dd MMM yyyy') : 'N/A'}</TableCell>
                                                        <TableCell className="space-x-1">
                                                            <Button variant="outline" size="sm" onClick={() => window.open(createPageUrl(`InvoiceDetails?id=${i.id}`), '_blank')}>View</Button>
                                                            <Button variant="outline" size="sm" onClick={() => window.open(createPageUrl(`PrintInvoice?id=${i.id}`), '_blank')}>Download</Button>
                                                        </TableCell>
                                                    </TableRow>
                                                ))}
                                            </TableBody>
                                        </Table>
                                    )}
                                </CardContent>
                            </Card>
                        </TabsContent>

                        <TabsContent value="transactions" className="mt-4">
                            <Card>
                                <CardHeader><CardTitle>Transactions ({transactions.length})</CardTitle></CardHeader>
                                <CardContent>
                                    {transactions.length === 0 ? (
                                        <p className="text-center text-gray-500">No transactions found for this customer.</p>
                                    ) : (
                                        <Table>
                                            <TableHeader>
                                                <TableRow>
                                                    <TableHead>Date</TableHead>
                                                    <TableHead>Type</TableHead>
                                                    <TableHead>Amount</TableHead>
                                                    <TableHead>Method</TableHead>
                                                </TableRow>
                                            </TableHeader>
                                            <TableBody>
                                                {transactions.map(t => (
                                                    <TableRow key={t.id}>
                                                        <TableCell>{format(new Date(t.transaction_date), 'MMM dd, yyyy')}</TableCell>
                                                        <TableCell>{t.transaction_type}</TableCell>
                                                        <TableCell className={t.amount >= 0 ? 'text-green-600' : 'text-red-600'}>
                                                            ${Math.abs(t.amount).toLocaleString()}
                                                        </TableCell>
                                                        <TableCell>{t.payment_method}</TableCell>
                                                    </TableRow>
                                                ))}
                                            </TableBody>
                                        </Table>
                                    )}
                                </CardContent>
                            </Card>
                        </TabsContent>

                        <TabsContent value="files" className="mt-4">
                            <Card>
                                <CardHeader><CardTitle>Files ({files.length})</CardTitle></CardHeader>
                                <CardContent>
                                    {files.length === 0 ? (
                                        <p className="text-center text-gray-500">No files found for this customer's cases.</p>
                                    ) : (
                                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                                            {files.map(f => (
                                                <Card key={f.id} className="p-3">
                                                    <div className="text-sm">
                                                        <p className="font-medium truncate">{f.file_name}</p>
                                                        <p className="text-gray-500 text-xs mt-1">by {f.uploaded_by}</p>
                                                        <p className="text-gray-500 text-xs">{format(new Date(f.upload_date), 'MMM dd, yyyy')}</p>
                                                    </div>
                                                </Card>
                                            ))}
                                        </div>
                                    )}
                                </CardContent>
                            </Card>
                        </TabsContent>

                        <TabsContent value="communications" className="mt-4">
                            <Card>
                                <CardHeader><CardTitle>Communications ({communications.length})</CardTitle></CardHeader>
                                <CardContent>
                                    {communications.length === 0 ? (
                                        <p className="text-center text-gray-500">No communications found for this customer.</p>
                                    ) : (
                                        <div className="space-y-4">
                                            {communications.map(c => (
                                                <div key={c.id} className="border-l-4 border-blue-500 pl-4 py-2">
                                                    <div className="flex items-center justify-between mb-1">
                                                        <Badge variant="outline">{c.type}</Badge>
                                                        <span className="text-sm text-gray-500">
                                                            {format(new Date(c.communication_date), 'MMM dd, yyyy HH:mm')}
                                                        </span>
                                                    </div>
                                                    <h4 className="font-medium">{c.subject}</h4>
                                                    <p className="text-sm text-gray-600 mt-1">{c.content}</p>
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </CardContent>
                            </Card>
                        </TabsContent>

                        <TabsContent value="logs" className="mt-4">
                            <Card>
                                <CardHeader><CardTitle>Recent Logs ({jobHistory.length})</CardTitle></CardHeader>
                                <CardContent>
                                    {jobHistory.length === 0 ? (
                                        <p className="text-center text-gray-500">No recent logs found for this customer's cases.</p>
                                    ) : (
                                        <div className="space-y-4">
                                            {jobHistory.map(a => (
                                                <div key={a.id} className="flex items-start space-x-3">
                                                    <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                                                    <div className="flex-1">
                                                        <p className="text-sm font-medium">{a.description}</p>
                                                        <p className="text-xs text-gray-500">
                                                            {format(new Date(a.timestamp), 'MMM dd, yyyy HH:mm')} by {a.performed_by}
                                                        </p>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </CardContent>
                            </Card>
                        </TabsContent>
                    </Tabs>
                </div>
            </div>

            <EditCustomerDialog
                open={isEditDialogOpen}
                onOpenChange={setIsEditDialogOpen}
                customer={customer}
                onCustomerUpdate={fetchData}
            />
        </div>
    );
}
