import React, { useState, useEffect, useMemo } from 'react';
import { Asset } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Package, PlusCircle, TrendingUp, TrendingDown, DollarSign, Printer } from 'lucide-react';
import AssetFormDialog from '../components/assets/AssetFormDialog';
import AssetDetailsDialog from '../components/assets/AssetDetailsDialog';
import AssetTable from '../components/assets/AssetTable';
import { format } from 'date-fns';
import { createPageUrl } from '@/utils';

const calculateCurrentValue = (asset) => {
    if (asset.depreciation_method === 'No Depreciation' || !asset.purchase_date || !asset.purchase_cost || !asset.useful_life_years) {
        return asset.purchase_cost || 0;
    }
    
    const purchaseDate = new Date(asset.purchase_date);
    const now = new Date();
    const yearsElapsed = (now.getTime() - purchaseDate.getTime()) / (1000 * 60 * 60 * 24 * 365.25);
    
    if (yearsElapsed <= 0) return asset.purchase_cost;
    if (yearsElapsed >= asset.useful_life_years) return 0;
    
    const yearlyDepreciation = asset.purchase_cost / asset.useful_life_years;
    const totalDepreciation = yearlyDepreciation * yearsElapsed;
    
    return Math.max(0, asset.purchase_cost - totalDepreciation);
};

const StatCard = ({ title, value, icon: Icon, color, change, period }) => (
    <Card className="shadow-lg hover:shadow-xl transition-all duration-300 bg-white/80 backdrop-blur-sm border-0">
        <CardContent className="p-4 flex items-center justify-between">
            <div>
                <p className="text-sm font-medium text-gray-500">{title}</p>
                <p className="text-2xl font-bold text-gray-800">{value}</p>
                 {change !== undefined && (
                    <div className={`flex items-center text-xs mt-1 ${change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {change >= 0 ? <TrendingUp className="w-4 h-4 mr-1" /> : <TrendingDown className="w-4 h-4 mr-1" />}
                        <span>{change}% {period}</span>
                    </div>
                )}
            </div>
            <div className={`p-3 rounded-full bg-gradient-to-br ${color}`}>
                <Icon className="w-6 h-6 text-white" />
            </div>
        </CardContent>
    </Card>
);


export default function AssetsPage() {
    const [assets, setAssets] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [isDetailsOpen, setIsDetailsOpen] = useState(false);
    const [selectedAsset, setSelectedAsset] = useState(null);

    const fetchData = async () => {
        setIsLoading(true);
        try {
            const data = await Asset.list('-created_date');
            setAssets(data);
        } catch (error) {
            console.error("Failed to fetch assets:", error);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    const handleAddAsset = () => {
        setSelectedAsset(null);
        setIsFormOpen(true);
    };

    const handleEditAsset = (asset) => {
        setSelectedAsset(asset);
        setIsFormOpen(true);
    };
    
    const handleViewAsset = (asset) => {
        setSelectedAsset(asset);
        setIsDetailsOpen(true);
    };
    
    const handleDeleteAsset = async (assetId) => {
        if (window.confirm('Are you sure you want to delete this asset? This action cannot be undone.')) {
            try {
                await Asset.delete(assetId);
                fetchData();
            } catch (error) {
                console.error("Failed to delete asset:", error);
                alert("Could not delete the asset.");
            }
        }
    };
    
    const handlePrintLabel = (asset) => {
        window.open(createPageUrl(`PrintAssetLabel?id=${asset.id}`), '_blank');
    };

    const valuationStats = useMemo(() => {
        const totalPurchaseCost = assets.reduce((sum, asset) => sum + (asset.purchase_cost || 0), 0);
        const totalCurrentValue = assets.reduce((sum, asset) => sum + calculateCurrentValue(asset), 0);
        const totalDepreciation = totalPurchaseCost - totalCurrentValue;
        return { totalPurchaseCost, totalCurrentValue, totalDepreciation };
    }, [assets]);
    
    const formatCurrency = (value) => {
        return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);
    };

    return (
        <div className="p-8">
            <div className="flex justify-between items-center mb-8">
                <div className="flex items-center space-x-4">
                    <div className="p-3 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-xl shadow-lg">
                        <Package className="w-8 h-8 text-white" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                            Asset Management
                        </h1>
                        <p className="text-sm text-gray-500 mt-1">
                            Track company equipment, software, and other valuable assets.
                        </p>
                    </div>
                </div>
                <Button onClick={handleAddAsset} className="bg-gradient-to-r from-green-500 to-emerald-600 text-white shadow-lg">
                    <PlusCircle className="w-5 h-5 mr-2" />
                    Add Asset
                </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                <StatCard 
                    title="Total Current Asset Value" 
                    value={formatCurrency(valuationStats.totalCurrentValue)}
                    icon={DollarSign} 
                    color="from-green-500 to-emerald-500" 
                />
                <StatCard 
                    title="Total Purchase Cost" 
                    value={formatCurrency(valuationStats.totalPurchaseCost)}
                    icon={DollarSign} 
                    color="from-blue-500 to-cyan-500" 
                />
                <StatCard 
                    title="Total Depreciation" 
                    value={formatCurrency(valuationStats.totalDepreciation)}
                    icon={TrendingDown} 
                    color="from-orange-500 to-amber-500" 
                />
            </div>

            <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0">
                <CardHeader>
                    <CardTitle>All Company Assets</CardTitle>
                </CardHeader>
                <CardContent>
                    <AssetTable
                        assets={assets.map(a => ({...a, current_value: calculateCurrentValue(a)}))}
                        onEdit={handleEditAsset}
                        onDelete={handleDeleteAsset}
                        onView={handleViewAsset}
                        onPrint={handlePrintLabel}
                        isLoading={isLoading}
                    />
                </CardContent>
            </Card>
            
            <AssetFormDialog
                open={isFormOpen}
                onOpenChange={setIsFormOpen}
                asset={selectedAsset}
                onSave={fetchData}
            />
            
            <AssetDetailsDialog
                open={isDetailsOpen}
                onOpenChange={setIsDetailsOpen}
                asset={selectedAsset ? {...selectedAsset, current_value: calculateCurrentValue(selectedAsset)} : null}
            />
        </div>
    );
}