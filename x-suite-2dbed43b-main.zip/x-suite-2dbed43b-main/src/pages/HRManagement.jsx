
import React, { useEffect, useMemo, useState } from 'react';
import { Employee } from '@/api/entities';
import { EmployeeBankAccount } from '@/api/entities';
import { LogEvent } from '@/api/entities';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Download, Eye, EyeOff, Plus } from 'lucide-react';

const mask = (s) => {
  if (!s) return '';
  const digits = s.replace(/\s+/g, '');
  const tail = digits.slice(-4);
  return '**** **** **** ' + tail;
};

function ibanIsValid(ibanRaw) {
  if (!ibanRaw) return true; // Treat empty as valid for optional fields or if handled by other validation
  const iban = ibanRaw.replace(/\s+/g, "").toUpperCase();
  if (iban.length < 15 || iban.length > 34) return false;

  // Move first four characters to the end
  const rearranged = iban.slice(4) + iban.slice(0, 4);

  // Replace letters with numbers (A=10, B=11, ..., Z=35)
  const expanded = rearranged.replace(/[A-Z]/g, ch => (ch.charCodeAt(0) - 55).toString());

  // Perform modulo 97-10 check
  let remainder = 0;
  for (let i = 0; i < expanded.length; i += 7) {
    remainder = Number(String(remainder) + expanded.slice(i, i + 7)) % 97;
  }
  return remainder === 1;
}

const fmtIBAN = (s) => (s || "").replace(/\s+/g, "").replace(/(.{4})/g, "$1 ").trim();


export default function HRManagementPage() {
  const [employees, setEmployees] = useState([]);
  const [accounts, setAccounts] = useState([]);
  const [q, setQ] = useState('');
  const [currentUser, setCurrentUser] = useState(null);
  const [activeEmp, setActiveEmp] = useState(null);
  const [showAccDialog, setShowAccDialog] = useState(false);
  const [editingAcc, setEditingAcc] = useState(null);
  const [revealDialog, setRevealDialog] = useState({ open: false, acc: null, reason: '' });
  const [accessDenied, setAccessDenied] = useState(false);

  const refresh = async () => {
    const [es, as, u] = await Promise.all([Employee.list(), EmployeeBankAccount.list(), User.me()]);
    setEmployees(es); setAccounts(as); setCurrentUser(u);
  };
  useEffect(() => { refresh(); }, []);

  useEffect(() => {
    if (!currentUser) return; // Wait for currentUser to be loaded
    const role = currentUser.role === 'admin' ? 'Admin' : (currentUser.access_role || '');
    if (!['Admin', 'Accounts'].includes(role)) {
      setAccessDenied(true);
    }
  }, [currentUser]);

  const filtered = useMemo(() => {
    const needle = q.toLowerCase();
    return employees.filter(e => [e.name, e.employeeCode, e.department, e.email, e.mobile].filter(Boolean).some(s => s.toLowerCase().includes(needle)));
  }, [employees, q]);

  const empAccounts = (empId) => accounts.filter(a => a.employeeId === empId && a.status !== 'Inactive');

  const saveAccount = async () => {
    const data = { ...editingAcc, updatedBy: currentUser?.email };
    if (!data.accountName?.trim() || !data.bankName?.trim()) return alert("Account Name and Bank Name are required");
    if (!data.accountNumberCipher && !data.ibanCipher) return alert("Provide Account Number or IBAN");
    if (data.ibanCipher && !ibanIsValid(data.ibanCipher)) return alert("IBAN checksum failed");
    if (data.ibanCipher) data.ibanCipher = fmtIBAN(data.ibanCipher);

    // Rule: only one primary
    if (data.isPrimary) {
      const existing = accounts.filter(a => a.employeeId === data.employeeId && a.id !== data.id && a.isPrimary);
      for (const a of existing) await EmployeeBankAccount.update(a.id, { isPrimary: false });
    }
    if (editingAcc.id) await EmployeeBankAccount.update(editingAcc.id, data);
    else await EmployeeBankAccount.create(data);

    await LogEvent.create({
      time: new Date().toISOString(),
      user: currentUser?.email,
      module: 'HR',
      action: editingAcc.id ? 'BankAccount.Update' : 'BankAccount.Create',
      entityId: editingAcc.id || '',
      summary: `Bank account ${data.accountName} saved`,
      sensitive: true
    });

    setShowAccDialog(false); setEditingAcc(null); refresh();
  };

  const setPrimary = async (acc) => {
    const empId = acc.employeeId;
    const existing = accounts.filter(a => a.employeeId === empId && a.isPrimary);
    for (const a of existing) await EmployeeBankAccount.update(a.id, { isPrimary: false });
    await EmployeeBankAccount.update(acc.id, { isPrimary: true, updatedBy: currentUser?.email });
    await LogEvent.create({ time: new Date().toISOString(), user: currentUser?.email, module: 'HR', action: 'BankAccount.SetPrimary', entityId: acc.id, summary: `Primary set for ${acc.accountName}`, sensitive: true });
    refresh();
  };

  const archive = async (acc) => {
    await EmployeeBankAccount.update(acc.id, { status: 'Inactive', updatedBy: currentUser?.email });
    await LogEvent.create({ time: new Date().toISOString(), user: currentUser?.email, module: 'HR', action: 'BankAccount.Archive', entityId: acc.id, summary: `Archived ${acc.accountName}`, sensitive: true });
    refresh();
  };

  const reveal = async (acc) => {
    setRevealDialog({ open: true, acc, reason: '' });
  };

  const confirmReveal = async () => {
    const acc = revealDialog.acc;
    await LogEvent.create({
      time: new Date().toISOString(),
      user: currentUser?.email,
      module: 'HR',
      action: 'BankAccount.Reveal',
      entityId: acc.id,
      summary: `Reveal full for ${acc.accountName} — Reason: ${revealDialog.reason}`,
      sensitive: true
    });
    setRevealDialog({ open: false, acc: null, reason: '' });
    alert(`Account: ${acc.accountNumberCipher || '-'}\nIBAN: ${acc.ibanCipher || '-'}`);
  };

  const exportPayroll = (full = false) => {
    const rows = accounts
      .filter(a => a.isPayroll && a.status === 'Active')
      .map(a => ({
        employee: employees.find(e => e.id === a.employeeId)?.name || '',
        bank: a.bankName,
        account: full ? (a.accountNumberCipher || '') : mask(a.accountNumberCipher || ''),
        iban: full ? (a.ibanCipher || '') : mask(a.ibanCipher || ''),
        currency: a.currencyCode || ''
      }));
    const headers = ['employee', 'bank', 'account', 'iban', 'currency'];
    const csv = [headers.join(','), ...rows.map(r => headers.map(h => `"${(r[h] || '').toString().replace(/"/g, '""')}"`).join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' }); const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = full ? 'payroll_full.csv' : 'payroll_masked.csv'; a.click(); URL.revokeObjectURL(url);
  };

  if (accessDenied) {
    return <div className="min-h-[60vh] flex items-center justify-center text-gray-600">Access denied.</div>;
  }

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">HR Management</h1>
      <Card className="mb-4">
        <CardContent className="p-4 flex gap-3 items-center">
          <Input placeholder="Search employees" value={q} onChange={e => setQ(e.target.value)} className="w-64" />
          <Button variant="outline" onClick={() => exportPayroll(false)}><Download className="w-4 h-4 mr-2" />Export Payroll (Masked)</Button>
          <Button onClick={() => exportPayroll(true)}><Download className="w-4 h-4 mr-2" />Export Payroll (Full)</Button>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle>Employees</CardTitle></CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow><TableHead>Code</TableHead><TableHead>Name</TableHead><TableHead>Department</TableHead><TableHead>Status</TableHead></TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map(e => (
                  <TableRow key={e.id} onClick={() => setActiveEmp(e)} className="cursor-pointer hover:bg-gray-50">
                    <TableCell>{e.employeeCode || '-'}</TableCell>
                    <TableCell>{e.name}</TableCell>
                    <TableCell>{e.department || '-'}</TableCell>
                    <TableCell>{e.status}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Bank Accounts {activeEmp ? `— ${activeEmp.name}` : ''}</CardTitle></CardHeader>
          <CardContent>
            {!activeEmp ? (
              <div className="text-gray-500">Select an employee to manage bank accounts</div>
            ) : (
              <>
                <div className="mb-3"><Button onClick={() => { setEditingAcc({ employeeId: activeEmp.id, accountName: '', bankName: '', currencyCode: 'OMR', isPayroll: true, isPrimary: false }); setShowAccDialog(true); }}><Plus className="w-4 h-4 mr-2" />Add Account</Button></div>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Account Name</TableHead>
                      <TableHead>Bank</TableHead>
                      <TableHead>Masked Account</TableHead>
                      <TableHead>Masked IBAN</TableHead>
                      <TableHead>Currency</TableHead>
                      <TableHead>Tags</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {empAccounts(activeEmp.id).map(a => (
                      <TableRow key={a.id}>
                        <TableCell>{a.accountName}</TableCell>
                        <TableCell>{a.bankName}</TableCell>
                        <TableCell>{mask(a.accountNumberCipher || '')}</TableCell>
                        <TableCell>{mask(a.ibanCipher || '')}</TableCell>
                        <TableCell>{a.currencyCode || 'OMR'}</TableCell>
                        <TableCell>
                          {a.isPrimary && <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded mr-1">Primary</span>}
                          {a.isPayroll && <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded">Payroll</span>}
                        </TableCell>
                        <TableCell>{a.status}</TableCell>
                        <TableCell className="space-x-2">
                          <Button variant="outline" size="sm" onClick={() => { setEditingAcc(a); setShowAccDialog(true); }}>Edit</Button>
                          {!a.isPrimary && <Button variant="outline" size="sm" onClick={() => setPrimary(a)}>Set Primary</Button>}
                          <Button variant="outline" size="sm" onClick={() => archive(a)}>Archive</Button>
                          <Button variant="outline" size="sm" onClick={() => reveal(a)}><Eye className="w-4 h-4 mr-1" />Reveal</Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={showAccDialog} onOpenChange={setShowAccDialog}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editingAcc?.id ? 'Edit Bank Account' : 'Add Bank Account'}</DialogTitle></DialogHeader>
          {editingAcc && (
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2"><Label>Account Name</Label><Input value={editingAcc.accountName || ''} onChange={e => setEditingAcc({ ...editingAcc, accountName: e.target.value })} /></div>
              <div><Label>Bank Name</Label><Input value={editingAcc.bankName || ''} onChange={e => setEditingAcc({ ...editingAcc, bankName: e.target.value })} /></div>
              <div><Label>Branch</Label><Input value={editingAcc.branch || ''} onChange={e => setEditingAcc({ ...editingAcc, branch: e.target.value })} /></div>
              <div><Label>Account Number (stored encrypted)</Label><Input value={editingAcc.accountNumberCipher || ''} onChange={e => setEditingAcc({ ...editingAcc, accountNumberCipher: e.target.value })} /></div>
              <div><Label>IBAN (stored encrypted)</Label><Input value={editingAcc.ibanCipher || ''} onChange={e => setEditingAcc({ ...editingAcc, ibanCipher: e.target.value })} /></div>
              <div><Label>SWIFT/BIC</Label><Input value={editingAcc.swiftBic || ''} onChange={e => setEditingAcc({ ...editingAcc, swiftBic: e.target.value })} /></div>
              <div><Label>Currency</Label><Input value={editingAcc.currencyCode || 'OMR'} onChange={e => setEditingAcc({ ...editingAcc, currencyCode: e.target.value })} /></div>
              <div><Label>Primary</Label><Input type="checkbox" checked={!!editingAcc.isPrimary} onChange={e => setEditingAcc({ ...editingAcc, isPrimary: e.target.checked })} /></div>
              <div><Label>Payroll</Label><Input type="checkbox" checked={!!editingAcc.isPayroll} onChange={e => setEditingAcc({ ...editingAcc, isPayroll: e.target.checked })} /></div>
              <div className="col-span-2"><Label>Notes</Label><Input value={editingAcc.notes || ''} onChange={e => setEditingAcc({ ...editingAcc, notes: e.target.value })} /></div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAccDialog(false)}>Cancel</Button>
            <Button onClick={saveAccount}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={revealDialog.open} onOpenChange={(o) => setRevealDialog({ open: o, acc: revealDialog.acc, reason: '' })}>
        <DialogContent>
          <DialogHeader><DialogTitle>Reveal Sensitive Details</DialogTitle></DialogHeader>
          <p className="text-sm text-gray-600">Provide a valid business reason. This action will be audited.</p>
          <div className="mt-2">
            <Label>Reason</Label>
            <Input value={revealDialog.reason} onChange={e => setRevealDialog({ ...revealDialog, reason: e.target.value })} placeholder="e.g., Payroll verification for March" />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRevealDialog({ open: false, acc: null, reason: '' })}>Cancel</Button>
            <Button onClick={confirmReveal} disabled={!revealDialog.reason}>Confirm Reveal</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
