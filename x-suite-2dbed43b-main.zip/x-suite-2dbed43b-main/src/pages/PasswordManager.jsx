import React, { useEffect, useMemo, useState } from 'react';
import { VaultItem } from '@/api/entities';
import { LogEvent } from '@/api/entities';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Table, TableHeader, TableHead, TableRow, TableBody, TableCell } from '@/components/ui/table';
import { Eye, EyeOff, Plus } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';

const generatePassword = (len = 16) => {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%^&*()_+-=';
  return Array.from({ length: len }).map(() => chars[Math.floor(Math.random() * chars.length)]).join('');
};
const strength = (s) => {
  let score = 0;
  if (!s) return 'Weak';
  if (s.length >= 12) score++;
  if (/[A-Z]/.test(s) && /[a-z]/.test(s)) score++;
  if (/\d/.test(s)) score++;
  if (/[^A-Za-z0-9]/.test(s)) score++;
  return ['Weak','Fair','Good','Strong'][Math.min(score,3)];
};

export default function PasswordManagerPage() {
  const [items, setItems] = useState([]);
  const [q, setQ] = useState('');
  const [editing, setEditing] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);

  const refresh = async () => {
    const [it, u] = await Promise.all([VaultItem.list('-created_date'), User.me()]);
    setItems(it); setCurrentUser(u);
  };
  useEffect(() => { refresh(); }, []);

  const filtered = useMemo(() => {
    const needle = q.toLowerCase();
    return items.filter(v => [v.title, v.username, v.url, (v.tags||[]).join(' ')].filter(Boolean).some(s => s.toLowerCase().includes(needle)));
  }, [items, q]);

  const save = async () => {
    if (editing.id) await VaultItem.update(editing.id, editing);
    else await VaultItem.create(editing);
    setEditing(null); refresh();
  };

  const reveal = async (v) => {
    await LogEvent.create({ time: new Date().toISOString(), user: currentUser?.email, module: 'Passwords', action: 'Reveal', entityId: v.id, summary: `Reveal ${v.title}`, sensitive: true });
    alert(v.secretCipher || '(empty)');
  };

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold">Password Manager</h1>
        <Button onClick={() => setEditing({ type:'credential', title:'', secretCipher:'' })}><Plus className="w-4 h-4 mr-2" />New</Button>
      </div>

      <Card className="mb-4">
        <CardContent className="p-4 flex gap-3 items-center">
          <Input placeholder="Search" value={q} onChange={e => setQ(e.target.value)} className="w-64" />
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Vault</CardTitle></CardHeader>
        <CardContent>
          <Table>
            <TableHeader><TableRow><TableHead>Title</TableHead><TableHead>User</TableHead><TableHead>URL</TableHead><TableHead>Tags</TableHead><TableHead>Actions</TableHead></TableRow></TableHeader>
            <TableBody>
              {filtered.map(v => (
                <TableRow key={v.id}>
                  <TableCell>{v.title}</TableCell>
                  <TableCell>{v.username || '-'}</TableCell>
                  <TableCell className="break-all">{v.url || '-'}</TableCell>
                  <TableCell>{(v.tags||[]).join(', ')}</TableCell>
                  <TableCell className="space-x-2">
                    <Button variant="outline" size="sm" onClick={() => setEditing(v)}>Edit</Button>
                    <Button variant="outline" size="sm" onClick={() => reveal(v)}><Eye className="w-4 h-4 mr-1" />Reveal</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={!!editing} onOpenChange={() => setEditing(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing?.id ? 'Edit' : 'New'} Vault Item</DialogTitle></DialogHeader>
          {editing && (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Type</Label>
                <Input value={editing.type || 'credential'} onChange={e => setEditing({ ...editing, type: e.target.value })} />
              </div>
              <div className="col-span-1">
                <Label>Title</Label>
                <Input value={editing.title || ''} onChange={e => setEditing({ ...editing, title: e.target.value })} />
              </div>
              <div>
                <Label>Username</Label>
                <Input value={editing.username || ''} onChange={e => setEditing({ ...editing, username: e.target.value })} />
              </div>
              <div className="col-span-2">
                <Label>URL</Label>
                <Input value={editing.url || ''} onChange={e => setEditing({ ...editing, url: e.target.value })} />
              </div>
              <div className="col-span-2">
                <Label>Secret (stored encrypted)</Label>
                <Input value={editing.secretCipher || ''} onChange={e => setEditing({ ...editing, secretCipher: e.target.value })} />
                <div className="text-xs text-gray-500 mt-1">Strength: {strength(editing.secretCipher || '')}</div>
                <div className="mt-2">
                  <Button variant="outline" size="sm" onClick={() => setEditing({ ...editing, secretCipher: generatePassword() })}>Generate Strong Password</Button>
                </div>
              </div>
              <div className="col-span-2">
                <Label>Tags (comma)</Label>
                <Input value={(editing.tags || []).join(', ')} onChange={e => setEditing({ ...editing, tags: e.target.value.split(',').map(s => s.trim()).filter(Boolean) })} />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button>
            <Button onClick={save}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}