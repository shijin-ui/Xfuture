
import React, { useState, useEffect } from 'react';
import { useNavigate, Link, useOutletContext } from 'react-router-dom';
import { format, parseISO } from 'date-fns';
import { MoreHorizontal, Edit, FileText, Download, Plus, Search } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Table, TableHeader, TableBody, TableRow, TableCell } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const statusColors = {
  'Draft': 'bg-blue-100 text-blue-800',
  'Sent': 'bg-green-100 text-green-800',
  'Approved': 'bg-purple-100 text-purple-800',
  'Rejected': 'bg-red-100 text-red-800',
  'Expired': 'bg-yellow-100 text-yellow-800',
  // Add other common statuses if necessary for your application
  'Pending': 'bg-orange-100 text-orange-800',
  'Completed': 'bg-teal-100 text-teal-800',
};

export default function QuotesPage() {
  const [quotes, setQuotes] = useState([]);
  const [filteredQuotes, setFilteredQuotes] = useState([]);
  const [customers, setCustomers] = useState({});
  const [cases, setCases] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();

  // Assuming createPageUrl is provided via OutletContext in a React Router setup
  // If not using useOutletContext, you might define createPageUrl as a utility function
  const { createPageUrl } = useOutletContext(); 

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        // --- Mock Data Simulation ---
        // In a real application, you would fetch this data from an API
        const mockQuotes = [
          { id: 'q1', quote_number: 'Q-001', case_id: 'c1', customer_id: 'cust1', created_date: '2023-01-15T10:00:00Z', total_amount: 1500.75, status: 'Draft' },
          { id: 'q2', quote_number: 'Q-002', case_id: 'c2', customer_id: 'cust2', created_date: '2023-02-20T11:30:00Z', total_amount: 2300.00, status: 'Sent' },
          { id: 'q3', quote_number: 'Q-003', case_id: 'c1', customer_id: 'cust3', created_date: '2023-03-01T09:15:00Z', total_amount: 800.50, status: 'Approved' },
          { id: 'q4', quote_number: 'Q-004', case_id: 'c3', customer_id: 'cust1', created_date: '2023-04-05T14:00:00Z', total_amount: 3500.25, status: 'Expired' },
          { id: 'q5', quote_number: 'Q-005', case_id: 'c2', customer_id: 'cust2', created_date: '2023-05-10T16:00:00Z', total_amount: 1200.00, status: 'Sent' },
          { id: 'q6', quote_number: 'Q-006', case_id: 'c1', customer_id: 'cust3', created_date: '2023-06-12T08:45:00Z', total_amount: 950.00, status: 'Draft' },
        ];
        const mockCustomers = {
          'cust1': { id: 'cust1', full_name: 'Alice Johnson' },
          'cust2': { id: 'cust2', full_name: 'Bob Williams' },
          'cust3': { id: 'cust3', full_name: 'Charlie Brown' },
        };
        const mockCases = {
          'c1': { id: 'c1', case_number: 'CASE-XYZ-2023' },
          'c2': { id: 'c2', case_number: 'CASE-ABC-2023' },
          'c3': { id: 'c3', case_number: 'CASE-DEF-2023' },
        };
        // --- End Mock Data ---

        setQuotes(mockQuotes);
        setCustomers(mockCustomers);
        setCases(mockCases);
      } catch (error) {
        console.error('Failed to fetch data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    setFilteredQuotes(
      quotes.filter(quote => {
        const customerName = customers[quote.customer_id]?.full_name || '';
        const caseNumber = cases[quote.case_id]?.case_number || '';
        const lowerCaseSearchTerm = searchTerm.toLowerCase();

        return (
          quote.quote_number.toLowerCase().includes(lowerCaseSearchTerm) ||
          customerName.toLowerCase().includes(lowerCaseSearchTerm) ||
          caseNumber.toLowerCase().includes(lowerCaseSearchTerm)
        );
      })
    );
  }, [searchTerm, quotes, customers, cases]);

  const handlePrintOrDownload = (quoteId) => {
    // This will open the print page in a new tab. The PrintQuote page
    // will automatically set the document title for the PDF filename
    // and trigger the print dialog, which can be used for printing or saving as PDF.
    window.open(createPageUrl(`PrintQuote?id=${quoteId}`), '_blank');
  };

  return (
    <div className="p-8 bg-gradient-to-br from-slate-50 to-indigo-100 min-h-screen">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-extrabold text-gray-900 drop-shadow-sm">Quotes</h1>
        <Button onClick={() => navigate(createPageUrl('CreateQuote'))} className="bg-blue-600 hover:bg-blue-700 text-white shadow-lg">
          <Plus className="w-5 h-5 mr-2" /> New Quote
        </Button>
      </div>

      <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0 overflow-hidden">
        <div className="p-4 border-b bg-gray-50/50 flex justify-between items-center">
          <h2 className="text-xl font-semibold text-gray-800">All Quotes</h2>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
            <Input
              type="text"
              placeholder="Search quotes..."
              className="pl-9 pr-4 py-2 border rounded-md w-64 focus:outline-none focus:ring-2 focus:ring-blue-500"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableCell className="w-[120px] font-medium text-gray-600">Quote #</TableCell>
                <TableCell className="font-medium text-gray-600">Case #</TableCell>
                <TableCell className="font-medium text-gray-600">Customer</TableCell>
                <TableCell className="w-[150px] font-medium text-gray-600">Date</TableCell>
                <TableCell className="w-[120px] text-right font-medium text-gray-600">Total</TableCell>
                <TableCell className="w-[100px] text-center font-medium text-gray-600">Status</TableCell>
                <TableCell className="w-[80px] text-right"></TableCell>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={7} className="h-24 text-center text-gray-500">
                    Loading quotes...
                  </TableCell>
                </TableRow>
              ) : filteredQuotes.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="h-24 text-center text-gray-500">
                    No quotes found. Try adjusting your search.
                  </TableCell>
                </TableRow>
              ) : (
                filteredQuotes.map(quote => {
                  const caseInfo = cases[quote.case_id];
                  const customerInfo = customers[quote.customer_id];
                  return (
                    <TableRow key={quote.id} className="hover:bg-blue-50/50">
                      <TableCell className="font-semibold text-blue-600">
                        <Link to={createPageUrl(`QuoteDetails?id=${quote.id}`)}>
                          {quote.quote_number}
                        </Link>
                      </TableCell>
                      <TableCell>{caseInfo?.case_number || 'N/A'}</TableCell>
                      <TableCell>{customerInfo?.full_name || 'N/A'}</TableCell>
                      <TableCell>{format(parseISO(quote.created_date), 'dd MMM yyyy')}</TableCell>
                      <TableCell>${(quote.total_amount || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}</TableCell>
                      <TableCell className="text-center">
                        <Badge className={`${statusColors[quote.status] || 'bg-gray-200 text-gray-800'} font-medium`}>
                          {quote.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <MoreHorizontal className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => navigate(createPageUrl(`QuoteDetails?id=${quote.id}`))}>
                              <Edit className="w-4 h-4 mr-2" /> Edit / View
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handlePrintOrDownload(quote.id)}>
                              <FileText className="w-4 h-4 mr-2" /> Print Quote
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handlePrintOrDownload(quote.id)}>
                              <Download className="w-4 h-4 mr-2" /> Download PDF
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
}
