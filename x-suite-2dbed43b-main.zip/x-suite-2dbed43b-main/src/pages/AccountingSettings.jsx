import React, { useState, useEffect } from 'react';
import { AccountingLocale } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Globe, Plus, Edit, Trash2, DollarSign, RefreshCw, Star, AlertCircle } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function AccountingSettingsPage() {
    const [locales, setLocales] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [showDialog, setShowDialog] = useState(false);
    const [editingLocale, setEditingLocale] = useState(null);
    const [isUpdatingRates, setIsUpdatingRates] = useState(false);

    const [formData, setFormData] = useState({
        country_name: '',
        country_code: '',
        currency_code: '',
        currency_symbol: '',
        currency_name: '',
        decimal_places: 2,
        decimal_separator: '.',
        thousand_separator: ',',
        currency_position: 'after',
        tax_name: 'VAT',
        tax_rate: 0.05,
        tax_number_label: 'VAT Number',
        exchange_rate_to_usd: 1,
        date_format: 'dd/MM/yyyy',
        is_active: true,
        is_default: false,
        notes: ''
    });

    useEffect(() => {
        fetchLocales();
    }, []);

    const fetchLocales = async () => {
        setIsLoading(true);
        try {
            const data = await AccountingLocale.list('country_name');
            setLocales(data);
        } catch (error) {
            console.error('Failed to fetch accounting locales:', error);
        } finally {
            setIsLoading(false);
        }
    };

    const handleSave = async () => {
        try {
            if (editingLocale) {
                await AccountingLocale.update(editingLocale.id, formData);
            } else {
                // If setting as default, remove default from others first
                if (formData.is_default) {
                    const currentDefault = locales.find(l => l.is_default);
                    if (currentDefault) {
                        await AccountingLocale.update(currentDefault.id, { is_default: false });
                    }
                }
                await AccountingLocale.create(formData);
            }
            
            setShowDialog(false);
            setEditingLocale(null);
            resetForm();
            fetchLocales();
        } catch (error) {
            console.error('Failed to save locale:', error);
            alert('Failed to save accounting locale');
        }
    };

    const handleEdit = (locale) => {
        setEditingLocale(locale);
        setFormData({ ...locale });
        setShowDialog(true);
    };

    const handleDelete = async (localeId) => {
        if (window.confirm('Are you sure you want to delete this accounting locale?')) {
            try {
                await AccountingLocale.delete(localeId);
                fetchLocales();
            } catch (error) {
                console.error('Failed to delete locale:', error);
                alert('Failed to delete accounting locale');
            }
        }
    };

    const handleSetDefault = async (localeId) => {
        try {
            // Remove default from current default
            const currentDefault = locales.find(l => l.is_default);
            if (currentDefault && currentDefault.id !== localeId) {
                await AccountingLocale.update(currentDefault.id, { is_default: false });
            }
            
            // Set new default
            await AccountingLocale.update(localeId, { is_default: true });
            fetchLocales();
        } catch (error) {
            console.error('Failed to set default locale:', error);
            alert('Failed to set default locale');
        }
    };

    const resetForm = () => {
        setFormData({
            country_name: '',
            country_code: '',
            currency_code: '',
            currency_symbol: '',
            currency_name: '',
            decimal_places: 2,
            decimal_separator: '.',
            thousand_separator: ',',
            currency_position: 'after',
            tax_name: 'VAT',
            tax_rate: 0.05,
            tax_number_label: 'VAT Number',
            exchange_rate_to_usd: 1,
            date_format: 'dd/MM/yyyy',
            is_active: true,
            is_default: false,
            notes: ''
        });
    };

    const initializeDefaultLocales = async () => {
        const defaultLocales = [
            {
                country_name: 'Oman',
                country_code: 'OM',
                currency_code: 'OMR',
                currency_symbol: 'OMR',
                currency_name: 'Omani Rial',
                decimal_places: 3,
                decimal_separator: '.',
                thousand_separator: ',',
                currency_position: 'after',
                tax_name: 'VAT',
                tax_rate: 0.05,
                tax_number_label: 'VAT Number',
                exchange_rate_to_usd: 2.6,
                date_format: 'dd/MM/yyyy',
                is_active: true,
                is_default: true,
                notes: 'Default Oman locale with 5% VAT and 3 decimal places for OMR'
            },
            {
                country_name: 'United Arab Emirates',
                country_code: 'AE',
                currency_code: 'AED',
                currency_symbol: 'AED',
                currency_name: 'UAE Dirham',
                decimal_places: 2,
                decimal_separator: '.',
                thousand_separator: ',',
                currency_position: 'after',
                tax_name: 'VAT',
                tax_rate: 0.05,
                tax_number_label: 'TRN',
                exchange_rate_to_usd: 3.67,
                date_format: 'dd/MM/yyyy',
                is_active: true,
                is_default: false,
                notes: 'UAE locale with 5% VAT and TRN (Tax Registration Number)'
            },
            {
                country_name: 'Saudi Arabia',
                country_code: 'SA',
                currency_code: 'SAR',
                currency_symbol: 'SAR',
                currency_name: 'Saudi Riyal',
                decimal_places: 2,
                decimal_separator: '.',
                thousand_separator: ',',
                currency_position: 'after',
                tax_name: 'VAT',
                tax_rate: 0.15,
                tax_number_label: 'VAT Number',
                exchange_rate_to_usd: 3.75,
                date_format: 'dd/MM/yyyy',
                is_active: true,
                is_default: false,
                notes: 'Saudi Arabia locale with 15% VAT'
            },
            {
                country_name: 'United States',
                country_code: 'US',
                currency_code: 'USD',
                currency_symbol: '$',
                currency_name: 'US Dollar',
                decimal_places: 2,
                decimal_separator: '.',
                thousand_separator: ',',
                currency_position: 'before',
                tax_name: 'Sales Tax',
                tax_rate: 0.08,
                tax_number_label: 'Tax ID',
                exchange_rate_to_usd: 1,
                date_format: 'MM/dd/yyyy',
                is_active: true,
                is_default: false,
                notes: 'US locale with variable sales tax (8% average) and dollar-first format'
            }
        ];

        try {
            for (const locale of defaultLocales) {
                await AccountingLocale.create(locale);
            }
            fetchLocales();
        } catch (error) {
            console.error('Failed to initialize default locales:', error);
        }
    };

    const formatCurrency = (amount, locale) => {
        if (!amount || !locale) return '0.00';
        
        const formattedAmount = parseFloat(amount).toFixed(locale.decimal_places)
            .replace(/\B(?=(\d{3})+(?!\d))/g, locale.thousand_separator);
        
        return locale.currency_position === 'before' 
            ? `${locale.currency_symbol} ${formattedAmount}`
            : `${formattedAmount} ${locale.currency_symbol}`;
    };

    const previewAmount = 1234.567;
    const defaultLocale = locales.find(l => l.is_default);

    return (
        <div className="p-8 bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen">
            <div className="flex justify-between items-center mb-8">
                <div className="flex items-center space-x-4">
                    <div className="p-3 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-xl shadow-lg">
                        <Globe className="w-8 h-8 text-white" />
                    </div>
                    <div>
                        <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                            Accounting Locales
                        </h1>
                        <p className="text-gray-500 mt-1">Manage currency, tax, and formatting settings by country</p>
                    </div>
                </div>
                <div className="flex space-x-3">
                    {locales.length === 0 && (
                        <Button onClick={initializeDefaultLocales} variant="outline">
                            Initialize Default Locales
                        </Button>
                    )}
                    <Button onClick={() => { resetForm(); setShowDialog(true); }}>
                        <Plus className="w-4 h-4 mr-2" />
                        Add Locale
                    </Button>
                </div>
            </div>

            <Tabs defaultValue="locales" className="space-y-6">
                <TabsList>
                    <TabsTrigger value="locales">Manage Locales</TabsTrigger>
                    <TabsTrigger value="preview">Format Preview</TabsTrigger>
                </TabsList>

                <TabsContent value="locales">
                    <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0">
                        <CardHeader>
                            <CardTitle className="flex items-center justify-between">
                                <span>Accounting Locales</span>
                                {defaultLocale && (
                                    <Badge className="bg-green-100 text-green-800">
                                        Default: {defaultLocale.country_name} ({defaultLocale.currency_code})
                                    </Badge>
                                )}
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            {locales.length === 0 ? (
                                <div className="text-center py-12 text-gray-500">
                                    <Globe className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                                    <h3 className="text-lg font-medium mb-2">No Accounting Locales Found</h3>
                                    <p className="mb-4">Initialize default locales or create a custom one to get started</p>
                                    <Button onClick={initializeDefaultLocales}>
                                        Initialize Default Locales
                                    </Button>
                                </div>
                            ) : (
                                <Table>
                                    <TableHeader>
                                        <TableRow>
                                            <TableHead>Country</TableHead>
                                            <TableHead>Currency</TableHead>
                                            <TableHead>Tax</TableHead>
                                            <TableHead>Format</TableHead>
                                            <TableHead>Status</TableHead>
                                            <TableHead>Actions</TableHead>
                                        </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {locales.map(locale => (
                                            <TableRow key={locale.id}>
                                                <TableCell>
                                                    <div className="flex items-center space-x-2">
                                                        <span className="font-medium">{locale.country_name}</span>
                                                        <Badge variant="outline" className="text-xs">{locale.country_code}</Badge>
                                                        {locale.is_default && (
                                                            <Star className="w-4 h-4 text-yellow-500 fill-current" />
                                                        )}
                                                    </div>
                                                </TableCell>
                                                <TableCell>
                                                    <div>
                                                        <span className="font-medium">{locale.currency_code}</span>
                                                        <div className="text-xs text-gray-500">
                                                            {formatCurrency(100, locale)}
                                                        </div>
                                                    </div>
                                                </TableCell>
                                                <TableCell>
                                                    <div>
                                                        <span className="font-medium">{locale.tax_name}</span>
                                                        <div className="text-xs text-gray-500">
                                                            {(locale.tax_rate * 100).toFixed(1)}%
                                                        </div>
                                                    </div>
                                                </TableCell>
                                                <TableCell>
                                                    <div className="text-sm">
                                                        <div>{locale.decimal_places} decimals</div>
                                                        <div className="text-xs text-gray-500">{locale.date_format}</div>
                                                    </div>
                                                </TableCell>
                                                <TableCell>
                                                    <Badge className={locale.is_active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                                                        {locale.is_active ? 'Active' : 'Inactive'}
                                                    </Badge>
                                                </TableCell>
                                                <TableCell>
                                                    <div className="flex items-center space-x-2">
                                                        {!locale.is_default && (
                                                            <Button
                                                                variant="ghost"
                                                                size="sm"
                                                                onClick={() => handleSetDefault(locale.id)}
                                                                className="text-yellow-600 hover:text-yellow-700"
                                                            >
                                                                <Star className="w-4 h-4" />
                                                            </Button>
                                                        )}
                                                        <Button
                                                            variant="ghost"
                                                            size="sm"
                                                            onClick={() => handleEdit(locale)}
                                                        >
                                                            <Edit className="w-4 h-4" />
                                                        </Button>
                                                        <Button
                                                            variant="ghost"
                                                            size="sm"
                                                            onClick={() => handleDelete(locale.id)}
                                                            className="text-red-500 hover:text-red-700"
                                                        >
                                                            <Trash2 className="w-4 h-4" />
                                                        </Button>
                                                    </div>
                                                </TableCell>
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            )}
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="preview">
                    <Card className="shadow-xl bg-white/90 backdrop-blur-sm border-0">
                        <CardHeader>
                            <CardTitle>Currency Format Preview</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                {locales.filter(l => l.is_active).map(locale => (
                                    <div key={locale.id} className="p-4 border rounded-lg bg-gray-50">
                                        <div className="flex items-center justify-between mb-3">
                                            <h3 className="font-semibold">{locale.country_name}</h3>
                                            {locale.is_default && (
                                                <Badge className="bg-green-100 text-green-800 text-xs">Default</Badge>
                                            )}
                                        </div>
                                        <div className="space-y-2 text-sm">
                                            <div className="flex justify-between">
                                                <span>Amount:</span>
                                                <span className="font-mono">{formatCurrency(previewAmount, locale)}</span>
                                            </div>
                                            <div className="flex justify-between">
                                                <span>{locale.tax_name}:</span>
                                                <span className="font-mono">{formatCurrency(previewAmount * locale.tax_rate, locale)}</span>
                                            </div>
                                            <div className="flex justify-between border-t pt-2">
                                                <span>Total:</span>
                                                <span className="font-mono font-bold">{formatCurrency(previewAmount * (1 + locale.tax_rate), locale)}</span>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>

            {/* Add/Edit Dialog */}
            <Dialog open={showDialog} onOpenChange={setShowDialog}>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                    <DialogHeader>
                        <DialogTitle>
                            {editingLocale ? 'Edit Accounting Locale' : 'Add Accounting Locale'}
                        </DialogTitle>
                    </DialogHeader>
                    <div className="grid grid-cols-2 gap-6 py-4">
                        <div className="space-y-4">
                            <div>
                                <Label>Country Name *</Label>
                                <Input
                                    value={formData.country_name}
                                    onChange={(e) => setFormData({...formData, country_name: e.target.value})}
                                    placeholder="e.g., Oman"
                                />
                            </div>
                            <div>
                                <Label>Country Code *</Label>
                                <Input
                                    value={formData.country_code}
                                    onChange={(e) => setFormData({...formData, country_code: e.target.value.toUpperCase()})}
                                    placeholder="e.g., OM"
                                    maxLength={2}
                                />
                            </div>
                            <div>
                                <Label>Currency Code *</Label>
                                <Input
                                    value={formData.currency_code}
                                    onChange={(e) => setFormData({...formData, currency_code: e.target.value.toUpperCase()})}
                                    placeholder="e.g., OMR"
                                    maxLength={3}
                                />
                            </div>
                            <div>
                                <Label>Currency Symbol *</Label>
                                <Input
                                    value={formData.currency_symbol}
                                    onChange={(e) => setFormData({...formData, currency_symbol: e.target.value})}
                                    placeholder="e.g., OMR or $"
                                />
                            </div>
                            <div>
                                <Label>Currency Name</Label>
                                <Input
                                    value={formData.currency_name}
                                    onChange={(e) => setFormData({...formData, currency_name: e.target.value})}
                                    placeholder="e.g., Omani Rial"
                                />
                            </div>
                        </div>
                        <div className="space-y-4">
                            <div>
                                <Label>Tax Name</Label>
                                <Input
                                    value={formData.tax_name}
                                    onChange={(e) => setFormData({...formData, tax_name: e.target.value})}
                                    placeholder="e.g., VAT, GST"
                                />
                            </div>
                            <div>
                                <Label>Tax Rate *</Label>
                                <Input
                                    type="number"
                                    step="0.001"
                                    value={formData.tax_rate}
                                    onChange={(e) => setFormData({...formData, tax_rate: parseFloat(e.target.value) || 0})}
                                    placeholder="e.g., 0.05 for 5%"
                                />
                            </div>
                            <div>
                                <Label>Tax Number Label</Label>
                                <Input
                                    value={formData.tax_number_label}
                                    onChange={(e) => setFormData({...formData, tax_number_label: e.target.value})}
                                    placeholder="e.g., VAT Number, TRN"
                                />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <Label>Decimal Places</Label>
                                    <Select value={formData.decimal_places.toString()} onValueChange={(value) => setFormData({...formData, decimal_places: parseInt(value)})}>
                                        <SelectTrigger>
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="0">0</SelectItem>
                                            <SelectItem value="2">2</SelectItem>
                                            <SelectItem value="3">3</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div>
                                    <Label>Currency Position</Label>
                                    <Select value={formData.currency_position} onValueChange={(value) => setFormData({...formData, currency_position: value})}>
                                        <SelectTrigger>
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="before">Before ($ 100.00)</SelectItem>
                                            <SelectItem value="after">After (100.00 OMR)</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                            </div>
                            <div>
                                <Label>Exchange Rate to USD</Label>
                                <Input
                                    type="number"
                                    step="0.0001"
                                    value={formData.exchange_rate_to_usd}
                                    onChange={(e) => setFormData({...formData, exchange_rate_to_usd: parseFloat(e.target.value) || 1})}
                                    placeholder="e.g., 2.6 for OMR"
                                />
                            </div>
                        </div>
                        <div className="col-span-2 space-y-4">
                            <div className="flex items-center justify-between">
                                <Label>Active</Label>
                                <Switch
                                    checked={formData.is_active}
                                    onCheckedChange={(checked) => setFormData({...formData, is_active: checked})}
                                />
                            </div>
                            <div className="flex items-center justify-between">
                                <Label>Set as Default</Label>
                                <Switch
                                    checked={formData.is_default}
                                    onCheckedChange={(checked) => setFormData({...formData, is_default: checked})}
                                />
                            </div>
                            <div>
                                <Label>Notes</Label>
                                <Textarea
                                    value={formData.notes}
                                    onChange={(e) => setFormData({...formData, notes: e.target.value})}
                                    placeholder="Additional notes about this locale"
                                    rows={3}
                                />
                            </div>
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setShowDialog(false)}>
                            Cancel
                        </Button>
                        <Button onClick={handleSave}>
                            {editingLocale ? 'Update' : 'Create'} Locale
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}