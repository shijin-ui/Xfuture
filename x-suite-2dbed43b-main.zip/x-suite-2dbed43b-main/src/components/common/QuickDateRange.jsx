import React from "react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { addMonths, endOfDay, endOfMonth, endOfYear, format, startOfDay, startOfMonth, startOfYear } from "date-fns";
import { Calendar as CalendarIcon, ChevronDown } from "lucide-react";

export default function QuickDateRange({ value, onChange, className = "" }) {
  const [open, setOpen] = React.useState(false);
  const [range, setRange] = React.useState(value || { start: startOfMonth(new Date()), end: endOfDay(new Date()) });

  React.useEffect(() => {
    if (value) setRange(value);
  }, [value]);

  const presets = [
    { key: "today", label: "Today", get: () => ({ start: startOfDay(new Date()), end: endOfDay(new Date()) }) },
    { key: "this_month", label: "This Month", get: () => ({ start: startOfMonth(new Date()), end: endOfMonth(new Date()) }) },
    { key: "this_year", label: "This Year", get: () => ({ start: startOfYear(new Date()), end: endOfYear(new Date()) }) },
    { key: "last_month", label: "Last Month", get: () => {
      const d = addMonths(new Date(), -1);
      return { start: startOfMonth(d), end: endOfMonth(d) };
    }},
  ];

  const apply = (r) => {
    setRange(r);
    onChange && onChange(r);
    setOpen(false);
  };

  return (
    <div className={className}>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button variant="outline" className="rounded-xl">
            <CalendarIcon className="w-4 h-4 mr-2" />
            {format(range.start, "dd MMM yyyy")} — {format(range.end, "dd MMM yyyy")}
            <ChevronDown className="w-4 h-4 ml-2 opacity-60" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-[320px]">
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-2">
              {presets.map(p => (
                <Button key={p.key} variant="ghost" className="justify-start" onClick={() => apply(p.get())}>
                  {p.label}
                </Button>
              ))}
            </div>
            <div>
              <Calendar
                mode="range"
                selected={{ from: range.start, to: range.end }}
                onSelect={(val) => {
                  if (val?.from && val?.to) setRange({ start: startOfDay(val.from), end: endOfDay(val.to) });
                }}
                numberOfMonths={1}
              />
              <div className="flex justify-end pt-2 gap-2">
                <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                <Button onClick={() => apply(range)}>Apply</Button>
              </div>
            </div>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}