import React from "react";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";

export default function DataExportButtons({ rows = [], filename = "export", toCsv }) {
  const download = (content, name, type) => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  const csv = toCsv ? toCsv(rows) : defaultCsv(rows);

  function defaultCsv(rowsArr) {
    if (!rowsArr || rowsArr.length === 0) return "";
    const headers = Object.keys(rowsArr[0]);
    const esc = (v) => {
      if (v === null || v === undefined) return "";
      const s = typeof v === "object" ? JSON.stringify(v) : String(v);
      return s.includes(",") || s.includes('"') || s.includes("\n") ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const body = rowsArr.map(r => headers.map(h => esc(r[h])).join(",")).join("\n");
    return `${headers.join(",")}\n${body}`;
  }

  const handleCsv = () => download(csv, `${filename}.csv`, "text/csv;charset=utf-8");
  // For Excel option, provide CSV with .xlsx extension for convenience (opens in Excel)
  const handleXlsx = () => download(csv, `${filename}.xlsx`, "text/csv;charset=utf-8");

  return (
    <div className="flex gap-2">
      <Button variant="outline" size="sm" onClick={handleCsv}><Download className="w-4 h-4 mr-2" />CSV</Button>
      <Button variant="outline" size="sm" onClick={handleXlsx}><Download className="w-4 h-4 mr-2" />Excel</Button>
    </div>
  );
}