import React from "react";
import { format } from "date-fns";

export default function CurrentDateTime({ className = "" }) {
  const [now, setNow] = React.useState(new Date());

  React.useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000 * 30);
    return () => clearInterval(id);
  }, []);

  return (
    <div className={`text-sm text-muted-foreground ${className}`} aria-label="Current date and time">
      {format(now, "EEE, dd MMM yyyy · HH:mm")}
    </div>
  );
}