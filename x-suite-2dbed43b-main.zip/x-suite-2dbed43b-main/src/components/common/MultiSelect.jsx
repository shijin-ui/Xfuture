import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from '@/components/ui/badge';
import { ChevronDown, X, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';

export default function MultiSelect({ options, selected, onChange, placeholder = "Select accessories..." }) {
  const [searchTerm, setSearchTerm] = useState("");

  const handleSelect = (option) => {
    if (selected.includes(option)) {
      onChange(selected.filter(item => item !== option));
    } else {
      onChange([...selected, option]);
    }
  };

  const handleClear = (e, optionToClear) => {
    e.stopPropagation();
    onChange(selected.filter(item => item !== optionToClear));
  };
  
  const filteredOptions = options.filter(option => 
      option.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Separate selected and unselected options, showing selected first
  const selectedOptions = filteredOptions.filter(option => selected.includes(option));
  const unselectedOptions = filteredOptions.filter(option => !selected.includes(option));
  const sortedOptions = [...selectedOptions, ...unselectedOptions];

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          className="w-full justify-between h-auto min-h-[40px] flex-wrap font-normal"
        >
          <div className="flex gap-1 flex-wrap items-center">
            {selected && selected.length > 0 ? (
              selected.map(item => (
                <Badge key={item} variant="secondary" className="flex items-center gap-1.5 py-1 px-2">
                  <span>{item}</span>
                  <X 
                    className="h-3 w-3 cursor-pointer rounded-full hover:bg-muted-foreground/20" 
                    onClick={(e) => handleClear(e, item)}
                  />
                </Badge>
              ))
            ) : (
              <span className="text-muted-foreground">{placeholder}</span>
            )}
          </div>
          <ChevronDown className="h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[--radix-popover-trigger-width] p-0">
        <div className="p-3 border-b">
           <div className="relative">
             <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
             <Input
               placeholder="Search accessories..."
               value={searchTerm}
               onChange={(e) => setSearchTerm(e.target.value)}
               className="pl-8"
             />
           </div>
        </div>
        <ScrollArea className="max-h-80">
          <div className="p-2 space-y-1">
            {selectedOptions.length > 0 && (
              <>
                <div className="px-2 py-1 text-xs font-medium text-muted-foreground uppercase tracking-wide">
                  Selected ({selected.length})
                </div>
                {selectedOptions.map((option) => (
                  <div
                    key={option}
                    className="flex items-center space-x-2 p-2 hover:bg-muted rounded-md cursor-pointer bg-blue-50"
                    onClick={() => handleSelect(option)}
                  >
                    <Checkbox
                      id={`check-${option}`}
                      checked={true}
                      readOnly
                    />
                    <label
                      htmlFor={`check-${option}`}
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 w-full cursor-pointer text-blue-700"
                    >
                      {option}
                    </label>
                  </div>
                ))}
              </>
            )}
            {unselectedOptions.length > 0 && (
              <>
                {selectedOptions.length > 0 && (
                  <div className="border-t my-2"></div>
                )}
                <div className="px-2 py-1 text-xs font-medium text-muted-foreground uppercase tracking-wide">
                  Available ({unselectedOptions.length})
                </div>
                {unselectedOptions.map((option) => (
                  <div
                    key={option}
                    className="flex items-center space-x-2 p-2 hover:bg-muted rounded-md cursor-pointer"
                    onClick={() => handleSelect(option)}
                  >
                    <Checkbox
                      id={`check-${option}`}
                      checked={false}
                      readOnly
                    />
                    <label
                      htmlFor={`check-${option}`}
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 w-full cursor-pointer"
                    >
                      {option}
                    </label>
                  </div>
                ))}
              </>
            )}
            {sortedOptions.length === 0 && (
              <p className="text-center text-sm text-muted-foreground py-4">No matching accessories found.</p>
            )}
          </div>
        </ScrollArea>
      </PopoverContent>
    </Popover>
  );
}