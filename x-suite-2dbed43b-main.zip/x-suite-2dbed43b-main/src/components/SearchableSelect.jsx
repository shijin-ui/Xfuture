
import React, { useState, useEffect, useRef } from 'react';
import { ChevronDown, Search, Check } from 'lucide-react';

const SearchableSelect = ({
  value,
  onValueChange,
  options = [],
  placeholder = "Select an option...",
  searchPlaceholder = "Search...",
  className = "",
  disabled = false,
  creatable = false
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const dropdownRef = useRef(null);
  const searchInputRef = useRef(null);

  const normalizedOptions = React.useMemo(() => {
    // FIX: Use a Set to ensure unique options before mapping
    const uniqueOptions = [...new Set(options.map(opt => typeof opt === 'string' ? opt : opt.value))];

    return uniqueOptions.map(optValue => {
        const originalOpt = options.find(o => (typeof o === 'string' ? o : o.value) === optValue);
        if (typeof originalOpt === 'string') {
            return { label: originalOpt, value: originalOpt };
        }
        if (originalOpt && typeof originalOpt === 'object') {
            return { label: originalOpt.label || originalOpt.value, value: originalOpt.value, subtitle: originalOpt.subtitle };
        }
        return { label: String(optValue), value: String(optValue) };
    });
  }, [options]);

  const filteredOptions = React.useMemo(() => {
    if (!searchTerm) {
      return normalizedOptions;
    }
    return normalizedOptions.filter(option =>
      option.label.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [normalizedOptions, searchTerm]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
        setSearchTerm('');
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (isOpen && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [isOpen]);

  const handleSelect = (option) => {
    onValueChange(option.value);
    setIsOpen(false);
    setSearchTerm('');
  };

  const handleCreateNew = () => {
    if (creatable && searchTerm.trim() && !normalizedOptions.some(opt => opt.value.toLowerCase() === searchTerm.trim().toLowerCase())) {
        onValueChange(searchTerm.trim());
        setIsOpen(false);
        setSearchTerm('');
    }
  };

  const currentOption = normalizedOptions.find(opt => opt.value === value);
  // FIX: This ensures we only display the label, not a concatenated string.
  const displayValue = currentOption ? currentOption.label : (value || placeholder);

  return (
    <div className={`relative ${className}`} ref={dropdownRef}>
      <button
        type="button"
        onClick={() => !disabled && setIsOpen(!isOpen)}
        disabled={disabled}
        className={`w-full px-3 py-2 text-left bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
          disabled ? 'bg-gray-100 cursor-not-allowed' : 'hover:border-gray-400'
        } ${isOpen ? 'ring-2 ring-blue-500 border-blue-500' : ''}`}
      >
        <div className="flex items-center justify-between">
          <span className={`truncate ${value ? 'text-gray-900' : 'text-gray-500'}`}>
            {displayValue}
          </span>
          <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
        </div>
      </button>

      {isOpen && (
        <div className="absolute z-50 w-full mt-1 bg-white border border-gray-300 rounded-md shadow-lg max-h-96 overflow-hidden">
          <div className="p-2 border-b border-gray-200">
            <div className="relative">
              <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                ref={searchInputRef}
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder={searchPlaceholder}
                className="w-full pl-8 pr-3 py-2 text-sm border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
          </div>
          <div className="max-h-80 overflow-y-auto p-1">
            {filteredOptions.length === 0 ? (
              <div className="px-3 py-2 text-sm text-gray-500 text-center">
                {creatable && searchTerm.trim() && !normalizedOptions.some(opt => opt.value.toLowerCase() === searchTerm.trim().toLowerCase()) ? (
                  <button
                    type="button"
                    onClick={handleCreateNew}
                    className="w-full text-left hover:bg-blue-50 px-2 py-1 rounded text-blue-600"
                  >
                    Create "{searchTerm.trim()}"
                  </button>
                ) : (
                  'No options found'
                )}
              </div>
            ) : (
              <>
                {filteredOptions.map((option, index) => (
                  <button
                    key={index}
                    type="button"
                    onClick={() => handleSelect(option)}
                    className={`w-full text-left text-sm rounded-md transition-colors duration-150 flex items-center justify-between p-2 ${
                      value === option.value ? 'bg-primary/10 font-semibold text-primary' : 'text-foreground hover:bg-muted/80'
                    }`}
                  >
                    <div className="flex flex-col">
                        <span className="font-medium">{option.label}</span>
                        {option.subtitle && <span className="text-xs text-gray-500">{option.subtitle}</span>}
                    </div>
                    {value === option.value && <Check className="w-4 h-4 text-primary" />}
                  </button>
                ))}
                {creatable && searchTerm.trim() && !normalizedOptions.some(opt => opt.value.toLowerCase() === searchTerm.trim().toLowerCase()) && (
                  <button
                    type="button"
                    onClick={handleCreateNew}
                    className="w-full px-3 py-2 text-left text-sm hover:bg-blue-50 text-blue-600 border-t border-gray-200 mt-1"
                  >
                    Create "{searchTerm.trim()}"
                  </button>
                )}
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default SearchableSelect;
