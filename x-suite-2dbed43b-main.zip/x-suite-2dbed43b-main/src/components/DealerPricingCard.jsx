import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Users, Percent, Target, Calendar } from 'lucide-react';

export default function DealerPricingCard({ customer, monthlyStats }) {
    if (!customer?.customer_group?.startsWith('Dealer')) {
        return null;
    }

    const getDealerLevel = (group) => {
        if (group?.includes('Bronze')) return 'Bronze';
        if (group?.includes('Silver')) return 'Silver'; 
        if (group?.includes('Gold')) return 'Gold';
        if (group?.includes('Platinum')) return 'Platinum';
        return 'Bronze';
    };

    const getDealerColors = (level) => {
        const colors = {
            'Bronze': 'bg-gradient-to-r from-amber-100 to-yellow-100 text-amber-800 border-amber-200',
            'Silver': 'bg-gradient-to-r from-gray-100 to-slate-100 text-gray-800 border-gray-300',
            'Gold': 'bg-gradient-to-r from-yellow-100 to-amber-100 text-yellow-800 border-yellow-300',
            'Platinum': 'bg-gradient-to-r from-purple-100 to-indigo-100 text-purple-800 border-purple-300'
        };
        return colors[level] || colors['Bronze'];
    };

    const dealerLevel = getDealerLevel(customer.customer_group);
    const discountPercentage = customer.dealer_discount_percentage || 0;

    return (
        <Card className="shadow-lg border-0">
            <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-t-lg">
                <CardTitle className="text-indigo-800 flex items-center">
                    <Users className="w-5 h-5 mr-2" />
                    Dealer Information
                </CardTitle>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
                <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-600">Dealer Level:</span>
                    <Badge className={`${getDealerColors(dealerLevel)} font-medium px-3 py-1`}>
                        {dealerLevel} Dealer
                    </Badge>
                </div>

                <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-600">Discount Rate:</span>
                    <div className="flex items-center">
                        <Percent className="w-4 h-4 mr-1 text-green-600" />
                        <span className="font-bold text-green-600">{discountPercentage}%</span>
                    </div>
                </div>

                {customer.monthly_case_target && (
                    <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-gray-600">Monthly Target:</span>
                        <div className="flex items-center">
                            <Target className="w-4 h-4 mr-1 text-blue-600" />
                            <span className="font-semibold text-blue-600">{customer.monthly_case_target} cases</span>
                        </div>
                    </div>
                )}

                {monthlyStats && (
                    <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                        <h4 className="text-sm font-semibold text-gray-700 mb-2">This Month Performance</h4>
                        <div className="grid grid-cols-2 gap-3 text-sm">
                            <div>
                                <span className="text-gray-600">Cases:</span>
                                <span className="ml-2 font-semibold">{monthlyStats.cases || 0}</span>
                            </div>
                            <div>
                                <span className="text-gray-600">Revenue:</span>
                                <span className="ml-2 font-semibold text-green-600">
                                    ${(monthlyStats.revenue || 0).toLocaleString()}
                                </span>
                            </div>
                        </div>
                    </div>
                )}

                {customer.dealer_since && (
                    <div className="flex items-center justify-between text-sm text-gray-500 pt-2 border-t">
                        <span>Dealer since:</span>
                        <div className="flex items-center">
                            <Calendar className="w-4 h-4 mr-1" />
                            {new Date(customer.dealer_since).toLocaleDateString()}
                        </div>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}