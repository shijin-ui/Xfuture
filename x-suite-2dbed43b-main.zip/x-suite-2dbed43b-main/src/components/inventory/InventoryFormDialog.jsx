import React, { useState, useEffect } from 'react';
import { Inventory } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';

const itemTypes = ["HDD", "SSD", "PCB", "Other"];
const conditions = ["New", "Used - Working", "Used - Tested", "For Parts Only", "Defective"];
const interfaces = ["SATA", "SAS", "NVMe", "IDE/PATA", "USB", "Other"];

export default function InventoryFormDialog({ open, onOpenChange, item, onSave }) {
    const [formData, setFormData] = useState(null);

    useEffect(() => {
        if (open) {
            setFormData(item ? { ...item } : {
                name: '',
                item_type: 'HDD',
                brand: '',
                model_number: '',
                serial_number: '',
                capacity: '',
                interface: 'SATA',
                condition: 'Used - Tested',
                quantity: 1,
                location: '',
                supplier: '',
                purchase_cost: '',
                purchase_date: '',
                notes: '',
                case_id: '',
                is_donor: true,
                compatibility_tags: '',
                // HDD specific
                dom: '',
                product_of: '',
                pcb_number: '',
                dcm: '',
                head_map: '',
                preamp: '',
                part_number: '',
                micro_jogs: '',
                firmware: '',
                mlc: '',
                // SSD specific
                controller_details: '',
                ssd_family: '',
                // PCB specific
                pcb_revision: '',
                // Testing
                tested_date: '',
                test_results: ''
            });
        } else {
            setFormData(null);
        }
    }, [open, item]);

    const handleChange = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const generateName = () => {
        if (!formData.brand || !formData.item_type) return '';
        
        let name = `${formData.brand}`;
        if (formData.model_number) name += ` ${formData.model_number}`;
        if (formData.capacity) name += ` ${formData.capacity}`;
        if (formData.item_type === 'PCB' && formData.pcb_number) name += ` PCB-${formData.pcb_number}`;
        
        return name;
    };

    const handleSave = async () => {
        if (!formData.item_type || !formData.brand) {
            alert('Item Type and Brand are required.');
            return;
        }

        const dataToSave = { ...formData };
        
        // Auto-generate name if not provided
        if (!dataToSave.name) {
            dataToSave.name = generateName();
        }
        
        // Clean up numeric fields
        dataToSave.quantity = parseInt(dataToSave.quantity, 10) || 1;
        dataToSave.purchase_cost = parseFloat(dataToSave.purchase_cost) || 0;
        
        // Remove empty date fields
        if (!dataToSave.purchase_date) delete dataToSave.purchase_date;
        if (!dataToSave.tested_date) delete dataToSave.tested_date;

        try {
            if (item?.id) {
                await Inventory.update(item.id, dataToSave);
            } else {
                await Inventory.create(dataToSave);
            }
            onSave();
            onOpenChange(false);
        } catch (error) {
            console.error("Failed to save inventory item:", error);
            alert("Failed to save item.");
        }
    };

    if (!formData) return null;

    const renderTypeSpecificFields = () => {
        switch (formData.item_type) {
            case 'HDD':
                return (
                    <>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <Label>Interface</Label>
                                <Select value={formData.interface} onValueChange={(value) => handleChange('interface', value)}>
                                    <SelectTrigger><SelectValue /></SelectTrigger>
                                    <SelectContent>{interfaces.map(i => <SelectItem key={i} value={i}>{i}</SelectItem>)}</SelectContent>
                                </Select>
                            </div>
                            <div>
                                <Label>DOM (Date of Manufacture)</Label>
                                <Input value={formData.dom} onChange={(e) => handleChange('dom', e.target.value)} placeholder="e.g., 15MAR2020" />
                            </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <Label>Product Of (Country)</Label>
                                <Input value={formData.product_of} onChange={(e) => handleChange('product_of', e.target.value)} placeholder="e.g., China, Thailand" />
                            </div>
                            <div>
                                <Label>PCB Number</Label>
                                <Input value={formData.pcb_number} onChange={(e) => handleChange('pcb_number', e.target.value)} placeholder="e.g., 100664987" />
                            </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <Label>DCM</Label>
                                <Input value={formData.dcm} onChange={(e) => handleChange('dcm', e.target.value)} placeholder="e.g., HBRNNT2MH" />
                            </div>
                            <div>
                                <Label>Head Map</Label>
                                <Input value={formData.head_map} onChange={(e) => handleChange('head_map', e.target.value)} placeholder="e.g., 0123456789AB" />
                            </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <Label>Preamp</Label>
                                <Input value={formData.preamp} onChange={(e) => handleChange('preamp', e.target.value)} placeholder="e.g., STM4651F" />
                            </div>
                            <div>
                                <Label>Part Number</Label>
                                <Input value={formData.part_number} onChange={(e) => handleChange('part_number', e.target.value)} placeholder="e.g., ST2000DM008" />
                            </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <Label>Micro Jogs</Label>
                                <Input value={formData.micro_jogs} onChange={(e) => handleChange('micro_jogs', e.target.value)} placeholder="Micro jog settings" />
                            </div>
                            <div>
                                <Label>Firmware</Label>
                                <Input value={formData.firmware} onChange={(e) => handleChange('firmware', e.target.value)} placeholder="e.g., CC26" />
                            </div>
                        </div>
                        <div>
                            <Label>MLC</Label>
                            <Input value={formData.mlc} onChange={(e) => handleChange('mlc', e.target.value)} placeholder="MLC details" />
                        </div>
                    </>
                );
                
            case 'SSD':
                return (
                    <>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <Label>Interface</Label>
                                <Select value={formData.interface} onValueChange={(value) => handleChange('interface', value)}>
                                    <SelectTrigger><SelectValue /></SelectTrigger>
                                    <SelectContent>{interfaces.map(i => <SelectItem key={i} value={i}>{i}</SelectItem>)}</SelectContent>
                                </Select>
                            </div>
                            <div>
                                <Label>DOM (Date of Manufacture)</Label>
                                <Input value={formData.dom} onChange={(e) => handleChange('dom', e.target.value)} placeholder="e.g., 2021-W24" />
                            </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <Label>Product Of (Country)</Label>
                                <Input value={formData.product_of} onChange={(e) => handleChange('product_of', e.target.value)} placeholder="e.g., Korea, China" />
                            </div>
                            <div>
                                <Label>SSD Family</Label>
                                <Input value={formData.ssd_family} onChange={(e) => handleChange('ssd_family', e.target.value)} placeholder="e.g., 980 PRO, MX500" />
                            </div>
                        </div>
                        <div>
                            <Label>Controller Details</Label>
                            <Input value={formData.controller_details} onChange={(e) => handleChange('controller_details', e.target.value)} placeholder="e.g., Samsung Phoenix, Marvell 88SS1074" />
                        </div>
                    </>
                );
                
            case 'PCB':
                return (
                    <>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <Label>PCB Number <span className="text-red-500">*</span></Label>
                                <Input value={formData.pcb_number} onChange={(e) => handleChange('pcb_number', e.target.value)} placeholder="e.g., 100664987" />
                            </div>
                            <div>
                                <Label>PCB Revision</Label>
                                <Input value={formData.pcb_revision} onChange={(e) => handleChange('pcb_revision', e.target.value)} placeholder="e.g., Rev A, Rev B" />
                            </div>
                        </div>
                    </>
                );
                
            case 'Other':
                return (
                    <>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <Label>Category</Label>
                                <Select value={formData.category || ''} onValueChange={(value) => handleChange('category', value)}>
                                    <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="Cable">Cable</SelectItem>
                                        <SelectItem value="Adapter">Adapter</SelectItem>
                                        <SelectItem value="Tool">Tool</SelectItem>
                                        <SelectItem value="Enclosure">Enclosure</SelectItem>
                                        <SelectItem value="Software">Software</SelectItem>
                                        <SelectItem value="Documentation">Documentation</SelectItem>
                                        <SelectItem value="Spare Part">Spare Part</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div>
                                <Label>Part Number</Label>
                                <Input value={formData.part_number} onChange={(e) => handleChange('part_number', e.target.value)} placeholder="Manufacturer part number" />
                            </div>
                        </div>
                        <div>
                            <Label>Specifications</Label>
                            <Textarea value={formData.specifications || ''} onChange={(e) => handleChange('specifications', e.target.value)} placeholder="Technical specifications, connector types, etc." className="h-20" />
                        </div>
                    </>
                );
                
            default:
                return null;
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
                <DialogHeader>
                    <DialogTitle>{item ? 'Edit Inventory Item' : 'Add New Inventory Item'}</DialogTitle>
                </DialogHeader>
                <div className="overflow-y-auto pr-2 max-h-[70vh]">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-4">
                        {/* Left Column - Basic Information */}
                        <div className="space-y-4">
                            <div className="bg-blue-50 p-4 rounded-lg">
                                <h3 className="font-semibold text-blue-800 mb-3">Basic Information</h3>
                                
                                <div>
                                    <Label>Item Type <span className="text-red-500">*</span></Label>
                                    <Select value={formData.item_type} onValueChange={(value) => handleChange('item_type', value)}>
                                        <SelectTrigger><SelectValue /></SelectTrigger>
                                        <SelectContent>{itemTypes.map(type => <SelectItem key={type} value={type}>{type}</SelectItem>)}</SelectContent>
                                    </Select>
                                </div>
                                
                                <div className="grid grid-cols-2 gap-4 mt-4">
                                    <div>
                                        <Label>Brand <span className="text-red-500">*</span></Label>
                                        <Input value={formData.brand} onChange={(e) => handleChange('brand', e.target.value)} placeholder="e.g., Seagate, WD, Samsung" />
                                    </div>
                                    <div>
                                        <Label>Model Number</Label>
                                        <Input value={formData.model_number} onChange={(e) => handleChange('model_number', e.target.value)} placeholder="e.g., ST2000DM008" />
                                    </div>
                                </div>
                                
                                <div className="grid grid-cols-2 gap-4 mt-4">
                                    <div>
                                        <Label>Serial Number</Label>
                                        <Input value={formData.serial_number} onChange={(e) => handleChange('serial_number', e.target.value)} placeholder="Unique serial number" />
                                    </div>
                                    <div>
                                        <Label>Capacity</Label>
                                        <Input value={formData.capacity} onChange={(e) => handleChange('capacity', e.target.value)} placeholder="e.g., 2TB, 512GB" />
                                    </div>
                                </div>
                                
                                <div>
                                    <Label>Item Name (Auto-generated if empty)</Label>
                                    <Input value={formData.name} onChange={(e) => handleChange('name', e.target.value)} placeholder="Auto-generated from brand + model + capacity" />
                                </div>
                            </div>
                        </div>

                        {/* Right Column - Type Specific & Additional Info */}
                        <div className="space-y-4">
                            <div className="bg-green-50 p-4 rounded-lg">
                                <h3 className="font-semibold text-green-800 mb-3">Technical Specifications</h3>
                                {renderTypeSpecificFields()}
                            </div>
                            
                            <div className="bg-yellow-50 p-4 rounded-lg">
                                <h3 className="font-semibold text-yellow-800 mb-3">Inventory Details</h3>
                                
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <Label>Condition</Label>
                                        <Select value={formData.condition} onValueChange={(value) => handleChange('condition', value)}>
                                            <SelectTrigger><SelectValue /></SelectTrigger>
                                            <SelectContent>{conditions.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                                        </Select>
                                    </div>
                                    <div>
                                        <Label>Quantity</Label>
                                        <Input type="number" value={formData.quantity} onChange={(e) => handleChange('quantity', e.target.value)} placeholder="1" />
                                    </div>
                                </div>
                                
                                <div className="grid grid-cols-2 gap-4 mt-4">
                                    <div>
                                        <Label>Location</Label>
                                        <Input value={formData.location} onChange={(e) => handleChange('location', e.target.value)} placeholder="e.g., Shelf B-7, Clean Room" />
                                    </div>
                                    <div>
                                        <Label>Supplier</Label>
                                        <Input value={formData.supplier} onChange={(e) => handleChange('supplier', e.target.value)} placeholder="e.g., Local IT Store" />
                                    </div>
                                </div>
                                
                                <div className="grid grid-cols-2 gap-4 mt-4">
                                    <div>
                                        <Label>Purchase Cost ($)</Label>
                                        <Input type="number" value={formData.purchase_cost} onChange={(e) => handleChange('purchase_cost', e.target.value)} placeholder="50.00" />
                                    </div>
                                    <div>
                                        <Label>Purchase Date</Label>
                                        <Input type="date" value={formData.purchase_date} onChange={(e) => handleChange('purchase_date', e.target.value)} />
                                    </div>
                                </div>
                                
                                <div className="flex items-center space-x-2 mt-4">
                                    <Checkbox 
                                        id="is-donor" 
                                        checked={formData.is_donor}
                                        onCheckedChange={(checked) => handleChange('is_donor', checked)}
                                    />
                                    <Label htmlFor="is-donor">This is a donor part</Label>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    {/* Full width fields */}
                    <div className="space-y-4 mt-6">
                        <div>
                            <Label>Compatibility Tags (comma-separated)</Label>
                            <Input value={formData.compatibility_tags} onChange={(e) => handleChange('compatibility_tags', e.target.value)} placeholder="e.g., 2TB, 5400RPM, ST2000DM008, Barracuda" />
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <Label>Tested Date</Label>
                                <Input type="date" value={formData.tested_date} onChange={(e) => handleChange('tested_date', e.target.value)} />
                            </div>
                            <div>
                                <Label>Assigned to Case ID</Label>
                                <Input value={formData.case_id} onChange={(e) => handleChange('case_id', e.target.value)} placeholder="Leave blank if available" />
                            </div>
                        </div>
                        
                        <div>
                            <Label>Test Results</Label>
                            <Textarea value={formData.test_results} onChange={(e) => handleChange('test_results', e.target.value)} placeholder="Compatibility test results, functionality notes..." className="h-16" />
                        </div>
                        
                        <div>
                            <Label>Notes</Label>
                            <Textarea value={formData.notes} onChange={(e) => handleChange('notes', e.target.value)} placeholder="Additional technical notes, usage history, special considerations..." className="h-20" />
                        </div>
                    </div>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
                    <Button onClick={handleSave}>Save Item</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}