
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Save, X, AlertTriangle, ExternalLink } from 'lucide-react';
import { Case } from '@/api/entities';
import { Customer } from '@/api/entities';
import { format } from 'date-fns';
import { createPageUrl } from '@/utils';
import SearchableSelect from './SearchableSelect';
import { getSettingsByCategory } from './utils/settingsLoader';

export default function DeviceDialog({ open, onOpenChange, onSave, onSelectServer, device = null }) {
  const [deviceData, setDeviceData] = useState({
    media_type: '',
    brand: '',
    media_model: '',
    media_serial_number: '',
    capacity: '',
    condition: 'Good',
    role: 'Patient',
    accessories: ''
  });
  
  const [duplicateWarning, setDuplicateWarning] = useState(null);
  const [isCheckingSerial, setIsCheckingSerial] = useState(false);

  // Dynamic options from settings
  const [deviceTypes, setDeviceTypes] = useState([]);
  const [brands, setBrands] = useState([]);
  const [capacities, setCapacities] = useState([]);
  const [accessories, setAccessories] = useState([]);
  const [conditions, setConditions] = useState([]);
  const [roles, setRoles] = useState([]);

  // Load options from settings
  useEffect(() => {
    const loadOptions = async () => {
      try {
        const [
          deviceTypesData,
          brandsData,
          capacitiesData,
          accessoriesData,
          conditionsData,
          rolesData
        ] = await Promise.all([
          getSettingsByCategory('Device Types'),
          getSettingsByCategory('Brands'),
          getSettingsByCategory('Capacities'),
          getSettingsByCategory('Accessories'),
          getSettingsByCategory('Device Conditions'),
          getSettingsByCategory('Device Roles')
        ]);
        
        setDeviceTypes(deviceTypesData);
        setBrands(brandsData);
        setCapacities(capacitiesData);
        setAccessories(accessoriesData);
        setConditions(conditionsData.length > 0 ? conditionsData : ['Good', 'Fair', 'Poor', 'Damaged']);
        setRoles(rolesData.length > 0 ? rolesData : ['Patient', 'Backup', 'Donor', 'Clone']);
      } catch (error) {
        console.error('Failed to load device options:', error);
      }
    };
    
    if (open) {
      loadOptions();
    }
  }, [open]);

  // Initialize device data when dialog opens or device prop changes
  useEffect(() => {
    if (open) {
      if (device) {
        // Editing existing device - populate with existing data
        setDeviceData({
          media_type: device.media_type || '',
          brand: device.brand || '',
          media_model: device.media_model || '',
          media_serial_number: device.media_serial_number || '',
          capacity: device.capacity || '',
          condition: device.condition || 'Good',
          role: device.role || 'Patient',
          accessories: device.accessories || ''
        });
      } else {
        // Adding new device - use default values
        setDeviceData({
          media_type: '',
          brand: '',
          media_model: '',
          media_serial_number: '',
          capacity: '',
          condition: 'Good',
          role: 'Patient',
          accessories: ''
        });
      }
      // Clear any previous warnings
      setDuplicateWarning(null);
    }
  }, [open, device]);

  // Automatically switch to server dialog when "Server" is selected
  useEffect(() => {
    if (deviceData.media_type === 'Server' && onSelectServer) {
      onSelectServer();
      onOpenChange(false); // Close current dialog immediately
    }
  }, [deviceData.media_type, onSelectServer, onOpenChange]);


  const checkSerialNumber = async (serialNumber) => {
    if (!serialNumber || serialNumber.trim().length < 3) {
      setDuplicateWarning(null);
      return;
    }

    setIsCheckingSerial(true);
    try {
      // Search for cases with devices that have this serial number
      const allCases = await Case.list();
      
      for (const caseItem of allCases) {
        let foundDevice = null;
        
        // Check devices array
        if (caseItem.devices && caseItem.devices.length > 0) {
          foundDevice = caseItem.devices.find(dev => 
            dev.media_serial_number && 
            dev.media_serial_number.toLowerCase().trim() === serialNumber.toLowerCase().trim()
          );
        }
        
        // Check primary device fields if not found in devices array
        if (!foundDevice && caseItem.media_serial_number && 
            caseItem.media_serial_number.toLowerCase().trim() === serialNumber.toLowerCase().trim()) {
          foundDevice = {
            media_type: caseItem.media_type,
            brand: 'N/A'
          };
        }
        
        if (foundDevice) {
          // Get customer information
          try {
            const customer = await Customer.get(caseItem.customer_id);
            setDuplicateWarning({
              caseId: caseItem.id,
              caseNumber: caseItem.case_number,
              createdDate: caseItem.created_date,
              deviceType: foundDevice.media_type,
              brand: foundDevice.brand,
              customerName: customer?.full_name || 'Unknown Customer',
              status: caseItem.status
            });
          } catch (error) {
            console.warn(`Could not fetch customer for case ${caseItem.case_number}:`, error);
            setDuplicateWarning({
              caseId: caseItem.id,
              caseNumber: caseItem.case_number,
              createdDate: caseItem.created_date,
              deviceType: foundDevice.media_type,
              brand: foundDevice.brand,
              customerName: 'Unknown Customer',
              status: caseItem.status
            });
          }
          return;
        }
      }
      
      setDuplicateWarning(null);
    } catch (error) {
      console.error('Error checking serial number:', error);
    } finally {
      setIsCheckingSerial(false);
    }
  };

  const handleSerialNumberChange = (value) => {
    setDeviceData({...deviceData, media_serial_number: value});
    
    // Debounce the serial number check
    clearTimeout(window.serialCheckTimeout);
    window.serialCheckTimeout = setTimeout(() => {
      checkSerialNumber(value);
    }, 500);
  };

  const handleViewCase = () => {
    if (duplicateWarning?.caseId) {
      window.open(createPageUrl(`CaseDetails?id=${duplicateWarning.caseId}`), '_blank');
    }
  };

  const handleSave = () => {
    if (!deviceData.media_type) {
      alert('Please select a device type');
      return;
    }
    
    if (!deviceData.media_serial_number || deviceData.media_serial_number.trim().length === 0) {
      alert('Serial number is mandatory');
      return;
    }
    
    if (duplicateWarning) {
      const proceed = window.confirm(
        `Warning: This device was previously registered on ${format(new Date(duplicateWarning.createdDate), 'dd MMM yyyy')} under case ${duplicateWarning.caseNumber} for customer ${duplicateWarning.customerName}.\n\nDo you want to proceed anyway?`
      );
      if (!proceed) return;
    }
    
    onSave(deviceData);
    onOpenChange(false);
  };

  const handleCancel = () => {
    onOpenChange(false);
    setDuplicateWarning(null);
  };

  const handleAccessoryChange = (value) => {
    const currentAccessories = deviceData.accessories ? deviceData.accessories.split(', ').filter(a => a.trim()) : [];
    
    // If the value is already selected, remove it (toggle behavior)
    if (currentAccessories.includes(value)) {
      const updatedAccessories = currentAccessories.filter(a => a !== value);
      setDeviceData({...deviceData, accessories: updatedAccessories.join(', ')});
    } else {
      // Add the new accessory
      const updatedAccessories = [...currentAccessories, value];
      setDeviceData({...deviceData, accessories: updatedAccessories.join(', ')});
    }
  };

  const removeAccessory = (accessoryToRemove) => {
    const currentAccessories = deviceData.accessories ? deviceData.accessories.split(', ').filter(a => a.trim()) : [];
    const updatedAccessories = currentAccessories.filter(a => a !== accessoryToRemove);
    setDeviceData({...deviceData, accessories: updatedAccessories.join(', ')});
  };

  const selectedAccessories = deviceData.accessories ? deviceData.accessories.split(', ').filter(a => a.trim()) : [];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{device ? 'Edit Device' : 'Add New Device'}</DialogTitle>
        </DialogHeader>
        
        <div className="grid grid-cols-2 gap-6 py-4">
          <div className="space-y-4">
            <div>
              <Label>Device Type <span className="text-red-500">*</span></Label>
              <SearchableSelect
                value={deviceData.media_type}
                onValueChange={(value) => setDeviceData({...deviceData, media_type: value})}
                placeholder="Select device type"
                options={deviceTypes}
              />
            </div>
            
            <div>
              <Label>Brand</Label>
              <SearchableSelect
                value={deviceData.brand}
                onValueChange={(value) => setDeviceData({...deviceData, brand: value})}
                placeholder="Select brand"
                options={brands}
              />
            </div>

            <div>
              <Label>Model</Label>
              <Input 
                value={deviceData.media_model}
                onChange={(e) => setDeviceData({...deviceData, media_model: e.target.value})}
                placeholder="Enter model"
              />
            </div>

            <div>
              <Label>Serial Number <span className="text-red-500">*</span></Label>
              <div className="space-y-2">
                <Input 
                  value={deviceData.media_serial_number}
                  onChange={(e) => handleSerialNumberChange(e.target.value)}
                  placeholder="Enter serial number"
                  className={duplicateWarning ? 'border-orange-500' : ''}
                />
                {isCheckingSerial && (
                  <p className="text-sm text-gray-500">Checking for duplicates...</p>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <Label>Capacity</Label>
              <SearchableSelect
                value={deviceData.capacity}
                onValueChange={(value) => setDeviceData({...deviceData, capacity: value})}
                placeholder="e.g., 1TB, 500GB"
                options={capacities}
              />
            </div>

            <div>
              <Label>Role <span className="text-red-500">*</span></Label>
              <Select value={deviceData.role} onValueChange={(value) => setDeviceData({...deviceData, role: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select role" />
                </SelectTrigger>
                <SelectContent>
                  {roles.map(role => (
                    <SelectItem key={role} value={role}>{role}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Condition <span className="text-red-500">*</span></Label>
              <Select value={deviceData.condition} onValueChange={(value) => setDeviceData({...deviceData, condition: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select condition" />
                </SelectTrigger>
                <SelectContent>
                  {conditions.map(condition => (
                    <SelectItem key={condition} value={condition}>{condition}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Accessories</Label>
              <SearchableSelect
                value=""
                onValueChange={handleAccessoryChange}
                placeholder="Select accessories"
                options={accessories}
              />
              
              {selectedAccessories.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-1">
                  {selectedAccessories.map((accessory, index) => (
                    <span 
                      key={index}
                      className="inline-flex items-center px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded-full"
                    >
                      {accessory}
                      <button
                        type="button"
                        onClick={() => removeAccessory(accessory)}
                        className="ml-1 text-blue-600 hover:text-blue-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                        aria-label={`Remove ${accessory}`}
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>
              )}
              
              <div className="mt-2">
                <Input
                  placeholder="Or type custom accessories (comma separated)"
                  value={deviceData.accessories}
                  onChange={(e) => setDeviceData({...deviceData, accessories: e.target.value})}
                  className="text-sm"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Example: Adapter, USB Cable, Carrying Bag
                </p>
              </div>
            </div>
          </div>
        </div>

        {duplicateWarning && (
          <Alert className="border-orange-500 bg-orange-50">
            <AlertTriangle className="h-4 w-4 text-orange-600" />
            <AlertDescription className="text-orange-800">
              <div className="space-y-1">
                <div>
                  <strong>Warning:</strong> This device was registered.
                </div>
                <div className="text-sm mt-2 space-y-1">
                  <div><strong>Registered Date:</strong> {format(new Date(duplicateWarning.createdDate), 'dd MMM yyyy')}</div>
                  <div>
                    <strong>Case ID:</strong>{' '}
                    <button 
                      onClick={handleViewCase}
                      className="font-bold text-blue-600 hover:text-blue-800 underline inline-flex items-center gap-1"
                    >
                      {duplicateWarning.caseNumber}
                      <ExternalLink className="h-3 w-3" />
                    </button>
                  </div>
                  <div><strong>Customer Name:</strong> {duplicateWarning.customerName}</div>
                  <div><strong>Status:</strong> {duplicateWarning.status}</div>
                  {duplicateWarning.deviceType && (
                    <div><strong>Device:</strong> {duplicateWarning.deviceType}{duplicateWarning.brand !== 'N/A' && ` - ${duplicateWarning.brand}`}</div>
                  )}
                </div>
              </div>
            </AlertDescription>
          </Alert>
        )}

        <div className="flex justify-end space-x-2 pt-4">
          <Button variant="destructive" onClick={handleCancel}>
            <X className="w-4 h-4 mr-2" />
            Cancel
          </Button>
          <Button onClick={handleSave} className="bg-gray-800 hover:bg-gray-900">
            <Save className="w-4 h-4 mr-2" />
            {device ? 'Update Device' : 'Add Device'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
