import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';

const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value || 0);
};

const DetailRow = ({ label, value }) => (
    <div className="flex justify-between py-2 border-b border-gray-100">
        <span className="text-sm text-gray-500">{label}</span>
        <span className="text-sm font-medium text-gray-800">{value || 'N/A'}</span>
    </div>
);

export default function AssetDetailsDialog({ open, onOpenChange, asset }) {
    if (!asset) return null;

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-2xl">
                <DialogHeader>
                    <DialogTitle>{asset.asset_name}</DialogTitle>
                    <DialogDescription>
                        Asset Code: {asset.asset_code} | Category: {asset.category}
                    </DialogDescription>
                </DialogHeader>
                <div className="py-4 max-h-[70vh] overflow-y-auto pr-2">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-2">
                        <div>
                            <h4 className="font-semibold mb-2 mt-4 text-gray-700">Financial Information</h4>
                            <DetailRow label="Purchase Cost" value={formatCurrency(asset.purchase_cost)} />
                            <DetailRow label="Current Value" value={formatCurrency(asset.current_value)} />
                            <DetailRow label="Purchase Date" value={asset.purchase_date ? format(new Date(asset.purchase_date), 'PPP') : 'N/A'} />
                            <DetailRow label="Depreciation Method" value={asset.depreciation_method} />
                            <DetailRow label="Useful Life" value={`${asset.useful_life_years || 0} years`} />
                        </div>
                        <div>
                            <h4 className="font-semibold mb-2 mt-4 text-gray-700">Asset Status</h4>
                            <DetailRow label="Status" value={<Badge className={asset.status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>{asset.status}</Badge>} />
                            <DetailRow label="Condition" value={asset.condition} />
                            <DetailRow label="Location" value={asset.location} />
                            <DetailRow label="Assigned To" value={asset.assigned_to} />
                            <DetailRow label="Warranty End" value={asset.warranty_end ? format(new Date(asset.warranty_end), 'PPP') : 'N/A'} />
                        </div>
                        <div className="col-span-2">
                             <h4 className="font-semibold mb-2 mt-4 text-gray-700">Specifications</h4>
                             <DetailRow label="Asset Type" value={asset.asset_type} />
                             <DetailRow label="Brand" value={asset.brand} />
                             <DetailRow label="Model" value={asset.model} />
                             <DetailRow label="Serial Number" value={asset.serial_number} />
                        </div>
                        {asset.notes && (
                             <div className="col-span-2 mt-4">
                                <h4 className="font-semibold mb-2 text-gray-700">Notes</h4>
                                <p className="text-sm p-3 bg-gray-50 rounded-md border">{asset.notes}</p>
                            </div>
                        )}
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
}