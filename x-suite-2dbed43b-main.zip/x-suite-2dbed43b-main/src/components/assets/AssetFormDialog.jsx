import React, { useState, useEffect } from 'react';
import { Asset } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const assetTypes = ["Hardware", "Software", "Subscription", "Tool", "Equipment", "Furniture", "Vehicle"];
const categories = ["Data Recovery Tool", "Workstation", "Server", "Storage Device", "Adapter/Cable", "Clean Room Equipment", "Testing Equipment", "Recovery Software", "OS License", "Cloud Service", "Office Furniture", "Vehicle", "Other"];
const statuses = ["Active", "Inactive", "Maintenance", "Retired", "Sold", "Lost/Stolen"];
const conditions = ["Excellent", "Good", "Fair", "Poor", "Damaged"];
const depreciationMethods = ["Straight Line", "No Depreciation"];

export default function AssetFormDialog({ open, onOpenChange, asset, onSave }) {
    const [formData, setFormData] = useState(null);

    useEffect(() => {
        const generateAssetCode = () => `ASSET-${Date.now().toString().slice(-6)}`;

        if (open) {
            setFormData(asset ? { ...asset } : {
                asset_name: '',
                asset_code: generateAssetCode(),
                asset_type: 'Hardware',
                category: 'Workstation',
                purchase_date: new Date().toISOString().split('T')[0],
                purchase_cost: '',
                depreciation_method: 'Straight Line',
                useful_life_years: 5,
                status: 'Active',
                condition: 'Good',
                location: '',
                assigned_to: '',
                serial_number: '',
                warranty_end: '',
                notes: '',
            });
        } else {
            setFormData(null);
        }
    }, [open, asset]);

    const handleChange = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const handleSave = async () => {
        if (!formData.asset_name || !formData.asset_type || !formData.category) {
            alert('Asset Name, Type, and Category are required.');
            return;
        }

        const dataToSave = { ...formData };
        dataToSave.purchase_cost = parseFloat(dataToSave.purchase_cost) || 0;
        dataToSave.useful_life_years = parseInt(dataToSave.useful_life_years, 10) || 0;
        if (!dataToSave.purchase_date) delete dataToSave.purchase_date;
        if (!dataToSave.warranty_end) delete dataToSave.warranty_end;

        try {
            if (asset?.id) {
                await Asset.update(asset.id, dataToSave);
            } else {
                await Asset.create(dataToSave);
            }
            onSave();
            onOpenChange(false);
        } catch (error) {
            console.error("Failed to save asset:", error);
            alert("Failed to save asset.");
        }
    };

    if (!formData) return null;

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-4xl">
                <DialogHeader>
                    <DialogTitle>{asset ? 'Edit Asset' : 'Add New Asset'}</DialogTitle>
                    <DialogDescription>
                        {asset ? `Editing asset: ${formData.asset_name}` : 'Enter the details of the new company asset.'}
                    </DialogDescription>
                </DialogHeader>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 py-4 max-h-[70vh] overflow-y-auto pr-2">
                    {/* Column 1 */}
                    <div className="space-y-4">
                        <div>
                            <Label>Asset Name <span className="text-red-500">*</span></Label>
                            <Input value={formData.asset_name} onChange={(e) => handleChange('asset_name', e.target.value)} placeholder="e.g. Dell XPS 15 Laptop" />
                        </div>
                        <div>
                            <Label>Asset Code</Label>
                            <Input value={formData.asset_code} readOnly disabled />
                        </div>
                        <div>
                            <Label>Asset Type <span className="text-red-500">*</span></Label>
                            <Select value={formData.asset_type} onValueChange={(value) => handleChange('asset_type', value)}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>{assetTypes.map(type => <SelectItem key={type} value={type}>{type}</SelectItem>)}</SelectContent>
                            </Select>
                        </div>
                        <div>
                            <Label>Category <span className="text-red-500">*</span></Label>
                            <Select value={formData.category} onValueChange={(value) => handleChange('category', value)}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>{categories.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                            </Select>
                        </div>
                         <div>
                            <Label>Serial Number / License Key</Label>
                            <Input value={formData.serial_number} onChange={(e) => handleChange('serial_number', e.target.value)} />
                        </div>
                    </div>
                    {/* Column 2 */}
                    <div className="space-y-4">
                        <div>
                            <Label>Purchase Date</Label>
                            <Input type="date" value={formData.purchase_date} onChange={(e) => handleChange('purchase_date', e.target.value)} />
                        </div>
                        <div>
                            <Label>Purchase Cost ($)</Label>
                            <Input type="number" value={formData.purchase_cost} onChange={(e) => handleChange('purchase_cost', e.target.value)} placeholder="e.g. 1500.00" />
                        </div>
                        <div>
                            <Label>Depreciation Method</Label>
                            <Select value={formData.depreciation_method} onValueChange={(value) => handleChange('depreciation_method', value)}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>{depreciationMethods.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
                            </Select>
                        </div>
                         <div>
                            <Label>Useful Life (Years)</Label>
                            <Input type="number" value={formData.useful_life_years} onChange={(e) => handleChange('useful_life_years', e.target.value)} placeholder="e.g. 5" disabled={formData.depreciation_method === 'No Depreciation'} />
                        </div>
                        <div>
                            <Label>Warranty End Date</Label>
                            <Input type="date" value={formData.warranty_end} onChange={(e) => handleChange('warranty_end', e.target.value)} />
                        </div>
                    </div>
                    {/* Column 3 */}
                    <div className="space-y-4">
                        <div>
                            <Label>Status</Label>
                             <Select value={formData.status} onValueChange={(value) => handleChange('status', value)}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>{statuses.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                            </Select>
                        </div>
                        <div>
                            <Label>Condition</Label>
                            <Select value={formData.condition} onValueChange={(value) => handleChange('condition', value)}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>{conditions.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                            </Select>
                        </div>
                        <div>
                            <Label>Location</Label>
                            <Input value={formData.location} onChange={(e) => handleChange('location', e.target.value)} placeholder="e.g. Main Office, Room 101" />
                        </div>
                        <div>
                            <Label>Assigned To (User Email)</Label>
                            <Input value={formData.assigned_to} onChange={(e) => handleChange('assigned_to', e.target.value)} placeholder="e.g. tech@company.com" />
                        </div>
                        <div className="md:col-span-1">
                            <Label>Notes</Label>
                            <Textarea value={formData.notes} onChange={(e) => handleChange('notes', e.target.value)} placeholder="Any specific details..." className="h-24"/>
                        </div>
                    </div>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
                    <Button onClick={handleSave}>Save Asset</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}