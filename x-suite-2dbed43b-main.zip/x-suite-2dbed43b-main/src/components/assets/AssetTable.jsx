import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Edit, Trash2, Eye, Printer } from 'lucide-react';
import { format } from 'date-fns';

const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value || 0);
};

const getStatusColor = (status) => {
    switch (status) {
        case 'Active': return 'bg-green-100 text-green-800';
        case 'Maintenance': return 'bg-yellow-100 text-yellow-800';
        case 'Retired':
        case 'Sold':
        case 'Lost/Stolen':
             return 'bg-red-100 text-red-800';
        default: return 'bg-gray-100 text-gray-800';
    }
};

export default function AssetTable({ assets, onEdit, onDelete, onView, onPrint, isLoading }) {
    if (isLoading) {
        return <div className="text-center py-12">Loading assets...</div>;
    }

    if (!assets || assets.length === 0) {
        return <div className="text-center py-12">No assets found.</div>;
    }

    return (
        <div className="overflow-x-auto">
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Asset Name</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Purchase Cost</TableHead>
                        <TableHead>Current Value</TableHead>
                        <TableHead>Location</TableHead>
                        <TableHead>Assigned To</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {assets.map(asset => (
                        <TableRow key={asset.id} className="hover:bg-gray-50">
                            <TableCell className="font-medium">
                                <div>{asset.asset_name}</div>
                                <div className="text-xs text-gray-500">{asset.asset_code || 'N/A'}</div>
                            </TableCell>
                            <TableCell>{asset.asset_type}</TableCell>
                            <TableCell>
                                <Badge className={getStatusColor(asset.status)}>{asset.status}</Badge>
                            </TableCell>
                            <TableCell>{formatCurrency(asset.purchase_cost)}</TableCell>
                            <TableCell className="font-semibold">{formatCurrency(asset.current_value)}</TableCell>
                            <TableCell>{asset.location || 'N/A'}</TableCell>
                            <TableCell>{asset.assigned_to || 'Unassigned'}</TableCell>
                            <TableCell className="text-right">
                                <div className="flex items-center justify-end space-x-1">
                                    <Button variant="ghost" size="icon" onClick={() => onView(asset)} className="h-8 w-8 hover:bg-gray-200">
                                        <Eye className="w-4 h-4 text-gray-600" />
                                    </Button>
                                    <Button variant="ghost" size="icon" onClick={() => onEdit(asset)} className="h-8 w-8 hover:bg-blue-100">
                                        <Edit className="w-4 h-4 text-blue-600" />
                                    </Button>
                                    <Button variant="ghost" size="icon" onClick={() => onPrint(asset)} className="h-8 w-8 hover:bg-yellow-100">
                                        <Printer className="w-4 h-4 text-yellow-700" />
                                    </Button>
                                    <Button variant="ghost" size="icon" onClick={() => onDelete(asset.id)} className="h-8 w-8 hover:bg-red-100">
                                        <Trash2 className="w-4 h-4 text-red-600" />
                                    </Button>
                                </div>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </div>
    );
}