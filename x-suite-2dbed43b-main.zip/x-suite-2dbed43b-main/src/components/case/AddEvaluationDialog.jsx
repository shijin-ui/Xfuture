
import React, { useState, useEffect } from 'react';
import { MediaEvaluation } from '@/api/entities';
import { User } from '@/api/entities';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Wrench, Database } from 'lucide-react';
import { format } from 'date-fns';

const PHYSICAL_FINDINGS = [
    "Read/Write Head Failure",
    "Platter Damage / Scratches",
    "Spindle Motor Seizure",
    "PCB / Electronics Failure",
    "Firmware Corruption",
    "Drive Not Detected",
    "Clicking / Beeping Noises"
];

const LOGICAL_FINDINGS = [
    "File System Corruption (RAW)",
    "Accidentally Deleted Data",
    "Formatted Partition",
    "Virus or Malware Damage",
    "Lost Partition Table",
    "Operating System Failure",
    "File-Specific Corruption"
];

const FEASIBILITY_OPTIONS = ["High (90-100%)", "Good (70-89%)", "Fair (50-69%)", "Low (<50%)", "Not Possible"];

// Initial form data structure with default values
const initialFormData = {
    case_id: '',
    device_serial_number: '',
    technician_name: '',
    evaluation_date: new Date(), // Initialize as Date object
    physical_findings: [],
    physical_findings_notes: '',
    logical_findings: [],
    logical_findings_notes: '',
    recovery_plan: 'Attempt to clone the drive using specialized hardware. If successful, perform a logical scan on the clone to recover data. If cloning fails, proceed with head stack assembly replacement in a cleanroom environment.',
    required_parts: 'Compatible donor drive may be required.',
    recovery_feasibility: 'Good (70-89%)',
    estimated_completion_time: '3-5 Business Days',
    risk_assessment: 'Standard risks associated with invasive recovery apply. There is a possibility of partial data recovery due to media degradation.',
    recommendation: 'Proceed with proposed recovery plan.',
};

export default function AddEvaluationDialog({ open, onOpenChange, caseData, onEvaluationAdded }) {
    const [currentUser, setCurrentUser] = useState(null);
    const [formData, setFormData] = useState(initialFormData); // Initialize with default data

    // Fetch current user on component mount
    useEffect(() => {
        const getUser = async () => {
            try {
                const user = await User.me();
                setCurrentUser(user);
            } catch (e) {
                console.error("Failed to fetch current user:", e);
            }
        };
        getUser();
    }, []);

    // Reset form data when dialog opens, caseData changes, or currentUser is set
    useEffect(() => {
        if (open && caseData && currentUser) {
            const defaultDevice = caseData.devices && caseData.devices.length > 0
                ? (caseData.devices.find(d => d.device_status !== 'Collected') || caseData.devices[0]) // Prefer non-collected, otherwise pick first device
                : null;

            setFormData({
                ...initialFormData, // Start with default values
                case_id: caseData.id,
                device_serial_number: defaultDevice?.media_serial_number || '',
                technician_name: currentUser?.full_name || '', // Use current user's full name
                evaluation_date: new Date(), // Set current date/time
            });
        }
    }, [open, caseData, currentUser]); // Dependencies

    const handleCheckboxChange = (field, value, checked) => {
        setFormData(prev => {
            const currentValues = prev[field] || [];
            if (checked) {
                return { ...prev, [field]: [...currentValues, value] };
            } else {
                return { ...prev, [field]: currentValues.filter(item => item !== value) };
            }
        });
    };

    const handleDateChange = (e) => {
        const dateString = e.target.value;
        if (dateString) {
            setFormData(prev => ({
                ...prev,
                evaluation_date: new Date(dateString) // Convert input string to Date object
            }));
        } else {
             setFormData(prev => ({
                ...prev,
                evaluation_date: null // Allow clearing if input is empty
            }));
        }
    };

    const handleSubmit = async () => { // Renamed from handleSave
        if (!formData.device_serial_number) {
            alert("Please select a device to evaluate.");
            return;
        }

        const payload = {
            ...formData,
            // Convert evaluation_date (which is a Date object) to ISO string for submission
            evaluation_date: formData.evaluation_date instanceof Date ? formData.evaluation_date.toISOString() : null,
        };

        try {
            await MediaEvaluation.create(payload);
            onEvaluationAdded();
            onOpenChange(false);
        } catch (error) {
            console.error("Failed to create evaluation:", error);
            alert("Failed to create evaluation.");
        }
    };

    if (!caseData) return null; // Ensure caseData is available before rendering

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle>Create Media Evaluation Report</DialogTitle>
                    <DialogDescription>
                        Fill in the details of the diagnostic findings for Job ID: {caseData.case_number}
                    </DialogDescription>
                </DialogHeader>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-4">
                    {/* Left Column - Case Details */}
                    <div className="space-y-4">
                        <Card>
                            <CardHeader>
                                <CardTitle className="text-base">Case Details</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3 text-sm">
                                <div className="grid grid-cols-2 gap-2">
                                    <div>
                                        <Label>Technician</Label>
                                        <Input value={formData.technician_name} disabled className="h-8"/>
                                    </div>
                                    <div>
                                        <Label>Evaluation Date</Label>
                                        <Input
                                            type="datetime-local"
                                            // Format the Date object to "YYYY-MM-DDTHH:mm" for datetime-local input
                                            value={formData.evaluation_date ? format(formData.evaluation_date, "yyyy-MM-dd'T'HH:mm") : ''}
                                            onChange={handleDateChange}
                                            className="h-8"
                                        />
                                    </div>
                                </div>
                                <div>
                                    <Label>Device for Evaluation</Label>
                                    <Select value={formData.device_serial_number} onValueChange={value => setFormData({...formData, device_serial_number: value})}>
                                        <SelectTrigger className="h-8"><SelectValue placeholder="Select a device..."/></SelectTrigger>
                                        <SelectContent>
                                            {caseData.devices.map(d => (
                                                <SelectItem key={d.media_serial_number} value={d.media_serial_number}>
                                                    {d.media_type} - {d.media_serial_number}
                                                </SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Right Column - Physical & Logical Findings */}
                    <div className="space-y-6">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center text-base"><Wrench className="w-4 h-4 mr-2 text-red-500"/>Physical Findings</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                               <div className="grid grid-cols-2 gap-2">
                                    {PHYSICAL_FINDINGS.map(finding => (
                                        <div key={finding} className="flex items-center space-x-2">
                                            <Checkbox
                                                id={`phy-${finding.replace(/\s/g, '-')}`} // Ensure unique and valid ID
                                                onCheckedChange={(checked) => handleCheckboxChange('physical_findings', finding, checked)}
                                                checked={formData.physical_findings?.includes(finding)}
                                            />
                                            <Label htmlFor={`phy-${finding.replace(/\s/g, '-')}`} className="text-sm font-normal">{finding}</Label>
                                        </div>
                                    ))}
                                </div>
                                <Textarea placeholder="Notes on physical condition..." value={formData.physical_findings_notes} onChange={e => setFormData({...formData, physical_findings_notes: e.target.value})} />
                            </CardContent>
                        </Card>
                        <Card>
                             <CardHeader>
                                <CardTitle className="flex items-center text-base"><Database className="w-4 h-4 mr-2 text-blue-500"/>Logical Findings</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                                <div className="grid grid-cols-2 gap-2">
                                    {LOGICAL_FINDINGS.map(finding => (
                                        <div key={finding} className="flex items-center space-x-2">
                                            <Checkbox
                                                id={`log-${finding.replace(/\s/g, '-')}`} // Ensure unique and valid ID
                                                onCheckedChange={(checked) => handleCheckboxChange('logical_findings', finding, checked)}
                                                checked={formData.logical_findings?.includes(finding)}
                                            />
                                            <Label htmlFor={`log-${finding.replace(/\s/g, '-')}`} className="text-sm font-normal">{finding}</Label>
                                        </div>
                                    ))}
                                </div>
                                <Textarea placeholder="Notes on logical condition..." value={formData.logical_findings_notes} onChange={e => setFormData({...formData, logical_findings_notes: e.target.value})} />
                            </CardContent>
                        </Card>
                    </div>
                </div>

                {/* Additional fields below the two-column layout */}
                <div className="space-y-4 mt-6">
                    <div>
                        <Label>Recovery Plan</Label>
                        <Textarea placeholder="Describe the steps for recovery..." value={formData.recovery_plan} onChange={e => setFormData({...formData, recovery_plan: e.target.value})} />
                    </div>
                     <div>
                        <Label>Required Parts / Tools</Label>
                        <Input placeholder="e.g., Donor drive model XYZ, head comb tool" value={formData.required_parts} onChange={e => setFormData({...formData, required_parts: e.target.value})} />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <Label>Recovery Feasibility</Label>
                            <Select value={formData.recovery_feasibility} onValueChange={value => setFormData({...formData, recovery_feasibility: value})}>
                                <SelectTrigger><SelectValue/></SelectTrigger>
                                <SelectContent>
                                    {FEASIBILITY_OPTIONS.map(opt => <SelectItem key={opt} value={opt}>{opt}</SelectItem>)}
                                </SelectContent>
                            </Select>
                        </div>
                        <div>
                            <Label>Estimated Completion Time</Label>
                            <Input placeholder="e.g., 3-5 Business Days" value={formData.estimated_completion_time} onChange={e => setFormData({...formData, estimated_completion_time: e.target.value})} />
                        </div>
                    </div>
                     <div>
                        <Label>Risk Assessment</Label>
                        <Textarea placeholder="e.g., Due to platter damage, some recovered files may be corrupt." value={formData.risk_assessment} onChange={e => setFormData({...formData, risk_assessment: e.target.value})} />
                    </div>
                     <div>
                        <Label>Final Recommendation</Label>
                        <Textarea value={formData.recommendation} onChange={e => setFormData({...formData, recommendation: e.target.value})} />
                    </div>
                </div>

                <DialogFooter className="mt-6">
                    <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
                    <Button onClick={handleSubmit}>Save Evaluation</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}
