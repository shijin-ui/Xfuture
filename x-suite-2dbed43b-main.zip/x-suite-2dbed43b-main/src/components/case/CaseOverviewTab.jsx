
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { format } from 'date-fns';
import { 
    Edit, HardDrive, User, Server, UserIcon, Save, X, 
    Hash, FileText, Activity, AlertTriangle, Clock, UserPlus,
    Disc, Barcode, Database, AlertCircle, Info, Box,
    Building, Users, Mail, Phone, MapPin
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Case } from '@/api/entities';
import { Customer } from '@/api/entities';
import { User as B44User } from '@/api/entities';
import { JobHistory } from '@/api/entities';
import { getSettingsByCategory } from '../utils/settingsLoader';
import { Textarea } from '@/components/ui/textarea';
import MultiSelect from '../common/MultiSelect';
import SearchableSelect from '../SearchableSelect';
import CaseCommunicationCard from './CaseCommunicationCard';

const DetailRow = ({ label, children, multiline, valueClassName }) => {
    // For multiline, we stack them vertically
    if (multiline) {
        return (
            <div className="py-2">
                <div className="text-sm text-gray-500 mb-1">{label} :</div>
                <div className={`text-sm font-medium w-full ${valueClassName || 'text-gray-800'}`}>
                    {children}
                </div>
            </div>
        );
    }
    
    // For single line, we align label, colon, and value
    return (
        <div className="py-2 flex items-center">
            <span className="text-sm text-gray-500 w-32 shrink-0">{label}</span>
            <span className="text-sm text-gray-500 mr-2">:</span>
            <div className={`text-sm font-medium ${valueClassName || 'text-gray-800'}`}>
                {children}
            </div>
        </div>
    );
};

export default function CaseOverviewTab({ caseData, customer, onDataUpdate, quotes, invoices, evaluations }) {
    const [editModes, setEditModes] = useState({ case: false, device: false, client: false });
    const [editableData, setEditableData] = useState({});
    const [currentUser, setCurrentUser] = useState(null);

    const [dropdownOptions, setDropdownOptions] = useState({
        serviceTypes: [],
        caseStatuses: [],
        priorities: [],
        engineers: [],
        deviceTypes: [],
        capacities: [],
        customerGroups: [],
        accessories: [],
        serviceProblems: [],
    });

    useEffect(() => {
        const loadUser = async () => {
            try {
                const user = await B44User.me();
                setCurrentUser(user);
            } catch (error) {
                console.error('Failed to load current user:', error);
            }
        };
        loadUser();
    }, []);

    const fetchDropdownData = async (card) => {
        if (card === 'case') {
            const [statuses, priorities, services, users] = await Promise.all([
                getSettingsByCategory('Case Statuses'),
                getSettingsByCategory('Case Priorities'),
                getSettingsByCategory('Service Types'),
                B44User.list(),
            ]);
            const engineers = users.filter(u => u.access_role === 'Technician');
            setDropdownOptions(prev => ({
                ...prev,
                caseStatuses: statuses,
                priorities: priorities,
                serviceTypes: services,
                engineers: engineers.map(e => ({ value: e.email, label: e.full_name }))
            }));
        }
        if (card === 'device') {
             const [types, caps, accessoriesData, problems] = await Promise.all([
                getSettingsByCategory('Device Types'),
                getSettingsByCategory('Capacities'),
                getSettingsByCategory('Accessories'),
                getSettingsByCategory('Service Problems'),
            ]);
            setDropdownOptions(prev => ({
                ...prev,
                deviceTypes: types,
                capacities: caps,
                accessories: accessoriesData,
                serviceProblems: problems,
            }));
        }
        if (card === 'client') {
             const groups = await getSettingsByCategory('Customer Groups');
             setDropdownOptions(prev => ({ ...prev, customerGroups: groups }));
        }
    };
    
    const handleEditToggle = (card) => {
        const isEnteringEditMode = !editModes[card];
        setEditModes(prev => ({ ...prev, [card]: isEnteringEditMode }));

        if (isEnteringEditMode) {
            fetchDropdownData(card);
            if (card === 'case') setEditableData(caseData);
            if (card === 'device') {
                const device = (caseData.devices && caseData.devices.length > 0) ? caseData.devices[0] : {};
                const accessoriesArray = device.accessories 
                    ? device.accessories.split(',').map(s => s.trim()).filter(s => s !== '') 
                    : [];
                setEditableData({ ...caseData, ...device, accessories: accessoriesArray });
            }
            if (card === 'client') setEditableData(customer);
        }
    };

    const handleCancel = (card) => {
        setEditModes(prev => ({ ...prev, [card]: false }));
        setEditableData({});
    };

    const handleInputChange = (field, value) => {
        setEditableData(prev => ({ ...prev, [field]: value }));
    };

    const logActivity = async (action, description, oldValue = null, newValue = null) => {
        if (!currentUser || !caseData?.id) return;
        
        try {
            await JobHistory.create({
                case_id: caseData.id,
                action_type: action,
                description: description,
                old_value: oldValue,
                new_value: newValue,
                performed_by: currentUser.email,
                timestamp: new Date().toISOString()
            });
        } catch (error) {
                console.error('Failed to log activity:', error);
        }
    };

    const handleSave = async (card) => {
        const changes = [];
        
        try {
            if (card === 'case') {
                // Track individual field changes
                if (editableData.client_reference !== caseData.client_reference) {
                    changes.push(`Client Reference changed from "${caseData.client_reference || 'N/A'}" to "${editableData.client_reference || 'N/A'}"`);
                }
                if (editableData.service_type !== caseData.service_type) {
                    changes.push(`Service Type changed from "${caseData.service_type || 'N/A'}" to "${editableData.service_type || 'N/A'}"`);
                }
                if (editableData.status !== caseData.status) {
                    changes.push(`Status changed from "${caseData.status}" to "${editableData.status}"`);
                    // Log status change as separate entry
                    await logActivity(
                        "Status Changed",
                        `Case status updated from "${caseData.status}" to "${editableData.status}" via inline edit`,
                        caseData.status,
                        editableData.status
                    );
                }
                if (editableData.priority !== caseData.priority) {
                    changes.push(`Priority changed from "${caseData.priority || 'N/A'}" to "${editableData.priority || 'N/A'}"`);
                }
                if (editableData.assigned_engineer !== caseData.assigned_engineer) {
                    changes.push(`Assigned Engineer changed from "${caseData.assigned_engineer || 'N/A'}" to "${editableData.assigned_engineer || 'N/A'}"`);
                }

                await Case.update(caseData.id, {
                    client_reference: editableData.client_reference,
                    service_type: editableData.service_type,
                    status: editableData.status,
                    priority: editableData.priority,
                    assigned_engineer: editableData.assigned_engineer,
                });

                if (changes.length > 0) {
                    await logActivity(
                        "Case Updated",
                        `Case information updated: ${changes.join(', ')}`,
                        null,
                        null
                    );
                }

            } else if (card === 'device') {
                const primaryDevice = caseData.devices?.[0] || {};
                const deviceChanges = [];

                if (editableData.media_type !== primaryDevice.media_type) {
                    deviceChanges.push(`Media Type changed from "${primaryDevice.media_type || 'N/A'}" to "${editableData.media_type || 'N/A'}"`);
                }
                if (editableData.media_model !== primaryDevice.media_model) {
                    deviceChanges.push(`Media Model changed from "${primaryDevice.media_model || 'N/A'}" to "${editableData.media_model || 'N/A'}"`);
                }
                if (editableData.media_serial_number !== primaryDevice.media_serial_number) {
                    deviceChanges.push(`Serial Number changed from "${primaryDevice.media_serial_number || 'N/A'}" to "${editableData.media_serial_number || 'N/A'}"`);
                }
                if (editableData.capacity !== primaryDevice.capacity) {
                    deviceChanges.push(`Capacity changed from "${primaryDevice.capacity || 'N/A'}" to "${editableData.capacity || 'N/A'}"`);
                }
                if (editableData.device_problem !== caseData.device_problem) {
                    deviceChanges.push(`Device Problem changed from "${caseData.device_problem || 'N/A'}" to "${editableData.device_problem || 'N/A'}"`);
                }
                if (editableData.important_data !== caseData.important_data) {
                    deviceChanges.push(`Important Data updated`);
                }
                
                // Compare accessories arrays
                const oldAccessories = primaryDevice.accessories ? primaryDevice.accessories.split(',').map(s => s.trim()).filter(s => s !== '') : [];
                const newAccessories = editableData.accessories || [];
                if (JSON.stringify(oldAccessories.sort()) !== JSON.stringify(newAccessories.sort())) {
                    deviceChanges.push(`Accessories changed from "${oldAccessories.join(', ') || 'None'}" to "${newAccessories.join(', ') || 'None'}"`);
                }

                const updatedDevices = [{
                    ...primaryDevice,
                    media_type: editableData.media_type,
                    media_model: editableData.media_model,
                    media_serial_number: editableData.media_serial_number,
                    capacity: editableData.capacity,
                    accessories: editableData.accessories ? editableData.accessories.join(', ') : '',
                }, ...(caseData.devices?.slice(1) || [])];

                await Case.update(caseData.id, {
                    devices: updatedDevices,
                    device_problem: editableData.device_problem,
                    important_data: editableData.important_data,
                    media_type: editableData.media_type,
                    media_model: editableData.media_model,
                    media_serial_number: editableData.media_serial_number,
                    media_capacity: editableData.capacity,
                });

                if (deviceChanges.length > 0) {
                    await logActivity(
                        "Device Updated",
                        `Device information updated: ${deviceChanges.join(', ')}`,
                        null,
                        null
                    );
                }

            } else if (card === 'client') {
                const clientChanges = [];

                if (editableData.full_name !== customer.full_name) {
                    clientChanges.push(`Customer Name changed from "${customer.full_name}" to "${editableData.full_name}"`);
                }
                if (editableData.company_name !== customer.company_name) {
                    clientChanges.push(`Company changed from "${customer.company_name || 'N/A'}" to "${editableData.company_name || 'N/A'}"`);
                }
                if (editableData.customer_group !== customer.customer_group) {
                    clientChanges.push(`Customer Group changed from "${customer.customer_group || 'N/A'}" to "${editableData.customer_group || 'N/A'}"`);
                }
                if (editableData.email !== customer.email) {
                    clientChanges.push(`Email changed from "${customer.email}" to "${editableData.email}"`);
                }
                if (editableData.phone_number !== customer.phone_number) {
                    clientChanges.push(`Phone Number changed from "${customer.phone_number || 'N/A'}" to "${editableData.phone_number || 'N/A'}"`);
                }
                if (editableData.city !== customer.city) {
                    clientChanges.push(`Location changed from "${customer.city || 'N/A'}" to "${editableData.city || 'N/A'}"`);
                }

                await Customer.update(customer.id, {
                    full_name: editableData.full_name,
                    company_name: editableData.company_name,
                    customer_group: editableData.customer_group,
                    email: editableData.email,
                    phone_number: editableData.phone_number,
                    city: editableData.city,
                });

                if (clientChanges.length > 0) {
                    await logActivity(
                        "Client Updated",
                        `Client information updated: ${clientChanges.join(', ')}`,
                        null,
                        null
                    );
                }
            }
            
            await onDataUpdate();
            handleCancel(card);
        } catch (error) {
            console.error(`Failed to save ${card}:`, error);
        }
    };

    const primaryDevice = caseData?.devices?.[0];

    return (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            <Card className="shadow-sm border-0 bg-blue-50/20">
                <CardHeader className="flex flex-row items-center justify-between pb-0 pt-4 px-4">
                    <CardTitle className="text-base font-semibold text-blue-800 flex items-center">
                        <User className="w-4 h-4 mr-2"/>Case Info
                    </CardTitle>
                    {editModes.case ? (
                        <div className="flex items-center space-x-1">
                           <Button variant="ghost" size="icon" onClick={() => handleSave('case')}><Save className="w-4 h-4 text-green-600"/></Button>
                           <Button variant="ghost" size="icon" onClick={() => handleCancel('case')}><X className="w-4 h-4 text-red-600"/></Button>
                        </div>
                    ) : (
                        <Button variant="ghost" size="icon" onClick={() => handleEditToggle('case')}><Edit className="w-4 h-4 text-blue-600"/></Button>
                    )}
                </CardHeader>
                <CardContent className="px-4 pb-4">
                    <DetailRow label="Job ID">{caseData.case_number}</DetailRow>
                    <DetailRow label="Client Reference">
                        {editModes.case ? (
                            <Input value={editableData.client_reference || ''} onChange={(e) => handleInputChange('client_reference', e.target.value)} className="h-7 text-xs" />
                        ) : (caseData.client_reference || '--')}
                    </DetailRow>
                    <DetailRow label="Service">
                        {editModes.case ? (
                            <SearchableSelect value={editableData.service_type} onValueChange={(val) => handleInputChange('service_type', val)} options={dropdownOptions.serviceTypes.map(s => ({label: s, value: s}))} placeholder="Select Service..." />
                        ) : (caseData.service_type || 'N/A')}
                    </DetailRow>
                    <DetailRow label="Status">
                        {editModes.case ? (
                           <SearchableSelect value={editableData.status} onValueChange={(val) => handleInputChange('status', val)} options={dropdownOptions.caseStatuses.map(s => ({label: s, value: s}))} placeholder="Select Status..." />
                        ) : ( <Badge variant="outline" className="font-medium">{caseData.status || 'N/A'}</Badge> )}
                    </DetailRow>
                    <DetailRow label="Priority">
                        {editModes.case ? (
                            <SearchableSelect value={editableData.priority} onValueChange={(val) => handleInputChange('priority', val)} options={dropdownOptions.priorities.map(p => ({label: p, value: p}))} placeholder="Select Priority..."/>
                        ) : ( <Badge variant="outline" className="font-medium">{caseData.priority || 'N/A'}</Badge> )}
                    </DetailRow>
                    <DetailRow label="Assigned Engineer">
                         {editModes.case ? (
                            <SearchableSelect value={editableData.assigned_engineer} onValueChange={(val) => handleInputChange('assigned_engineer', val)} options={dropdownOptions.engineers} placeholder="Assign Engineer..."/>
                        ) : (caseData.assigned_engineer || 'N/A')}
                    </DetailRow>
                    <DetailRow label="Created By">{caseData.created_by?.split('@')[0]}</DetailRow>
                    <DetailRow label="Created At">{format(new Date(caseData.created_date), 'dd-MM-yyyy HH:mm')}</DetailRow>
                </CardContent>
            </Card>

            <Card className="shadow-sm border-0 bg-green-50/20">
                <CardHeader className="flex flex-row items-center justify-between pb-0 pt-4 px-4">
                    <CardTitle className="text-base font-semibold text-green-800 flex items-center">
                        <HardDrive className="w-4 h-4 mr-2"/>Device Info
                    </CardTitle>
                    {editModes.device ? (
                        <div className="flex items-center space-x-1">
                           <Button variant="ghost" size="icon" onClick={() => handleSave('device')}><Save className="w-4 h-4 text-green-600"/></Button>
                           <Button variant="ghost" size="icon" onClick={() => handleCancel('device')}><X className="w-4 h-4 text-red-600"/></Button>
                        </div>
                    ) : (
                        <Button variant="ghost" size="icon" onClick={() => handleEditToggle('device')}><Edit className="w-4 h-4 text-green-600"/></Button>
                    )}
                </CardHeader>
                <CardContent className="px-4 pb-4">
                    <DetailRow label="Media Type">
                        {editModes.device ? (
                            <SearchableSelect value={editableData.media_type} onValueChange={(val) => handleInputChange('media_type', val)} options={dropdownOptions.deviceTypes.map(t => ({label: t, value: t}))} placeholder="Select Type..."/>
                        ) : (primaryDevice?.media_type || 'N/A')}
                    </DetailRow>
                    <DetailRow label="Media Model">
                         {editModes.device ? (
                            <Input value={editableData.media_model || ''} onChange={(e) => handleInputChange('media_model', e.target.value)} className="h-7 text-xs" />
                        ) : (primaryDevice?.media_model || 'N/A')}
                    </DetailRow>
                    <DetailRow label="Serial Number">
                        {editModes.device ? (
                            <Input value={editableData.media_serial_number || ''} onChange={(e) => handleInputChange('media_serial_number', e.target.value)} className="h-7 text-xs" />
                        ) : (primaryDevice?.media_serial_number || 'N/A')}
                    </DetailRow>
                    <DetailRow label="Capacity">
                        {editModes.device ? (
                            <SearchableSelect value={editableData.capacity} onValueChange={(val) => handleInputChange('capacity', val)} options={dropdownOptions.capacities.map(c => ({label: c, value: c}))} placeholder="Select Capacity..."/>
                        ) : (primaryDevice?.capacity || 'N/A')}
                    </DetailRow>
                    <DetailRow label="Device Problem" valueClassName="text-red-600">
                         {editModes.device ? (
                            <SearchableSelect value={editableData.device_problem} onValueChange={(val) => handleInputChange('device_problem', val)} options={dropdownOptions.serviceProblems.map(p => ({label: p, value: p}))} placeholder="Select Problem..."/>
                        ) : (caseData.device_problem || 'N/A')}
                    </DetailRow>
                    <DetailRow label="Important Data" multiline>
                        {editModes.device ? (
                            <Textarea value={editableData.important_data || ''} onChange={(e) => handleInputChange('important_data', e.target.value)} className="h-16 text-xs" />
                        ) : (caseData.important_data || 'N/A')}
                    </DetailRow>
                    <DetailRow label="Accessories" multiline>
                        {editModes.device ? (
                             <MultiSelect options={dropdownOptions.accessories} selected={editableData.accessories || []} onChange={(val) => handleInputChange('accessories', val)} />
                        ) : (
                            <div className="flex flex-wrap gap-1">
                                {primaryDevice?.accessories?.split(',').map(item => item.trim() && <Badge key={item} variant="secondary" className="text-xs">{item}</Badge>)}
                            </div>
                        )}
                    </DetailRow>
                </CardContent>
            </Card>

            <Card className="shadow-sm border-0 bg-purple-50/20">
                <CardHeader className="flex flex-row items-center justify-between pb-0 pt-4 px-4">
                    <CardTitle className="text-base font-semibold text-purple-800 flex items-center">
                        <UserIcon className="w-4 h-4 mr-2"/>Client Info
                    </CardTitle>
                    {editModes.client ? (
                        <div className="flex items-center space-x-1">
                           <Button variant="ghost" size="icon" onClick={() => handleSave('client')}><Save className="w-4 h-4 text-green-600"/></Button>
                           <Button variant="ghost" size="icon" onClick={() => handleCancel('client')}><X className="w-4 h-4 text-red-600"/></Button>
                        </div>
                    ) : (
                        <Button variant="ghost" size="icon" onClick={() => handleEditToggle('client')}><Edit className="w-4 h-4 text-purple-600"/></Button>
                    )}
                </CardHeader>
                <CardContent className="px-4 pb-4">
                     <DetailRow label="Customer Name">
                        {editModes.client ? (
                            <Input value={editableData.full_name || ''} onChange={(e) => handleInputChange('full_name', e.target.value)} className="h-7 text-xs" />
                        ) : (customer?.full_name || 'N/A')}
                    </DetailRow>
                     <DetailRow label="Company">
                        {editModes.client ? (
                            <Input value={editableData.company_name || ''} onChange={(e) => handleInputChange('company_name', e.target.value)} className="h-7 text-xs" />
                        ) : (customer?.company_name || 'N/A')}
                    </DetailRow>
                    <DetailRow label="Customer Group">
                         {editModes.client ? (
                            <SearchableSelect value={editableData.customer_group} onValueChange={(val) => handleInputChange('customer_group', val)} options={dropdownOptions.customerGroups.map(g => ({label: g, value: g}))} placeholder="Select Group..."/>
                        ) : (customer?.customer_group || 'N/A')}
                    </DetailRow>
                    <DetailRow label="Email">
                        {editModes.client ? (
                            <Input value={editableData.email || ''} onChange={(e) => handleInputChange('email', e.target.value)} className="h-7 text-xs" />
                        ) : (customer?.email || 'N/A')}
                    </DetailRow>
                    <DetailRow label="Mobile Number">
                         {editModes.client ? (
                            <Input value={editableData.phone_number || ''} onChange={(e) => handleInputChange('phone_number', e.target.value)} className="h-7 text-xs" />
                        ) : (customer?.phone_number || 'N/A')}
                    </DetailRow>
                     <DetailRow label="Location">
                        {editModes.client ? (
                            <Input value={editableData.city || ''} onChange={(e) => handleInputChange('city', e.target.value)} className="h-7 text-xs" />
                        ) : (customer?.city || 'N/A')}
                    </DetailRow>
                </CardContent>
            </Card>
            
            <CaseCommunicationCard
                caseData={caseData}
                customer={customer}
                quotes={quotes}
                invoices={invoices}
                evaluations={evaluations}
            />
        </div>
    );
}
