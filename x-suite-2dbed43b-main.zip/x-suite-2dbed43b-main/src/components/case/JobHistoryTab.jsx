import React, { useState, useEffect } from 'react';
import { JobHistory } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { History, Clock, User, Edit, Plus, FileText, DollarSign, Eye, Printer, AlertTriangle } from 'lucide-react';
import { format } from 'date-fns';

export default function JobHistoryTab({ caseId }) {
  const [history, setHistory] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchHistory = async () => {
    setIsLoading(true);
    try {
      const data = await JobHistory.filter({ case_id: caseId }, '-timestamp');
      setHistory(data);
    } catch (error) {
      console.error("Failed to fetch job history:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (caseId) {
      fetchHistory();
    }
  }, [caseId]);

  const getActionIcon = (actionType) => {
    switch (actionType) {
      case 'Case Created': return Plus;
      case 'Case Updated': return Edit;
      case 'Status Changed': return AlertTriangle;
      case 'Device Added': return Plus;
      case 'Device Updated': return Edit;
      case 'Client Updated': return User;
      case 'Evaluation Added': return FileText;
      case 'File Uploaded': return FileText;
      case 'Quote Generated': return FileText;
      case 'Invoice Created': return DollarSign;
      case 'Payment Received': return DollarSign;
      case 'Device Collected': return Eye;
      case 'Form Printed': return Printer;
      default: return Clock;
    }
  };

  const getActionColor = (actionType) => {
    switch (actionType) {
      case 'Case Created':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Case Updated':
      case 'Device Updated':
      case 'Client Updated':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Status Changed':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'Device Added':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'Evaluation Added':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'File Uploaded':
        return 'bg-indigo-100 text-indigo-800 border-indigo-200';
      case 'Quote Generated':
        return 'bg-teal-100 text-teal-800 border-teal-200';
      case 'Invoice Created':
        return 'bg-rose-100 text-rose-800 border-rose-200';
      case 'Payment Received':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'Device Collected':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Form Printed':
        return 'bg-gray-100 text-gray-800 border-gray-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const formatUserName = (email) => {
    if (!email) return 'System';
    const namePart = email.split('@')[0];
    return namePart.charAt(0).toUpperCase() + namePart.slice(1);
  };

  return (
    <Card className="shadow-lg border-0">
      <CardHeader className="flex flex-row items-center space-x-4 bg-gray-50 rounded-t-lg p-6">
        <History className="w-6 h-6 text-gray-600"/>
        <CardTitle className="text-gray-800 text-xl">Activity Log & Chain of Custody</CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        {isLoading ? (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-500">Loading activity history...</p>
          </div>
        ) : history.length > 0 ? (
          <div className="space-y-4">
            {history.map((entry, index) => {
              const ActionIcon = getActionIcon(entry.action_type);
              return (
                <div key={entry.id} className="flex items-start space-x-4 p-4 bg-gradient-to-r from-gray-50 to-white rounded-lg border hover:shadow-md transition-shadow">
                  <div className="flex-shrink-0 relative">
                    <div className="w-10 h-10 bg-white rounded-full border-2 border-blue-200 flex items-center justify-center">
                      <ActionIcon className="w-5 h-5 text-blue-600" />
                    </div>
                    {index < history.length - 1 && (
                      <div className="absolute top-10 left-1/2 transform -translate-x-0.5 w-0.5 h-8 bg-gray-300"></div>
                    )}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-2">
                      <Badge className={`${getActionColor(entry.action_type)} font-medium text-xs px-3 py-1`}>
                        {entry.action_type}
                      </Badge>
                      <div className="flex items-center text-sm text-gray-500 space-x-2">
                        <User className="w-4 h-4" />
                        <span className="font-medium">{formatUserName(entry.performed_by)}</span>
                        <Clock className="w-4 h-4 ml-2" />
                        <span>{format(new Date(entry.timestamp), 'MMM dd, yyyy')}</span>
                        <span className="text-gray-400">•</span>
                        <span className="font-mono text-xs">{format(new Date(entry.timestamp), 'h:mm a')}</span>
                      </div>
                    </div>
                    
                    <p className="text-gray-800 font-medium mb-2 leading-relaxed">{entry.description}</p>
                    
                    {(entry.old_value || entry.new_value) && (
                      <div className="bg-blue-50 rounded-md p-3 mt-2 border-l-4 border-blue-200">
                        <div className="text-sm">
                          {entry.old_value && (
                            <div className="mb-1">
                              <span className="font-medium text-red-600">Previous: </span>
                              <span className="text-gray-700 font-mono text-xs bg-red-50 px-2 py-1 rounded">{entry.old_value}</span>
                            </div>
                          )}
                          {entry.new_value && (
                            <div>
                              <span className="font-medium text-green-600">Updated to: </span>
                              <span className="text-gray-700 font-mono text-xs bg-green-50 px-2 py-1 rounded">{entry.new_value}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                    
                    <div className="text-xs text-gray-400 mt-2 flex items-center">
                      <span className="bg-gray-100 px-2 py-1 rounded-full">ID: {entry.id}</span>
                      <span className="ml-2">Recorded at {format(new Date(entry.timestamp), 'yyyy-MM-dd HH:mm:ss')} UTC</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-12">
            <History className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 text-lg font-medium">No activity records found</p>
            <p className="text-gray-400 text-sm mt-1">Activity will appear here as actions are performed on this case</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}