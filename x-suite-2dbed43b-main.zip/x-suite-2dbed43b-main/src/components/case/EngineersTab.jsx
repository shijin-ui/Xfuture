import React, { useState, useEffect } from 'react';
import { Case } from '@/api/entities';
import { User } from '@/api/entities';
import { JobHistory } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Users, Plus, X, UserCheck } from 'lucide-react';
import { format } from 'date-fns';

export default function EngineersTab({ caseData, onDataUpdate }) {
  const [engineers, setEngineers] = useState([]);
  const [assignedEngineers, setAssignedEngineers] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (caseData && engineers.length > 0) {
      const assigned = (caseData.assigned_engineers || []).map(email => 
        engineers.find(eng => eng.email === email)
      ).filter(Boolean);
      setAssignedEngineers(assigned);
    }
  }, [caseData, engineers]);

  const loadData = async () => {
    try {
      const [user, allUsers] = await Promise.all([
        User.me(),
        User.list()
      ]);
      setCurrentUser(user);
      const engineerUsers = allUsers.filter(u => 
        u.access_role === 'Technician' || u.access_role === 'Admin'
      );
      setEngineers(engineerUsers);
    } catch (error) {
      console.error('Failed to load engineers:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddEngineer = async (engineerEmail) => {
    if (!caseData || !currentUser) return;
    
    const currentEngineers = caseData.assigned_engineers || [];
    if (currentEngineers.includes(engineerEmail)) return;

    const newEngineers = [...currentEngineers, engineerEmail];
    const engineer = engineers.find(e => e.email === engineerEmail);
    
    try {
      await Case.update(caseData.id, { 
        assigned_engineers: newEngineers,
        assigned_engineer: newEngineers[0] // Keep backward compatibility
      });
      
      await JobHistory.create({
        case_id: caseData.id,
        action_type: "Engineer Assigned",
        description: `Engineer ${engineer?.full_name || engineerEmail} assigned to case`,
        performed_by: currentUser.email,
        timestamp: new Date().toISOString()
      });
      
      onDataUpdate();
    } catch (error) {
      console.error('Failed to assign engineer:', error);
    }
  };

  const handleRemoveEngineer = async (engineerEmail) => {
    if (!caseData || !currentUser) return;
    
    const currentEngineers = caseData.assigned_engineers || [];
    const newEngineers = currentEngineers.filter(e => e !== engineerEmail);
    const engineer = engineers.find(e => e.email === engineerEmail);
    
    try {
      await Case.update(caseData.id, { 
        assigned_engineers: newEngineers,
        assigned_engineer: newEngineers[0] || null // Keep backward compatibility
      });
      
      await JobHistory.create({
        case_id: caseData.id,
        action_type: "Engineer Unassigned",
        description: `Engineer ${engineer?.full_name || engineerEmail} unassigned from case`,
        performed_by: currentUser.email,
        timestamp: new Date().toISOString()
      });
      
      onDataUpdate();
    } catch (error) {
      console.error('Failed to unassign engineer:', error);
    }
  };

  const availableEngineers = engineers.filter(eng => 
    !(caseData?.assigned_engineers || []).includes(eng.email)
  );

  if (isLoading) {
    return <div className="p-6">Loading engineers...</div>;
  }

  return (
    <Card className="shadow-lg border-0">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center">
          <Users className="w-5 h-5 mr-2 text-blue-600" />
          Assigned Engineers ({assignedEngineers.length})
        </CardTitle>
        <Select onValueChange={handleAddEngineer}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Assign Engineer..." />
          </SelectTrigger>
          <SelectContent>
            {availableEngineers.map(engineer => (
              <SelectItem key={engineer.email} value={engineer.email}>
                {engineer.full_name} ({engineer.access_role})
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent>
        {assignedEngineers.length > 0 ? (
          <div className="space-y-4">
            {assignedEngineers.map((engineer, index) => (
              <div key={engineer.email} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center space-x-3">
                  <Avatar>
                    <AvatarFallback className="bg-blue-100 text-blue-600">
                      {engineer.full_name.split(' ').map(n => n[0]).join('').toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-medium">{engineer.full_name}</h3>
                    <p className="text-sm text-gray-500">{engineer.email}</p>
                    <div className="flex items-center space-x-2 mt-1">
                      <Badge variant="outline">{engineer.access_role}</Badge>
                      {index === 0 && (
                        <Badge className="bg-blue-100 text-blue-800">Primary</Badge>
                      )}
                    </div>
                  </div>
                </div>
                <Button 
                  variant="outline" 
                  size="icon"
                  onClick={() => handleRemoveEngineer(engineer.email)}
                  className="text-red-600 hover:text-red-800"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <UserCheck className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500">No engineers assigned to this case</p>
            <p className="text-sm text-gray-400">Use the dropdown above to assign engineers</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}