import React, { useState, useEffect } from 'react';
import { Company } from '@/api/entities';
import { getSettingsByCategory } from '../utils/settingsLoader';
import { previewNextEntityNumber, prepareEntityForCreation } from '../utils/entityNumbering';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Building } from 'lucide-react';
import SearchableSelect from '../SearchableSelect';

export default function EditCompanyDialog({ open, onOpenChange, company, onSave, onCompanyUpdate }) {
  const [formData, setFormData] = useState({
    company_name: '',
    company_code: '',
    vat_number: '',
    url: '',
    country: 'Oman',
    city: '',
    industry: '',
    address: '',
    customer_group: 'Corporate'
  });

  const [countries, setCountries] = useState([]);
  const [cities, setCities] = useState([]);
  const [industries, setIndustries] = useState([]);

  useEffect(() => {
    const fetchOptions = async () => {
      try {
        const [countriesData, citiesData, industriesData] = await Promise.all([
          getSettingsByCategory('Countries'),
          getSettingsByCategory('Cities'),
          getSettingsByCategory('Industries')
        ]);
        setCountries([...new Set(countriesData || ['Oman'])]);
        // FIX: Ensure cities are unique before setting state
        const uniqueCities = [...new Set(citiesData || [])];
        setCities(uniqueCities.map(cityName => ({ city_name: cityName, country: 'Oman' })));
        setIndustries([...new Set(industriesData || ['Data Recovery', 'IT Services', 'Technology', 'Healthcare', 'Finance'])]);
      } catch (error) {
        console.error('Failed to fetch options:', error);
        setIndustries(['Data Recovery', 'IT Services', 'Technology']);
      }
    };
    fetchOptions();
  }, []);

  useEffect(() => {
    if (company && open) {
      setFormData({
        company_name: company.company_name || '',
        company_code: company.company_code || '',
        vat_number: company.vat_number || '',
        url: company.url || '',
        country: company.country || 'Oman',
        city: company.city || '',
        industry: company.industry || '',
        address: company.address || '',
        customer_group: company.customer_group || 'Corporate'
      });
    } else if (!company && open) {
      const resetFormForNew = async () => {
        const nextCompanyCode = await previewNextEntityNumber('Company');
        setFormData({
          company_name: '',
          company_code: nextCompanyCode,
          vat_number: '',
          url: '',
          country: 'Oman',
          city: '',
          industry: '',
          address: '',
          customer_group: 'Corporate'
        });
      };
      resetFormForNew();
    }
  }, [company, open]);

  const handleSave = async () => {
    if (!formData.company_name.trim()) {
      alert('Company name is required');
      return;
    }

    try {
      let result;
      if (company) {
        result = await Company.update(company.id, formData);
      } else {
        const finalCompanyData = await prepareEntityForCreation('Company', formData);
        result = await Company.create(finalCompanyData);
      }

      if (onSave) {
        onSave(result);
      }
      if (onCompanyUpdate) {
        onCompanyUpdate();
      }

      onOpenChange(false);
    } catch (error) {
      console.error('Failed to save company:', error);
      alert('Failed to save company');
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <Building className="w-5 h-5 text-blue-600 mr-2" />
            {company ? 'Edit Company Details' : 'Add Company Details'}
          </DialogTitle>
        </DialogHeader>
        
        <div className="grid grid-cols-2 gap-4 py-4">
          <div className="col-span-2">
            <Label>Company Name <span className="text-red-500">*</span></Label>
            <Input 
              value={formData.company_name}
              onChange={(e) => setFormData({...formData, company_name: e.target.value})}
              placeholder="Enter company name"
            />
          </div>

          <div>
            <Label>Company Code</Label>
            <Input 
              value={formData.company_code}
              readOnly
              className="bg-gray-50 text-gray-600"
              title="Auto-generated from Settings"
            />
          </div>
          
          <div>
            <Label>VAT Number</Label>
            <Input 
              value={formData.vat_number}
              onChange={(e) => setFormData({...formData, vat_number: e.target.value})}
              placeholder="VAT registration number"
            />
          </div>
          
          <div>
            <Label>Website URL</Label>
            <Input 
              value={formData.url}
              onChange={(e) => setFormData({...formData, url: e.target.value})}
              placeholder="https://company.com"
            />
          </div>
          
          <div>
            <Label>Industry</Label>
            <SearchableSelect
              value={formData.industry}
              onValueChange={(value) => setFormData({...formData, industry: value})}
              options={industries}
              placeholder="Select industry"
              creatable={false}
            />
          </div>
          
          <div>
            <Label>Country</Label>
            <SearchableSelect
              value={formData.country}
              onValueChange={(value) => setFormData({...formData, country: value})}
              options={countries}
              placeholder="Select country"
            />
          </div>
          
          <div>
            <Label>City</Label>
            <SearchableSelect
              value={formData.city}
              onValueChange={(value) => setFormData({...formData, city: value})}
              options={cities
                .filter(city => city.country === formData.country)
                .map(city => ({ label: city.city_name, value: city.city_name }))
              }
              placeholder="City"
              creatable={true}
            />
          </div>
          
          <div className="col-span-2">
            <Label>Address</Label>
            <Input 
              value={formData.address}
              onChange={(e) => setFormData({...formData, address: e.target.value})}
              placeholder="Full company address"
            />
          </div>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave}>
            {company ? 'Update Company' : 'Add Company'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}