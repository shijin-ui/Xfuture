
import React from 'react';
import { CheckCircle, Clock, AlertTriangle, Package, Truck, Home, FileText, XCircle } from 'lucide-react'; // Added XCircle
import { format } from 'date-fns';

const CaseStatusTracker = ({ currentStatus, caseData, quotes = [], showDates = true }) => {
  // Define the status flow based on your business rules
  const getStatusFlow = (status) => {
    const preQuoteFlow = [
      { key: 'Received', label: 'Device Received', icon: Package, description: 'Device received and registered' },
      { key: 'Diagnosis', label: 'Under Diagnosis', icon: Clock, description: 'Evaluating device condition' },
    ];
    
    // Check for terminal statuses that happen before a quote is approved
    if (['Unrecoverable', 'Returned', 'Cancelled'].includes(status)) {
        // If a quote was never sent or accepted, it's a pre-quote cancellation/return
        const quoteWasSentOrAccepted = quotes.some(q => ['Sent', 'Accepted'].includes(q.status)) || caseData.approved_date;
        
        if (!quoteWasSentOrAccepted) {
            let terminalStep = { key: 'Unrecoverable', label: 'Unrecoverable', icon: AlertTriangle, description: 'Recovery not possible' };
            if (status === 'Cancelled') {
                terminalStep = { key: 'Cancelled', label: 'Cancelled', icon: XCircle, description: 'Case cancelled by customer' };
            }
            if (status === 'Returned') {
                terminalStep = { key: 'Returned', label: 'Returned', icon: Home, description: 'Device returned to customer' };
            }
            return [...preQuoteFlow, terminalStep];
        }
    }

    // Default flow for quoted, approved, and completed cases
    const mainFlow = [
      ...preQuoteFlow,
      { key: 'Quoted', label: 'Quote Sent', icon: FileText, description: 'Recovery quote provided' },
      { key: 'Approved', label: 'Approved', icon: CheckCircle, description: 'Quote approved, work started' },
      { key: 'In Progress', label: 'Recovery in Progress', icon: Clock, description: 'Data recovery in progress' },
      { key: 'Completed', label: 'Recovery Completed', icon: CheckCircle, description: 'Data recovery completed' },
      { key: 'Shipped', label: 'Delivered', icon: Truck, description: 'Device delivered to customer' }
    ];

    // If a case is cancelled or returned after a quote was sent/approved, we show the quote step.
    if (['Cancelled', 'Returned'].includes(status)) {
        let terminalStep = { key: 'Returned', label: 'Returned', icon: Home, description: 'Device returned to customer' };
        if (status === 'Cancelled') {
            terminalStep = { key: 'Cancelled', label: 'Cancelled', icon: XCircle, description: 'Case cancelled by customer' };
        }
        const quoteIndex = mainFlow.findIndex(s => s.key === 'Quoted');
        // If 'Quoted' step is found, slice the mainFlow up to and including 'Quoted', then add the terminal step.
        // If 'Quoted' is not found (which should not happen in mainFlow), this logic might need adjustment,
        // but for a typical flow, 'Quoted' is always present in mainFlow before a post-quote cancellation/return.
        if (quoteIndex !== -1) {
          return [...mainFlow.slice(0, quoteIndex + 1), terminalStep];
        }
    }
    
    return mainFlow;
  };

  const statusFlow = getStatusFlow(currentStatus);
  
  const getStatusIndex = (status) => {
    const index = statusFlow.findIndex(s => s.key === status);
    return index >= 0 ? index : -1;
  };

  const getStatusDate = (stepKey) => {
    if (!caseData || !showDates) return null;

    switch (stepKey) {
      case 'Received':
        return caseData.created_date;
      case 'Quoted':
        // Get the earliest quote sent date
        const sentQuote = quotes.find(q => q.sent_date && q.status === 'Sent');
        return sentQuote?.sent_date;
      case 'Approved':
        return caseData.approved_date;
      case 'Completed':
        return caseData.completed_date;
      case 'Shipped':
      case 'Delivered':
        return caseData.shipped_date || caseData.delivered_date;
      case 'Returned':
        return caseData.returned_date;
      // No specific date fields for 'Cancelled' or 'Unrecoverable' are assumed in caseData,
      // so these will return null, and no date will be displayed for these steps.
      default:
        return null;
    }
  };

  const currentIndex = getStatusIndex(currentStatus);
  
  // Determine if the current flow path signifies a "negative" outcome for styling purposes.
  // This checks if any of the terminal "negative" steps are part of the generated statusFlow.
  const isNegativeOutcomeFlow = statusFlow.some(step => ['Returned', 'Cancelled', 'Unrecoverable'].includes(step.key));

  return (
    <div className="w-full max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-sm">
      <h3 className="text-lg font-semibold mb-6 text-center text-gray-800">
        Track Your Case Progress
      </h3>
      
      <div className="relative">
        {/* Progress Line */}
        <div className="absolute top-8 left-0 right-0 h-0.5 bg-gray-200">
          <div 
            className={`h-full transition-all duration-1000 ${
              isNegativeOutcomeFlow ? 'bg-red-400' : 'bg-blue-500' // Apply red for negative outcomes
            }`}
            style={{ 
              width: currentIndex >= 0 ? `${((currentIndex + 1) / statusFlow.length) * 100}%` : '0%' 
            }}
          />
        </div>

        {/* Status Steps */}
        <div className="flex justify-between items-center relative">
          {statusFlow.map((step, index) => {
            const isCompleted = index <= currentIndex;
            const isCurrent = index === currentIndex;
            const Icon = step.icon;
            const stepDate = getStatusDate(step.key);
            
            return (
              <div key={step.key} className="flex flex-col items-center text-center max-w-32">
                {/* Icon Circle */}
                <div
                  className={`relative z-10 flex items-center justify-center w-16 h-16 rounded-full border-4 transition-all duration-500 ${
                    isCompleted
                      ? isNegativeOutcomeFlow // Apply red for negative outcomes
                        ? 'bg-red-500 border-red-500 text-white'
                        : 'bg-blue-500 border-blue-500 text-white'
                      : 'bg-gray-100 border-gray-300 text-gray-400'
                  } ${
                    isCurrent ? 'ring-4 ring-blue-200 animate-pulse' : ''
                  }`}
                >
                  <Icon className="w-6 h-6" />
                </div>
                
                {/* Label */}
                <div className="mt-3">
                  <p className={`text-sm font-medium ${
                    isCompleted ? 'text-gray-800' : 'text-gray-500'
                  }`}>
                    {step.label}
                  </p>
                  <p className="text-xs text-gray-500 mt-1 leading-tight">
                    {step.description}
                  </p>
                  
                  {/* Show actual dates */}
                  {isCompleted && stepDate && showDates && (
                    <p className="text-xs text-blue-600 mt-1 font-medium">
                      {format(new Date(stepDate), 'MMM dd, yyyy')}
                    </p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Current Status Message */}
      <div className="mt-6 p-4 bg-blue-50 rounded-lg text-center">
        <p className="text-sm text-blue-800">
          <strong>Current Status:</strong> {currentStatus}
        </p>
        {caseData?.assigned_engineer && (
          <p className="text-xs text-blue-600 mt-1">
            Assigned Engineer: {caseData.assigned_engineer}
          </p>
        )}
      </div>
    </div>
  );
};

export default CaseStatusTracker;
