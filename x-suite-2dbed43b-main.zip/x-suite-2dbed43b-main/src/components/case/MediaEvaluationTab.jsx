
import React, { useState, useEffect } from 'react';
import { MediaEvaluation } from '@/api/entities';
import { Case } from '@/api/entities'; // Added import for Case entity
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { PlusCircle, Activity, FileText } from 'lucide-react';
import { format } from 'date-fns';
import { createPageUrl } from '@/utils';
import AddEvaluationDialog from './AddEvaluationDialog';
import { Badge } from '@/components/ui/badge';

export default function MediaEvaluationTab({ caseId, onDataRefresh }) { // Removed caseData from props
  const [evaluations, setEvaluations] = useState([]);
  const [caseData, setCaseData] = useState(null); // Added state for caseData
  const [isLoading, setIsLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const fetchEvaluations = async () => {
    if (!caseId) return;
    setIsLoading(true);
    try {
      // Fetch both evaluations and case data concurrently
      const [evalData, caseResult] = await Promise.all([
        MediaEvaluation.filter({ case_id: caseId }, '-evaluation_date'),
        Case.get(caseId) // Fetch case data
      ]);
      setEvaluations(evalData);
      setCaseData(caseResult); // Set case data
    } catch (error) {
      console.error("Failed to fetch evaluations or case data:", error); // Updated error message
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchEvaluations();
  }, [caseId]);
  
  const handleEvaluationAdded = () => {
    fetchEvaluations();
    if(onDataRefresh) onDataRefresh();
  }

  const getFeasibilityColor = (feasibility) => {
    if (!feasibility) return 'bg-gray-100 text-gray-800';
    if (feasibility.startsWith('High')) return 'bg-green-100 text-green-800';
    if (feasibility.startsWith('Good')) return 'bg-blue-100 text-blue-800';
    if (feasibility.startsWith('Fair')) return 'bg-yellow-100 text-yellow-800';
    if (feasibility.startsWith('Low')) return 'bg-orange-100 text-orange-800';
    if (feasibility.startsWith('Not')) return 'bg-red-100 text-red-800';
    return 'bg-gray-100 text-gray-800';
  };

  // Derived state to check if the case has devices
  const hasDevices = caseData && caseData.devices && caseData.devices.length > 0;

  return (
    <>
      <Card className="shadow-lg border-0">
        <CardHeader className="flex flex-row items-center justify-between">
          <div className="flex items-center space-x-4">
              <Activity className="w-6 h-6 text-orange-600"/>
              <CardTitle className="text-orange-800">Media Evaluation Reports</CardTitle>
          </div>
          <Button size="sm" onClick={() => setIsDialogOpen(true)} disabled={!hasDevices}> {/* Updated disabled condition */}
            <PlusCircle className="w-4 h-4 mr-2"/>
            Add Evaluation Report
          </Button>
        </CardHeader>
        <CardContent className="p-6">
          {isLoading ? (
            <p>Loading evaluations...</p>
          ) : evaluations.length > 0 ? (
            <div className="space-y-4">
              {evaluations.map(e => (
                <div key={e.id} className="p-4 border rounded-lg bg-gray-50 flex justify-between items-center">
                  <div>
                      <p className="font-semibold text-gray-800">
                        Evaluation for S/N: <span className="font-bold text-blue-700">{e.device_serial_number}</span>
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        By {e.technician_name} on {format(new Date(e.evaluation_date), 'dd MMM yyyy')}
                      </p>
                      <Badge className={`mt-2 text-xs ${getFeasibilityColor(e.recovery_feasibility)}`}>
                        Feasibility: {e.recovery_feasibility}
                      </Badge>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => window.open(createPageUrl(`PrintEvaluationReport?id=${e.id}`), '_blank')}
                  >
                    <FileText className="w-4 h-4 mr-2" />
                    View Report
                  </Button>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
                <p className="text-gray-500 mb-2">No media evaluations recorded yet.</p>
                {!hasDevices && ( // Updated condition for warning message
                    <p className="text-sm text-red-500">Please add a device to the case before creating an evaluation.</p>
                )}
            </div>
          )}
        </CardContent>
      </Card>
      
      {hasDevices && ( // Updated conditional rendering for dialog
        <AddEvaluationDialog
            open={isDialogOpen}
            onOpenChange={setIsDialogOpen}
            caseData={caseData}
            onEvaluationAdded={handleEvaluationAdded}
        />
      )}
    </>
  );
}
