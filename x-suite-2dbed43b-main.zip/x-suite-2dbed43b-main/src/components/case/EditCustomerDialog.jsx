import React, { useState, useEffect } from 'react';
import { Customer } from '@/api/entities';
import { Company } from '@/api/entities';
import { getSettingsByCategory } from '../utils/settingsLoader';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { UserPlus, Building, Plus } from 'lucide-react';
import SearchableSelect from '../SearchableSelect';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const EditCustomerDialog = ({ open, onOpenChange, customer, onCustomerUpdate }) => {
    const [formData, setFormData] = useState({});
    const [companies, setCompanies] = useState([]);
    const [cities, setCities] = useState([]);
    const [customerGroups, setCustomerGroups] = useState([]);
    const [countries, setCountries] = useState([]);
    const [showNewCompanyDialog, setShowNewCompanyDialog] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);

    useEffect(() => {
        if (customer) {
            setFormData({
                full_name: customer.full_name || '',
                customer_code: customer.customer_code || '',
                email: customer.email || '',
                secondary_email: customer.secondary_email || '',
                phone_number: customer.phone_number || '',
                phone_country_code: customer.phone_country_code || '+968',
                secondary_phone: customer.secondary_phone || '',
                secondary_phone_country_code: customer.secondary_phone_country_code || '+968',
                city: customer.city || '',
                country: customer.country || 'Oman',
                address: customer.address || '',
                company_name: customer.company_name || '',
                customer_group: customer.customer_group || 'Individual',
                notes: customer.notes || ''
            });
        }
    }, [customer, open]);

    useEffect(() => {
        const fetchOptions = async () => {
            if (open) {
                try {
                    const [companiesData, citiesData, groupsData, countriesData] = await Promise.all([
                        Company.list(),
                        getSettingsByCategory('Cities'),
                        getSettingsByCategory('Customer Groups'),
                        getSettingsByCategory('Countries')
                    ]);
                    setCompanies(companiesData || []);
                    const uniqueCities = [...new Set(citiesData || [])];
                    setCities(uniqueCities.map(cityName => ({ city_name: cityName, country: 'Oman' })));
                    setCustomerGroups([...new Set(groupsData || ['Individual', 'Corporate', 'VIP', 'Government', 'Education'])]);
                    setCountries([...new Set(countriesData || ['Oman'])]);
                } catch (error) {
                    console.error('Failed to fetch dialog options:', error);
                }
            }
        };
        fetchOptions();
    }, [open]);

    const handleSave = async (e) => {
        e.preventDefault();
        if (!formData.full_name || !formData.email) {
            alert('Full Name and Email are required.');
            return;
        }
        setIsSubmitting(true);
        try {
            await Customer.update(customer.id, formData);
            onCustomerUpdate(); // This function should trigger a refresh in the parent component
            onOpenChange(false);
        } catch (error) {
            console.error('Failed to update customer:', error);
            alert('Failed to update customer.');
        } finally {
            setIsSubmitting(false);
        }
    };
    
    const countryCodes = [
        { code: '+968', flag: '🇴🇲', country: 'Oman' },
        { code: '+971', flag: '🇦🇪', country: 'UAE' },
        { code: '+966', flag: '🇸🇦', country: 'Saudi Arabia' },
        { code: '+965', flag: '🇰🇼', country: 'Kuwait' },
        { code: '+974', flag: '🇶🇦', country: 'Qatar' },
        { code: '+973', flag: '🇧🇭', country: 'Bahrain' },
        { code: '+1', flag: '🇺🇸', country: 'USA' },
        { code: '+44', flag: '🇬🇧', country: 'UK' },
        { code: '+91', flag: '🇮🇳', country: 'India' }
    ];

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle>Edit Customer Details</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSave} className="py-4">
                    <div className="grid grid-cols-2 gap-x-6 gap-y-4">
                        <div>
                            <Label>Full Name <span className="text-red-500">*</span></Label>
                            <Input value={formData.full_name || ''} onChange={(e) => setFormData({...formData, full_name: e.target.value})} required />
                        </div>
                        <div>
                            <Label>Customer Code</Label>
                            <Input value={formData.customer_code || ''} readOnly disabled className="bg-gray-50"/>
                        </div>
                        <div>
                            <Label>Email <span className="text-red-500">*</span></Label>
                            <Input type="email" value={formData.email || ''} onChange={(e) => setFormData({...formData, email: e.target.value})} required />
                        </div>
                        <div>
                            <Label>Secondary Email</Label>
                            <Input type="email" value={formData.secondary_email || ''} onChange={(e) => setFormData({...formData, secondary_email: e.target.value})} />
                        </div>

                        <div>
                            <Label>Phone</Label>
                            <div className="flex">
                                <Select value={formData.phone_country_code || '+968'} onValueChange={(value) => setFormData({...formData, phone_country_code: value})}>
                                    <SelectTrigger className="w-28">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {countryCodes.map(cc => <SelectItem key={cc.code} value={cc.code}><span className="flex items-center">{cc.flag} {cc.code}</span></SelectItem>)}
                                    </SelectContent>
                                </Select>
                                <Input value={formData.phone_number || ''} onChange={(e) => setFormData({...formData, phone_number: e.target.value})} className="flex-1 ml-1" />
                            </div>
                        </div>
                         <div>
                            <Label>Secondary Phone</Label>
                            <div className="flex">
                                <Select value={formData.secondary_phone_country_code || '+968'} onValueChange={(value) => setFormData({...formData, secondary_phone_country_code: value})}>
                                    <SelectTrigger className="w-28">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {countryCodes.map(cc => <SelectItem key={cc.code} value={cc.code}><span className="flex items-center">{cc.flag} {cc.code}</span></SelectItem>)}
                                    </SelectContent>
                                </Select>
                                <Input value={formData.secondary_phone || ''} onChange={(e) => setFormData({...formData, secondary_phone: e.target.value})} className="flex-1 ml-1" />
                            </div>
                        </div>

                        <div>
                            <Label>Group</Label>
                            <SearchableSelect
                                value={formData.customer_group}
                                onValueChange={(value) => setFormData({...formData, customer_group: value})}
                                options={customerGroups.map(opt => ({ label: opt, value: opt }))}
                            />
                        </div>
                        
                        <div>
                            <Label>Company</Label>
                            <SearchableSelect
                                value={formData.company_name}
                                onValueChange={(value) => setFormData({...formData, company_name: value})}
                                options={companies.map(c => ({ label: c.company_name, value: c.company_name }))}
                                placeholder="Search and select company..."
                            />
                        </div>

                        <div>
                            <Label>Country</Label>
                            <SearchableSelect
                                value={formData.country}
                                onValueChange={(value) => setFormData({...formData, country: value, city: ''})}
                                options={countries.map(opt => ({ label: opt, value: opt }))}
                            />
                        </div>
                        <div>
                            <Label>City</Label>
                            <SearchableSelect
                                value={formData.city}
                                onValueChange={(value) => setFormData({...formData, city: value})}
                                options={cities.filter(c => c.country === formData.country).map(c => ({ label: c.city_name, value: c.city_name }))}
                                creatable={true}
                            />
                        </div>
                        <div className="col-span-2">
                            <Label>Address</Label>
                            <Input value={formData.address || ''} onChange={(e) => setFormData({...formData, address: e.target.value})} />
                        </div>
                        <div className="col-span-2">
                            <Label>Notes</Label>
                            <Textarea value={formData.notes || ''} onChange={(e) => setFormData({...formData, notes: e.target.value})} />
                        </div>
                    </div>
                    <DialogFooter className="mt-6">
                        <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
                        <Button type="submit" disabled={isSubmitting}>{isSubmitting ? 'Saving...' : 'Save Changes'}</Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
};

export default EditCustomerDialog;