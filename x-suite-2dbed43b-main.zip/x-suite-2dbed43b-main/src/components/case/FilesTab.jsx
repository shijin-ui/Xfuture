import React, { useState, useEffect, useRef } from 'react';
import { CaseFile } from '@/api/entities';
import { User } from '@/api/entities';
import { UploadFile } from '@/api/integrations';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Upload, File, Image, Trash2 } from 'lucide-react';

export default function FilesTab({ caseId }) {
  const [files, setFiles] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isUploading, setIsUploading] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const fileInputRef = useRef(null);

  const fetchFiles = async () => {
    setIsLoading(true);
    try {
      const data = await CaseFile.filter({ case_id: caseId }, "-upload_date");
      setFiles(data);
    } catch (error) {
      console.error("Failed to fetch files:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const getUser = async () => {
        try {
            const user = await User.me();
            setCurrentUser(user);
        } catch(e) {
            console.error(e)
        }
    }
    getUser();
    if (caseId) {
        fetchFiles();
    }
  }, [caseId]);

  const handleFileSelect = async (event) => {
    const file = event.target.files[0];
    if (!file || !currentUser) return;

    setIsUploading(true);
    try {
        const { file_url } = await UploadFile({ file });
        await CaseFile.create({
            case_id: caseId,
            file_name: file.name,
            file_url: file_url,
            uploaded_by: currentUser.full_name,
            upload_date: new Date().toISOString()
        });
        fetchFiles(); // Refresh list
    } catch (error) {
        console.error("Failed to upload file:", error);
        alert("Failed to upload file.");
    } finally {
        setIsUploading(false);
        // Reset file input
        if (fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    }
  };

  const handleDelete = async (fileId) => {
      if (window.confirm("Are you sure you want to delete this file?")) {
          try {
              await CaseFile.delete(fileId);
              fetchFiles();
          } catch(err) {
              console.error("Failed to delete file:", err);
              alert("Failed to delete file.");
          }
      }
  }

  const isImage = (fileName) => /\.(jpg|jpeg|png|gif)$/i.test(fileName);

  return (
    <Card className="shadow-lg border-0">
      <CardHeader className="flex flex-row items-center justify-between">
        <div className="flex items-center space-x-4">
            <File className="w-6 h-6 text-indigo-600"/>
            <CardTitle className="text-indigo-800">Case Files</CardTitle>
        </div>
        <Button size="sm" onClick={() => fileInputRef.current?.click()} disabled={isUploading}>
            <Upload className="w-4 h-4 mr-2"/>
            {isUploading ? 'Uploading...' : 'Upload File'}
        </Button>
        <input type="file" ref={fileInputRef} onChange={handleFileSelect} className="hidden" />
      </CardHeader>
      <CardContent className="p-6">
        {isLoading ? <p>Loading files...</p> : files.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {files.map(f => (
              <Card key={f.id} className="group relative">
                <a href={f.file_url} target="_blank" rel="noopener noreferrer">
                  {isImage(f.file_name) ? (
                    <img src={f.file_url} alt={f.file_name} className="w-full h-32 object-cover rounded-t-lg"/>
                  ) : (
                    <div className="w-full h-32 flex items-center justify-center bg-gray-100 rounded-t-lg">
                        <File className="w-12 h-12 text-gray-400"/>
                    </div>
                  )}
                </a>
                <CardContent className="p-2 text-xs">
                  <p className="font-semibold truncate">{f.file_name}</p>
                  <p className="text-gray-500">by {f.uploaded_by}</p>
                </CardContent>
                <Button 
                    variant="destructive" 
                    size="icon" 
                    className="absolute top-1 right-1 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={(e) => { e.preventDefault(); handleDelete(f.id); }}
                >
                    <Trash2 className="h-3 w-3" />
                </Button>
              </Card>
            ))}
          </div>
        ) : <p className="text-gray-500 text-center py-8">No files attached to this case.</p>}
      </CardContent>
    </Card>
  );
}