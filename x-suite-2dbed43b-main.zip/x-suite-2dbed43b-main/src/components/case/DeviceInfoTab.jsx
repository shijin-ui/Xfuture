
import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Case } from '@/api/entities';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { HardDrive, Server, Smartphone, Monitor, Database, Usb, MemoryStick, Disc, Plus, Edit2, Trash2, Clock, AlertTriangle } from 'lucide-react';
import { getSettingsByCategory } from '../utils/settingsLoader';
import SearchableSelect from '../SearchableSelect';
import { format } from 'date-fns';
import MultiSelect from '../common/MultiSelect'; // Added import

const getDeviceIcon = (mediaType) => {
    if (!mediaType) return HardDrive;
    const lowerMediaType = mediaType.toLowerCase();
    if (lowerMediaType.includes('server') || lowerMediaType.includes('nas')) return Server;
    if (lowerMediaType.includes('raid')) return Database;
    if (lowerMediaType.includes('phone') || lowerMediaType.includes('mobile') || lowerMediaType.includes('ipad')) return Smartphone;
    if (lowerMediaType.includes('laptop') || lowerMediaType.includes('macbook') || lowerMediaType.includes('imac')) return Monitor;
    if (lowerMediaType.includes('usb') || lowerMediaType.includes('flash')) return Usb;
    if (lowerMediaType.includes('memory card') || lowerMediaType.includes('sd card')) return MemoryStick;
    if (lowerMediaType.includes('cd') || lowerMediaType.includes('dvd')) return Disc;
    return HardDrive;
};

export default function DeviceInfoTab({ caseData, onCaseUpdate }) {
  const [isAddDeviceOpen, setIsAddDeviceOpen] = useState(false);
  const [isEditDeviceOpen, setIsEditDeviceOpen] = useState(false);
  const [editingDeviceIndex, setEditingDeviceIndex] = useState(null);
  const [deviceFormData, setDeviceFormData] = useState({});
  const [currentUser, setCurrentUser] = useState(null);

  // Dynamic options state
  const [deviceTypes, setDeviceTypes] = useState([]);
  const [brands, setBrands] = useState([]);
  const [capacities, setCapacities] = useState([]);
  const [accessoriesOptions, setAccessoriesOptions] = useState([]); // Added state for accessories
  const [interfaces, setInterfaces] = useState([]);
  const [madeInOptions, setMadeInOptions] = useState([]);
  const [encryptionOptions, setEncryptionOptions] = useState([]);
  const [platterNoOptions, setPlatterNoOptions] = useState([]);
  const [headNoOptions, setHeadNoOptions] = useState([]);


  useEffect(() => {
    const loadUserAndOptions = async () => {
        try {
            const [
                user, deviceTypesData, brandsData, capacitiesData, accessoriesData, // Added accessoriesData
                interfacesData, madeInData, encryptionData, platterData, headData
            ] = await Promise.all([
                User.me(),
                getSettingsByCategory('Device Types'),
                getSettingsByCategory('Brands'),
                getSettingsByCategory('Capacities'),
                getSettingsByCategory('Accessories'), // Fetch accessories
                getSettingsByCategory('Device Interface'),
                getSettingsByCategory('Device Made In'),
                getSettingsByCategory('Device Encryption'),
                getSettingsByCategory('Device Platter No'),
                getSettingsByCategory('Device Head No'),
            ]);
            setCurrentUser(user);
            setDeviceTypes(deviceTypesData);
            setBrands(brandsData);
            setCapacities(capacitiesData);
            setAccessoriesOptions(accessoriesData); // Set accessories options
            setInterfaces(interfacesData);
            setMadeInOptions(madeInData);
            setEncryptionOptions(encryptionData);
            setPlatterNoOptions(platterData);
            setHeadNoOptions(headData);
        } catch (error) {
            console.error("Failed to load initial data:", error);
        }
    };
    loadUserAndOptions();
  }, []);

  const handleAddNewDevice = (role) => {
    setEditingDeviceIndex(null);
    setDeviceFormData({
      media_type: '', brand: '', media_model: '', media_serial_number: '',
      capacity: '', condition: 'Good', role: role, accessories: [], // Use array for multi-select
      device_status: 'In Lab',
      pcb_no: '', part_no: '', dom: '', dcm_mlc: '', interface: '',
      made_in: '', firmware: '', encryption: '', platter_no: '',
      head_no: '', ph: '', preamp: ''
    });
    setIsAddDeviceOpen(true);
  };

  const handleEditDevice = (device, index) => {
    setEditingDeviceIndex(index);
    // Parse string to array for multi-select, handle empty/null cases
    const accessoriesArray = device.accessories ? device.accessories.split(',').map(s => s.trim()) : [];
    setDeviceFormData({...device, accessories: accessoriesArray});
    setIsEditDeviceOpen(true);
  };

  const handleRemoveDevice = async (indexToRemove) => {
    if (window.confirm('Are you sure you want to remove this device?')) {
        const updatedDevices = caseData.devices.filter((_, index) => index !== indexToRemove);
        
        try {
            const updatePayload = { devices: updatedDevices };
            
            // If we're removing the primary device (index 0), update top-level fields
            if (indexToRemove === 0 && updatedDevices.length > 0) {
                const newPrimaryDevice = updatedDevices[0];
                updatePayload.media_type = newPrimaryDevice.media_type;
                updatePayload.media_model = newPrimaryDevice.media_model;
                updatePayload.media_serial_number = newPrimaryDevice.media_serial_number;
                updatePayload.media_capacity = newPrimaryDevice.capacity;
            } else if (updatedDevices.length === 0) {
                // If no devices left, clear top-level fields
                updatePayload.media_type = '';
                updatePayload.media_model = '';
                updatePayload.media_serial_number = '';
                updatePayload.media_capacity = '';
            }
            
            await Case.update(caseData.id, updatePayload);
            if (onCaseUpdate) {
                await onCaseUpdate();
            }
        } catch (error) {
            console.error('Failed to remove device:', error);
            alert('Error removing device.');
        }
    }
  };
  
  const handleSaveDevice = async () => {
    let updatedDevices;
    const currentDevices = caseData.devices || [];

    // Join accessories array back into a comma-separated string before saving
    const deviceToSave = {
        ...deviceFormData,
        accessories: deviceFormData.accessories.join(', ') // Convert array back to string
    };

    if (editingDeviceIndex !== null) {
      updatedDevices = [...currentDevices];
      updatedDevices[editingDeviceIndex] = deviceToSave;
    } else {
      const newDevice = {
          ...deviceToSave, // Use deviceToSave here
          registered_date: new Date().toISOString(),
          registered_by: currentUser?.email || 'System'
      };
      updatedDevices = [...currentDevices, newDevice];
    }

    try {
        // Prepare update payload that synchronizes both devices array and top-level fields
        const updatePayload = { devices: updatedDevices };
        
        // If we're updating the first (primary) device, also update top-level fields
        // This applies if we are editing the device at index 0, OR if we are adding a new device and it becomes the first device
        if (editingDeviceIndex === 0 || (editingDeviceIndex === null && updatedDevices.length === 1)) {
            const primaryDevice = editingDeviceIndex === 0 ? updatedDevices[0] : updatedDevices[updatedDevices.length - 1];
            updatePayload.media_type = primaryDevice.media_type;
            updatePayload.media_model = primaryDevice.media_model;
            updatePayload.media_serial_number = primaryDevice.media_serial_number;
            updatePayload.media_capacity = primaryDevice.capacity;
        }
        
        await Case.update(caseData.id, updatePayload);
        setIsAddDeviceOpen(false);
        setIsEditDeviceOpen(false);
        setEditingDeviceIndex(null);
        // Call onCaseUpdate to refresh data but stay on current tab
        if (onCaseUpdate) {
            await onCaseUpdate();
        }
    } catch (error) {
        console.error('Failed to save device:', error);
        alert('Error saving device.');
    }
  };
  
  const allDevices = caseData.devices || [];
  const patientDevices = allDevices.filter(d => d.role === 'Patient');
  const supportDevices = allDevices.filter(d => d.role !== 'Patient');

  return (
    <>
      <div className="space-y-6">
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
              {/* Patient Devices */}
              <Card className="shadow-sm">
                  <CardHeader className="bg-blue-50 border-b">
                      <CardTitle className="text-blue-600 flex items-center">
                          <HardDrive className="w-5 h-5 mr-2" />
                          Patient Device(s)
                      </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                      {patientDevices.length > 0 ? (
                          patientDevices.map((device, index) => (
                              <div key={index} className="mb-6 last:mb-0">
                                  <div className="flex justify-between items-center mb-3">
                                      <h3 className="font-semibold text-gray-900">
                                          {device.media_type}
                                      </h3>
                                      <div className="flex items-center space-x-1">
                                          <Button 
                                              variant="ghost" 
                                              size="icon"
                                              onClick={() => handleEditDevice(device, allDevices.findIndex(d => d === device))}
                                              className="h-8 w-8 text-gray-500 hover:text-blue-600"
                                          >
                                              <Edit2 className="w-4 h-4" />
                                          </Button>
                                          <Button 
                                              variant="ghost" 
                                              size="icon"
                                              onClick={() => handleRemoveDevice(allDevices.findIndex(d => d === device))}
                                              className="h-8 w-8 text-gray-500 hover:text-red-600"
                                          >
                                              <Trash2 className="w-4 h-4" />
                                          </Button>
                                      </div>
                                  </div>
                                  
                                  <div className="mt-3 grid grid-cols-2 gap-x-4 gap-y-1 text-sm">
                                      <div className="flex">
                                          <span className="w-16 text-gray-500">Brand</span>
                                          <span className="mr-2">:</span>
                                          <span className="text-gray-800">{device.brand || 'N/A'}</span>
                                      </div>
                                      <div className="flex">
                                          <span className="w-16 text-gray-500">Model</span>
                                          <span className="mr-2">:</span>
                                          <span className="text-gray-800">{device.media_model || 'N/A'}</span>
                                      </div>
                                      <div className="flex">
                                          <span className="w-16 text-gray-500">S/N</span>
                                          <span className="mr-2">:</span>
                                          <span className="text-gray-800">{device.media_serial_number || 'N/A'}</span>
                                      </div>
                                      <div className="flex">
                                          <span className="w-16 text-gray-500">Capacity</span>
                                          <span className="mr-2">:</span>
                                          <span className="text-gray-800">{device.capacity || 'N/A'}</span>
                                      </div>
                                      {device.pcb_no && (
                                          <div className="flex">
                                              <span className="w-16 text-gray-500">PCB No.</span>
                                              <span className="mr-2">:</span>
                                              <span className="text-gray-800">{device.pcb_no}</span>
                                          </div>
                                      )}
                                      {device.part_no && (
                                          <div className="flex">
                                              <span className="w-16 text-gray-500">P/N</span>
                                              <span className="mr-2">:</span>
                                              <span className="text-gray-800">{device.part_no}</span>
                                          </div>
                                      )}
                                      {device.dom && (
                                          <div className="flex">
                                              <span className="w-16 text-gray-500">DOM</span>
                                              <span className="mr-2">:</span>
                                              <span className="text-gray-800">{device.dom}</span>
                                          </div>
                                      )}
                                      {device.dcm_mlc && (
                                          <div className="flex">
                                              <span className="w-16 text-gray-500">DCM/MLC</span>
                                              <span className="mr-2">:</span>
                                              <span className="text-gray-800">{device.dcm_mlc}</span>
                                          </div>
                                      )}
                                      {device.interface && (
                                          <div className="flex">
                                              <span className="w-16 text-gray-500">Interface</span>
                                              <span className="mr-2">:</span>
                                              <span className="text-gray-800">{device.interface}</span>
                                          </div>
                                      )}
                                      {device.made_in && (
                                          <div className="flex">
                                              <span className="w-16 text-gray-500">Made In</span>
                                              <span className="mr-2">:</span>
                                              <span className="text-gray-800">{device.made_in}</span>
                                          </div>
                                      )}
                                      {device.firmware && (
                                          <div className="flex">
                                              <span className="w-16 text-gray-500">Firmware</span>
                                              <span className="mr-2">:</span>
                                              <span className="text-gray-800">{device.firmware}</span>
                                          </div>
                                      )}
                                      {device.encryption && (
                                          <div className="flex">
                                              <span className="w-16 text-gray-500">Encryption</span>
                                              <span className="mr-2">:</span>
                                              <span className="text-gray-800">{device.encryption}</span>
                                          </div>
                                      )}
                                      {device.platter_no && (
                                          <div className="flex">
                                              <span className="w-16 text-gray-500">Platter No</span>
                                              <span className="mr-2">:</span>
                                              <span className="text-gray-800">{device.platter_no}</span>
                                          </div>
                                      )}
                                      {device.head_no && (
                                          <div className="flex">
                                              <span className="w-16 text-gray-500">Head No</span>
                                              <span className="mr-2">:</span>
                                              <span className="text-gray-800">{device.head_no}</span>
                                          </div>
                                      )}
                                      {device.ph && (
                                          <div className="flex">
                                              <span className="w-16 text-gray-500">PH</span>
                                              <span className="mr-2">:</span>
                                              <span className="text-gray-800">{device.ph}</span>
                                          </div>
                                      )}
                                      {device.preamp && (
                                          <div className="flex">
                                              <span className="w-16 text-gray-500">Preamp</span>
                                              <span className="mr-2">:</span>
                                              <span className="text-gray-800">{device.preamp}</span>
                                          </div>
                                      )}
                                  </div>
                                  {device.accessories && (
                                      <div className="flex mt-2">
                                          <span className="w-20 text-purple-600 font-medium">Accessories</span>
                                          <span className="mr-2">:</span>
                                          <div className="flex flex-wrap gap-1">
                                              {device.accessories && device.accessories.split(',').map((acc, i) => ( // Display based on stored string
                                                  <Badge key={i} className="text-xs px-2 py-0.5 bg-purple-100 text-purple-800">
                                                      {acc.trim()}
                                                  </Badge>
                                              ))}
                                          </div>
                                      </div>
                                  )}
                              </div>
                          ))
                      ) : (
                          <p className="text-sm text-gray-500 text-center py-8">No patient devices added.</p>
                      )}
                      <Button 
                          variant="outline" 
                          className="w-full mt-4" 
                          onClick={() => handleAddNewDevice('Patient')}
                      >
                          <Plus className="w-4 h-4 mr-2" /> Add Patient Device
                      </Button>
                  </CardContent>
              </Card>

              {/* Backup & Support Devices */}
              <Card className="shadow-sm">
                  <CardHeader className="bg-green-50 border-b">
                      <CardTitle className="text-green-600 flex items-center">
                          <Database className="w-5 h-5 mr-2" />
                          Backup & Support
                      </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                      {supportDevices.length > 0 ? (
                          supportDevices.map((device, index) => (
                              <div key={index} className="mb-6 last:mb-0">
                                  <div className="flex justify-between items-center mb-3">
                                      <div className="flex items-center space-x-2">
                                          <h3 className="font-semibold text-gray-900">
                                              {device.media_type}
                                          </h3>
                                          <Badge className="bg-green-100 text-green-800 text-xs">
                                              {device.role}
                                          </Badge>
                                      </div>
                                      <div className="flex items-center space-x-1">
                                          <Button 
                                              variant="ghost" 
                                              size="icon"
                                              onClick={() => handleEditDevice(device, allDevices.findIndex(d => d === device))}
                                              className="h-8 w-8 text-gray-500 hover:text-green-600"
                                          >
                                              <Edit2 className="w-4 h-4" />
                                          </Button>
                                          <Button 
                                              variant="ghost" 
                                              size="icon"
                                              onClick={() => handleRemoveDevice(allDevices.findIndex(d => d === device))}
                                              className="h-8 w-8 text-gray-500 hover:text-red-600"
                                          >
                                              <Trash2 className="w-4 h-4" />
                                          </Button>
                                      </div>
                                  </div>
                                  
                                  <div className="mt-3 grid grid-cols-2 gap-x-4 gap-y-1 text-sm">
                                      <div className="flex">
                                          <span className="w-16 text-gray-500">Brand</span>
                                          <span className="mr-2">:</span>
                                          <span className="text-gray-800">{device.brand || 'N/A'}</span>
                                      </div>
                                      <div className="flex">
                                          <span className="w-16 text-gray-500">Model</span>
                                          <span className="mr-2">:</span>
                                          <span className="text-gray-800">{device.media_model || 'N/A'}</span>
                                      </div>
                                      <div className="flex">
                                          <span className="w-16 text-gray-500">S/N</span>
                                          <span className="mr-2">:</span>
                                          <span className="text-gray-800">{device.media_serial_number || 'N/A'}</span>
                                      </div>
                                      <div className="flex">
                                          <span className="w-16 text-gray-500">Capacity</span>
                                          <span className="mr-2">:</span>
                                          <span className="text-gray-800">{device.capacity || 'N/A'}</span>
                                      </div>
                                      {device.pcb_no && (
                                          <div className="flex">
                                              <span className="w-16 text-gray-500">PCB No.</span>
                                              <span className="mr-2">:</span>
                                              <span className="text-gray-800">{device.pcb_no}</span>
                                          </div>
                                      )}
                                      {device.part_no && (
                                          <div className="flex">
                                              <span className="w-16 text-gray-500">P/N</span>
                                              <span className="mr-2">:</span>
                                              <span className="text-gray-800">{device.part_no}</span>
                                          </div>
                                      )}
                                      {device.dom && (
                                          <div className="flex">
                                              <span className="w-16 text-gray-500">DOM</span>
                                              <span className="mr-2">:</span>
                                              <span className="text-gray-800">{device.dom}</span>
                                          </div>
                                      )}
                                      {device.dcm_mlc && (
                                          <div className="flex">
                                              <span className="w-16 text-gray-500">DCM/MLC</span>
                                              <span className="mr-2">:</span>
                                              <span className="text-gray-800">{device.dcm_mlc}</span>
                                          </div>
                                      )}
                                      {device.interface && (
                                          <div className="flex">
                                              <span className="w-16 text-gray-500">Interface</span>
                                              <span className="mr-2">:</span>
                                              <span className="text-gray-800">{device.interface}</span>
                                          </div>
                                      )}
                                      {device.made_in && (
                                          <div className="flex">
                                              <span className="w-16 text-gray-500">Made In</span>
                                              <span className="mr-2">:</span>
                                              <span className="text-gray-800">{device.made_in}</span>
                                          </div>
                                      )}
                                      {device.firmware && (
                                          <div className="flex">
                                              <span className="w-16 text-gray-500">Firmware</span>
                                              <span className="mr-2">:</span>
                                              <span className="text-gray-800">{device.firmware}</span>
                                          </div>
                                      )}
                                      {device.encryption && (
                                          <div className="flex">
                                              <span className="w-16 text-gray-500">Encryption</span>
                                              <span className="mr-2">:</span>
                                              <span className="text-gray-800">{device.encryption}</span>
                                          </div>
                                      )}
                                      {device.platter_no && (
                                          <div className="flex">
                                              <span className="w-16 text-gray-500">Platter No</span>
                                              <span className="mr-2">:</span>
                                              <span className="text-gray-800">{device.platter_no}</span>
                                          </div>
                                      )}
                                      {device.head_no && (
                                          <div className="flex">
                                              <span className="w-16 text-gray-500">Head No</span>
                                              <span className="mr-2">:</span>
                                              <span className="text-gray-800">{device.head_no}</span>
                                          </div>
                                      )}
                                      {device.ph && (
                                          <div className="flex">
                                              <span className="w-16 text-gray-500">PH</span>
                                              <span className="mr-2">:</span>
                                              <span className="text-gray-800">{device.ph}</span>
                                          </div>
                                      )}
                                      {device.preamp && (
                                          <div className="flex">
                                              <span className="w-16 text-gray-500">Preamp</span>
                                              <span className="mr-2">:</span>
                                              <span className="text-gray-800">{device.preamp}</span>
                                          </div>
                                      )}
                                  </div>
                                  {device.accessories && (
                                      <div className="flex mt-2">
                                          <span className="w-20 text-purple-600 font-medium">Accessories</span>
                                          <span className="mr-2">:</span>
                                          <div className="flex flex-wrap gap-1">
                                              {device.accessories && device.accessories.split(',').map((acc, i) => ( // Display based on stored string
                                                  <Badge key={i} className="text-xs px-2 py-0.5 bg-purple-100 text-purple-800">
                                                      {acc.trim()}
                                                  </Badge>
                                              ))}
                                          </div>
                                      </div>
                                  )}
                              </div>
                          ))
                      ) : (
                          <p className="text-sm text-gray-500 text-center py-8">No support devices added.</p>
                      )}
                      <Button 
                          variant="outline" 
                          className="w-full mt-4" 
                          onClick={() => handleAddNewDevice('Backup')}
                      >
                          <Plus className="w-4 h-4 mr-2" /> Add Support Device
                      </Button>
                  </CardContent>
              </Card>

              {/* Device History */}
              <Card className="shadow-sm">
                  <CardHeader className="bg-gray-50 border-b">
                      <CardTitle className="text-gray-600 flex items-center">
                          <Clock className="w-5 h-5 mr-2" />
                          Device History
                      </CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                      {allDevices.length > 0 ? (
                          <ul className="space-y-4">
                              {allDevices.slice().reverse().map((device, index) => {
                                  const DeviceIcon = getDeviceIcon(device.media_type);
                                  return (
                                      <li key={index} className="flex items-start space-x-3">
                                          <DeviceIcon className="w-5 h-5 mt-0.5 text-gray-400" />
                                          <div className="flex-1">
                                              <div className="font-medium text-gray-800">
                                                  {device.brand} {device.media_model}
                                              </div>
                                              <div className="text-xs text-gray-500 mt-1">
                                                  Registered by {device.registered_by?.split('@')[0] || 'N/A'} on {device.registered_date ? format(new Date(device.registered_date), 'dd MMM yyyy') : 'N/A'} at {device.registered_date ? format(new Date(device.registered_date), 'h:mm a') : 'N/A'}
                                              </div>
                                          </div>
                                      </li>
                                  );
                              })}
                          </ul>
                      ) : (
                          <p className="text-sm text-gray-500 text-center py-8">No device history.</p>
                      )}
                  </CardContent>
              </Card>
          </div>
      </div>

      {/* Add/Edit Dialog */}
      <Dialog open={isAddDeviceOpen || isEditDeviceOpen} onOpenChange={isEditDeviceOpen ? setIsEditDeviceOpen : setIsAddDeviceOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>{isEditDeviceOpen ? 'Edit Device' : 'Add New Device'}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 py-4 max-h-[70vh] overflow-y-auto pr-2">
            <div>
              <Label>Device Type*</Label>
              <SearchableSelect
                value={deviceFormData.media_type}
                onValueChange={(value) => setDeviceFormData({...deviceFormData, media_type: value})}
                options={deviceTypes}
              />
            </div>
            <div>
              <Label>Brand</Label>
              <SearchableSelect
                value={deviceFormData.brand}
                onValueChange={(value) => setDeviceFormData({...deviceFormData, brand: value})}
                options={brands}
              />
            </div>
            <div>
              <Label>Model</Label>
              <Input value={deviceFormData.media_model || ''} onChange={(e) => setDeviceFormData({...deviceFormData, media_model: e.target.value})} />
            </div>
            <div>
              <Label>Serial Number*</Label>
              <Input value={deviceFormData.media_serial_number || ''} onChange={(e) => setDeviceFormData({...deviceFormData, media_serial_number: e.target.value})} />
            </div>
            <div>
              <Label>Capacity</Label>
              <SearchableSelect
                value={deviceFormData.capacity}
                onValueChange={(value) => setDeviceFormData({...deviceFormData, capacity: value})}
                options={capacities}
              />
            </div>
             <div>
              <Label>Role*</Label>
              <Select value={deviceFormData.role} onValueChange={(value) => setDeviceFormData({...deviceFormData, role: value})}>
                <SelectTrigger><SelectValue/></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Patient">Patient</SelectItem>
                  <SelectItem value="Backup">Backup</SelectItem>
                  <SelectItem value="Donor">Donor</SelectItem>
                   <SelectItem value="Clone">Clone</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="md:col-span-3">
              <Label>Accessories</Label>
              {/* Changed to MultiSelect */}
              <MultiSelect
                options={accessoriesOptions}
                selected={deviceFormData.accessories || []}
                onChange={(value) => setDeviceFormData({...deviceFormData, accessories: value})}
              />
            </div>
            {deviceFormData.role !== 'Backup' && (
              <div className="md:col-span-3 border-t pt-4 mt-2 grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label>PCB No.</Label>
                    <Input value={deviceFormData.pcb_no || ''} onChange={(e) => setDeviceFormData({...deviceFormData, pcb_no: e.target.value})} />
                  </div>
                  <div>
                    <Label>P/N</Label>
                    <Input value={deviceFormData.part_no || ''} onChange={(e) => setDeviceFormData({...deviceFormData, part_no: e.target.value})} />
                  </div>
                  <div>
                    <Label>DOM</Label>
                    <Input value={deviceFormData.dom || ''} onChange={(e) => setDeviceFormData({...deviceFormData, dom: e.target.value})} />
                  </div>
                  <div>
                    <Label>DCM/MLC</Label>
                    <Input value={deviceFormData.dcm_mlc || ''} onChange={(e) => setDeviceFormData({...deviceFormData, dcm_mlc: e.target.value})} />
                  </div>
                  <div>
                    <Label>Interface</Label>
                    <SearchableSelect
                      value={deviceFormData.interface}
                      onValueChange={(value) => setDeviceFormData({...deviceFormData, interface: value})}
                      options={interfaces}
                    />
                  </div>
                  <div>
                    <Label>Made In</Label>
                    <SearchableSelect
                      value={deviceFormData.made_in}
                      onValueChange={(value) => setDeviceFormData({...deviceFormData, made_in: value})}
                      options={madeInOptions}
                    />
                  </div>
                  <div>
                    <Label>Firmware</Label>
                    <Input value={deviceFormData.firmware || ''} onChange={(e) => setDeviceFormData({...deviceFormData, firmware: e.target.value})} />
                  </div>
                  <div>
                    <Label>Encryption</Label>
                    <SearchableSelect
                      value={deviceFormData.encryption}
                      onValueChange={(value) => setDeviceFormData({...deviceFormData, encryption: value})}
                      options={encryptionOptions}
                    />
                  </div>
                  <div>
                    <Label>Platter No.</Label> {/* Fixed typo here */}
                    <SearchableSelect
                      value={deviceFormData.platter_no}
                      onValueChange={(value) => setDeviceFormData({...deviceFormData, platter_no: value})}
                      options={platterNoOptions}
                    />
                  </div>
                  <div>
                    <Label>Head No.</Label>
                   <SearchableSelect
                    value={deviceFormData.head_no}
                    onValueChange={(value) => setDeviceFormData({...deviceFormData, head_no: value})}
                    options={headNoOptions}
                  />
                </div>
                <div>
                  <Label>PH</Label>
                  <Input value={deviceFormData.ph || ''} onChange={(e) => setDeviceFormData({...deviceFormData, ph: e.target.value})} />
                </div>
                <div>
                  <Label>Preamp</Label>
                  <Input value={deviceFormData.preamp || ''} onChange={(e) => setDeviceFormData({...deviceFormData, preamp: e.target.value})} />
                </div>
            </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setIsAddDeviceOpen(false); setIsEditDeviceOpen(false); }}>Cancel</Button>
            <Button onClick={handleSaveDevice}>Save Device</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
