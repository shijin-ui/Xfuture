import React, { useState, useEffect } from 'react';
import { InternalNote } from '@/api/entities';
import { User } from '@/api/entities';
import { JobHistory } from '@/api/entities';
import { UploadFile } from '@/api/integrations';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { MessageSquare, Plus, Paperclip, Lock } from 'lucide-react';
import { format } from 'date-fns';

export default function InternalNotesTab({ caseId }) {
  const [notes, setNotes] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showAddNote, setShowAddNote] = useState(false);
  const [newNote, setNewNote] = useState({
    note_type: 'General Note',
    content: '',
    is_confidential: false
  });

  useEffect(() => {
    if (caseId) {
      loadData();
    }
  }, [caseId]);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [user, notesData] = await Promise.all([
        User.me(),
        InternalNote.filter({ case_id: caseId }, '-timestamp')
      ]);
      setCurrentUser(user);
      
      // Filter notes based on user permissions
      const visibleNotes = notesData.filter(note => {
        if (!note.is_confidential) return true;
        if (user.access_role === 'Admin') return true;
        if (note.engineer_email === user.email) return true;
        return false;
      });
      
      setNotes(visibleNotes);
    } catch (error) {
      console.error('Failed to load internal notes:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddNote = async () => {
    if (!newNote.content.trim() || !currentUser) return;

    try {
      await InternalNote.create({
        case_id: caseId,
        note_type: newNote.note_type,
        content: newNote.content,
        engineer_email: currentUser.email,
        is_confidential: newNote.is_confidential,
        timestamp: new Date().toISOString()
      });

      await JobHistory.create({
        case_id: caseId,
        action_type: "Internal Note Added",
        description: `${newNote.note_type}: ${newNote.content.substring(0, 50)}${newNote.content.length > 50 ? '...' : ''}`,
        performed_by: currentUser.email,
        timestamp: new Date().toISOString()
      });

      setNewNote({
        note_type: 'General Note',
        content: '',
        is_confidential: false
      });
      setShowAddNote(false);
      loadData();
    } catch (error) {
      console.error('Failed to add note:', error);
    }
  };

  const getNoteTypeColor = (type) => {
    switch (type) {
      case 'Status Update': return 'bg-blue-100 text-blue-800';
      case 'Parts Replaced': return 'bg-green-100 text-green-800';
      case 'Recovery Attempt': return 'bg-orange-100 text-orange-800';
      case 'Technical Issue': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card className="shadow-lg border-0">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center">
          <MessageSquare className="w-5 h-5 mr-2 text-blue-600" />
          Internal Engineering Notes ({notes.length})
        </CardTitle>
        <Button onClick={() => setShowAddNote(!showAddNote)}>
          <Plus className="w-4 h-4 mr-2" />
          Add Note
        </Button>
      </CardHeader>
      <CardContent className="space-y-6">
        {showAddNote && (
          <Card className="border-2 border-blue-200 bg-blue-50">
            <CardContent className="p-4 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Note Type</Label>
                  <Select 
                    value={newNote.note_type} 
                    onValueChange={(value) => setNewNote({...newNote, note_type: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="General Note">General Note</SelectItem>
                      <SelectItem value="Status Update">Status Update</SelectItem>
                      <SelectItem value="Parts Replaced">Parts Replaced</SelectItem>
                      <SelectItem value="Recovery Attempt">Recovery Attempt</SelectItem>
                      <SelectItem value="Technical Issue">Technical Issue</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center space-x-2 mt-6">
                  <Checkbox 
                    id="confidential"
                    checked={newNote.is_confidential}
                    onCheckedChange={(checked) => setNewNote({...newNote, is_confidential: checked})}
                  />
                  <Label htmlFor="confidential" className="text-sm">
                    Confidential (Admin + Author Only)
                  </Label>
                </div>
              </div>
              <Textarea
                placeholder="Enter technical details, parts used, recovery attempts, etc..."
                value={newNote.content}
                onChange={(e) => setNewNote({...newNote, content: e.target.value})}
                rows={4}
              />
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setShowAddNote(false)}>Cancel</Button>
                <Button onClick={handleAddNote}>Add Note</Button>
              </div>
            </CardContent>
          </Card>
        )}

        {isLoading ? (
          <div className="text-center py-8">Loading notes...</div>
        ) : notes.length > 0 ? (
          <div className="space-y-4">
            {notes.map((note) => (
              <Card key={note.id} className={`${note.is_confidential ? 'border-l-4 border-l-red-400 bg-red-50' : ''}`}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <Avatar className="h-8 w-8">
                        <AvatarFallback className="text-xs">
                          {note.engineer_email.split('@')[0].substring(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="flex items-center space-x-2">
                          <Badge className={getNoteTypeColor(note.note_type)}>
                            {note.note_type}
                          </Badge>
                          {note.is_confidential && (
                            <Badge className="bg-red-100 text-red-800">
                              <Lock className="w-3 h-3 mr-1" />
                              Confidential
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-gray-600 mt-1">
                          by {note.engineer_email.split('@')[0]} • {format(new Date(note.timestamp), 'MMM dd, yyyy h:mm a')}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="pl-11">
                    <p className="text-gray-800 whitespace-pre-wrap">{note.content}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <MessageSquare className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500">No internal notes yet</p>
            <p className="text-sm text-gray-400">Add technical updates and recovery progress</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}