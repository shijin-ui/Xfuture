
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Quote } from '@/api/entities';
import { Invoice } from '@/api/entities';
import { Transaction } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PlusCircle, FileText, DollarSign, Edit, MoreHorizontal, Download, Eye, Receipt, Trash2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { format, parseISO } from 'date-fns';
import { createPageUrl } from '@/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";


const quoteStatusColors = {
  Draft: 'bg-gray-200 text-gray-800',
  Sent: 'bg-blue-100 text-blue-800',
  Accepted: 'bg-green-100 text-green-800',
  Rejected: 'bg-red-100 text-red-800'
};

const invoiceStatusColors = {
  Draft: 'bg-gray-200 text-gray-800',
  Sent: 'bg-blue-100 text-blue-800',
  Unpaid: 'bg-orange-100 text-orange-800',
  'Partially Paid': 'bg-yellow-100 text-yellow-800',
  Paid: 'bg-green-100 text-green-800',
  Overdue: 'bg-red-100 text-red-800'
};

export default function QuotesInvoicesTab({ caseId, caseData, customer, onDataRefresh }) {
  const [quotes, setQuotes] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [clientQuotes, setClientQuotes] = useState([]);
  const [clientInvoices, setClientInvoices] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [itemToDelete, setItemToDelete] = useState(null);
  const [deleteType, setDeleteType] = useState(''); // 'quote' or 'invoice'
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      if (!caseId || !customer?.id) return;

      try {
        setIsLoading(true);

        // Add small delays between calls to avoid rate limiting
        const caseQuotes = await Quote.filter({ case_id: caseId }, '-created_date');
        await new Promise((resolve) => setTimeout(resolve, 200));

        const caseInvoices = await Invoice.filter({ case_id: caseId }, '-created_date');
        await new Promise((resolve) => setTimeout(resolve, 200));

        const customerQuotes = await Quote.filter({ customer_id: customer.id }, '-created_date');
        await new Promise((resolve) => setTimeout(resolve, 200));

        const customerInvoices = await Invoice.filter({ customer_id: customer.id }, '-created_date');

        setQuotes(caseQuotes);
        setInvoices(caseInvoices);
        setClientQuotes(customerQuotes.filter((q) => q.case_id !== caseId));
        setClientInvoices(customerInvoices.filter((i) => i.case_id !== caseId));

      } catch (error) {
        console.error('Failed to fetch quotes/invoices:', error);
        setError('Failed to load data');
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [caseId, customer?.id]);

  const handleCreateQuote = () => {
    navigate(createPageUrl(`QuoteDetails?caseId=${caseId}`));
  };

  const handleCreateInvoice = () => {
    navigate(createPageUrl(`InvoiceDetails?caseId=${caseId}`));
  };

  const handleCreateProformaInvoice = () => {
    navigate(createPageUrl(`InvoiceDetails?caseId=${caseId}&proforma=true`));
  };

  const handleEditQuote = (quoteId) => {
    navigate(createPageUrl(`QuoteDetails?id=${quoteId}`));
  };

  const handleEditInvoice = (invoiceId) => {
    navigate(createPageUrl(`InvoiceDetails?id=${invoiceId}`));
  };

  const handlePrintQuote = (quoteId) => {
    window.open(createPageUrl(`PrintQuote?id=${quoteId}`), '_blank');
  };

  const handlePrintInvoice = (invoiceId) => {
    window.open(createPageUrl(`PrintInvoice?id=${invoiceId}`), '_blank');
  };

  const handleDelete = async () => {
    if (!itemToDelete) return;
    try {
      if (deleteType === 'quote') {
        await Quote.delete(itemToDelete.id);
      } else if (deleteType === 'invoice') {
        await Invoice.delete(itemToDelete.id);
      }
      onDataRefresh(); // Refresh the parent component's data
      setItemToDelete(null);
      setDeleteType('');
    } catch (error) {
      console.error(`Failed to delete ${deleteType}:`, error);
      alert(`Could not delete the ${deleteType}.`);
    }
  };


  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardContent className="p-6 text-center">
            <p className="text-gray-500">Loading quotes...</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 text-center">
            <p className="text-gray-500">Loading invoices...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (error) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardContent className="p-6 text-center">
            <p className="text-red-500">{error}</p>
            <Button
              variant="outline"
              className="mt-4"
              onClick={() => window.location.reload()}
            >
              Retry
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Current Case Quotes */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center">
            <FileText className="w-5 h-5 mr-2 text-blue-600" />
            Quotes
          </CardTitle>
          <Button onClick={handleCreateQuote} size="sm" className="inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 bg-primary text-primary-foreground hover:bg-primary/90 h-9 rounded-md px-3">
            <PlusCircle className="w-4 h-4 mr-2" />
            New Quote
          </Button>
        </CardHeader>
        <CardContent>
          {quotes.length > 0 ?
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Number</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {quotes.map((quote) =>
                  <TableRow key={quote.id}>
                    <TableCell className="font-semibold">#{quote.quote_number}</TableCell>
                    <TableCell className="text-sm text-gray-600">{quote.total_amount?.toFixed(3) || '0.000'} OMR</TableCell>
                    <TableCell className="text-xs text-gray-500">{format(parseISO(quote.created_date), 'dd MMM yyyy')}</TableCell>
                    <TableCell>
                      <Badge className={quoteStatusColors[quote.status] || 'bg-gray-200 text-gray-800'}>
                        {quote.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end items-center space-x-1">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleEditQuote(quote.id)}>
                              <Edit className="w-4 h-4 mr-2" />
                              Edit Quote
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handlePrintQuote(quote.id)}>
                              <Eye className="w-4 h-4 mr-2" />
                              View/Print
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="icon" className="text-red-500" onClick={() => { setItemToDelete(quote); setDeleteType('quote'); }}>
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                              <AlertDialogDescription>
                                This will permanently delete Quote #{itemToDelete?.quote_number}. This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel onClick={() => setItemToDelete(null)}>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table> :
            <div className="text-center py-8 text-gray-500">
              <FileText className="w-12 h-12 mx-auto mb-3 text-gray-300" />
              <p>No quotes generated for this case yet.</p>
              <p className="text-sm">Create a quote to get started</p>
            </div>
          }
        </CardContent>
      </Card>

      {/* Current Case Invoices */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center">
            <DollarSign className="w-5 h-5 mr-2 text-green-600" />
            Invoices
          </CardTitle>
          <div className="flex space-x-2">
            <Button onClick={handleCreateProformaInvoice} size="sm" variant="outline" className="bg-purple-50 text-purple-600 border-purple-200 hover:bg-purple-100">
              <Receipt className="w-4 h-4 mr-2" />
              Proforma
            </Button>
            <Button onClick={handleCreateInvoice} size="sm">
              <PlusCircle className="w-4 h-4 mr-2" />
              Invoice
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {invoices.length > 0 ?
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Number</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {invoices.map((invoice) =>
                  <TableRow key={invoice.id}>
                    <TableCell>
                      <div className="font-semibold flex items-center space-x-1">
                        <span>{invoice.is_proforma ? 'Proforma' : 'Invoice'} #{invoice.invoice_number}</span>
                        {invoice.is_proforma &&
                          <Badge className="bg-purple-100 text-purple-800 text-xs">
                            Proforma
                          </Badge>
                        }
                      </div>
                    </TableCell>
                    <TableCell className="text-sm text-gray-600">
                      {invoice.total_amount?.toFixed(3) || '0.000'} OMR
                    </TableCell>
                    <TableCell className="text-xs text-gray-500">
                      {format(parseISO(invoice.issued_date || invoice.created_date), 'dd MMM yyyy')}
                      {invoice.due_date && !invoice.is_proforma &&
                        <span> • Due: {format(parseISO(invoice.due_date), 'dd MMM')}</span>
                      }
                    </TableCell>
                    <TableCell>
                      <Badge className={invoiceStatusColors[invoice.status] || 'bg-gray-200 text-gray-800'}>
                        {invoice.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end items-center space-x-1">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleEditInvoice(invoice.id)}>
                              <Edit className="w-4 h-4 mr-2" />
                              Edit {invoice.is_proforma ? 'Proforma' : 'Invoice'}
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handlePrintInvoice(invoice.id)}>
                              <Eye className="w-4 h-4 mr-2" />
                              View/Print
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="icon" className="text-red-500" onClick={() => { setItemToDelete(invoice); setDeleteType('invoice'); }}>
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                              <AlertDialogDescription>
                                This will permanently delete {itemToDelete?.is_proforma ? 'Proforma' : 'Invoice'} #{itemToDelete?.invoice_number}. This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel onClick={() => setItemToDelete(null)}>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table> :
            <div className="text-center py-8 text-gray-500">
              <DollarSign className="w-12 h-12 mx-auto mb-3 text-gray-300" />
              <p>No invoices created for this case yet.</p>
              <p className="text-sm">Create an invoice or proforma to get started</p>
            </div>
          }
        </CardContent>
      </Card>

      {/* Client History Section */}
      {(clientQuotes.length > 0 || clientInvoices.length > 0) &&
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Client Quote History */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium text-gray-600">
                {customer?.full_name}'s Other Quotes ({clientQuotes.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              {clientQuotes.length > 0 ?
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {clientQuotes.slice(0, 5).map((quote) =>
                    <div key={quote.id} className="flex items-center justify-between p-2 bg-blue-50 rounded text-sm">
                      <div>
                        <div className="font-medium">Quote #{quote.quote_number}</div>
                        <div className="text-xs text-gray-600">
                          {quote.total_amount?.toFixed(3) || '0.000'} OMR • {format(parseISO(quote.created_date), 'dd MMM yyyy')}
                        </div>
                      </div>
                      <Badge className={quoteStatusColors[quote.status] || 'bg-gray-200 text-gray-800'} size="sm">
                        {quote.status}
                      </Badge>
                    </div>
                  )}
                  {clientQuotes.length > 5 &&
                    <div className="text-center text-xs text-gray-500 pt-2">
                      and {clientQuotes.length - 5} more...
                    </div>
                  }
                </div> :
                <p className="text-sm text-gray-500">No other quotes</p>
              }
            </CardContent>
          </Card>

          {/* Client Invoice History */}
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium text-gray-600">
                {customer?.full_name}'s Other Invoices ({clientInvoices.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              {clientInvoices.length > 0 ?
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {clientInvoices.slice(0, 5).map((invoice) =>
                    <div key={invoice.id} className="flex items-center justify-between p-2 bg-green-50 rounded text-sm">
                      <div>
                        <div className="font-medium flex items-center space-x-1">
                          <span>{invoice.is_proforma ? 'Proforma' : 'Invoice'} #{invoice.invoice_number}</span>
                          {invoice.is_proforma &&
                            <Badge className="bg-purple-100 text-purple-800 text-xs">P</Badge>
                          }
                        </div>
                        <div className="text-xs text-gray-600">
                          {invoice.total_amount?.toFixed(3) || '0.000'} OMR • {format(parseISO(invoice.issued_date || invoice.created_date), 'dd MMM yyyy')}
                        </div>
                      </div>
                      <Badge className={invoiceStatusColors[invoice.status] || 'bg-gray-200 text-gray-800'} size="sm">
                        {invoice.status}
                      </Badge>
                    </div>
                  )}
                  {clientInvoices.length > 5 &&
                    <div className="text-center text-xs text-gray-500 pt-2">
                      and {clientInvoices.length - 5} more...
                    </div>
                  }
                </div> :
                <p className="text-sm text-gray-500">No other invoices</p>
              }
            </CardContent>
          </Card>
        </div>
      }
    </div>
  );
}
