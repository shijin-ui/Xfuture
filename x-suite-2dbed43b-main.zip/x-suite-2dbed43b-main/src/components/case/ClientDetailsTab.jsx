
import React, { useState, useEffect } from 'react';
import { Customer } from '@/api/entities';
import { Company } from '@/api/entities';
import { Case } from '@/api/entities';
import { Quote } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { User, Briefcase, History, Edit, Mail, Phone, MapPin, Building, Hash, ExternalLink, ArrowRightLeft, KeyRound, Eye, EyeOff, Copy, FileText } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import EditCustomerDialog from './EditCustomerDialog';
import EditCompanyDialog from './EditCompanyDialog';
import SearchableSelect from '../SearchableSelect';
import { format } from 'date-fns'; // Import date-fns for date formatting

const DetailRow = ({ icon: Icon, label, value, isLink = false }) => {
    if (!value && value !== 0) return null; // Ensure 0 is not treated as falsy
    return (
        <div className="flex items-start py-1.5">
            <Icon className="w-4 h-4 mr-3 mt-0.5 text-gray-500" />
            <div>
                <p className="text-xs text-gray-500 mb-0.5">{label}</p>
                {isLink ? (
                    <a href={isLink === 'email' ? `mailto:${value}`: `tel:${value}`} className="text-sm font-medium text-blue-600 hover:underline">{value}</a>
                ) : (
                    <p className="text-sm font-medium text-gray-800">{value}</p>
                )}
            </div>
        </div>
    );
};

export default function ClientDetailsTab({ customer, caseData, company, onDataUpdate }) {
    const [isEditCustomerOpen, setIsEditCustomerOpen] = useState(false);
    const [isEditCompanyOpen, setIsEditCompanyOpen] = useState(false);
    const [isChangeCompanyOpen, setIsChangeCompanyOpen] = useState(false);
    const [isChangeClientOpen, setIsChangeClientOpen] = useState(false);
    const [allCompanies, setAllCompanies] = useState([]);
    const [allCustomers, setAllCustomers] = useState([]);
    const [selectedCompanyId, setSelectedCompanyId] = useState('');
    const [selectedClientId, setSelectedClientId] = useState('');
    const [caseHistory, setCaseHistory] = useState([]);
    const [isLoadingHistory, setIsLoadingHistory] = useState(false);
    const [showPassword, setShowPassword] = useState(false);
    const [copied, setCopied] = useState(false);

    useEffect(() => {
        const fetchCaseHistory = async () => {
            if (customer?.id && caseData?.id) {
                setIsLoadingHistory(true);
                try {
                    // Fetch cases and quotes in parallel for efficiency
                    const [allCases, allQuotes] = await Promise.all([
                        Case.filter({ customer_id: customer.id }, '-created_date'),
                        Quote.filter({ customer_id: customer.id })
                    ]);

                    // Create a map for quick quote lookup by case_id
                    const quoteMap = allQuotes.reduce((map, quote) => {
                        map[quote.case_id] = quote;
                        return map;
                    }, {});

                    // Filter out the current case and enrich with quote data
                    const previousCases = allCases
                        .filter(c => c.id !== caseData.id)
                        .map(c => ({
                            ...c,
                            quote: quoteMap[c.id] || null // Attach quote if it exists
                        }));
                        
                    setCaseHistory(previousCases);
                } catch (error) {
                    console.error("Failed to fetch case history or quotes:", error);
                    setCaseHistory([]);
                } finally {
                    setIsLoadingHistory(false);
                }
            }
        };

        fetchCaseHistory();
    }, [customer, caseData]);

    // Fetch all companies or customers when their respective dialogs open
    useEffect(() => {
        if (isChangeCompanyOpen) {
            const fetchCompanies = async () => {
                try {
                    const companies = await Company.list('company_name');
                    setAllCompanies(companies);
                } catch (error) {
                    console.error('Failed to fetch companies:', error);
                }
            };
            fetchCompanies();
        }
        if (isChangeClientOpen) {
            const fetchCustomers = async () => {
                try {
                    const customers = await Customer.list('full_name');
                    setAllCustomers(customers);
                } catch (error) {
                    console.error('Failed to fetch customers:', error);
                }
            };
            fetchCustomers();
        }
    }, [isChangeCompanyOpen, isChangeClientOpen]);
    
    const quoteStatusColors = {
        Draft: 'bg-gray-100 text-gray-800 border-gray-300',
        Sent: 'bg-blue-100 text-blue-800 border-blue-300',
        Accepted: 'bg-green-100 text-green-800 border-green-300',
        Rejected: 'bg-red-100 text-red-800 border-red-300',
    };

    const caseStatusColors = {
        'Received': 'bg-blue-100 text-blue-800',
        'In Lab': 'bg-purple-100 text-purple-800',
        'Diagnosis': 'bg-orange-100 text-orange-800',
        'Quoted': 'bg-yellow-100 text-yellow-800',
        'Approved': 'bg-indigo-100 text-indigo-800',
        'In Progress': 'bg-cyan-100 text-cyan-800',
        'Data Ready': 'bg-emerald-100 text-emerald-800',
        'Payment Pending': 'bg-amber-100 text-amber-800',
        'Completed': 'bg-green-100 text-green-800',
        'Closed': 'bg-gray-100 text-gray-800',
        'Returned': 'bg-red-100 text-red-800'
    };

    const handleChangeCompany = async () => {
        if (!selectedCompanyId) {
            alert('Please select a company');
            return;
        }

        try {
            const selectedCompany = allCompanies.find(c => c.id === selectedCompanyId);
            if (!selectedCompany) {
                alert('Selected company not found');
                return;
            }

            // Update customer with new company name
            await Customer.update(customer.id, { 
                company_name: selectedCompany.company_name 
            });

            setIsChangeCompanyOpen(false);
            setSelectedCompanyId('');
            // Ensure data refresh propagates to all components
            if (onDataUpdate) onDataUpdate(); // This line ensures data refresh
        } catch (error) {
            console.error('Failed to change company:', error);
            alert('Failed to change company assignment');
        }
    };

    const handleChangeClient = async () => {
        if (!selectedClientId) {
            alert('Please select a client');
            return;
        }
        if (!caseData || !caseData.id) {
            alert('Current case data is missing.');
            return;
        }

        try {
            await Case.update(caseData.id, { customer_id: selectedClientId });
            setIsChangeClientOpen(false);
            setSelectedClientId('');
            if (onDataUpdate) onDataUpdate();
        } catch (error) {
            console.error('Failed to change client:', error);
            alert('Failed to change client assignment');
        }
    };

    const handleCopyPassword = () => {
        if (caseData?.device_password) {
            navigator.clipboard.writeText(caseData.device_password);
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        }
    };

    return (
        <div className="grid md:grid-cols-3 gap-6">
            <Card className="shadow-lg border-0 md:col-span-1">
                <CardHeader className="flex flex-row items-center justify-between pb-3 bg-blue-50">
                    <CardTitle className="text-lg font-semibold text-blue-800 flex items-center"><User className="w-5 h-5 mr-2"/>Client Details</CardTitle>
                    <div className="flex space-x-1">
                        <Button 
                            variant="ghost" 
                            size="icon" 
                            onClick={() => setIsChangeClientOpen(true)}
                            title="Change Client"
                        >
                            <ArrowRightLeft className="w-4 h-4 text-orange-600"/>
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => setIsEditCustomerOpen(true)}>
                            <Edit className="w-4 h-4 text-blue-600"/>
                        </Button>
                    </div>
                </CardHeader>
                <CardContent className="pt-3 pb-3 space-y-0 divide-y divide-gray-100">
                    <DetailRow icon={User} label="Full Name" value={customer?.full_name} />
                    <DetailRow icon={Mail} label="Email" value={customer?.email} isLink="email" />
                    <DetailRow icon={Phone} label="Phone" value={customer?.phone_number} isLink="tel" />
                    {customer?.secondary_phone && (
                        <DetailRow icon={Phone} label="Secondary Phone" value={customer?.secondary_phone} isLink="tel" />
                    )}
                    <DetailRow icon={MapPin} label="City" value={customer?.city} />
                    <DetailRow icon={MapPin} label="Country" value={customer?.country} />
                    <DetailRow icon={MapPin} label="Address" value={customer?.address} />
                    {customer?.customer_group && (
                        <DetailRow icon={Hash} label="Customer Group" value={customer?.customer_group} />
                    )}
                    {customer?.customer_code && (
                        <DetailRow icon={Hash} label="Customer Code" value={customer?.customer_code} />
                    )}
                    {customer?.dealer_discount_percentage > 0 && (
                        <DetailRow icon={Hash} label="Dealer Discount" value={`${customer?.dealer_discount_percentage}%`} />
                    )}
                    {customer?.dealer_since && (
                        <DetailRow icon={Hash} label="Dealer Since" value={format(new Date(customer.dealer_since), 'dd MMM yyyy')} />
                    )}
                    {customer?.notes && (
                        <DetailRow icon={FileText} label="Notes" value={customer?.notes} />
                    )}
                    {caseData?.device_password && (
                        <div className="flex items-start py-1.5">
                            <KeyRound className="w-4 h-4 mr-3 mt-0.5 text-gray-500" />
                            <div className="flex-1">
                                <p className="text-xs text-gray-500 mb-0.5">Device Password</p>
                                <div className="flex items-center justify-between">
                                    <p className="text-sm font-medium text-gray-800 font-mono tracking-wider">
                                        {showPassword ? caseData.device_password : '●●●●●●●●'}
                                    </p>
                                    <div className="flex items-center space-x-1">
                                        <Button
                                            variant="ghost"
                                            size="icon"
                                            className="h-6 w-6"
                                            onClick={() => setShowPassword(!showPassword)}
                                            title={showPassword ? "Hide password" : "Show password"}
                                        >
                                            {showPassword ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                                        </Button>
                                        <Button
                                            variant="ghost"
                                            size="icon"
                                            className="h-6 w-6"
                                            onClick={handleCopyPassword}
                                            title="Copy password"
                                        >
                                            <Copy className="w-3 h-3" />
                                        </Button>
                                    </div>
                                </div>
                                {copied && <p className="text-xs text-green-600 mt-1">Copied to clipboard!</p>}
                            </div>
                        </div>
                    )}
                </CardContent>
            </Card>

            <Card className="shadow-lg border-0 md:col-span-1">
                <CardHeader className="flex flex-row items-center justify-between pb-2 bg-green-50">
                    <CardTitle className="text-lg font-semibold text-green-800 flex items-center"><Briefcase className="w-5 h-5 mr-2"/>Company Details</CardTitle>
                    <div className="flex space-x-1">
                        {customer?.company_name && (
                            <Button 
                                variant="ghost" 
                                size="icon" 
                                onClick={() => setIsChangeCompanyOpen(true)}
                                title="Change Company"
                            >
                                <ArrowRightLeft className="w-4 h-4 text-orange-600"/>
                            </Button>
                        )}
                        {company && (
                            <Button variant="ghost" size="icon" onClick={() => setIsEditCompanyOpen(true)}>
                                <Edit className="w-4 h-4 text-green-600"/>
                            </Button>
                        )}
                    </div>
                </CardHeader>
                <CardContent className="pt-4 divide-y">
                    {customer?.company_name ? (
                        <>
                            <DetailRow icon={Building} label="Company Name" value={customer.company_name} />
                            <DetailRow icon={Hash} label="VAT Number" value={company?.vat_number || 'N/A'} />
                            <DetailRow icon={Mail} label="Company Email" value={company?.email} isLink="email" />
                            <DetailRow icon={Phone} label="Company Phone" value={company?.phone} isLink="tel" />
                            <DetailRow icon={MapPin} label="Company Address" value={company?.address} />
                        </>
                    ) : (
                        <div className="py-10 text-center">
                            <p className="text-sm text-gray-500 mb-3">No company associated with this client.</p>
                            <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => setIsChangeCompanyOpen(true)}
                                className="text-green-600 border-green-600 hover:bg-green-50"
                            >
                                <Building className="w-4 h-4 mr-2"/>
                                Assign Company
                            </Button>
                        </div>
                    )}
                </CardContent>
            </Card>
            
            <Card className="shadow-lg border-0 md:col-span-1">
                <CardHeader className="bg-gray-50 pb-2">
                    <CardTitle className="text-lg font-semibold text-gray-800 flex items-center"><History className="w-5 h-5 mr-2"/>Client Case History</CardTitle>
                </CardHeader>
                <CardContent className="pt-2">
                    {isLoadingHistory ? (
                        <p className="text-center text-sm text-gray-500 py-10">Loading history...</p>
                    ) : caseHistory.length > 0 ? (
                        <div className="divide-y max-h-64 overflow-y-auto">
                            {caseHistory.map(c => (
                                <div key={c.id} className="flex items-center justify-between py-2.5">
                                    <div className="flex-1 min-w-0">
                                        <a
                                            href={createPageUrl(`CaseDetails?id=${c.id}`)}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="text-sm font-medium text-blue-600 hover:underline flex items-center"
                                            title={`View case #${c.case_number}`}
                                        >
                                            #{c.case_number}
                                            <ExternalLink className="w-3 h-3 ml-1.5" />
                                        </a>
                                        <div className="mt-1">
                                            <Badge className={`text-xs ${caseStatusColors[c.status] || 'bg-gray-100 text-gray-800'}`}>
                                                {c.status}
                                            </Badge>
                                        </div>
                                    </div>
                                    <div className="text-right ml-2">
                                        {c.quote ? (
                                            <>
                                                <p className="text-sm font-semibold text-gray-800">
                                                    ${c.quote.total_amount?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) || '0.00'}
                                                </p>
                                                <Badge className={`text-xs mt-1 ${quoteStatusColors[c.quote.status] || quoteStatusColors.Draft}`}>
                                                    {c.quote.status}
                                                </Badge>
                                            </>
                                        ) : (
                                            <Badge variant="outline" className="text-xs text-gray-400">No Quote</Badge>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <p className="text-center text-sm text-gray-500 py-10">No previous cases found.</p>
                    )}
                </CardContent>
            </Card>

            <EditCustomerDialog
                open={isEditCustomerOpen}
                onOpenChange={setIsEditCustomerOpen}
                customer={customer}
                onCustomerUpdate={onDataUpdate}
            />
            {company && (
                <EditCompanyDialog
                    open={isEditCompanyOpen}
                    onOpenChange={setIsEditCompanyOpen}
                    company={company}
                    customer={customer}
                    onCompanyUpdate={onDataUpdate}
                />
            )}

            {/* Change Company Dialog */}
            <Dialog open={isChangeCompanyOpen} onOpenChange={setIsChangeCompanyOpen}>
                <DialogContent className="max-w-md">
                    <DialogHeader>
                        <DialogTitle className="flex items-center">
                            <ArrowRightLeft className="w-5 h-5 mr-2 text-orange-600"/>
                            {customer?.company_name ? 'Change Company' : 'Assign Company'}
                        </DialogTitle>
                    </DialogHeader>
                    
                    <div className="py-4">
                        {customer?.company_name && (
                            <div className="mb-4 p-3 bg-gray-50 rounded-lg">
                                <Label className="text-sm text-gray-600">Current Company:</Label>
                                <p className="font-semibold text-gray-800">{customer.company_name}</p>
                            </div>
                        )}
                        
                        <div>
                            <Label>Select New Company <span className="text-red-500">*</span></Label>
                            <SearchableSelect
                                value={selectedCompanyId}
                                onValueChange={setSelectedCompanyId}
                                placeholder="Search and select a company..."
                                options={allCompanies.map(comp => ({
                                    value: comp.id,
                                    label: comp.company_name,
                                    subtitle: comp.city ? `${comp.city}${comp.country ? `, ${comp.country}` : ''}` : comp.country || ''
                                }))}
                                searchPlaceholder="Type to search companies..."
                                className="w-full"
                            />
                        </div>
                        
                        {selectedCompanyId && (
                            <div className="mt-3 p-3 bg-blue-50 rounded-lg">
                                <Label className="text-sm text-blue-600">Selected Company:</Label>
                                {(() => {
                                    const selectedComp = allCompanies.find(c => c.id === selectedCompanyId);
                                    return selectedComp ? (
                                        <div className="text-sm">
                                            <p className="font-semibold">{selectedComp.company_name}</p>
                                            {selectedComp.vat_number && (
                                                <p className="text-gray-600">VAT: {selectedComp.vat_number}</p>
                                            )}
                                            {(selectedComp.city || selectedComp.country) && (
                                                <p className="text-gray-600">
                                                    {selectedComp.city}{selectedComp.city && selectedComp.country && ', '}{selectedComp.country}
                                                </p>
                                            )}
                                        </div>
                                    ) : null;
                                })()}
                            </div>
                        )}
                    </div>

                    <DialogFooter>
                        <Button variant="outline" onClick={() => {
                            setIsChangeCompanyOpen(false);
                            setSelectedCompanyId('');
                        }}>
                            Cancel
                        </Button>
                        <Button 
                            onClick={handleChangeCompany}
                            className="bg-orange-600 hover:bg-orange-700"
                            disabled={!selectedCompanyId}
                        >
                            {customer?.company_name ? 'Change Company' : 'Assign Company'}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            {/* Change Client Dialog */}
            <Dialog open={isChangeClientOpen} onOpenChange={setIsChangeClientOpen}>
                <DialogContent className="max-w-md">
                    <DialogHeader>
                        <DialogTitle className="flex items-center">
                            <ArrowRightLeft className="w-5 h-5 mr-2 text-orange-600"/>
                            Change Client
                        </DialogTitle>
                    </DialogHeader>
                    
                    <div className="py-4">
                        <div className="mb-4 p-3 bg-gray-50 rounded-lg">
                            <Label className="text-sm text-gray-600">Current Client:</Label>
                            <p className="font-semibold text-gray-800">{customer?.full_name}</p>
                        </div>
                        
                        <div>
                            <Label>Select New Client <span className="text-red-500">*</span></Label>
                            <SearchableSelect
                                value={selectedClientId}
                                onValueChange={setSelectedClientId}
                                placeholder="Search and select a client..."
                                options={allCustomers.map(cust => ({
                                    value: cust.id,
                                    label: cust.full_name,
                                    subtitle: cust.email || cust.phone_number
                                }))}
                                searchPlaceholder="Type to search clients..."
                                className="w-full"
                            />
                        </div>
                    </div>

                    <DialogFooter>
                        <Button variant="outline" onClick={() => {
                            setIsChangeClientOpen(false);
                            setSelectedClientId('');
                        }}>
                            Cancel
                        </Button>
                        <Button 
                            onClick={handleChangeClient}
                            className="bg-orange-600 hover:bg-orange-700"
                            disabled={!selectedClientId}
                        >
                            Change Client
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}
