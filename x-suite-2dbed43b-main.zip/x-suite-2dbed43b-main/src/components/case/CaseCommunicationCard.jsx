import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Send, FileText, DollarSign, MessageSquare, Zap, Loader2, MessageCircle } from 'lucide-react';
import { SendEmail } from '@/api/integrations';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

const ActionButton = ({ icon: Icon, text, onClick, disabled = false, isLoading = false }) => {
    return (
        <Button onClick={onClick} disabled={disabled || isLoading} className="w-full justify-start text-left h-auto py-3">
            {isLoading ? (
                <Loader2 className="w-4 h-4 mr-3 animate-spin" />
            ) : (
                <Icon className="w-4 h-4 mr-3" />
            )}
            <div className="flex flex-col">
                <span className="font-semibold">{text}</span>
            </div>
        </Button>
    );
};

export default function CaseCommunicationCard({ caseData, customer, quotes, invoices, evaluations }) {
    const [loading, setLoading] = useState({});
    const [isCustomEmailOpen, setIsCustomEmailOpen] = useState(false);
    const [customEmailData, setCustomEmailData] = useState({ subject: '', body: '' });

    const latestQuote = quotes?.[0];
    const latestInvoice = invoices?.[0];
    const latestEvaluation = evaluations?.[0];

    const handleSend = async (type) => {
        if (!customer?.email) {
            alert("Customer email is not available.");
            return;
        }

        setLoading(prev => ({ ...prev, [type]: true }));

        let subject = '';
        let body = '';
        const portalLink = `https://[YOUR_APP_URL]/ClientPortal?caseId=${caseData.id}`; // Placeholder URL

        switch (type) {
            case 'diagnosis_quote':
                subject = `Diagnosis Report & Quote for Case #${caseData.case_number}`;
                body = `Dear ${customer.full_name},\n\nYour diagnosis report and quote for case #${caseData.case_number} are ready.\n\nPlease log in to your client portal to review the documents and approve the quote.\n\nPortal Link: ${portalLink}\n\nThank you,\nSpace Data Recovery`;
                break;
            case 'invoice':
                subject = `Invoice for Case #${caseData.case_number}`;
                body = `Dear ${customer.full_name},\n\nYour invoice for case #${caseData.case_number} is ready.\n\nPlease log in to your client portal to view and pay the invoice.\n\nPortal Link: ${portalLink}\n\nThank you,\nSpace Data Recovery`;
                break;
            case 'custom':
                subject = customEmailData.subject;
                body = customEmailData.body;
                break;
            default:
                break;
        }

        try {
            await SendEmail({ to: customer.email, subject, body, from_name: "Space Data Recovery" });
            alert('Email sent successfully!');
            if (type === 'custom') {
                setIsCustomEmailOpen(false);
                setCustomEmailData({ subject: '', body: '' });
            }
        } catch (error) {
            console.error("Failed to send email:", error);
            alert("Failed to send email. Please try again.");
        } finally {
            setLoading(prev => ({ ...prev, [type]: false }));
        }
    };
    
    const handleWhatsapp = () => {
        if (!customer?.phone_number) {
            alert('Customer phone number is missing.');
            return;
        }
        const phoneNumber = customer.phone_number.replace(/\D/g, '');
        const message = `Hi ${customer.full_name}, regarding your case #${caseData.case_number}...`;
        const encodedMessage = encodeURIComponent(message);
        const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;
        window.open(whatsappUrl, '_blank');
    };

    return (
        <>
            <Card className="shadow-lg border-0">
                <CardHeader className="flex flex-row items-center justify-between pb-2 bg-yellow-50">
                    <CardTitle className="text-lg font-semibold text-yellow-800 flex items-center"><Zap className="w-5 h-5 mr-2"/>Quick Communication</CardTitle>
                </CardHeader>
                <CardContent className="pt-4 px-4 pb-4 space-y-2">
                    <ActionButton
                        icon={FileText}
                        text="Send Diagnosis & Quote"
                        onClick={() => handleSend('diagnosis_quote')}
                        disabled={!latestEvaluation || !latestQuote}
                        isLoading={loading['diagnosis_quote']}
                    />
                    <ActionButton
                        icon={DollarSign}
                        text="Send Invoice"
                        onClick={() => handleSend('invoice')}
                        disabled={!latestInvoice}
                        isLoading={loading['invoice']}
                    />
                    <ActionButton
                        icon={Send}
                        text="Send Custom Email"
                        onClick={() => setIsCustomEmailOpen(true)}
                        isLoading={loading['custom']}
                    />
                    <ActionButton
                        icon={MessageCircle}
                        text="Send WhatsApp Message"
                        onClick={handleWhatsapp}
                    />
                </CardContent>
            </Card>

            <Dialog open={isCustomEmailOpen} onOpenChange={setIsCustomEmailOpen}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Send Custom Email</DialogTitle>
                    </DialogHeader>
                    <div className="py-4 space-y-4">
                        <div>
                            <Label>To</Label>
                            <Input value={customer?.email || ''} readOnly disabled />
                        </div>
                        <div>
                            <Label htmlFor="subject">Subject</Label>
                            <Input 
                                id="subject"
                                value={customEmailData.subject} 
                                onChange={(e) => setCustomEmailData(prev => ({ ...prev, subject: e.target.value }))}
                            />
                        </div>
                        <div>
                            <Label htmlFor="body">Message</Label>
                            <Textarea 
                                id="body"
                                value={customEmailData.body}
                                onChange={(e) => setCustomEmailData(prev => ({ ...prev, body: e.target.value }))}
                                rows={10}
                            />
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setIsCustomEmailOpen(false)}>Cancel</Button>
                        <Button onClick={() => handleSend('custom')} disabled={loading['custom']}>
                            {loading['custom'] ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : <Send className="w-4 h-4 mr-2"/>}
                            Send Email
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </>
    );
}