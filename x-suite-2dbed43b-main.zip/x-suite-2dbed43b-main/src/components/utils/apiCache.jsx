// Global API response cache to prevent duplicate calls
const cache = new Map();
const CACHE_DURATION = 30000; // 30 seconds

export const getCachedData = (key) => {
  const cached = cache.get(key);
  if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
    return cached.data;
  }
  return null;
};

export const setCachedData = (key, data) => {
  cache.set(key, {
    data,
    timestamp: Date.now()
  });
};

export const clearCache = (keyPrefix = null) => {
  if (keyPrefix) {
    // Clear only keys that start with the prefix
    for (const key of cache.keys()) {
      if (key.startsWith(keyPrefix)) {
        cache.delete(key);
      }
    }
  } else {
    // Clear all cache
    cache.clear();
  }
};

// Request throttling
const requestQueue = new Map();

export const throttleRequest = async (key, requestFn, delay = 100) => {
  // Check if the same request is already in progress
  if (requestQueue.has(key)) {
    return await requestQueue.get(key);
  }
  
  // Add delay to prevent rate limiting
  await new Promise(resolve => setTimeout(resolve, delay));
  
  // Execute the request and cache the promise
  const promise = requestFn();
  requestQueue.set(key, promise);
  
  try {
    const result = await promise;
    return result;
  } finally {
    // Remove from queue when done
    requestQueue.delete(key);
  }
};