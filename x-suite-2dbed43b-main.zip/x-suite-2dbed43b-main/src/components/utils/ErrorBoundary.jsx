import React from 'react';
import { AlertTriangle, RefreshCw, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { 
      hasError: false, 
      error: null, 
      errorInfo: null,
      isNetworkError: false 
    };
  }

  static getDerivedStateFromError(error) {
    // Check if it's a network-related error
    const isNetworkError = error.message && (
      error.message.toLowerCase().includes('network') ||
      error.message.toLowerCase().includes('fetch') ||
      error.message.toLowerCase().includes('connection') ||
      error.message.toLowerCase().includes('cors')
    );

    return { 
      hasError: true, 
      isNetworkError 
    };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo);
    this.setState({
      error,
      errorInfo
    });
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-background flex items-center justify-center p-4">
          <Card className="max-w-lg w-full">
            <CardContent className="p-8 text-center">
              <AlertTriangle className="w-16 h-16 text-red-500 mx-auto mb-4" />
              
              <h1 className="text-2xl font-bold mb-2">
                {this.state.isNetworkError ? 'Connection Error' : 'Application Error'}
              </h1>
              
              <p className="text-muted-foreground mb-6">
                {this.state.isNetworkError 
                  ? 'Unable to connect to the server. Please check your internet connection and try again.'
                  : 'Something went wrong while loading the application.'
                }
              </p>

              {this.state.isNetworkError && (
                <div className="bg-muted p-4 rounded-lg mb-6 text-sm text-left">
                  <h3 className="font-medium mb-2">Troubleshooting Steps:</h3>
                  <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                    <li>Check your internet connection</li>
                    <li>Verify the server is running</li>
                    <li>Check if the API URL is correct</li>
                    <li>Look for CORS or firewall issues</li>
                  </ul>
                </div>
              )}

              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Button onClick={() => window.location.reload()}>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Reload Page
                </Button>
                
                <Button variant="outline" onClick={() => window.location.href = '/'}>
                  <Home className="w-4 h-4 mr-2" />
                  Go Home
                </Button>
              </div>

              {window.location.hostname === 'localhost' && this.state.error && (
                <details className="mt-6 text-left">
                  <summary className="cursor-pointer text-sm font-medium mb-2">
                    Error Details (Development)
                  </summary>
                  <pre className="text-xs bg-muted p-3 rounded overflow-auto">
                    {this.state.error.toString()}
                    {this.state.errorInfo.componentStack}
                  </pre>
                </details>
              )}
            </CardContent>
          </Card>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;