
import { Setting } from '@/api/entities';

// Cache for settings to prevent repeated API calls
const settingsCache = new Map();
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

// Rate limiting
let lastRequestTime = 0;
const MIN_REQUEST_INTERVAL = 100; // 100ms between requests

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

export const getSettingsByCategory = async (category) => {
    // Check cache first
    const cacheKey = `settings_${category}`;
    const cached = settingsCache.get(cacheKey);
    
    if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
        return cached.data;
    }

    // Rate limiting - ensure minimum interval between requests
    const now = Date.now();
    const timeSinceLastRequest = now - lastRequestTime;
    if (timeSinceLastRequest < MIN_REQUEST_INTERVAL) {
        await delay(MIN_REQUEST_INTERVAL - timeSinceLastRequest);
    }
    lastRequestTime = Date.now();

    try {
        const settings = await Setting.filter({ category, is_active: true }, 'display_order');
        // FIX: Ensure values are unique by converting to a Set and back to an array.
        const settingValues = [...new Set(settings.map(s => s.value).filter(v => v && v.trim() !== ''))];
        
        // Cache the result
        settingsCache.set(cacheKey, {
            data: settingValues,
            timestamp: Date.now()
        });
        
        return settingValues;
    } catch (error) {
        console.error(`Failed to load settings for category ${category}:`, error);
        
        // Return cached data if available, even if expired
        if (cached) {
            console.warn(`Using expired cache for ${category}`);
            return cached.data;
        }
        
        // Return empty array as fallback
        return [];
    }
};

export const clearSettingsCache = () => {
    settingsCache.clear();
};

// Preload common settings to reduce individual requests
export const preloadCommonSettings = async () => {
    const commonCategories = [
        'Device Types',
        'Capacities', 
        'Service Problems',
        'Service Types',
        'Case Priorities',
        'Case Statuses',
        'Customer Groups',
        'Phone Country Codes' // Added this category for preloading
    ];

    // Load in batches to avoid overwhelming the API
    const batchSize = 3;
    for (let i = 0; i < commonCategories.length; i += batchSize) {
        const batch = commonCategories.slice(i, i + batchSize);
        await Promise.all(batch.map(category => getSettingsByCategory(category)));
        
        // Small delay between batches
        if (i + batchSize < commonCategories.length) {
            await delay(200);
        }
    }
};
