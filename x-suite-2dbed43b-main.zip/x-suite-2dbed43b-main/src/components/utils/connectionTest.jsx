// Connection testing utilities
export const testConnection = async () => {
  const results = {
    internetConnection: false,
    apiServer: false,
    apiUrl: window.REACT_APP_API_URL || 'http://localhost:8000/api',
    timestamp: new Date().toISOString()
  };

  try {
    // Test basic internet connectivity
    const response = await fetch('https://httpbin.org/get', { 
      method: 'GET',
      mode: 'cors',
      cache: 'no-cache'
    });
    results.internetConnection = response.ok;
  } catch (error) {
    console.error('Internet connection test failed:', error);
    results.internetConnection = false;
  }

  try {
    // Test API server connectivity
    const apiResponse = await fetch(`${results.apiUrl}/health`, {
      method: 'GET',
      mode: 'cors',
      cache: 'no-cache',
      headers: {
        'Content-Type': 'application/json'
      }
    });
    results.apiServer = apiResponse.ok;
    results.apiStatus = apiResponse.status;
  } catch (error) {
    console.error('API server test failed:', error);
    results.apiServer = false;
    results.apiError = error.message;
  }

  return results;
};

export const diagnoseConnectionIssue = async () => {
  const test = await testConnection();
  
  let diagnosis = {
    issue: 'unknown',
    message: 'Unknown connection issue',
    suggestions: []
  };

  if (!test.internetConnection && !test.apiServer) {
    diagnosis = {
      issue: 'no_internet',
      message: 'No internet connection detected',
      suggestions: [
        'Check your internet connection',
        'Verify network settings',
        'Try restarting your router'
      ]
    };
  } else if (test.internetConnection && !test.apiServer) {
    diagnosis = {
      issue: 'api_unreachable',
      message: `API server unreachable at ${test.apiUrl}`,
      suggestions: [
        'Verify the API server is running',
        'Check the REACT_APP_API_URL environment variable',
        'Ensure there are no firewall blocking the connection',
        'Check for CORS configuration issues'
      ]
    };
  } else if (test.internetConnection && test.apiServer) {
    diagnosis = {
      issue: 'intermittent',
      message: 'Connection seems to be working now',
      suggestions: [
        'The issue may have been temporary',
        'Try refreshing the page',
        'Check browser console for more details'
      ]
    };
  }

  return { test, diagnosis };
};