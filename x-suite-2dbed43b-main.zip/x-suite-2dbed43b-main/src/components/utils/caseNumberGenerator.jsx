import { Setting } from '@/api/entities';

export const getNextCaseNumber = async () => {
    try {
        // Try to get the current case number sequence from settings
        const numberSequences = await Setting.filter({ category: 'Number Sequences' });
        let caseSequence = numberSequences.find(s => s.value === 'Case Number');
        
        if (!caseSequence) {
            // Create the initial sequence if it doesn't exist
            caseSequence = await Setting.create({
                category: 'Number Sequences',
                value: 'Case Number',
                numeric_value: 26000, // Start from 26000 to match your numbering
                description: 'Auto-incrementing case number sequence'
            });
            return '26001'; // First case number
        }
        
        // Increment the sequence
        const nextNumber = (caseSequence.numeric_value || 26000) + 1;
        await Setting.update(caseSequence.id, { numeric_value: nextNumber });
        
        // Return plain number format (26001, 26002, etc.) - no prefix
        return nextNumber.toString();
        
    } catch (error) {
        console.error('Error generating case number:', error);
        // Fallback to timestamp-based number if database fails
        const fallbackNumber = 26000 + parseInt(Date.now().toString().slice(-3));
        return fallbackNumber.toString();
    }
};