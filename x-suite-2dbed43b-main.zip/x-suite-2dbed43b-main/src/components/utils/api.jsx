import { Case } from '@/api/entities';
import { Customer } from '@/api/entities';
import { Company } from '@/api/entities';
import { Quote } from '@/api/entities';
import { Invoice } from '@/api/entities';
import { Expense } from '@/api/entities';
import { Asset } from '@/api/entities';
import { Inventory } from '@/api/entities';
import { Supplier } from '@/api/entities';
import { Bank } from '@/api/entities';
import { Transaction } from '@/api/entities';
import { Setting } from '@/api/entities';
import { User } from '@/api/entities';
import { JobHistory } from '@/api/entities';
import { MediaEvaluation } from '@/api/entities';
import { Communication } from '@/api/entities';

/* 
  This file centralizes all data-fetching logic.
  When migrating, you will replace the logic in these functions 
  with API calls (e.g., using axios) to your self-hosted backend.
  The rest of the frontend will not need to change.
*/

const adaptFilter = (params) => {
  if (!params) return [{}, '-created_date', 20, 0];

  const { filters = {}, sort = '-created_date', limit = 20, page = 1 } = params;
  const offset = (page - 1) * limit;

  // Remove any null/undefined/empty string filters
  const cleanFilters = Object.entries(filters).reduce((acc, [key, value]) => {
    if (value !== null && value !== undefined && value !== '') {
      acc[key] = value;
    }
    return acc;
  }, {});

  return [cleanFilters, sort, limit, offset];
};

export const caseService = {
  getAll: (params) => {
    const [filters, sort, limit, offset] = adaptFilter(params);
    return Case.filter(filters, sort, limit, offset);
  },
  getById: (id) => Case.get(id),
  create: (data) => Case.create(data),
  update: (id, data) => Case.update(id, data),
  delete: (id) => Case.delete(id),
};

export const customerService = {
  getAll: (params) => {
    const [filters, sort, limit, offset] = adaptFilter(params);
    return Customer.filter(filters, sort, limit, offset);
  },
  getById: (id) => Customer.get(id),
  create: (data) => Customer.create(data),
  update: (id, data) => Customer.update(id, data),
  delete: (id) => Customer.delete(id),
};

export const quoteService = {
  getAll: (params) => {
    const [filters, sort, limit, offset] = adaptFilter(params);
    return Quote.filter(filters, sort, limit, offset);
  },
  getById: (id) => Quote.get(id),
  create: (data) => Quote.create(data),
  update: (id, data) => Quote.update(id, data),
  delete: (id) => Quote.delete(id),
};

export const invoiceService = {
  getAll: (params) => {
    const [filters, sort, limit, offset] = adaptFilter(params);
    return Invoice.filter(filters, sort, limit, offset);
  },
  getById: (id) => Invoice.get(id),
  create: (data) => Invoice.create(data),
  update: (id, data) => Invoice.update(id, data),
  delete: (id) => Invoice.delete(id),
};

export const settingService = {
    getByCategory: (category) => Setting.filter({ category, is_active: true }, 'display_order'),
    getAll: (params) => {
        const [filters, sort, limit, offset] = adaptFilter(params);
        return Setting.filter(filters, sort, limit, offset);
    },
    create: (data) => Setting.create(data),
    update: (id, data) => Setting.update(id, data),
    delete: (id) => Setting.delete(id),
}

export const userService = {
    getCurrentUser: () => User.me(),
    getAll: (params) => {
        const [filters, sort, limit, offset] = adaptFilter(params);
        return User.filter(filters, sort, limit, offset);
    },
    update: (id, data) => User.update(id, data),
    logout: () => User.logout(),
    loginWithRedirect: (url) => User.loginWithRedirect(url)
}

export const jobHistoryService = {
    getForCase: (caseId, params) => {
        const [filters, sort, limit, offset] = adaptFilter(params);
        return JobHistory.filter({ ...filters, case_id: caseId }, sort, limit, offset);
    }
}

export const companyService = {
    getAll: (params) => {
        const [filters, sort, limit, offset] = adaptFilter(params);
        return Company.filter(filters, sort, limit, offset);
    },
    getById: (id) => Company.get(id),
    create: (data) => Company.create(data),
    update: (id, data) => Company.update(id, data),
    delete: (id) => Company.delete(id),
}

export const mediaEvaluationService = {
    getForCase: (caseId, params) => {
        const [filters, sort, limit, offset] = adaptFilter(params);
        return MediaEvaluation.filter({ ...filters, case_id: caseId }, sort, limit, offset);
    },
    create: (data) => MediaEvaluation.create(data),
    update: (id, data) => MediaEvaluation.update(id, data),
    delete: (id) => MediaEvaluation.delete(id),
}

export const communicationService = {
    getForCase: (caseId, params) => {
        const [filters, sort, limit, offset] = adaptFilter(params);
        return Communication.filter({ ...filters, case_id: caseId }, sort, limit, offset);
    },
    create: (data) => Communication.create(data),
};