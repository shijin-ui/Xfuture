
import { User } from '@/api/entities';

// Global user cache manager to prevent multiple API calls
class UserCacheManager {
  constructor() {
    this.cache = null;
    this.cacheTime = 0;
    this.cacheDuration = 300000; // 5 minutes
    this.pendingRequest = null;
    this.requestCount = 0;
    this.lastRequestTime = 0;
    this.minRequestInterval = 3000; // Increased to 3 seconds between requests
  }

  async getUser() {
    const now = Date.now();
    if (this.cache && now - this.cacheTime < this.cacheDuration) {
      return this.cache;
    }

    if (this.pendingRequest) {
      return await this.pendingRequest;
    }

    if (now - this.lastRequestTime < this.minRequestInterval) {
        console.warn('Throttling user fetch requests.');
        if (this.cache) return this.cache;
        await new Promise(resolve => setTimeout(resolve, this.minRequestInterval - (now - this.lastRequestTime)));
    }

    this.pendingRequest = this.fetchUserWithRetry()
      .then(user => {
        this.cache = user;
        this.cacheTime = Date.now();
        this.pendingRequest = null;
        this.lastRequestTime = Date.now();
        return user;
      })
      .catch(error => {
        this.pendingRequest = null;
        this.lastRequestTime = Date.now();
        throw error;
      });

    return await this.pendingRequest;
  }

  async fetchUserWithRetry(retryCount = 0) {
    try {
      const user = await User.me();
      this.requestCount++;
      console.log(`User fetched successfully (request #${this.requestCount})`);
      return user;
    } catch (error) {
      console.error(`User fetch attempt ${retryCount + 1} failed:`, error.message);
      
      if (error.message && error.message.includes('429')) {
        // Rate limit hit - wait longer before retry
        const delay = Math.min(5000 * Math.pow(2, retryCount), 30000); // Exponential backoff, max 30s
        console.log(`Rate limit hit, waiting ${delay}ms before retry...`);
        await new Promise(resolve => setTimeout(resolve, delay));
        
        if (retryCount < 3) { // Allow up to 3 retries for 429 errors
          return this.fetchUserWithRetry(retryCount + 1);
        } else {
          throw new Error('Rate limit exceeded. Please wait a moment before trying again.');
        }
      } else if (error.message && (error.message.includes('401') || error.message.includes('403'))) {
        // Handle both 401 and 403 as authentication errors
        console.log('Authentication error detected, redirecting to login...');
        this.clearCache(); // Clear cache before redirect
        User.loginWithRedirect(window.location.href);
        throw new Error('Authentication required. Redirecting to login...');
      } else {
        if (retryCount < 2) {
          const delay = 5000 * (retryCount + 1); // Linear backoff for other errors
          console.log(`Request failed, retrying in ${delay}ms...`);
          await new Promise(resolve => setTimeout(resolve, delay));
          return this.fetchUserWithRetry(retryCount + 1);
        } else {
          // Final attempt failed, throw a specific error for network issues
          if (error.message && error.message.toLowerCase().includes('network error')) {
              throw new Error('A network error occurred. Please check your internet connection.');
          }
          throw error;
        }
      }
    }
  }

  clearCache() {
    this.cache = null;
    this.cacheTime = 0;
    console.log('User cache cleared.');
  }

  logout() {
    this.clearCache();
    // The actual logout is handled by User.logout() in the layout
  }
}

// Export singleton instance
export const userCacheManager = new UserCacheManager();
