import { consumeNextNumber, peekNextNumber } from './numberSequences';

/**
 * Centralized entity numbering configuration
 * Maps entity types to their Settings sequence names and prefixes
 */
const ENTITY_NUMBERING_CONFIG = {
    Customer: {
        sequenceName: 'Customer Number',
        prefix: 'SRC-',
        defaultStart: 10001,
        codeField: 'customer_code'
    },
    Company: {
        sequenceName: 'Company Number', 
        prefix: 'COMP-',
        defaultStart: 1001,
        codeField: 'company_code'
    },
    Case: {
        sequenceName: 'Case Number',
        prefix: '',
        defaultStart: 25450,
        codeField: 'case_number'
    },
    Quote: {
        sequenceName: 'Quote Number',
        prefix: 'QUO-',
        defaultStart: 1001,
        codeField: 'quote_number'
    },
    Invoice: {
        sequenceName: 'Invoice Number',
        prefix: 'INV-',
        defaultStart: 1001,
        codeField: 'invoice_number'
    },
    ProformaInvoice: {
        sequenceName: 'Proforma Invoice Number',
        prefix: 'PRO-',
        defaultStart: 1001,
        codeField: 'invoice_number'
    },
    Expense: {
        sequenceName: 'Expense Number',
        prefix: 'EXP-',
        defaultStart: 1001,
        codeField: 'expense_number'
    },
    Asset: {
        sequenceName: 'Asset Number',
        prefix: 'AST-',
        defaultStart: 1001,
        codeField: 'asset_code'
    },
    Inventory: {
        sequenceName: 'Inventory Number',
        prefix: 'INV-',
        defaultStart: 1001,
        codeField: 'item_code'
    },
    Supplier: {
        sequenceName: 'Supplier Number',
        prefix: 'SUP-',
        defaultStart: 1001,
        codeField: 'supplier_code'
    },
    Employee: {
        sequenceName: 'Employee Number',
        prefix: 'EMP-',
        defaultStart: 1001,
        codeField: 'employee_code'
    },
    BankTransfer: {
        sequenceName: 'Transfer Number',
        prefix: 'TRF-',
        defaultStart: 1001,
        codeField: 'transfer_number'
    },
    BankDeposit: {
        sequenceName: 'Deposit Number',
        prefix: 'DEP-',
        defaultStart: 1001,
        codeField: 'deposit_number'
    },
    PurchaseOrder: {
        sequenceName: 'PO Number',
        prefix: 'PO-',
        defaultStart: 1001,
        codeField: 'po_number'
    }
};

/**
 * Get the next number preview for an entity type (doesn't consume the number)
 * @param {string} entityType - The entity type (Customer, Company, Case, etc.)
 * @returns {Promise<string>} The formatted next number
 */
export const previewNextEntityNumber = async (entityType) => {
    const config = ENTITY_NUMBERING_CONFIG[entityType];
    if (!config) {
        console.warn(`No numbering config found for entity type: ${entityType}`);
        return `${entityType}-${Date.now().toString().slice(-4)}`;
    }

    try {
        return await peekNextNumber(config.sequenceName, config.prefix, config.defaultStart);
    } catch (error) {
        console.error(`Failed to preview next number for ${entityType}:`, error);
        return `${config.prefix}${config.defaultStart}`;
    }
};

/**
 * Generate and consume the next number for an entity (use when actually creating)
 * @param {string} entityType - The entity type
 * @returns {Promise<string>} The consumed formatted number
 */
export const generateEntityNumber = async (entityType) => {
    const config = ENTITY_NUMBERING_CONFIG[entityType];
    if (!config) {
        console.warn(`No numbering config found for entity type: ${entityType}`);
        return `${entityType}-${Date.now().toString().slice(-4)}`;
    }

    try {
        return await consumeNextNumber(config.sequenceName, config.prefix, config.defaultStart);
    } catch (error) {
        console.error(`Failed to generate number for ${entityType}:`, error);
        return `${config.prefix}${config.defaultStart}`;
    }
};

/**
 * Get the code field name for an entity type
 * @param {string} entityType - The entity type
 * @returns {string} The field name that stores the entity's number/code
 */
export const getEntityCodeField = (entityType) => {
    const config = ENTITY_NUMBERING_CONFIG[entityType];
    return config ? config.codeField : 'code';
};

/**
 * Helper to prepare entity data with proper numbering before creation
 * @param {string} entityType - The entity type
 * @param {object} entityData - The entity data
 * @returns {Promise<object>} Entity data with proper number assigned
 */
export const prepareEntityForCreation = async (entityType, entityData) => {
    const codeField = getEntityCodeField(entityType);
    const generatedNumber = await generateEntityNumber(entityType);
    
    return {
        ...entityData,
        [codeField]: generatedNumber
    };
};