
import { Setting } from '@/api/entities';

/**
 * Finds the correct setting for a given sequence, even if duplicates exist.
 * It always picks the setting with the highest numeric_value to prevent number reuse.
 * @param {string} sequenceName - e.g., 'Case Number', 'Customer Number'
 * @returns {Promise<object|null>} The setting object with the highest value, or null.
 */
const getSequenceSetting = async (sequenceName) => {
    const settings = await Setting.filter({ category: 'Number Sequences', value: sequenceName });

    if (!settings || settings.length === 0) {
        return null;
    }

    // In case of duplicates (as seen in screenshot), always use the one with the highest number.
    return settings.reduce((max, s) => ((s.numeric_value || 0) > (max.numeric_value || 0) ? s : max), settings[0]);
};

/**
 * Safely peeks at the next number in a sequence without consuming it.
 * Used for displaying the upcoming number in the UI.
 * @param {string} sequenceName - The name of the sequence, e.g., 'Case Number'.
 * @param {string} [prefix=''] - A prefix to add to the number, e.g., 'SRC-'.
 * @param {number} [defaultValue=1] - The number to start from if the sequence doesn't exist.
 * @returns {Promise<string>} The formatted next number string.
 */
export const peekNextNumber = async (sequenceName, prefix = '', defaultValue = 1) => {
    try {
        const setting = await getSequenceSetting(sequenceName);
        if (setting) {
            const currentNumber = setting.numeric_value || (defaultValue - 1);
            return `${prefix}${(currentNumber + 1)}`;
        }
        // If no setting exists, do not create one. Show a clear indicator.
        return `Not Configured`;
    } catch (error) {
        console.error(`Failed to peek next number for ${sequenceName}:`, error);
        return `Error`; // Fallback
    }
};

/**
 * Consumes the next number in a sequence, updating the value in the database.
 * This should only be called when a new record (Case, Customer) is actually being created.
 * @param {string} sequenceName - The name of the sequence.
 * @param {string} [prefix=''] - A prefix for the number.
 * @param {number} [defaultValue=1] - The starting number for a new sequence.
 * @returns {Promise<string>} The consumed, formatted number string.
 */
export const consumeNextNumber = async (sequenceName, prefix = '', defaultValue = 1) => {
    try {
        let setting = await getSequenceSetting(sequenceName);
        
        // FIX: If a setting does not exist, do NOT create it automatically.
        // This prevents the creation of duplicates. The sequence MUST be initialized in the Settings page first.
        if (!setting) {
            // Alert the user and throw an error to stop the process.
            const errorMessage = `Number sequence "${sequenceName}" is not initialized. Please configure it in the Settings page.`;
            alert(errorMessage);
            throw new Error(errorMessage);
        }

        const currentNumber = setting.numeric_value || (defaultValue - 1);
        const nextNumberValue = currentNumber + 1;
        // Atomically update the database with the new highest number
        await Setting.update(setting.id, { numeric_value: nextNumberValue });
        
        return `${prefix}${nextNumberValue}`;

    } catch (error) {
        console.error(`Failed to consume next number for ${sequenceName}:`, error);
        // Re-throw the error to ensure the calling function knows about the failure.
        throw error;
    }
};
