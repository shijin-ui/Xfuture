import { AccountingLocale } from '@/api/entities';

// Cache for locales to avoid repeated API calls
let localeCache = null;
let cacheTimestamp = 0;
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

export const getDefaultLocale = async () => {
    const now = Date.now();
    
    // Check if cache is still valid
    if (localeCache && (now - cacheTimestamp) < CACHE_DURATION) {
        return localeCache;
    }
    
    try {
        const locales = await AccountingLocale.list();
        const defaultLocale = locales.find(l => l.is_default && l.is_active);
        
        // Fallback to Oman if no default set
        if (!defaultLocale) {
            return {
                country_name: 'Oman',
                currency_code: 'OMR',
                currency_symbol: 'OMR',
                decimal_places: 3,
                decimal_separator: '.',
                thousand_separator: ',',
                currency_position: 'after',
                tax_name: 'VAT',
                tax_rate: 0.05
            };
        }
        
        localeCache = defaultLocale;
        cacheTimestamp = now;
        return defaultLocale;
    } catch (error) {
        console.error('Failed to load default locale:', error);
        // Return Oman as fallback
        return {
            country_name: 'Oman',
            currency_code: 'OMR',
            currency_symbol: 'OMR',
            decimal_places: 3,
            decimal_separator: '.',
            thousand_separator: ',',
            currency_position: 'after',
            tax_name: 'VAT',
            tax_rate: 0.05
        };
    }
};

export const formatCurrency = (amount, locale = null) => {
    if (!amount || isNaN(amount)) return '0' + (locale?.decimal_separator || '.') + '0'.repeat(locale?.decimal_places || 2);
    
    if (!locale) {
        // If no locale provided, use a default format
        return `${parseFloat(amount).toFixed(3).replace(/\B(?=(\d{3})+(?!\d))/g, ',')} OMR`;
    }
    
    const formattedAmount = parseFloat(amount).toFixed(locale.decimal_places)
        .replace('.', locale.decimal_separator)
        .replace(/\B(?=(\d{3})+(?!\d))/g, locale.thousand_separator);
    
    return locale.currency_position === 'before' 
        ? `${locale.currency_symbol} ${formattedAmount}`
        : `${formattedAmount} ${locale.currency_symbol}`;
};

export const convertCurrency = async (amount, fromCurrency, toCurrency) => {
    try {
        const locales = await AccountingLocale.list();
        const fromLocale = locales.find(l => l.currency_code === fromCurrency);
        const toLocale = locales.find(l => l.currency_code === toCurrency);
        
        if (!fromLocale || !toLocale) {
            console.error('Currency conversion failed: locale not found');
            return amount;
        }
        
        // Convert through USD as base currency
        const usdAmount = amount / fromLocale.exchange_rate_to_usd;
        const convertedAmount = usdAmount * toLocale.exchange_rate_to_usd;
        
        return convertedAmount;
    } catch (error) {
        console.error('Currency conversion failed:', error);
        return amount;
    }
};

export const clearLocaleCache = () => {
    localeCache = null;
    cacheTimestamp = 0;
};