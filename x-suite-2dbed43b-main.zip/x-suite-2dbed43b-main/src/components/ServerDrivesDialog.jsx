import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2 } from 'lucide-react';
import SearchableSelect from './SearchableSelect';
import { getSettingsByCategory } from './utils/settingsLoader';

export default function ServerDrivesDialog({ open, onOpenChange, initialDrives, onSave, capacities = [] }) {
    const [drives, setDrives] = useState([]);
    const [brands, setBrands] = useState([]);

    useEffect(() => {
        if (open) {
            setDrives(initialDrives || []);
            loadBrands();
        }
    }, [open, initialDrives]);

    const loadBrands = async () => {
        try {
            const brandsData = await getSettingsByCategory('Brands');
            setBrands(brandsData || []);
        } catch (error) {
            console.error('Failed to load brands:', error);
            setBrands([]);
        }
    };

    const handleAddDrive = () => {
        setDrives([...drives, { 
            media_serial_number: '', 
            media_model: '', 
            brand: '',
            capacity: '', 
            interface: 'SATA' 
        }]);
    };

    const handleRemoveDrive = (index) => {
        setDrives(drives.filter((_, i) => i !== index));
    };

    const handleDriveChange = (index, field, value) => {
        const newDrives = [...drives];
        newDrives[index][field] = value;
        setDrives(newDrives);
    };

    const handleSaveChanges = () => {
        onSave(drives);
        onOpenChange(false);
    };

    const capacityOptions = capacities.map(opt => ({ label: opt, value: opt }));
    const brandOptions = brands.map(brand => ({ label: brand, value: brand }));

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-6xl">
                <DialogHeader>
                    <DialogTitle className="text-xl font-semibold">Manage Server Drives</DialogTitle>
                </DialogHeader>
                <div className="py-4 max-h-[70vh] overflow-y-auto pr-2 space-y-4">
                    {drives.map((drive, index) => (
                        <div key={index} className="grid grid-cols-6 gap-4 items-end p-4 border rounded-lg bg-gray-50">
                            <div className="col-span-1">
                                <Label className="text-sm font-medium text-gray-700">Serial Number</Label>
                                <Input 
                                    value={drive.media_serial_number || ''}
                                    onChange={(e) => handleDriveChange(index, 'media_serial_number', e.target.value)}
                                    placeholder="Enter serial number"
                                    className="mt-1"
                                />
                            </div>
                            <div className="col-span-1">
                                <Label className="text-sm font-medium text-gray-700">Model</Label>
                                <Input 
                                    value={drive.media_model || ''}
                                    onChange={(e) => handleDriveChange(index, 'media_model', e.target.value)}
                                    placeholder="Drive model"
                                    className="mt-1"
                                />
                            </div>
                            <div className="col-span-1">
                                <Label className="text-sm font-medium text-gray-700">Brand</Label>
                                <SearchableSelect
                                    value={drive.brand || ''}
                                    onValueChange={(value) => handleDriveChange(index, 'brand', value)}
                                    options={brandOptions}
                                    placeholder="Select brand..."
                                    creatable={false}
                                    className="mt-1"
                                />
                            </div>
                            <div className="col-span-1">
                                <Label className="text-sm font-medium text-gray-700">Capacity</Label>
                                <SearchableSelect
                                    value={drive.capacity || ''}
                                    onValueChange={(value) => handleDriveChange(index, 'capacity', value)}
                                    options={capacityOptions}
                                    placeholder="Select capacity..."
                                    creatable={false}
                                    className="mt-1"
                                />
                            </div>
                            <div className="col-span-1">
                                <Label className="text-sm font-medium text-gray-700">Interface</Label>
                                <Select value={drive.interface || 'SATA'} onValueChange={(val) => handleDriveChange(index, 'interface', val)}>
                                    <SelectTrigger className="mt-1">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="SATA">SATA</SelectItem>
                                        <SelectItem value="SAS">SAS</SelectItem>
                                        <SelectItem value="NVMe">NVMe</SelectItem>
                                        <SelectItem value="Other">Other</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="col-span-1">
                                <Button 
                                    variant="destructive" 
                                    size="icon" 
                                    onClick={() => handleRemoveDrive(index)}
                                    className="mt-6"
                                    title="Remove this drive"
                                >
                                    <Trash2 className="w-4 h-4" />
                                </Button>
                            </div>
                        </div>
                    ))}
                    
                    {drives.length === 0 && (
                        <div className="text-center py-8 text-gray-500">
                            <p className="mb-4">No drives added yet. Click the button below to add drives to this server.</p>
                        </div>
                    )}
                    
                    <Button variant="outline" className="w-full" onClick={handleAddDrive}>
                        <Plus className="w-4 h-4 mr-2" />
                        Add Another Drive
                    </Button>
                </div>
                <DialogFooter className="pt-4 border-t">
                    <Button variant="outline" onClick={() => onOpenChange(false)}>
                        Cancel
                    </Button>
                    <Button onClick={handleSaveChanges} className="bg-green-600 hover:bg-green-700">
                        Save Changes ({drives.length} drive{drives.length !== 1 ? 's' : ''})
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}