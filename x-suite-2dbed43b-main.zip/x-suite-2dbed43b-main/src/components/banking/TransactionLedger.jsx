import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { getDefaultLocale, formatCurrency } from '@/components/utils/currencyFormatter';

export default function TransactionLedger({ bank, ledgerData }) {
    const [locale, setLocale] = useState(null);

    useEffect(() => {
        const fetchLocale = async () => {
            const loc = await getDefaultLocale();
            setLocale(loc);
        };
        fetchLocale();
    }, []);

    if (!bank) return null;

    return (
        <Card className="shadow-lg">
            <CardHeader>
                <CardTitle>Transaction Ledger: {bank.bank_name}</CardTitle>
            </CardHeader>
            <CardContent>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Date</TableHead>
                            <TableHead>Type</TableHead>
                            <TableHead>Description</TableHead>
                            <TableHead className="text-right">Amount</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {ledgerData.length === 0 ? (
                            <TableRow>
                                <TableCell colSpan="4" className="text-center py-10">No transactions or expenses for this account.</TableCell>
                            </TableRow>
                        ) : (
                            ledgerData.map(item => (
                                <TableRow key={`${item.type}-${item.id}`}>
                                    <TableCell>{format(parseISO(item.transaction_date), 'dd MMM yyyy')}</TableCell>
                                    <TableCell>
                                        {item.type === 'income' ? (
                                            <span className="flex items-center text-green-600">
                                                <TrendingUp className="w-4 h-4 mr-2" /> Income
                                            </span>
                                        ) : (
                                            <span className="flex items-center text-red-600">
                                                <TrendingDown className="w-4 h-4 mr-2" /> Expense
                                            </span>
                                        )}
                                    </TableCell>
                                    <TableCell>{item.description || (item.type === 'income' ? `Payment for Invoice` : 'N/A')}</TableCell>
                                    <TableCell className={`text-right font-semibold ${item.type === 'income' ? 'text-green-700' : 'text-red-700'}`}>
                                        {locale ? formatCurrency(item.amount, locale) : '...'}
                                    </TableCell>
                                </TableRow>
                            ))
                        )}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
    );
}