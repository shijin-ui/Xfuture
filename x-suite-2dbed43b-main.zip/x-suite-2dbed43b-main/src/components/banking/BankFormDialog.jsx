import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Bank } from '@/api/entities';

export default function BankFormDialog({ isOpen, onClose, onSubmit, bank }) {
    const [formData, setFormData] = useState({
        bank_name: '',
        account_name: '',
        account_number: '',
        iban: '',
        currency: 'OMR',
        initial_balance: 0,
        is_active: true,
        notes: ''
    });
    const [isSaving, setIsSaving] = useState(false);

    useEffect(() => {
        if (bank) {
            setFormData({
                bank_name: bank.bank_name || '',
                account_name: bank.account_name || '',
                account_number: bank.account_number || '',
                iban: bank.iban || '',
                currency: bank.currency || 'OMR',
                initial_balance: bank.initial_balance || 0,
                is_active: bank.is_active !== undefined ? bank.is_active : true,
                notes: bank.notes || ''
            });
        } else {
            // Reset form for new entry
            setFormData({
                bank_name: '',
                account_name: '',
                account_number: '',
                iban: '',
                currency: 'OMR',
                initial_balance: 0,
                is_active: true,
                notes: ''
            });
        }
    }, [bank, isOpen]);

    const handleChange = (e) => {
        const { id, value } = e.target;
        setFormData(prev => ({ ...prev, [id]: value }));
    };
    
    const handleSwitchChange = (checked) => {
        setFormData(prev => ({ ...prev, is_active: checked }));
    };

    const handleSubmit = async () => {
        setIsSaving(true);
        try {
            if (bank && bank.id) {
                await Bank.update(bank.id, formData);
            } else {
                await Bank.create(formData);
            }
            onSubmit();
        } catch (error) {
            console.error("Failed to save bank account:", error);
            // Optionally, show an error message to the user
        } finally {
            setIsSaving(false);
        }
    };

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>{bank ? 'Edit Bank Account' : 'Add New Bank Account'}</DialogTitle>
                    <DialogDescription>
                        Fill in the details for the bank account.
                    </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="bank_name" className="text-right">Bank Name</Label>
                        <Input id="bank_name" value={formData.bank_name} onChange={handleChange} className="col-span-3" />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="account_name" className="text-right">Account Name</Label>
                        <Input id="account_name" value={formData.account_name} onChange={handleChange} className="col-span-3" />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="account_number" className="text-right">Account No.</Label>
                        <Input id="account_number" value={formData.account_number} onChange={handleChange} className="col-span-3" />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="iban" className="text-right">IBAN</Label>
                        <Input id="iban" value={formData.iban} onChange={handleChange} className="col-span-3" />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="initial_balance" className="text-right">Initial Balance</Label>
                        <Input id="initial_balance" type="number" value={formData.initial_balance} onChange={handleChange} className="col-span-3" />
                    </div>
                     <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="notes" className="text-right">Notes</Label>
                        <Textarea id="notes" value={formData.notes} onChange={handleChange} className="col-span-3" />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                        <Label htmlFor="is_active" className="text-right">Active</Label>
                        <Switch id="is_active" checked={formData.is_active} onCheckedChange={handleSwitchChange} />
                    </div>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={onClose}>Cancel</Button>
                    <Button onClick={handleSubmit} disabled={isSaving}>
                        {isSaving ? 'Saving...' : 'Save Account'}
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}